import React from 'react';
import './App.css';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './services/AuthContext';
import PrivateRoute from './services/PrivateRoute'
import Dashboard from './dashboard/Dashboard';
import Course from './dashboard/course/Course';
import CourseModule from './dashboard/coursemodule/CourseModule';
import CourseFee from './dashboard/coursefees/CourseFee';
import Enquiry from "./dashboard/enquiry/Enquiry";
import Registration from "./dashboard/registration/Registration";
import Billing from "./dashboard/billing/Billing";
import StaffAttendance from "./dashboard/staffattendance/StaffAttendance";
import StaffPay from "./dashboard/staffpay/Staffpay";
import StaffRegister from "./dashboard/staffregister/StaffRegister";
import StaffSchedule from "./dashboard/staffschedule/StaffSchedule";
import CalendarEvent from "./dashboard/calendar/Calendar";
import Department from "./dashboard/department/Department";
import Designation from "./dashboard/designation/Designation";
import ComingSoon from "./dashboard/ComingSoon";
import Sidebar from './dashboard/sidebar/Sidebar';
import Login from './authentication/Login';
import Navbar from './dashboard/sidebar/Navbar';
import './dashboard/theme/theme.css';

function App() {
  return (
    <Router>
      <AuthProvider>
        <div className="light-style layout-menu-fixed">
          <div className="layout-wrapper layout-content-navbar">
            <div className="layout-container">
              <Routes>
                <Route path="/" element={<Login />} />
                <Route path="/*" element={<ProtectedRoutes />} />
              </Routes>
            </div>
          </div>
        </div>
      </AuthProvider>
    </Router>
  );
}

function ProtectedRoutes() {
  return (
    <>
    
      <Sidebar />
      <div className="layout-page">
      <Navbar />
      <div className="content-wrapper">
      <Routes>
        <Route element={<PrivateRoute/>}>
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/course" element={<Course />} /> 
          <Route path="/coursemodule" element={<CourseModule />} />
          <Route path="/coursefees" element={<CourseFee />} />
          <Route path="/enquiry" element={<Enquiry />} />
          <Route path="/registration" element={<Registration />} />
          <Route path="/billing" element={<Billing />} />
          <Route path="/staffattendance" element={<StaffAttendance />} />
          <Route path="/staffpay" element={<StaffPay />} />
          <Route path="/staffregister" element={<StaffRegister />} />
          <Route path="/staffschedule" element={<StaffSchedule />} />
          <Route path="/calendarevent" element={<CalendarEvent />} />
          <Route path="/department" element={<Department />} />
          <Route path="/designation" element={<Designation />} />
          <Route path="*" element={<ComingSoon />} />
        </Route>
      </Routes>
      </div>
      </div>
    </>
  );
}


export default App;
