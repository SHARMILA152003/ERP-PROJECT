import React, { useState, useEffect, useRef, useContext } from "react";
import { createPortal } from "react-dom";
import AuthContext from "../../../services/AuthContext";
import "./addstaffregister.css";

// =====================================================
// TABS + FIELD DEFINITIONS
// Every field of every tab is described here once, so the
// Add page and the Edit page render the exact same form.
// =====================================================

const TAB_ICONS = {
    Personal: "bx-user",
    Professional: "bx-briefcase",
    Education: "bx-book",
    Bank: "bx-bank",
    Joining: "bx-calendar-check",
    Proof: "bx-id-card"
};

export const TABS = [
    "Personal",
    "Professional",
    "Education",
    "Bank",
    "Joining",
    "Proof"
];

const GENDERS = ["Male", "Female", "Other"];
const BLOOD_GROUPS = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"];
const MARITAL = ["Single", "Married", "Divorced", "Widowed"];
const STAFF_TYPES = ["Full Time", "Part Time", "Contract"];
const QUALIFICATIONS = [
    "10th", "12th", "Diploma", "B.E / B.Tech", "B.Sc", "BCA", "B.Com",
    "M.E / M.Tech", "M.Sc", "MCA", "MBA", "Ph.D", "Others"
];
const STATUSES = ["Active", "Deactive"];

// type: text | email | tel | date | select | textarea | file | readonly
// dynamic: true  -> select whose options are fetched (Department / Designation modules)
export const FIELDS = {

    Personal: [
        { name: "Staff_name", label: "Full Name", required: true, maxLength: 100 },
        { name: "Staff_father_name", label: "Father Name", required: true, maxLength: 100 },
        { name: "Staff_mother_name", label: "Mother Name", required: true, maxLength: 100 },
        { name: "Staff_dob", label: "Date of Birth", type: "date", required: true },
        { name: "Staff_age", label: "Age", type: "readonly" },
        { name: "Staff_gender", label: "Gender", type: "select", options: GENDERS, placeholder: "Select Gender", required: true },
        // Temporary address (shown first) + Permanent address.
        // Rendered together as one block by renderAddressBlock().
        { name: "Staff_temp_address", label: "Temporary Address Line 1", addr: "temp", required: true, maxLength: 255, placeholder: "Address Line 1" },
        { name: "Staff_temp_city", label: "Temporary City", addr: "temp", required: true, maxLength: 60, placeholder: "City" },
        { name: "Staff_temp_state", label: "Temporary State", addr: "temp", required: true, maxLength: 60, placeholder: "State" },
        { name: "Staff_temp_pincode", label: "Temporary Pincode", addr: "temp", required: true, maxLength: 6, placeholder: "Pincode" },
        { name: "Staff_perm_address", label: "Permanent Address Line 1", addr: "perm", required: true, maxLength: 255, placeholder: "Address Line 1" },
        { name: "Staff_perm_city", label: "Permanent City", addr: "perm", required: true, maxLength: 60, placeholder: "City" },
        { name: "Staff_perm_state", label: "Permanent State", addr: "perm", required: true, maxLength: 60, placeholder: "State" },
        { name: "Staff_perm_pincode", label: "Permanent Pincode", addr: "perm", required: true, maxLength: 6, placeholder: "Pincode" },
        { name: "Staff_mobile", label: "Mobile", type: "tel", required: true, maxLength: 10, placeholder: "10 digit mobile number" },
        { name: "Staff_email", label: "Email", type: "email", required: true, maxLength: 100, placeholder: "name@example.com" },
        { name: "Staff_blood_group", label: "Blood Group", type: "select", options: BLOOD_GROUPS, placeholder: "Select Blood Group", required: true },
        { name: "Staff_marital_status", label: "Marital Status", type: "select", options: MARITAL, placeholder: "Select Marital Status", required: true },
    ],

    Professional: [
        // Experience table (ExperienceSection) is drawn first; this total is
        // worked out from its rows, and typed by hand only when there are no rows.
        { name: "Staff_experience", label: "Total Experience (Years)", type: "text", maxLength: 4, placeholder: "e.g. 2.5" },
    ],

    // Education is a list of entries (LinkedIn style) - see EducationSection
    Education: [],

    Bank: [
        { name: "Staff_account_holder", label: "Account Holder Name", required: true, maxLength: 100 },
        { name: "Staff_bank_name", label: "Bank Name", required: true, maxLength: 100 },
        { name: "Staff_account_no", label: "Account Number", type: "tel", required: true, maxLength: 18 },
        { name: "Staff_ifsc", label: "IFSC Code", required: true, maxLength: 11, placeholder: "e.g. SBIN0001234" },
        { name: "Staff_branch", label: "Branch", required: true, maxLength: 100 },
    ],

    Joining: [
        { name: "Staff_joining_date", label: "Joining Date", type: "date", required: true },
        // Department and Designation are fetched from the Department / Designation modules.
        // Designation lists only the designations of the chosen department.
        { name: "Staff_department", label: "Department", type: "select", dynamic: true, placeholder: "Select Department", required: true },
        { name: "Staff_designation", label: "Designation", type: "select", dynamic: true, placeholder: "Select Designation", required: true },
        { name: "Staff_type", label: "Staff Type", type: "select", options: STAFF_TYPES, placeholder: "Select Staff Type", required: true },
        { name: "Staff_salary", label: "Salary (Monthly)", type: "tel", required: true, maxLength: 9 },
        { name: "Staff_Status", label: "Status", type: "select", options: STATUSES, placeholder: "Select Status", required: true },
    ],

    Proof: [
        { name: "Staff_aadhaar_no", label: "Aadhaar Number", type: "tel", required: true, maxLength: 12 },
        { name: "Staff_pan_no", label: "PAN Number", required: true, maxLength: 10, placeholder: "e.g. ABCDE1234F" },
        { name: "Staff_id_proof", label: "ID Proof (Aadhaar / PAN)", type: "file", third: true },
        { name: "Staff_address_proof", label: "Address Proof", type: "file", third: true },
        { name: "Staff_resume", label: "Resume", type: "file", third: true, dropText: "Drag and drop resume here" },
        // Education certificates: one box per qualification entered in the Education tab
        // (shown only when that qualification has data - see eduProofTypes)
        { name: "Staff_10th_proof", label: "10th Marksheet / Certificate", type: "file", third: true, eduQual: "10th", dropText: "Drag and drop 10th certificate here" },
        { name: "Staff_12th_proof", label: "12th Marksheet / Certificate", type: "file", third: true, eduQual: "12th", dropText: "Drag and drop 12th certificate here" },
        { name: "Staff_diploma_proof", label: "Diploma Certificate", type: "file", third: true, eduQual: "Diploma", dropText: "Drag and drop diploma certificate here" },
        { name: "Staff_ug_proof", label: "UG Degree Certificate", type: "file", third: true, eduQual: "UG", dropText: "Drag and drop UG certificate here" },
        { name: "Staff_pg_proof", label: "PG Degree Certificate", type: "file", third: true, eduQual: "PG", dropText: "Drag and drop PG certificate here" },
        { name: "Staff_phd_proof", label: "Ph.D Certificate", type: "file", third: true, eduQual: "Ph.D", dropText: "Drag and drop Ph.D certificate here" },
        { name: "Staff_others_proof", label: "Other Certificate", type: "file", third: true, eduQual: "Others", dropText: "Drag and drop certificate here" },
    ],
};

export const emptyStaff = () => {

    const values = { Staff_photo: null, Staff_education: [], Staff_bank_accounts: [], Staff_experience_details: [], Staff_skills: "" };

    TABS.forEach((tab) => {
        FIELDS[tab].forEach((f) => {
            values[f.name] = f.type === "file" ? null : "";
        });
    });

    values.Staff_same_address = "No";

    return values;
};


// every file upload field (photo + proofs) - saved files come back as URL strings
export const FILE_FIELD_NAMES = [
    "Staff_photo",
    ...Object.values(FIELDS).flat().filter((f) => f.type === "file").map((f) => f.name)
];

// =====================================================
// HELPERS
// =====================================================

const calcAge = (dob) => {

    if (!dob) return "";

    const birth = new Date(dob);

    if (Number.isNaN(birth.getTime())) return "";

    const today = new Date();

    let age = today.getFullYear() - birth.getFullYear();

    const m = today.getMonth() - birth.getMonth();

    if (m < 0 || (m === 0 && today.getDate() < birth.getDate())) age--;

    return age >= 0 ? String(age) : "";
};

// Only digits allowed in these fields
const DIGIT_FIELDS = [
    "Staff_mobile", "Staff_account_no", "Staff_aadhaar_no",
    "Staff_passing_year", "Staff_salary",
    "Staff_temp_pincode", "Staff_perm_pincode"
];

// Person-name fields: letters, space and ONE dot only (no hyphen, no apostrophe)
const PERSON_NAME_FIELDS = ["Staff_name", "Staff_father_name", "Staff_mother_name"];

const sanitizePersonName = (value) => {

    let text = String(value || "")
        .replace(/[^A-Za-z .]/g, "")       // blocks digits, hyphen, apostrophe and symbols
        .replace(/^[\s.]+/, "")             // cannot start with space or dot
        .replace(/\s{2,}/g, " ");           // single spaces only

    // keep only the first dot
    let dotSeen = false;

    text = text.replace(/\./g, () => {
        if (dotSeen) return "";
        dotSeen = true;
        return ".";
    });

    return text;
};

// Bank tab
// Account Holder Name: letters, space and ONE dot (no numbers / special characters)
const sanitizeHolderName = (value) => sanitizePersonName(value);

// Bank Name: letters, space, "." and "&" only (no numbers / other special characters)
const sanitizeBankName = (value) =>
    String(value || "")
        .replace(/[^A-Za-z .&]/g, "")
        .replace(/^[^A-Za-z]+/, "")          // must start with a letter
        .replace(/([.&])\1+/g, "$1")         // no repeated .. &&
        .replace(/\s{2,}/g, " ");

// Branch: letters, numbers, space and . , - ( ) & only
// (blocks = _ + / < > \ " ; ' ] [ { } and other symbols)
const sanitizeBranch = (value) =>
    String(value || "")
        .replace(/[^A-Za-z0-9 .,()&-]/g, "")
        .replace(/^[^A-Za-z0-9]+/, "")       // must start with a letter or number
        .replace(/([.,&-])\1+/g, "$1")
        .replace(/\s{2,}/g, " ");

const BANK_NAME_PATTERN = /^[A-Za-z .&]+$/;
const BRANCH_PATTERN = /^[A-Za-z0-9 .,()&-]+$/;

// Upper-case fields
const UPPER_FIELDS = ["Staff_ifsc", "Staff_pan_no"];

const norm = (v) => String(v || "").replace(/\s+/g, "").toLowerCase();

const fileLabel = (v) => {

    if (!v) return "";

    if (typeof v === "string") return v.split("/").pop();

    return v.name;
};

const MAX_FILE_MB = 2;


// =====================================================
// VALIDATION (one place — used while typing and on submit)
// =====================================================

export const validateField = (name, value, all, existingStaff, currentId) => {

    const v = typeof value === "string" ? value.trim() : value;

    const def = Object.values(FIELDS)
        .flat()
        .find((f) => f.name === name);

    if (!def) return "";

    if (def.type === "file") {

        if (value && typeof value !== "string") {

            if (value.size > MAX_FILE_MB * 1024 * 1024)
                return `File must be smaller than ${MAX_FILE_MB} MB.`;
        }

        return "";
    }

    // Permanent address is not needed when it is the same as the temporary one
    if (def.addr === "perm" && all && all.Staff_same_address === "Yes") return "";

    if (!v) return def.required ? `${def.label} is required.` : "";

    const others = (existingStaff || []).filter(
        (s) => Number(s.Staff_id) !== Number(currentId)
    );

    switch (name) {

        case "Staff_name":
        case "Staff_father_name":
        case "Staff_mother_name":
            if (v.length < 2) return `${def.label} must contain at least 2 characters.`;
            if (/-/.test(v)) return `${def.label} cannot contain a hyphen (-).`;
            if ((v.match(/\./g) || []).length > 1) return `${def.label} can contain only one dot (.).`;
            if (/'/.test(v)) return `${def.label} cannot contain an apostrophe (').`;
            if (!/^[A-Za-z .]+$/.test(v)) return `${def.label} can contain letters, space and one dot only.`;
            return "";

        case "Staff_account_holder":
            if (v.length < 2) return `${def.label} must contain at least 2 characters.`;
            if ((v.match(/\./g) || []).length > 1) return `${def.label} can contain only one dot (.).`;
            if (!/^[A-Za-z .]+$/.test(v)) return `${def.label} cannot contain numbers or special characters.`;
            return "";

        case "Staff_bank_name":
            if (v.length < 2) return `${def.label} must contain at least 2 characters.`;
            if (!/[A-Za-z]/.test(v) || !BANK_NAME_PATTERN.test(v))
                return `${def.label} cannot contain numbers or special characters.`;
            return "";

        case "Staff_branch":
            if (!BRANCH_PATTERN.test(v))
                return `${def.label} cannot contain = _ + / < > \\ " ; ' [ ] { } or other special characters.`;
            return "";

        case "Staff_temp_address":
        case "Staff_perm_address":
            if (v.length < 5) return `${def.label} must contain at least 5 characters.`;
            return "";

        case "Staff_temp_city":
        case "Staff_perm_city":
        case "Staff_temp_state":
        case "Staff_perm_state":
            if (!/^[A-Za-z .'-]+$/.test(v)) return `${def.label} can contain letters only.`;
            return "";

        case "Staff_temp_pincode":
        case "Staff_perm_pincode":
            if (!/^[1-9]\d{5}$/.test(v)) return "Enter a valid 6 digit pincode.";
            return "";

        case "Staff_dob": {
            const age = Number(calcAge(v));
            if (calcAge(v) === "") return "Enter a valid date of birth.";
            if (age < 18) return "Staff must be at least 18 years old.";
            if (age > 70) return "Please check the date of birth.";
            return "";
        }

        case "Staff_mobile":
            if (!/^[6-9]\d{9}$/.test(v)) return "Enter a valid 10 digit mobile number.";
            if (others.some((s) => String(s.Staff_mobile) === v))
                return `Mobile number ${v} is already registered.`;
            return "";

        case "Staff_email":
            if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v)) return "Enter a valid email address.";
            if (others.some((s) => norm(s.Staff_email) === norm(v)))
                return `Email ${v} is already registered.`;
            return "";

        case "Staff_experience":
            if (!/^\d{1,2}(\.\d)?$/.test(v)) return "Enter experience in years, e.g. 2 or 2.5.";
            return "";

        case "Staff_passing_year": {
            const y = Number(v);
            if (!/^\d{4}$/.test(v) || y < 1970 || y > new Date().getFullYear())
                return "Enter a valid year of passing.";
            return "";
        }

        case "Staff_percentage":
            if (!/^\d{1,3}(\.\d{1,2})?$/.test(v) || Number(v) > 100)
                return "Enter a valid percentage / CGPA.";
            return "";

        case "Staff_account_no":
            if (!/^\d{9,18}$/.test(v)) return "Account number must be 9 to 18 digits.";
            if (others.some((s) => String(s.Staff_account_no) === v))
                return "This account number is already registered.";
            return "";

        case "Staff_ifsc":
            if (!/^[A-Z]{4}0[A-Z0-9]{6}$/.test(v)) return "Enter a valid IFSC code, e.g. SBIN0001234.";
            return "";

        case "Staff_joining_date":
            return "";

        case "Staff_salary":
            if (!/^\d+$/.test(v)) return "Salary must be a number.";
            if (Number(v) <= 0) return "Salary must be greater than 0.";
            return "";

        case "Staff_aadhaar_no":
            if (!/^\d{12}$/.test(v)) return "Aadhaar number must be 12 digits.";
            if (others.some((s) => String(s.Staff_aadhaar_no) === v))
                return "This Aadhaar number is already registered.";
            return "";

        case "Staff_pan_no":
            if (!/^[A-Z]{5}\d{4}[A-Z]$/.test(v)) return "Enter a valid PAN, e.g. ABCDE1234F.";
            return "";

        default:
            return "";
    }
};




// =====================================================
// EDUCATION TABLE (bordered table, one row per qualification)
// S.No | Qualification | School/Institute | Board | Percentage | YOP |
// Degree | Department | Actions.  10th and 12th rows are fixed (Degree and
// Department are "-"); the 2nd row is a 12th / Diploma dropdown (Diploma
// enables Degree and Department); other rows pick UG / PG / ... Stored as an array in
// values.Staff_education and sent to Django as a JSON string.
// =====================================================

const MAX_EDU_ROWS = 10;

const QUAL_OPTIONS = ["UG", "PG", "Diploma", "Ph.D", "Others"];

// 2nd row: after 10th the staff did either 12th or a Diploma
const SCHOOL_QUAL_OPTIONS = ["12th", "Diploma"];

// first two rows are always there (cleared instead of deleted)
const FIXED_ROWS = 2;

// 10th / 12th have no Degree and Department ("-")
const NO_DEGREE_QUALS = ["10th", "12th"];

const isFixedQual = (q) => NO_DEGREE_QUALS.includes(q);

// typed fields of a row (the qualification itself is not "data")
const EDU_DATA_KEYS = ["school", "board", "percentage", "yop", "degree", "department"];

const emptyEducation = (qualification = "") => ({
    qualification,
    school: "", board: "", percentage: "", yop: "", degree: "", department: ""
});

// 10th, 12th and one UG row for a new staff
const defaultEducation = () => [
    emptyEducation("10th"),
    emptyEducation("12th"),
    emptyEducation("UG")
];

const text = (v) => (v === null || v === undefined ? "" : String(v));

// also understands the earlier format (grade / end_year / field)
const normalizeEdu = (e) => ({
    qualification: text(e.qualification),
    school: text(e.school),
    board: text(e.board),
    percentage: text(e.percentage !== undefined ? e.percentage : e.grade),
    yop: text(e.yop !== undefined ? e.yop : e.end_year),
    degree: text(e.degree),
    department: text(e.department !== undefined ? e.department : e.field)
});

// Value that can come from Django as a JSON string, an array,
// or (older records) only the single-qualification columns
export const parseEducation = (raw, legacy = {}) => {

    let list = [];

    if (Array.isArray(raw)) {
        list = raw;
    } else if (typeof raw === "string" && raw.trim()) {
        try {
            const parsed = JSON.parse(raw);
            if (Array.isArray(parsed)) list = parsed;
        } catch (e) {
            list = [];
        }
    }

    if (list.length > 0) return list.map(normalizeEdu);

    if (legacy.Staff_institution) {
        return [{
            ...emptyEducation(),
            school: text(legacy.Staff_institution),
            degree: text(legacy.Staff_qualification),
            department: text(legacy.Staff_specialization),
            yop: text(legacy.Staff_passing_year),
            percentage: text(legacy.Staff_percentage)
        }];
    }

    return defaultEducation();
};

// true when nothing is typed in the row
const isBlankEdu = (e) =>
    EDU_DATA_KEYS.every((k) => !text(e[k]).trim());

// Highest qualification (then latest year) fills the old single columns,
// so the existing list / backend fields keep working
const latestEducation = (list) => {

    const level = { "10th": 1, "12th": 2, Diploma: 3, Others: 3, UG: 4, PG: 5, "Ph.D": 6 };

    const score = (e) => (level[e.qualification] || 3) * 10000 + Number(e.yop || 0);

    return [...list].sort((a, b) => score(b) - score(a))[0];
};

// School / Institute and Board / University:
// letters, space and . , & ( ) only  (no numbers, hyphen, apostrophe or other symbols)
const sanitizeInstitution = (value) =>
    String(value || "")
        .replace(/[^A-Za-z .,&()]/g, "")      // blocks numbers - ' [ ] \ ; / etc.
        .replace(/^[^A-Za-z]+/, "")            // must start with a letter
        .replace(/([.,&])\1+/g, "$1")          // no repeated ... ,, &&
        .replace(/\s{2,}/g, " ");             // single spaces only

// Percentage: digits and ONE dot, up to 2 decimals, never above 100
const sanitizePercentage = (value) => {

    let v = String(value || "").replace(/[^0-9.]/g, "").replace(/^\.+/, "");

    const firstDot = v.indexOf(".");

    if (firstDot !== -1)
        v = v.slice(0, firstDot + 1) + v.slice(firstDot + 1).replace(/\./g, "").slice(0, 2);

    if (Number(v) > 100) v = v.slice(0, -1);

    return v;
};

const INSTITUTION_PATTERN = /^[A-Za-z .,&()]+$/;

const validateEducation = (e) => {

    const found = {};

    const school = text(e.school).trim();
    const board = text(e.board).trim();
    const pct = text(e.percentage).trim();
    const yop = text(e.yop).trim();

    if (!school) found.school = "School/Institute Name is required.";
    else if (school.length < 3) found.school = "School/Institute Name must contain at least 3 characters.";
    else if (!/[A-Za-z]/.test(school)) found.school = "School/Institute Name must contain letters.";
    else if (!INSTITUTION_PATTERN.test(school))
        found.school = "School/Institute Name cannot contain numbers, - ' or special characters.";

    if (board) {
        if (!/[A-Za-z]/.test(board)) found.board = "Board/University must contain letters.";
        else if (!INSTITUTION_PATTERN.test(board))
            found.board = "Board/University cannot contain numbers, - ' or special characters.";
    }

    if (pct && (!/^\d{1,3}(\.\d{1,2})?$/.test(pct) || Number(pct) > 100))
        found.percentage = "Percentage must be between 0 and 100.";

    if (yop) {

        const y = Number(yop);

        if (!/^\d{4}$/.test(yop) || y < 1950 || y > new Date().getFullYear() + 6)
            found.yop = "Enter a valid year of passing (YOP).";
    }

    return found;
};

// First problem of the filled rows, e.g. "Row 2: School/Institute Name is required."
const educationRowError = (list) => {

    for (let i = 0; i < list.length; i++) {

        if (isBlankEdu(list[i])) continue;

        const msg = Object.values(validateEducation(list[i]))[0];

        if (msg) return `Row ${i + 1}: ${msg}`;
    }

    return "";
};

// Rows without any data are not saved
const cleanEducation = (list) =>
    list
        .filter((e) => !isBlankEdu(e))
        .map((e) => {
            const clean = { qualification: text(e.qualification).trim() };
            EDU_DATA_KEYS.forEach((k) => {
                clean[k] = text(e[k]).trim();
            });
            return clean;
        });

// Qualifications that have data in the Education table (10th, 12th, Diploma, UG, PG, Ph.D, Others)
// -> these get a certificate upload box on the Proof tab
const EDU_PROOF_QUALS = ["10th", "12th", "Diploma", "UG", "PG", "Ph.D", "Others"];

const eduProofTypes = (list) =>
    EDU_PROOF_QUALS.filter((q) =>
        (list || []).some((e) => e.qualification === q && !isBlankEdu(e))
    );

// =====================================================
// YEAR PICKER (YOP column)
// Click the field -> 12-year grid (e.g. 2016 - 2027), arrows change the
// 12-year block, "Clear" empties and "This year" picks the current year.
// The popup is drawn on <body> so the scrolling table does not clip it.
// =====================================================

const YOP_MIN = 1950;
const YOP_MAX = new Date().getFullYear() + 6;   // same limit as validateEducation

const blockStart = (y) => y - (y % 12);

const YearPicker = ({ value, onChange, invalid, ariaLabel }) => {

    const thisYear = new Date().getFullYear();
    const selected = /^\d{4}$/.test(text(value)) ? Number(value) : null;

    const [open, setOpen] = useState(false);
    const [start, setStart] = useState(blockStart(selected || thisYear));
    const [pos, setPos] = useState({ top: 0, left: 0 });

    const btnRef = useRef(null);
    const popRef = useRef(null);

    const place = () => {

        const r = btnRef.current.getBoundingClientRect();
        const w = 280, h = 330;

        let left = Math.min(r.left, window.innerWidth - w - 8);
        let top = r.bottom + 6;

        // not enough room below -> open above the field
        if (top + h > window.innerHeight && r.top - h - 6 > 0) top = r.top - h - 6;

        setPos({ top, left: Math.max(8, left) });
    };

    const toggle = () => {

        if (!open) {
            setStart(blockStart(selected || thisYear));
            place();
        }

        setOpen(!open);
    };

    useEffect(() => {

        if (!open) return undefined;

        const outside = (e) => {
            if (popRef.current && popRef.current.contains(e.target)) return;
            if (btnRef.current && btnRef.current.contains(e.target)) return;
            setOpen(false);
        };

        const key = (e) => {
            if (e.key === "Escape") {
                setOpen(false);
                if (btnRef.current) btnRef.current.focus();
            }
        };

        window.addEventListener("resize", place);
        window.addEventListener("scroll", place, true);
        document.addEventListener("mousedown", outside);
        document.addEventListener("keydown", key);

        return () => {
            window.removeEventListener("resize", place);
            window.removeEventListener("scroll", place, true);
            document.removeEventListener("mousedown", outside);
            document.removeEventListener("keydown", key);
        };
    }, [open]);

    const pick = (y) => {
        onChange(String(y));
        setOpen(false);
    };

    const years = Array.from({ length: 12 }, (_, k) => start + k);

    return (
        <>
            <button
                type="button"
                ref={btnRef}
                className={"form-control staff-yp-input" + (invalid ? " is-invalid" : "")}
                aria-label={ariaLabel}
                aria-haspopup="dialog"
                aria-expanded={open}
                onClick={toggle}
            >
                <span className={selected ? "" : "staff-yp-ph"}>{selected || "Year"}</span>
                <i className="bx bx-calendar"></i>
            </button>

            {open && createPortal(
                <div
                    ref={popRef}
                    className="staff-yp-pop"
                    style={{ top: pos.top, left: pos.left }}
                    role="dialog"
                    aria-label="Select year"
                >
                    <div className="staff-yp-head">
                        <button type="button" className="staff-yp-nav" aria-label="Previous years"
                            disabled={start - 12 + 11 < YOP_MIN}
                            onClick={() => setStart(start - 12)}>
                            <i className="bx bx-chevron-left"></i>
                        </button>

                        <span className="staff-yp-range">{start} – {start + 11}</span>

                        <button type="button" className="staff-yp-nav" aria-label="Next years"
                            disabled={start + 12 > YOP_MAX}
                            onClick={() => setStart(start + 12)}>
                            <i className="bx bx-chevron-right"></i>
                        </button>
                    </div>

                    <div className="staff-yp-grid">
                        {years.map((y) => (
                            <button
                                type="button"
                                key={y}
                                className={"staff-yp-year" + (y === selected ? " is-selected" : "")}
                                disabled={y < YOP_MIN || y > YOP_MAX}
                                onClick={() => pick(y)}
                            >
                                {y}
                            </button>
                        ))}
                    </div>

                    <div className="staff-yp-foot">
                        <button type="button" onClick={() => { onChange(""); setOpen(false); }}>Clear</button>
                        <button type="button" onClick={() => pick(thisYear)}>This year</button>
                    </div>
                </div>,
                document.body
            )}
        </>
    );
};

const EducationSection = ({ entries, error, onChange }) => {

    // row problems are shown after the first failed Next / Save
    const [showErrs, setShowErrs] = useState(false);

    useEffect(() => {
        if (error) setShowErrs(true);
    }, [error]);

    // there are always rows to type in
    const rows = entries.length > 0 ? entries : defaultEducation();

    const setCell = (index, name, value) =>
        onChange(rows.map((r, i) => (i === index ? { ...r, [name]: value } : r)));

    const addRow = () => {

        if (rows.length >= MAX_EDU_ROWS) return;

        onChange([...rows, emptyEducation("UG")]);
    };

    // 10th and the 12th / Diploma row are cleared, other rows are deleted
    const removeRow = (index) => {

        if (index < FIXED_ROWS) {
            // the 12th / Diploma row goes back to 12th
            const q = index === 0 ? "10th" : "12th";
            onChange(rows.map((x, i) => (i === index ? emptyEducation(q) : x)));
        } else {
            onChange(rows.filter((_, i) => i !== index));
        }
    };

    return (
        <div
            className="col-12 staff-eq-wrap"
            onKeyDown={(e) => {
                // Enter must not move / submit the whole staff form
                if (e.key === "Enter" && e.target.tagName === "INPUT")
                    e.preventDefault();
            }}
        >

            <div className={"staff-eq-scroll" + (error ? " is-invalid" : "")}>

                <table className="staff-eq-table">

                    <thead>
                        <tr>
                            <th className="c-no">S.No</th>
                            <th className="c-qual">Qualification</th>
                            <th className="c-school">School/Institute Name</th>
                            <th className="c-board">Board/University</th>
                            <th className="c-pct">Percentage</th>
                            <th className="c-yop">YOP</th>
                            <th className="c-degree">Degree</th>
                            <th className="c-dept">Department</th>
                            <th className="c-act">Actions</th>
                        </tr>
                    </thead>

                    <tbody>

                        {rows.map((r, i) => {

                            // 10th / 12th: Degree and Department are "-"
                            const fixed = isFixedQual(r.qualification);

                            // 1st row: 10th (locked), 2nd row: 12th / Diploma dropdown
                            const lockedQual = i === 0 && r.qualification === "10th";
                            const qualOptions = i === 1 ? SCHOOL_QUAL_OPTIONS : QUAL_OPTIONS;

                            const re = showErrs && !isBlankEdu(r) ? validateEducation(r) : {};

                            const msg = Object.values(re)[0];

                            const input = (name, extra = {}) => (
                                <input
                                    className={"form-control" + (re[name] ? " is-invalid" : "")}
                                    aria-label={`${name} ${i + 1}`}
                                    value={r[name]}
                                    onChange={(e) => setCell(i, name, e.target.value)}
                                    {...extra}
                                />
                            );

                            return (
                                <React.Fragment key={i}>

                                    <tr>

                                        <td className="staff-eq-no">{i + 1}</td>

                                        <td>
                                            {lockedQual ? (
                                                <input
                                                    className="form-control"
                                                    aria-label={`Qualification ${i + 1}`}
                                                    value={r.qualification}
                                                    disabled
                                                    readOnly
                                                />
                                            ) : (
                                                <select
                                                    className="form-select"
                                                    aria-label={`Qualification ${i + 1}`}
                                                    value={r.qualification}
                                                    onChange={(e) => {
                                                        const q = e.target.value;
                                                        // 12th has no Degree / Department
                                                        onChange(rows.map((x, k) =>
                                                            k === i
                                                                ? {
                                                                    ...x,
                                                                    qualification: q,
                                                                    ...(isFixedQual(q) ? { degree: "", department: "" } : {})
                                                                }
                                                                : x
                                                        ));
                                                    }}
                                                >
                                                    <option value="">Select</option>
                                                    {r.qualification && !qualOptions.includes(r.qualification) && (
                                                        <option value={r.qualification}>{r.qualification}</option>
                                                    )}
                                                    {qualOptions.map((q) => (
                                                        <option key={q} value={q}>{q}</option>
                                                    ))}
                                                </select>
                                            )}
                                        </td>

                                        <td>{input("school", {
                                            maxLength: 150,
                                            onChange: (e) => setCell(i, "school", sanitizeInstitution(e.target.value))
                                        })}</td>

                                        <td>{input("board", { maxLength: 100, onChange: (e) => setCell(i, "board", sanitizeInstitution(e.target.value)), placeholder: r.qualification === "UG" || r.qualification === "PG" || r.qualification === "Ph.D" || r.qualification === "Diploma" ? "e.g. Anna University" : "e.g. State Board" })}</td>

                                        <td>
                                            {input("percentage", {
                                                maxLength: 6,
                                                inputMode: "decimal",
                                                onChange: (e) =>
                                                    setCell(i, "percentage", sanitizePercentage(e.target.value))
                                            })}
                                        </td>

                                        <td>
                                            <YearPicker
                                                value={r.yop}
                                                invalid={!!re.yop}
                                                ariaLabel={`yop ${i + 1}`}
                                                onChange={(v) => setCell(i, "yop", v)}
                                            />
                                        </td>

                                        <td>
                                            {fixed ? (
                                                <input
                                                    className="form-control"
                                                    aria-label={`Degree ${i + 1}`}
                                                    value="-"
                                                    disabled
                                                    readOnly
                                                />
                                            ) : input("degree", { maxLength: 100 })}
                                        </td>

                                        <td>
                                            {fixed ? (
                                                <input
                                                    className="form-control"
                                                    aria-label={`Department ${i + 1}`}
                                                    value="-"
                                                    disabled
                                                    readOnly
                                                />
                                            ) : input("department", { maxLength: 100 })}
                                        </td>

                                        <td className="staff-eq-actions">
                                            <button
                                                type="button"
                                                className="staff-eq-icon is-add"
                                                title="Add qualification"
                                                aria-label="Add qualification"
                                                disabled={rows.length >= MAX_EDU_ROWS}
                                                onClick={addRow}
                                            >
                                                <i className="bx bx-plus"></i>
                                            </button>
                                            <button
                                                type="button"
                                                className="staff-eq-icon is-remove"
                                                title={i < FIXED_ROWS ? "Clear this row" : "Remove this row"}
                                                aria-label={i < FIXED_ROWS ? "Clear this row" : "Remove this row"}
                                                disabled={i < FIXED_ROWS && isBlankEdu(r) && (i === 0 || r.qualification === "12th")}
                                                onClick={() => removeRow(i)}
                                            >
                                                <i className="bx bx-minus"></i>
                                            </button>
                                        </td>

                                    </tr>

                                    {msg && (
                                        <tr className="staff-eq-errrow">
                                            <td colSpan={9}>Row {i + 1}: {msg}</td>
                                        </tr>
                                    )}

                                </React.Fragment>
                            );
                        })}

                    </tbody>

                </table>

            </div>

            {error && (
                <div className="invalid-feedback d-block">{error}</div>
            )}

            <button
                type="button"
                className="staff-eq-add"
                disabled={rows.length >= MAX_EDU_ROWS}
                onClick={addRow}
            >
                + Add Qualification
            </button>

        </div>
    );
};


// =====================================================
// EXPERIENCE (Professional tab)
// S.No | Organisation Name | From Year | To Year | Designation | Actions
// Stored as an array in values.Staff_experience_details and sent to Django
// as a JSON string. Total experience is worked out from the years (a blank
// To Year means "still working", i.e. up to this year). Skills are kept as
// one comma separated string in Staff_skills.
// =====================================================

const MAX_EXP_ROWS = 10;
const EXP_KEYS = ["organisation", "from_year", "to_year", "designation"];
const SKILLS_MAX = 255;

const emptyExperience = () => ({ organisation: "", from_year: "", to_year: "", designation: "" });

const isBlankExp = (e) => EXP_KEYS.every((k) => !text(e[k]).trim());

// JSON string / array from Django, or nothing
export const parseExperience = (raw) => {

    let list = [];

    if (Array.isArray(raw)) {
        list = raw;
    } else if (typeof raw === "string" && raw.trim()) {
        try {
            const parsed = JSON.parse(raw);
            if (Array.isArray(parsed)) list = parsed;
        } catch (e) {
            list = [];
        }
    }

    list = list.map((e) => ({
        organisation: text(e.organisation),
        from_year: text(e.from_year),
        to_year: text(e.to_year),
        designation: text(e.designation)
    }));

    return list.length > 0 ? list : [emptyExperience()];
};

const cleanExperience = (list) =>
    list
        .filter((e) => !isBlankExp(e))
        .map((e) => {
            const c = {};
            EXP_KEYS.forEach((k) => { c[k] = text(e[k]).trim(); });
            return c;
        });

// problems of one row
const validateExperience = (e) => {

    const found = {};
    const thisYear = new Date().getFullYear();

    const org = text(e.organisation).trim();
    const from = text(e.from_year).trim();
    const to = text(e.to_year).trim();

    if (!org) found.organisation = "Organisation Name is required.";
    else if (org.length < 2) found.organisation = "Organisation Name is too short.";

    if (!/^\d{4}$/.test(from)) found.from_year = "Select the From Year.";
    else if (Number(from) < YOP_MIN || Number(from) > thisYear)
        found.from_year = `From Year must be between ${YOP_MIN} and ${thisYear}.`;

    if (to) {
        if (!/^\d{4}$/.test(to)) found.to_year = "Select a valid To Year.";
        else if (Number(to) > thisYear) found.to_year = `To Year cannot be after ${thisYear}.`;
        else if (!found.from_year && Number(to) < Number(from))
            found.to_year = "To Year cannot be before From Year.";
    }

    return found;
};

const experienceRowError = (list) => {

    for (let i = 0; i < list.length; i++) {

        if (isBlankExp(list[i])) continue;

        const msg = Object.values(validateExperience(list[i]))[0];

        if (msg) return `Experience row ${i + 1}: ${msg}`;
    }

    return "";
};

// Total years over all valid rows; overlapping years are counted once.
// Returns null when there is no usable row (the field is then typed by hand).
export const computeExperienceTotal = (list) => {

    const thisYear = new Date().getFullYear();

    const spans = list
        .filter((e) => !isBlankExp(e) && Object.keys(validateExperience(e)).length === 0)
        .map((e) => [Number(e.from_year), e.to_year ? Number(e.to_year) : thisYear])
        .sort((a, b) => a[0] - b[0]);

    if (spans.length === 0) return null;

    let total = 0;
    let [curFrom, curTo] = spans[0];

    for (let i = 1; i < spans.length; i++) {

        const [f, t] = spans[i];

        if (f <= curTo) {
            curTo = Math.max(curTo, t);
        } else {
            total += curTo - curFrom;
            curFrom = f;
            curTo = t;
        }
    }

    return total + (curTo - curFrom);
};

// most recent organisation (still working > latest To Year > latest From Year)
const latestOrganisation = (list) => {

    const score = (e) =>
        (e.to_year ? Number(e.to_year) : 9999) * 10000 + Number(e.from_year || 0);

    const sorted = [...list].sort((a, b) => score(b) - score(a));

    return sorted.length > 0 ? sorted[0].organisation : "";
};

const ExperienceSection = ({ entries, error, onChange }) => {

    // row problems are shown after the first failed Next / Save
    const [showErrs, setShowErrs] = useState(false);

    useEffect(() => {
        if (error) setShowErrs(true);
    }, [error]);

    // there is always a row to type in
    const rows = entries.length > 0 ? entries : [emptyExperience()];

    const setCell = (index, name, value) =>
        onChange(rows.map((r, i) => (i === index ? { ...r, [name]: value } : r)));

    const addRow = () => {
        if (rows.length >= MAX_EXP_ROWS) return;
        onChange([...rows, emptyExperience()]);
    };

    // the last remaining row is cleared instead of deleted
    const removeRow = (index) => {
        if (rows.length === 1) onChange([emptyExperience()]);
        else onChange(rows.filter((_, i) => i !== index));
    };

    return (
        <div
            className="col-12 staff-eq-wrap"
            onKeyDown={(e) => {
                // Enter must not move / submit the whole staff form
                if (e.key === "Enter" && e.target.tagName === "INPUT")
                    e.preventDefault();
            }}
        >

            <div className={"staff-eq-scroll" + (error ? " is-invalid" : "")}>

                <table className="staff-eq-table staff-exp-table">

                    <thead>
                        <tr>
                            <th className="c-no">S.No</th>
                            <th className="c-org">Organisation Name</th>
                            <th className="c-from">From Year</th>
                            <th className="c-to">To Year</th>
                            <th className="c-desg">Designation</th>
                            <th className="c-act">Actions</th>
                        </tr>
                    </thead>

                    <tbody>

                        {rows.map((r, i) => {

                            const re = showErrs && !isBlankExp(r) ? validateExperience(r) : {};

                            const msg = Object.values(re)[0];

                            const input = (name, extra = {}) => (
                                <input
                                    className={"form-control" + (re[name] ? " is-invalid" : "")}
                                    aria-label={`${name} ${i + 1}`}
                                    value={r[name]}
                                    onChange={(e) => setCell(i, name, e.target.value)}
                                    {...extra}
                                />
                            );

                            return (
                                <React.Fragment key={i}>

                                    <tr>

                                        <td className="staff-eq-no">{i + 1}</td>

                                        <td>{input("organisation", { maxLength: 150 })}</td>

                                        <td>
                                            <YearPicker
                                                value={r.from_year}
                                                invalid={!!re.from_year}
                                                ariaLabel={`from year ${i + 1}`}
                                                onChange={(v) => setCell(i, "from_year", v)}
                                            />
                                        </td>

                                        <td>
                                            <YearPicker
                                                value={r.to_year}
                                                invalid={!!re.to_year}
                                                ariaLabel={`to year ${i + 1}`}
                                                onChange={(v) => setCell(i, "to_year", v)}
                                            />
                                        </td>

                                        <td>{input("designation", { maxLength: 100 })}</td>

                                        <td className="staff-eq-actions">
                                            <button
                                                type="button"
                                                className="staff-eq-icon is-add"
                                                title="Add experience"
                                                aria-label="Add experience"
                                                disabled={rows.length >= MAX_EXP_ROWS}
                                                onClick={addRow}
                                            >
                                                <i className="bx bx-plus"></i>
                                            </button>
                                            <button
                                                type="button"
                                                className="staff-eq-icon is-remove"
                                                title={rows.length === 1 ? "Clear this row" : "Remove this row"}
                                                aria-label={rows.length === 1 ? "Clear this row" : "Remove this row"}
                                                disabled={rows.length === 1 && isBlankExp(r)}
                                                onClick={() => removeRow(i)}
                                            >
                                                <i className="bx bx-minus"></i>
                                            </button>
                                        </td>

                                    </tr>

                                    {msg && (
                                        <tr className="staff-eq-errrow">
                                            <td colSpan={6}>Row {i + 1}: {msg}</td>
                                        </tr>
                                    )}

                                </React.Fragment>
                            );
                        })}

                    </tbody>

                </table>

            </div>

            {error && (
                <div className="invalid-feedback d-block">{error}</div>
            )}

            <button
                type="button"
                className="staff-eq-add"
                disabled={rows.length >= MAX_EXP_ROWS}
                onClick={addRow}
            >
                + Add Experience
            </button>

            <div className="staff-exp-hint">
                Leave To Year empty if the staff still works there. Freshers can leave the table empty.
            </div>

        </div>
    );
};

// Software / Technical skills: type a skill and press Enter (or comma)
const SkillsSection = ({ value, error, onChange }) => {

    const [draft, setDraft] = useState("");

    const skills = text(value).split(",").map((x) => x.trim()).filter(Boolean);

    const save = (list) => onChange(list.join(", "));

    const add = () => {

        const name = draft.trim().replace(/,+$/, "").trim();

        if (!name) return;

        const exists = skills.some((x) => x.toLowerCase() === name.toLowerCase());
        const tooLong = [...skills, name].join(", ").length > SKILLS_MAX;

        if (!exists && !tooLong) save([...skills, name]);

        setDraft("");
    };

    return (
        <div className="col-md-6 mb-3 staff-skills">

            <label htmlFor="staff_skill_input" className="staff-field-label">
                Software/Technical Skills<span className="req">*</span>
            </label>

            <input
                id="staff_skill_input"
                className={"form-control" + (error ? " is-invalid" : "")}
                placeholder="Add a skill and press Enter"
                maxLength={60}
                value={draft}
                onChange={(e) => setDraft(e.target.value)}
                onKeyDown={(e) => {
                    if (e.key === "Enter" || e.key === ",") {
                        e.preventDefault();
                        add();
                    } else if (e.key === "Backspace" && !draft && skills.length > 0) {
                        save(skills.slice(0, -1));
                    }
                }}
                onBlur={add}
            />

            {error && (
                <div className="invalid-feedback d-block">{error}</div>
            )}

            <div className="staff-skill-box">
                {skills.map((sk) => (
                    <span className="staff-skill-chip" key={sk}>
                        {sk}
                        <button
                            type="button"
                            aria-label={`Remove ${sk}`}
                            onClick={() => save(skills.filter((x) => x !== sk))}
                        >
                            <i className="bx bx-x"></i>
                        </button>
                    </span>
                ))}
            </div>

        </div>
    );
};

// =====================================================
// EXTRA BANK ACCOUNTS (Bank tab: "+ Add Bank Account")
// The main account stays in the normal Staff_account_* fields; every
// additional account is one card here. Stored as an array in
// values.Staff_bank_accounts and sent to Django as a JSON string.
// =====================================================

const MAX_BANK_EXTRA = 4;

const BANK_KEYS = ["holder", "bank", "account_no", "ifsc", "branch"];

const emptyBank = () => ({ holder: "", bank: "", account_no: "", ifsc: "", branch: "" });

const isBlankBank = (b) => BANK_KEYS.every((k) => !text(b[k]).trim());

// JSON string / array from Django, or nothing
export const parseBankAccounts = (raw) => {

    let list = [];

    if (Array.isArray(raw)) {
        list = raw;
    } else if (typeof raw === "string" && raw.trim()) {
        try {
            const parsed = JSON.parse(raw);
            if (Array.isArray(parsed)) list = parsed;
        } catch (e) {
            list = [];
        }
    }

    return list.map((b) => ({
        holder: text(b.holder),
        bank: text(b.bank),
        account_no: text(b.account_no),
        ifsc: text(b.ifsc),
        branch: text(b.branch)
    }));
};

const cleanBankAccounts = (list) =>
    list
        .filter((b) => !isBlankBank(b))
        .map((b) => {
            const c = {};
            BANK_KEYS.forEach((k) => { c[k] = text(b[k]).trim(); });
            return c;
        });

// problems of one extra account (index = position in the list)
const validateBank = (b, index, list, mainAccountNo) => {

    const found = {};

    const holder = text(b.holder).trim();
    const no = text(b.account_no).trim();
    const ifsc = text(b.ifsc).trim();

    if (!holder) found.holder = "Account Holder Name is required.";
    else if (holder.length < 2 || (holder.match(/\./g) || []).length > 1 || !/^[A-Za-z .]+$/.test(holder))
        found.holder = "Account Holder Name cannot contain numbers or special characters.";

    const bankName = text(b.bank).trim();
    const branchName = text(b.branch).trim();

    if (!bankName) found.bank = "Bank Name is required.";
    else if (!/[A-Za-z]/.test(bankName) || !BANK_NAME_PATTERN.test(bankName))
        found.bank = "Bank Name cannot contain numbers or special characters.";

    if (branchName && !BRANCH_PATTERN.test(branchName))
        found.branch = "Branch cannot contain special characters.";

    if (!/^\d{9,18}$/.test(no)) found.account_no = "Account number must be 9 to 18 digits.";
    else if (no === String(mainAccountNo || "").trim() ||
             list.some((x, k) => k !== index && text(x.account_no).trim() === no))
        found.account_no = "This account number is already added.";

    if (!/^[A-Z]{4}0[A-Z0-9]{6}$/.test(ifsc))
        found.ifsc = "Enter a valid IFSC code, e.g. SBIN0001234.";

    return found;
};

// First problem of the filled extra accounts, e.g. "Account 2: ..."
const bankRowError = (list, mainAccountNo) => {

    for (let i = 0; i < list.length; i++) {

        if (isBlankBank(list[i])) continue;

        const msg = Object.values(validateBank(list[i], i, list, mainAccountNo))[0];

        if (msg) return `Additional account ${i + 1}: ${msg}`;
    }

    return "";
};

const BankAccountsSection = ({ entries, error, mainAccountNo, onChange }) => {

    // problems are shown after the first failed Next / Save
    const [showErrs, setShowErrs] = useState(false);

    useEffect(() => {
        if (error) setShowErrs(true);
    }, [error]);

    const setCell = (index, name, value) =>
        onChange(entries.map((b, i) => (i === index ? { ...b, [name]: value } : b)));

    const addAccount = () => {
        if (entries.length >= MAX_BANK_EXTRA) return;
        onChange([...entries, emptyBank()]);
    };

    const removeAccount = (index) =>
        onChange(entries.filter((_, i) => i !== index));

    return (
        <div
            className="col-12 staff-bank-extra"
            onKeyDown={(e) => {
                // Enter must not move / submit the whole staff form
                if (e.key === "Enter" && e.target.tagName === "INPUT")
                    e.preventDefault();
            }}
        >

            {entries.map((b, i) => {

                const re = showErrs && !isBlankBank(b)
                    ? validateBank(b, i, entries, mainAccountNo)
                    : {};

                const field = (name, label, extra = {}, required = true) => (
                    <div className="col-md-6 mb-3">
                        <label className="staff-field-label">
                            {label}{required && <span className="req">*</span>}
                        </label>
                        <input
                            className={"form-control" + (re[name] ? " is-invalid" : "")}
                            value={b[name]}
                            onChange={(e) => setCell(i, name, e.target.value)}
                            {...extra}
                        />
                        {re[name] && (
                            <div className="invalid-feedback d-block">{re[name]}</div>
                        )}
                    </div>
                );

                return (
                    <div className="staff-bank-card" key={i}>

                        <div className="staff-bank-card-head">
                            <span>
                                <i className="bx bx-bank me-1"></i>
                                Additional Bank Account {i + 1}
                            </span>
                            <button
                                type="button"
                                className="staff-eq-icon is-remove"
                                title="Remove this account"
                                aria-label="Remove this account"
                                onClick={() => removeAccount(i)}
                            >
                                <i className="bx bx-minus"></i>
                            </button>
                        </div>

                        <div className="row">
                            {field("holder", "Account Holder Name", {
                                maxLength: 100,
                                onChange: (e) => setCell(i, "holder", sanitizeHolderName(e.target.value))
                            })}
                            {field("bank", "Bank Name", {
                                maxLength: 100,
                                onChange: (e) => setCell(i, "bank", sanitizeBankName(e.target.value))
                            })}
                            {field("account_no", "Account Number", {
                                maxLength: 18,
                                inputMode: "numeric",
                                onChange: (e) =>
                                    setCell(i, "account_no", e.target.value.replace(/\D/g, ""))
                            })}
                            {field("ifsc", "IFSC Code", {
                                maxLength: 11,
                                placeholder: "e.g. SBIN0001234",
                                onChange: (e) =>
                                    setCell(i, "ifsc", e.target.value.toUpperCase())
                            })}
                            {field("branch", "Branch", {
                                maxLength: 100,
                                onChange: (e) => setCell(i, "branch", sanitizeBranch(e.target.value))
                            }, false)}
                        </div>

                    </div>
                );
            })}

            {error && (
                <div className="invalid-feedback d-block mb-2">{error}</div>
            )}

            <button
                type="button"
                className="staff-eq-add"
                disabled={entries.length >= MAX_BANK_EXTRA}
                onClick={addAccount}
            >
                + Add Bank Account
            </button>

        </div>
    );
};


// =====================================================
// DRAG AND DROP UPLOAD BOX (used for the Proof tab files)
// =====================================================

const FileDrop = ({ id, value, accept, dropText, invalid, onFile }) => {

    const [dragging, setDragging] = useState(false);

    const pick = (fileList) => {

        const file = fileList && fileList[0];

        if (file) onFile(file);

    };

    return (

        <div
            className={
                "staff-dropzone" +
                (dragging ? " is-dragging" : "") +
                (invalid ? " is-invalid" : "")
            }
            onDragOver={(e) => {
                e.preventDefault();
                setDragging(true);
            }}
            onDragLeave={() => setDragging(false)}
            onDrop={(e) => {
                e.preventDefault();
                setDragging(false);
                pick(e.dataTransfer.files);
            }}
        >

            <span className="staff-dropzone-icon">
                <i className="bx bx-up-arrow-alt"></i>
            </span>

            <div className="staff-dropzone-text">
                {dropText}
            </div>

            {value && (
                <div className="staff-dropzone-file">
                    <i className="bx bx-file me-1"></i>
                    {fileLabel(value)}
                </div>
            )}

            <label
                htmlFor={id}
                className="staff-dropzone-btn"
            >
                Browse files
            </label>

            <input
                id={id}
                type="file"
                accept={accept}
                hidden
                onChange={(e) => {
                    pick(e.target.files);
                    // same file can be picked again after an error
                    e.target.value = "";
                }}
            />

        </div>
    );
};

// =====================================================
// BUILD JSON PAYLOAD FOR DJANGO (text fields + photo/proof files as base64)
// Files are only sent when a NEW file was picked; an
// existing saved file (a URL string) is left untouched.
// =====================================================

// File -> { name, data } (data = base64 data URL). Django saves it as a file.
const fileToObject = (file) =>
    new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve({ name: file.name, data: reader.result });
        reader.onerror = reject;
        reader.readAsDataURL(file);
    });

// Plain JSON object for AuthContext insert / update (same style as Course).
export const buildStaffPayload = async (values, extra = {}) => {

    const payload = {};

    for (const key of Object.keys(values)) {

        const v = values[key];

        if (v instanceof File) {
            payload[key] = await fileToObject(v);
        } else if (Array.isArray(v)) {
            payload[key] = v;
        } else if (typeof v === "string") {
            // saved file URLs are not re-sent
            if (!FILE_FIELD_NAMES.includes(key)) payload[key] = v.trim();
        } else if (v !== null && v !== undefined) {
            payload[key] = v;
        }

    }

    return { ...payload, ...extra };
};

// =====================================================
// FORM COMPONENT
// props: initialValues, existingStaff, currentId,
//        title, submitLabel, onSubmit(values), onBack
// =====================================================

export const StaffForm = (props) => {

    const [values, setValues] = useState(() => {

        const init = {
            ...emptyStaff(),
            ...(props.initialValues || {})
        };

        // Education: JSON string / array from Django, or the old single columns
        init.Staff_education = parseEducation(init.Staff_education, init);

        // Additional bank accounts: JSON string / array from Django
        init.Staff_bank_accounts = parseBankAccounts(init.Staff_bank_accounts);

        // Experience rows: JSON string / array from Django
        init.Staff_experience_details = parseExperience(init.Staff_experience_details);
        init.Staff_skills = text(init.Staff_skills);

        // Older records only have one "Staff_address" -> use it as permanent address
        if (!init.Staff_perm_address && init.Staff_address)
            init.Staff_perm_address = init.Staff_address;

        if (init.Staff_same_address !== "Yes") init.Staff_same_address = "No";

        return init;
    });

    const [activeTab, setActiveTab] = useState(0);
    const [errors, setErrors] = useState({});
    const [loading, setLoading] = useState(false);

    // ---------- Department / Designation lists (Department + Designation modules) ----------
    const { getData } = useContext(AuthContext);

    const [departments, setDepartments] = useState([]);
    const [designations, setDesignations] = useState([]);
    const [listsLoading, setListsLoading] = useState(true);

    useEffect(() => {

        let alive = true;

        const load = async () => {

            try {

                const [dep, des] = await Promise.all([
                    getData("fetch_department_datail"),
                    getData("fetch_designation_datail")
                ]);

                if (!alive) return;

                setDepartments(Array.isArray(dep) ? dep : []);
                setDesignations(Array.isArray(des) ? des : []);

            } catch (err) {

                console.error("Failed to fetch department / designation:", err);

            } finally {

                if (alive) setListsLoading(false);

            }
        };

        load();

        return () => { alive = false; };

    }, [getData]);

    const isActiveStatus = (s) => !s || String(s).toLowerCase() === "active";

    // Options of the two dynamic selects.
    //  - Department  : Active departments
    //  - Designation : Active designations of the chosen department
    // The saved value is always kept in the list, so Edit never loses it.
    const dynamicOptions = (name) => {

        let names = [];

        if (name === "Staff_department") {

            names = departments
                .filter((d) => isActiveStatus(d.Department_Status))
                .map((d) => d.Department_standard);

        } else if (name === "Staff_designation") {

            const dep = departments.find(
                (d) => d.Department_standard === values.Staff_department
            );

            if (dep) {
                names = designations
                    .filter((x) =>
                        String(x.Department_id) === String(dep.Department_id) &&
                        isActiveStatus(x.Designation_Status)
                    )
                    .map((x) => x.Designation_name);
            }
        }

        const current = values[name];

        if (current && !names.includes(current)) names = [current, ...names];

        return names;
    };

    // tabs where the user already pressed Next / clicked a later step (errors are shown there)
    const [attempted, setAttempted] = useState([]);

    const markAttempted = (indexes) =>
        setAttempted((prev) => Array.from(new Set([...prev, ...indexes])));

    // Error popup (same style as the delete popup)
    const [popup, setPopup] = useState("");

    // Photo preview
    const [photoUrl, setPhotoUrl] = useState("");

    // Hidden photo input, opened by the box or the upload icon button
    const photoInputRef = useRef(null);

    useEffect(() => {

        const p = values.Staff_photo;

        if (!p) {
            setPhotoUrl("");
            return undefined;
        }

        if (typeof p === "string") {
            setPhotoUrl(p);
            return undefined;
        }

        const url = URL.createObjectURL(p);

        setPhotoUrl(url);

        return () => URL.revokeObjectURL(url);

    }, [values.Staff_photo]);


    // Age is always calculated from the date of birth
    useEffect(() => {

        setValues((prev) => {

            const age = calcAge(prev.Staff_dob);

            return prev.Staff_age === age ? prev : { ...prev, Staff_age: age };

        });

    }, [values.Staff_dob]);


    // "Same as temporary" = Yes -> permanent address always follows the temporary one
    useEffect(() => {

        if (values.Staff_same_address !== "Yes") return;

        setValues((prev) => {

            const next = {
                ...prev,
                Staff_perm_address: prev.Staff_temp_address,
                Staff_perm_city: prev.Staff_temp_city,
                Staff_perm_state: prev.Staff_temp_state,
                Staff_perm_pincode: prev.Staff_temp_pincode
            };

            const same =
                next.Staff_perm_address === prev.Staff_perm_address &&
                next.Staff_perm_city === prev.Staff_perm_city &&
                next.Staff_perm_state === prev.Staff_perm_state &&
                next.Staff_perm_pincode === prev.Staff_perm_pincode;

            return same ? prev : next;
        });

    }, [
        values.Staff_same_address,
        values.Staff_temp_address,
        values.Staff_temp_city,
        values.Staff_temp_state,
        values.Staff_temp_pincode
    ]);


    const setSameAddress = (answer) => {

        setValues((prev) => ({ ...prev, Staff_same_address: answer }));

        // permanent address errors are not relevant when it is the same
        if (answer === "Yes") {
            setErrors((prev) => {
                const next = { ...prev };
                ["Staff_perm_address", "Staff_perm_city",
                    "Staff_perm_state", "Staff_perm_pincode"]
                    .forEach((k) => delete next[k]);
                return next;
            });
        }
    };


    const setField = (name, value) => {

        setValues((prev) => ({ ...prev, [name]: value }));

        // live validation, under the input
        setErrors((prev) => ({
            ...prev,
            [name]: validateField(
                name, value, values, props.existingStaff, props.currentId
            )
        }));

    };


    const handleChange = (e, def) => {

        let value = e.target.value;

        // a designation belongs to one department -> changing the department clears it
        if (def.name === "Staff_department") {

            setValues((prev) => ({ ...prev, Staff_department: value, Staff_designation: "" }));

            setErrors((prev) => ({
                ...prev,
                Staff_department: validateField(
                    "Staff_department", value, values, props.existingStaff, props.currentId
                ),
                Staff_designation: ""
            }));

            return;
        }

        if (DIGIT_FIELDS.includes(def.name))
            value = value.replace(/\D/g, "");

        if (PERSON_NAME_FIELDS.includes(def.name))
            value = sanitizePersonName(value);

        if (def.name === "Staff_account_holder")
            value = sanitizeHolderName(value);

        if (def.name === "Staff_bank_name")
            value = sanitizeBankName(value);

        if (def.name === "Staff_branch")
            value = sanitizeBranch(value);

        if (UPPER_FIELDS.includes(def.name))
            value = value.toUpperCase();

        if (def.name === "Staff_experience" || def.name === "Staff_percentage")
            value = value.replace(/[^\d.]/g, "");

        setField(def.name, value);

    };


    const handleFile = (e, name) => {

        const file = e.target.files && e.target.files[0];

        if (!file) return;

        if (file.size > MAX_FILE_MB * 1024 * 1024) {
            setErrors((prev) => ({ ...prev, [name]: `Photo must be smaller than ${MAX_FILE_MB} MB.` }));
            return;
        }

        setField(name, file);

    };


    // Returns { fieldName: message } for the fields of the given tabs
    const validateTabs = (tabIndexes) => {

        const found = {};

        tabIndexes.forEach((i) => {

            if (TABS[i] === "Personal") {

                const photo = values.Staff_photo;

                if (!photo) found.Staff_photo = "Photo is required.";
                else if (typeof photo !== "string" && photo.size > MAX_FILE_MB * 1024 * 1024)
                    found.Staff_photo = `Photo must be smaller than ${MAX_FILE_MB} MB.`;
            }

            if (TABS[i] === "Education") {

                const filled = values.Staff_education.filter((e) => !isBlankEdu(e));

                if (filled.length === 0)
                    found.Staff_education = "Add at least one education.";
                else {
                    const rowError = educationRowError(values.Staff_education);
                    if (rowError) found.Staff_education = rowError;
                }
            }

            if (TABS[i] === "Professional") {

                const expError = experienceRowError(values.Staff_experience_details);

                if (expError) found.Staff_experience_details = expError;

                if (!text(values.Staff_skills).trim())
                    found.Staff_skills = "Software/Technical Skills is required.";
            }

            if (TABS[i] === "Bank") {

                const bankError = bankRowError(
                    values.Staff_bank_accounts, values.Staff_account_no
                );

                if (bankError) found.Staff_bank_accounts = bankError;
            }

            FIELDS[TABS[i]].forEach((f) => {

                const msg = validateField(
                    f.name, values[f.name], values,
                    props.existingStaff, props.currentId
                );

                if (msg) found[f.name] = msg;

            });

        });

        return found;
    };


    const showErrors = (found) => {

        setErrors((prev) => ({ ...prev, ...found }));

        const first = Object.values(found)[0];

        if (first) setPopup(first);

    };


    const goNext = () => {

        markAttempted([activeTab]);

        const found = validateTabs([activeTab]);

        if (Object.keys(found).length > 0) {

            showErrors(found);

            return;
        }

        setActiveTab((t) => Math.min(t + 1, TABS.length - 1));

    };


    const goPrev = () => {

        // leaving a page: its colour becomes green (filled) or red (not filled)
        markAttempted([activeTab]);

        setActiveTab((t) => Math.max(t - 1, 0));
    };


    // Clicking a step at the top opens that page freely (to view it).
    // The Next button still checks the current page, and Save checks all pages.
    // The page being left turns green (filled) or red (not filled).
    const goToTab = (target) => {

        if (target !== activeTab) markAttempted([activeTab]);

        setActiveTab(target);
    };


    const handleSubmit = async (e) => {

        e.preventDefault();

        // Enter key on a non-final tab behaves like "Next"
        if (activeTab < TABS.length - 1) {

            goNext();

            return;
        }

        markAttempted(TABS.map((_, i) => i));

        const found = validateTabs(TABS.map((_, i) => i));

        if (Object.keys(found).length > 0) {

            // jump to the first tab that has a problem
            const badTab = TABS.findIndex((tab) =>
                FIELDS[tab].some((f) => found[f.name]) ||
                (tab === "Personal" && found.Staff_photo) ||
                (tab === "Education" && found.Staff_education) ||
                (tab === "Professional" && (found.Staff_experience_details || found.Staff_skills)) ||
                (tab === "Bank" && found.Staff_bank_accounts)
            );

            setActiveTab(badTab);

            showErrors(found);

            return;
        }

        try {

            setLoading(true);

            // latest education also fills the old single columns
            const eduList = cleanEducation(values.Staff_education);

            const last = latestEducation(eduList);

            // experience rows: total years + latest company fill the old columns
            const expList = cleanExperience(values.Staff_experience_details);
            const expTotal = computeExperienceTotal(expList);

            // certificate boxes that are hidden (qualification removed) send nothing
            const shownQuals = eduProofTypes(eduList);
            const hiddenProofs = {};
            FIELDS.Proof.forEach((f) => {
                if (f.eduQual && !shownQuals.includes(f.eduQual) && values[f.name] instanceof File)
                    hiddenProofs[f.name] = null;
            });

            await props.onSubmit({
                ...values,
                ...hiddenProofs,
                Staff_experience_details: expList,
                Staff_experience: expTotal === null ? values.Staff_experience : String(expTotal),
                Staff_prev_company: expList.length > 0
                    ? latestOrganisation(expList)
                    : values.Staff_prev_company,
                Staff_education: eduList,
                Staff_bank_accounts: cleanBankAccounts(values.Staff_bank_accounts),
                Staff_qualification: last ? (last.degree || last.qualification) : "",
                Staff_specialization: last ? last.department : "",
                Staff_institution: last ? last.school : "",
                Staff_passing_year: last ? last.yop : "",
                Staff_percentage: last ? last.percentage : ""
            });

        } catch (err) {

            console.error("Staff save failed:", err);

            const data = err && err.responseData;

            let message = props.failMessage || "Staff could not be saved. Please try again.";

            if (data) {

                // First Django field error, or detail
                const firstKey = Object.keys(data).find((k) => k !== "detail");

                if (data.detail) {
                    message = data.detail;
                } else if (firstKey) {
                    message = Array.isArray(data[firstKey]) ? data[firstKey][0] : String(data[firstKey]);
                }

            }

            setPopup(message);

        } finally {

            setLoading(false);

        }

    };


    const tabIsDone = (index) => Object.keys(validateTabs([index])).length === 0;

    // blue  = not filled yet / not tried
    // green = filled and valid
    // red   = Next was pressed (or a later step clicked) and the tab is not valid
    const tabStatus = (index) => {

        const tab = TABS[index];
        const tried = attempted.includes(index);
        const mustFill = tab === "Education" || tab === "Professional" || FIELDS[tab].some((f) => f.required);

        if (tabIsDone(index)) return tried || mustFill ? "is-done" : "is-new";

        return tried ? "has-error" : "is-new";
    };

    const tabHasError = (tab) =>
        FIELDS[tab].some((f) => errors[f.name]) ||
        (tab === "Personal" && !!errors.Staff_photo) ||
        (tab === "Education" && !!errors.Staff_education) ||
        (tab === "Professional" && (!!errors.Staff_experience_details || !!errors.Staff_skills)) ||
        (tab === "Bank" && !!errors.Staff_bank_accounts);


    // ---------------- one field ----------------
    const renderField = (def) => {

        const id = def.name;
        const err = errors[def.name];
        const cls = (base) => base + (err ? " is-invalid" : "");

        let control;

        if (def.type === "select") {

            // Department / Designation come from the fetched lists
            const options = def.dynamic ? dynamicOptions(def.name) : def.options;

            const noDepartment =
                def.name === "Staff_designation" && !values.Staff_department;

            control = (
                <select
                    id={id}
                    className={cls("form-select")}
                    value={values[def.name]}
                    onChange={(e) => handleChange(e, def)}
                    disabled={def.dynamic && (listsLoading || noDepartment)}
                >
                    <option value="">
                        {def.dynamic && listsLoading
                            ? "Loading..."
                            : noDepartment
                                ? "Select Department first"
                                : def.placeholder}
                    </option>
                    {options.map((o) => (
                        <option key={o} value={o}>{o}</option>
                    ))}
                </select>
            );

        } else if (def.type === "textarea") {

            control = (
                <textarea
                    id={id}
                    rows="2"
                    className={cls("form-control")}
                    maxLength={def.maxLength}
                    placeholder={def.placeholder}
                    value={values[def.name]}
                    onChange={(e) => handleChange(e, def)}
                />
            );

        } else if (def.type === "readonly") {

            control = (
                <input
                    id={id}
                    type="text"
                    className="form-control"
                    value={values[def.name]}
                    readOnly
                />
            );

        } else if (def.type === "file") {

            control = (
                <>
                    <FileDrop
                        id={id}
                        value={values[def.name]}
                        accept={def.accept || ".jpg,.jpeg,.png,.pdf"}
                        dropText={def.dropText || "Drag and drop images here"}
                        invalid={!!err}
                        onFile={(file) => setField(def.name, file)}
                    />
                    <div className="staff-file-hint">
                        {`JPG, PNG or PDF, max ${MAX_FILE_MB} MB`}
                    </div>
                </>
            );

        } else {

            control = (
                <input
                    id={id}
                    type={def.type === "date" ? "date" : def.type === "email" ? "email" : "text"}
                    inputMode={def.type === "tel" ? "numeric" : undefined}
                    className={cls("form-control")}
                    maxLength={def.maxLength}
                    placeholder={def.placeholder}
                    value={values[def.name]}
                    onChange={(e) => handleChange(e, def)}
                    max={
                        def.name === "Staff_dob"
                            ? new Date().toISOString().split("T")[0]
                            : undefined
                    }
                />
            );

        }

        return (
            <div
                key={def.name}
                className={
                    def.full
                        ? "col-12 mb-3"
                        : def.third
                            ? "col-md-4 mb-3"
                            : "col-md-6 mb-3"
                }
            >

                <label htmlFor={id} className="staff-field-label">
                    {def.label}
                    {def.required && <span className="req">*</span>}
                </label>

                {control}

                {err && (
                    <div className="invalid-feedback d-block">{err}</div>
                )}

            </div>
        );
    };


    // ---------------- address block (temporary + permanent) ----------------
    const addressInput = (def) => {

        const err = errors[def.name];

        return (
            <>
                <input
                    id={def.name}
                    type="text"
                    inputMode={def.name.endsWith("pincode") ? "numeric" : undefined}
                    className={"form-control" + (err ? " is-invalid" : "")}
                    maxLength={def.maxLength}
                    placeholder={def.placeholder}
                    aria-label={def.label}
                    value={values[def.name]}
                    onChange={(e) => handleChange(e, def)}
                />
                {err && (
                    <div className="invalid-feedback d-block">{err}</div>
                )}
            </>
        );
    };

    const renderAddressGroup = (group) => {

        const [line, city, state, pin] = FIELDS.Personal.filter(
            (f) => f.addr === group
        );

        return (
            <div className="row staff-address-group">

                <div className="col-12 mb-3">
                    {addressInput(line)}
                </div>

                <div className="col-md-4 mb-3">
                    {addressInput(city)}
                </div>

                <div className="col-md-4 mb-3">
                    {addressInput(state)}
                </div>

                <div className="col-md-4 mb-3">
                    {addressInput(pin)}
                </div>

            </div>
        );
    };

    const renderAddressBlock = () => (

        <div key="address-block" className="col-12">

            {renderAddressGroup("temp")}

            <div className="staff-same-address">

                <span className="staff-same-address-q">
                    Is the Permanent Address the same as the Temporary Address?
                </span>

                {["Yes", "No"].map((opt) => (

                    <label key={opt} className="staff-radio">
                        <input
                            type="radio"
                            name="Staff_same_address"
                            value={opt}
                            checked={values.Staff_same_address === opt}
                            onChange={() => setSameAddress(opt)}
                        />
                        <span className="staff-radio-dot"></span>
                        <span className="staff-radio-text">{opt}</span>
                    </label>

                ))}

            </div>

            {values.Staff_same_address === "No" && renderAddressGroup("perm")}

        </div>
    );


    return (

        <div className="staffregister-page centered-form-page container-xxl flex-grow-1 container-p-y">

            <div className="centered-form-wrap">

                {/* ================= PAGE HEADER ================= */}
                <div className="page-header">

                    <h3 className="page-title">
                        {props.title}
                    </h3>

                    <button
                        type="button"
                        className="staff-back-btn"
                        onClick={props.onBack}
                        disabled={loading}
                    >
                        <i className="bx bx-arrow-back me-2"></i>
                        Back to list
                    </button>

                </div>


                <div className="card staffregister-card">

                    {/* ================= STEPS ================= */}
                    <div className="staff-steps">

                        {TABS.map((tab, i) => (

                            <button
                                key={tab}
                                type="button"
                                className={
                                    "staff-step" +
                                    (i === activeTab ? " is-active" : "") +
                                    (" " + tabStatus(i))
                                }
                                onClick={() => goToTab(i)}
                            >

                                <span className="staff-step-no">
                                    {i + 1}
                                </span>

                                <span className="staff-step-label">
                                    <i className={"bx me-1 " + TAB_ICONS[tab]}></i>
                                    {tab}
                                </span>

                            </button>

                        ))}

                    </div>

                    <div className="card-body">

                        <form onSubmit={handleSubmit} noValidate>

                            {/* PHOTO (Personal tab only) */}
                            {activeTab === 0 && (

                                <div className="staff-photo-row">

                                    <div className="staff-photo-wrap">

                                        <div
                                            className={"staff-photo-box" + (errors.Staff_photo ? " is-invalid" : "")}
                                            role="button"
                                            tabIndex={0}
                                            title="Upload photo"
                                            onClick={() =>
                                                photoInputRef.current &&
                                                photoInputRef.current.click()
                                            }
                                            onKeyDown={(e) => {
                                                if (e.key === "Enter" || e.key === " ") {
                                                    e.preventDefault();
                                                    photoInputRef.current &&
                                                        photoInputRef.current.click();
                                                }
                                            }}
                                        >

                                            {photoUrl ? (
                                                <img src={photoUrl} alt="Staff" />
                                            ) : (
                                                "Photo"
                                            )}

                                        </div>

                                        <button
                                            type="button"
                                            className="staff-photo-btn"
                                            title="Upload photo"
                                            aria-label="Upload photo"
                                            onClick={() =>
                                                photoInputRef.current &&
                                                photoInputRef.current.click()
                                            }
                                        >
                                            <i className="bx bx-upload"></i>
                                        </button>

                                        <input
                                            ref={photoInputRef}
                                            type="file"
                                            accept=".jpg,.jpeg,.png"
                                            hidden
                                            onChange={(e) => {
                                                handleFile(e, "Staff_photo");
                                                // same file can be picked again
                                                e.target.value = "";
                                            }}
                                        />

                                    </div>

                                </div>

                            )}

                            {activeTab === 0 && errors.Staff_photo && (
                                <div className="invalid-feedback d-block text-end">
                                    {errors.Staff_photo}
                                </div>
                            )}


                            <div className="row staff-form-grid">

                                {TABS[activeTab] === "Professional" && (
                                    <ExperienceSection
                                        entries={values.Staff_experience_details}
                                        error={errors.Staff_experience_details}
                                        onChange={(list) => {

                                            // total years follow the table
                                            const total = computeExperienceTotal(list);

                                            setValues((prev) => ({
                                                ...prev,
                                                Staff_experience_details: list,
                                                ...(total !== null ? { Staff_experience: String(total) } : {})
                                            }));

                                            setErrors((prev) => ({
                                                ...prev,
                                                Staff_experience_details: "",
                                                ...(total !== null ? { Staff_experience: "" } : {})
                                            }));
                                        }}
                                    />
                                )}

                                {TABS[activeTab] === "Education" && (
                                    <EducationSection
                                        entries={values.Staff_education}
                                        error={errors.Staff_education}
                                        onChange={(list) => {
                                            setValues((prev) => ({ ...prev, Staff_education: list }));
                                            setErrors((prev) => ({ ...prev, Staff_education: "" }));
                                        }}
                                    />
                                )}

                                {FIELDS[TABS[activeTab]].map((def) => {

                                    // certificate boxes only for the qualifications entered
                                    if (def.eduQual && !eduProofTypes(values.Staff_education).includes(def.eduQual)) {
                                        return null;
                                    }

                                    // address fields are drawn together as one block
                                    if (def.addr) {
                                        return def.name === "Staff_temp_address"
                                            ? renderAddressBlock()
                                            : null;
                                    }

                                    // total experience is calculated while the table has years
                                    if (def.name === "Staff_experience" &&
                                        computeExperienceTotal(values.Staff_experience_details) !== null) {
                                        return renderField({ ...def, type: "readonly" });
                                    }

                                    return renderField(def);
                                })}

                                {TABS[activeTab] === "Proof" && eduProofTypes(values.Staff_education).length === 0 && (
                                    <div className="col-12 mb-3 staff-file-hint">
                                        Enter your education details in the Education tab to upload their certificates here.
                                    </div>
                                )}

                                {TABS[activeTab] === "Professional" && (
                                    <SkillsSection
                                        value={values.Staff_skills}
                                        error={errors.Staff_skills}
                                        onChange={(v) => {
                                            setValues((prev) => ({ ...prev, Staff_skills: v }));
                                            setErrors((prev) => ({ ...prev, Staff_skills: "" }));
                                        }}
                                    />
                                )}

                                {TABS[activeTab] === "Bank" && (
                                    <BankAccountsSection
                                        entries={values.Staff_bank_accounts}
                                        error={errors.Staff_bank_accounts}
                                        mainAccountNo={values.Staff_account_no}
                                        onChange={(list) => {
                                            setValues((prev) => ({ ...prev, Staff_bank_accounts: list }));
                                            setErrors((prev) => ({ ...prev, Staff_bank_accounts: "" }));
                                        }}
                                    />
                                )}

                            </div>


                            {/* ================= FOOTER ================= */}
                            <div className="staff-form-footer">

                                <button
                                    type="button"
                                    className="btn btn-outline-secondary"
                                    onClick={activeTab === 0 ? props.onBack : goPrev}
                                    disabled={loading}
                                >
                                    <i
                                        className={
                                            "bx me-1 " +
                                            (activeTab === 0 ? "bx-x" : "bx-chevron-left")
                                        }
                                    ></i>
                                    {activeTab === 0 ? "Cancel" : "Previous"}
                                </button>

                                <div className="staff-footer-right">

                                    {/* Back to the staff list (first tab already has Cancel) */}
                                    {activeTab > 0 && (
                                        <button
                                            type="button"
                                            className="btn btn-outline-secondary staff-footer-back"
                                            onClick={props.onBack}
                                            disabled={loading}
                                        >
                                            <i className="bx bx-arrow-back me-1"></i>
                                            Back to list
                                        </button>
                                    )}

                                {activeTab < TABS.length - 1 ? (

                                    <button
                                        type="button"
                                        className="btn btn-primary"
                                        onClick={goNext}
                                    >
                                        Next
                                        <i className="bx bx-chevron-right ms-1"></i>
                                    </button>

                                ) : (

                                    <button
                                        type="submit"
                                        className="btn btn-primary"
                                        disabled={loading}
                                    >

                                        {loading ? (
                                            <>
                                                <span
                                                    className="spinner-border spinner-border-sm me-2"
                                                    role="status"
                                                    aria-hidden="true"
                                                ></span>
                                                Saving...
                                            </>
                                        ) : (
                                            <>
                                                <i className="bx bx-save me-1"></i>
                                                {props.submitLabel}
                                            </>
                                        )}

                                    </button>

                                )}

                                </div>

                            </div>

                        </form>

                    </div>

                </div>

            </div>


            {/* ================= ERROR POPUP ================= */}
            {popup && (

                <div
                    className="staff-popup-backdrop"
                    onClick={() => setPopup("")}
                >

                    <div
                        className="staff-popup"
                        role="alertdialog"
                        aria-modal="true"
                        onClick={(e) => e.stopPropagation()}
                    >

                        <div className="staff-popup-icon">
                            <i className="bx bx-error-circle"></i>
                        </div>

                        <h5>{popup}</h5>

                        <button
                            type="button"
                            className="btn btn-primary mt-3"
                            onClick={() => setPopup("")}
                            autoFocus
                        >
                            OK
                        </button>

                    </div>

                </div>

            )}

        </div>
    );
};


// =====================================================
// ADD STAFF PAGE
// =====================================================

const Addstaffregister = (props) => {

    const { insert } = useContext(AuthContext);

    const handleSave = async (values) => {

        // New staff are created Active by default (Status field on the
        // Joining tab can change it before saving)
        const payload = await buildStaffPayload(values);

        const response = await insert(
            payload,
            "staffregister_create"
        );

        console.log("Staff created:", response);

        // Refresh parent list and go back
        if (props.onSuccess) {

            await props.onSuccess();

        }

    };

    return (

        <StaffForm
            title="Add Staff"
            submitLabel="Save Staff"
            failMessage="Staff could not be registered. Please try again."
            existingStaff={props.existingStaff}
            onSubmit={handleSave}
            onBack={props.toggle}
        />

    );
};

export default Addstaffregister;