import React, {
    useState,
    useContext,
    useEffect,
    useCallback
} from "react";

import "./StaffRegister.css";

import Addstaffregister from "./addstaffregister/Addstaffregister";
import Updatestaffregister from "./updatestaffregister/Updatestaffregister";
import Deletestaffregister from "./deletestaffregister/Deletestaffregister";

import {
    parseEducation,
    parseExperience,
    parseBankAccounts
} from "./addstaffregister/Addstaffregister";

import AuthContext from "../../services/AuthContext";


// =====================================================
// HELPERS
// =====================================================

const show = (v) =>
    v === null || v === undefined || String(v).trim() === ""
        ? "-"
        : String(v);

const showDate = (d) => {

    if (!d) return "-";

    const date = new Date(d);

    return isNaN(date.getTime())
        ? String(d)
        : date.toLocaleDateString();

};

const joinAddress = (...parts) => {

    const text = parts
        .filter((p) => p && String(p).trim())
        .join(", ");

    return text || "-";

};

// =====================================================
// SEARCH BOX VALIDATION
// =====================================================

const SEARCH_MAX = { name: 50, department: 50, designation: 50, mobile: 10 };

// remove leading space + collapse repeated spaces
const tidySpaces = (v) =>
    v.replace(/^\s+/, "").replace(/\s{2,}/g, " ");

// Name: letters, space and ONE "." only (max 50)
const sanitizeName = (v) => {

    let text = tidySpaces(v.replace(/[^A-Za-z .]/g, ""))
        .replace(/^\.+/, "");              // cannot start with a dot

    // keep only the first dot
    let dotSeen = false;

    text = text.replace(/\./g, () => {
        if (dotSeen) return "";
        dotSeen = true;
        return ".";
    });

    return text.slice(0, SEARCH_MAX.name);

};

// Department: letters, numbers, space, ".", "/" and "-" (max 50)
const sanitizeDepartment = (v) =>
    tidySpaces(v.replace(/[^A-Za-z0-9 ./-]/g, "")).slice(0, SEARCH_MAX.department);

// Designation: letters, numbers, space, ".", "/" and "-" (max 50)
const sanitizeDesignation = (v) =>
    tidySpaces(v.replace(/[^A-Za-z0-9 ./-]/g, "")).slice(0, SEARCH_MAX.designation);

// Mobile: digits only (max 10)
const sanitizeMobile = (v) =>
    v.replace(/\D/g, "").slice(0, SEARCH_MAX.mobile);

// Status: only All ("") / Active / Deactive
const STATUS_OPTIONS = ["", "Active", "Deactive"];

const sanitizeStatus = (v) =>
    STATUS_OPTIONS.includes(v) ? v : "";

const SANITIZERS = {
    name: sanitizeName,
    department: sanitizeDepartment,
    designation: sanitizeDesignation,
    mobile: sanitizeMobile,
    status: sanitizeStatus
};

// hint under the mobile box when it does not start with 6, 7, 8 or 9
const mobileHint = (v) =>
    v && !/^[6-9]/.test(v)
        ? "Mobile number starts with 6, 7, 8 or 9"
        : "";


// uploaded documents (saved files come back as URL strings)
const DOCUMENTS = [
    { key: "Staff_id_proof", label: "ID Proof" },
    { key: "Staff_address_proof", label: "Address Proof" },
    { key: "Staff_resume", label: "Resume" },
    { key: "Staff_10th_proof", label: "10th Certificate" },
    { key: "Staff_12th_proof", label: "12th Certificate" },
    { key: "Staff_diploma_proof", label: "Diploma Certificate" },
    { key: "Staff_ug_proof", label: "UG Certificate" },
    { key: "Staff_pg_proof", label: "PG Certificate" },
    { key: "Staff_phd_proof", label: "Ph.D Certificate" },
    { key: "Staff_others_proof", label: "Other Certificate" }
];


// =====================================================
// SMALL PIECES
// =====================================================

function Section({ title, children }) {

    return (

        <div className="view-section">

            <div className="view-section-title">{title}</div>

            <div className="view-section-body">
                {children}
            </div>

        </div>

    );

}

function Row({ icon, label, value }) {

    return (

        <div className="view-row">

            <i className={`bx ${icon}`}></i>

            <span className="view-label">{label}</span>

            <span className="view-colon">:</span>

            <span className="view-value">{value}</span>

        </div>

    );

}

// =====================================================
// VIEW PANEL (opens beside the staff table)
// =====================================================

function Viewstaffregister({ data, toggle, className = "" }) {

    const staff = data || {};

    const education = parseEducation(staff.Staff_education, staff)
        .filter((e) =>
            [e.school, e.board, e.percentage, e.yop, e.degree, e.department]
                .some((v) => String(v || "").trim())
        );

    const experience = parseExperience(staff.Staff_experience_details)
        .filter((e) =>
            [e.organisation, e.from_year, e.to_year, e.designation]
                .some((v) => String(v || "").trim())
        );

    // main account (own columns) + extra accounts (JSON list)
    const mainAccount = {
        holder: staff.Staff_account_holder,
        bank: staff.Staff_bank_name,
        account_no: staff.Staff_account_no,
        ifsc: staff.Staff_ifsc,
        branch: staff.Staff_branch
    };

    const hasMain = Object.values(mainAccount)
        .some((v) => String(v || "").trim());

    const bankAccounts = [
        ...(hasMain ? [mainAccount] : []),
        ...parseBankAccounts(staff.Staff_bank_accounts)
    ];

    const documents = DOCUMENTS.filter(
        (d) => typeof staff[d.key] === "string" && staff[d.key]
    );


    return (

        <aside className={`staff-detail-panel ${className}`.trim()}>

            {/* TITLE + CLOSE */}

            <div className="panel-top">

                <h6 className="panel-title">Staff Details</h6>

                <button
                    type="button"
                    className="panel-close"
                    onClick={toggle}
                    title="Close"
                >
                    <i className="bx bx-x"></i>
                </button>

            </div>


            {/* PROFILE */}

            <div className="panel-profile">

                {staff.Staff_photo ? (

                    <img
                        className="panel-photo"
                        src={staff.Staff_photo}
                        alt={staff.Staff_name}
                    />

                ) : (

                    <span className="panel-photo panel-photo-letter">
                        {String(staff.Staff_name || "?")
                            .charAt(0)
                            .toUpperCase()}
                    </span>

                )}

                <div className="panel-name">{show(staff.Staff_name)}</div>

                <div className="panel-id">#{staff.Staff_id}</div>

                <div className="panel-designation">
                    Designation : <span>{show(staff.Staff_designation)}</span>
                </div>

            </div>

            <div className="panel-contact">

                <div>
                    <i className="bx bxs-envelope"></i>
                    {show(staff.Staff_email)}
                </div>

                <div>
                    <i className="bx bxs-phone phone"></i>
                    {show(staff.Staff_mobile)}
                </div>

            </div>


            {/* FULL DETAILS */}

            <Section title="Full Details:">

                <Row icon="bxs-user" label="Father Name" value={show(staff.Staff_father_name)} />
                <Row icon="bxs-user" label="Mother Name" value={show(staff.Staff_mother_name)} />
                <Row icon="bxs-calendar" label="DOB" value={showDate(staff.Staff_dob)} />
                <Row icon="bx-hourglass" label="Age" value={show(staff.Staff_age)} />
                <Row icon="bx-male-female" label="Gender" value={show(staff.Staff_gender)} />
                <Row icon="bxs-droplet" label="Blood Group" value={show(staff.Staff_blood_group)} />
                <Row icon="bxs-heart" label="Marital Status" value={show(staff.Staff_marital_status)} />
                <Row
                    icon="bxs-map"
                    label="Temporary Address"
                    value={joinAddress(
                        staff.Staff_temp_address,
                        staff.Staff_temp_city,
                        staff.Staff_temp_state,
                        staff.Staff_temp_pincode
                    )}
                />
                <Row
                    icon="bxs-map"
                    label="Permanent Address"
                    value={joinAddress(
                        staff.Staff_perm_address,
                        staff.Staff_perm_city,
                        staff.Staff_perm_state,
                        staff.Staff_perm_pincode
                    )}
                />
                <Row icon="bxs-id-card" label="Aadhaar No" value={show(staff.Staff_aadhaar_no)} />
                <Row icon="bxs-id-card" label="PAN No" value={show(staff.Staff_pan_no)} />

            </Section>


            {/* JOINING DETAILS */}

            <Section title="Joining Details:">

                <Row icon="bxs-calendar" label="Joining Date" value={showDate(staff.Staff_joining_date)} />
                <Row icon="bxs-briefcase" label="Designation" value={show(staff.Staff_designation)} />
                <Row icon="bxs-institution" label="Department" value={show(staff.Staff_department)} />
                <Row icon="bxs-user-badge" label="Staff Type" value={show(staff.Staff_type)} />
                <Row icon="bxs-wallet" label="Salary (Monthly)" value={show(staff.Staff_salary)} />
                <Row icon="bx-power-off" label="Status" value={show(staff.Staff_Status)} />

            </Section>


            {/* EDUCATION */}

            <Section title="Education Details:">

                {education.length === 0 ? (

                    <p className="view-empty">No education details added.</p>

                ) : (

                    education.map((e, i) => (

                        <div className="view-entry" key={i}>

                            <Row icon="bxs-graduation" label="Qualification" value={show(e.qualification)} />
                            <Row icon="bxs-book" label="Degree" value={show(e.degree)} />
                            <Row icon="bxs-institution" label="College" value={show(e.school)} />
                            <Row icon="bxs-building" label="Board / Univ." value={show(e.board)} />
                            <Row icon="bxs-sitemap" label="Department" value={show(e.department)} />
                            <Row icon="bxs-calendar" label="Year" value={show(e.yop)} />
                            <Row icon="bx-percent" label="Percentage" value={show(e.percentage)} />

                        </div>

                    ))

                )}

            </Section>


            {/* EXPERIENCE */}

            <Section title="Experience Details:">

                <Row icon="bxs-briefcase-alt-2" label="Total Experience" value={show(staff.Staff_experience)} />
                <Row icon="bxs-bulb" label="Skills" value={show(staff.Staff_skills)} />

                {experience.map((e, i) => (

                    <div className="view-entry" key={i}>

                        <Row icon="bxs-building" label="Organisation" value={show(e.organisation)} />
                        <Row icon="bxs-user-badge" label="Designation" value={show(e.designation)} />
                        <Row
                            icon="bxs-calendar"
                            label="Period"
                            value={`${show(e.from_year)} - ${e.to_year ? e.to_year : "Present"}`}
                        />

                    </div>

                ))}

            </Section>


            {/* BANK */}

            <Section title="Bank Details:">

                {bankAccounts.length === 0 ? (

                    <p className="view-empty">No bank details added.</p>

                ) : (

                    bankAccounts.map((b, i) => (

                        <div className="view-entry" key={i}>

                            <Row icon="bxs-user" label="Account Holder Name" value={show(b.holder)} />
                            <Row icon="bxs-credit-card" label="Account No" value={show(b.account_no)} />
                            <Row icon="bxs-institution" label="IFSC" value={show(b.ifsc)} />
                            <Row icon="bxs-bank" label="Bank Name" value={show(b.bank)} />
                            <Row icon="bxs-map" label="Branch" value={show(b.branch)} />

                        </div>

                    ))

                )}

            </Section>


            {/* DOCUMENTS */}

            <Section title="Documents:">

                {documents.length > 0 ? (

                    <div className="view-docs">

                        {documents.map((d) => (

                            <a
                                key={d.key}
                                href={staff[d.key]}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="view-doc"
                            >
                                <i className="bx bx-file me-1"></i>
                                {d.label}
                            </a>

                        ))}

                    </div>

                ) : (

                    <p className="view-empty">No documents uploaded.</p>

                )}

            </Section>

        </aside>

    );

}


function StaffRegister() {

    const [addPopupVisible, setAddPopupVisible] = useState(false);
    const [updatePageVisible, setUpdatePageVisible] = useState(false);
    const [deletePageVisible, setDeletePageVisible] = useState(false);
    const [viewPageVisible, setViewPageVisible] = useState(false);

    const [currentPage, setCurrentPage] = useState(1);

    // Filters (name / department / designation / mobile / status)
    const [filters, setFilters] = useState({
        name: "",
        department: "",
        designation: "",
        mobile: "",
        status: ""
    });

    const { getData, update } = useContext(AuthContext);

    const [staffList, setStaffList] = useState([]);

    const [value, setValue] = useState(null);


    // =====================================================
    // FETCH STAFF
    // =====================================================

    const fetchStaff = useCallback(async () => {

        try {

            const data = await getData(
                "fetch_staffregister_datail"
            );

            console.log(
                "Staff fetched:",
                data
            );

            if (Array.isArray(data)) {

                setStaffList(data);

            } else {

                setStaffList([]);

            }

        } catch (err) {

            console.error(
                "Failed to fetch staff:",
                err
            );

        }

    }, [getData]);


    // =====================================================
    // INITIAL LOAD
    // =====================================================

    useEffect(() => {

        fetchStaff();

    }, [fetchStaff]);


    // =====================================================
    // ADD PAGE (swaps the list for the Addstaffregister page)
    // =====================================================

    const showAddPage = () => {

        setAddPopupVisible(true);

    };

    const hideAddPage = () => {

        setAddPopupVisible(false);

    };


    const handleStaffCreated = async () => {

        console.log(
            "New staff created. Refreshing list..."
        );

        await fetchStaff();

        setAddPopupVisible(false);

        setCurrentPage(1);

    };


    // =====================================================
    // EDIT PAGE
    // =====================================================

    const hideUpdatePage = () => {

        setUpdatePageVisible(false);

    };

    const handleStaffUpdated = async () => {

        // Fetch latest data from Django, then back to the list
        // (stay on the same pagination page)
        await fetchStaff();

        setUpdatePageVisible(false);

    };


    // =====================================================
    // DELETE PAGE (confirmation page)
    // =====================================================

    const hideDeletePage = () => {

        setDeletePageVisible(false);

    };

    const handleStaffDeleted = async () => {

        await fetchStaff();

        setDeletePageVisible(false);

        setViewPageVisible(false);

        // The current page may no longer exist after a delete
        setCurrentPage(1);

    };


    // =====================================================
    // PAGINATION + SEARCH
    // =====================================================

    const itemsPerPage = 4;

    const indexOfLastItem =
        currentPage * itemsPerPage;

    const indexOfFirstItem =
        indexOfLastItem - itemsPerPage;

    // Each filter is case-insensitive and matches only from the START of
    // the value. Status "" means All status.
    const startsWith = (value, term) =>
        String(value || "")
            .toLowerCase()
            .startsWith(term.trim().toLowerCase());

    const filteredStaff = staffList.filter(
        (s) =>
            startsWith(s.Staff_name, filters.name) &&
            startsWith(s.Staff_department, filters.department) &&
            startsWith(s.Staff_designation, filters.designation) &&
            startsWith(s.Staff_mobile, filters.mobile) &&
            (filters.status === "" || s.Staff_Status === filters.status)
    );

    const handleFilter = (key, value) => {

        // clean the value before it is stored (blocks invalid characters)
        const clean = SANITIZERS[key] ? SANITIZERS[key](value) : value;

        setFilters((prev) => ({ ...prev, [key]: clean }));

        setCurrentPage(1);

    };

    // paste is cleaned the same way as typing
    const handlePasteFilter = (key) => (e) => {

        e.preventDefault();

        handleFilter(key, e.clipboardData.getData("text"));

    };

    const currentStaff =
        filteredStaff.slice(
            indexOfFirstItem,
            indexOfLastItem
        );


    const nextPage = () => {

        if (
            indexOfLastItem <
            filteredStaff.length
        ) {

            setCurrentPage(
                currentPage + 1
            );

        }

    };


    const prevPage = () => {

        if (currentPage > 1) {

            setCurrentPage(
                currentPage - 1
            );

        }

    };


    // =====================================================
    // UPDATE
    // =====================================================

    const handleUpdate = (staff) => {

        setValue(staff);

        setUpdatePageVisible(true);

    };


    // =====================================================
    // VIEW (read-only details page)
    // =====================================================

    const handleView = (staff) => {

        setValue(staff);

        setViewPageVisible(true);

    };

    const hideViewPage = () => {

        setViewPageVisible(false);

    };


    // =====================================================
    // DELETE
    // =====================================================

    const handleDelete = (staff) => {

        setValue(staff);

        setDeletePageVisible(true);

    };


    // =====================================================
    // STATUS BUTTON (Active / Deactive — click to switch)
    // =====================================================

    const handleToggleStatus = async (staff) => {

        const newStatus =
            staff.Staff_Status === "Active"
                ? "Deactive"
                : "Active";

        // Only the id + status are sent, so no file has to be re-uploaded
        const payload = {
            Staff_id: staff.Staff_id,
            Staff_Status: newStatus
        };

        try {

            await update(
                payload,
                "update_staffregister_datail",
                "/staffregister"
            );

            await fetchStaff();

        } catch (err) {

            console.error(
                "Failed to toggle status:",
                err
            );

        }

    };


    // =====================================================
    // ADD PAGE VIEW
    // =====================================================

    if (addPopupVisible) {

        return (

            <Addstaffregister
                toggle={hideAddPage}
                onSuccess={handleStaffCreated}
                existingStaff={staffList}
            />

        );

    }


    // =====================================================
    // EDIT PAGE VIEW
    // =====================================================

    if (updatePageVisible && value) {

        return (

            <Updatestaffregister
                toggle={hideUpdatePage}
                onSuccess={handleStaffUpdated}
                data={value}
                existingStaff={staffList}
            />

        );

    }


    // =====================================================
    // DELETE PAGE VIEW
    // =====================================================

    if (deletePageVisible && value) {

        return (

            <Deletestaffregister
                toggle={hideDeletePage}
                onSuccess={handleStaffDeleted}
                data={value}
            />

        );

    }


    return (

        <div className="staffregister-page container-xxl flex-grow-1 container-p-y">


            {/* ================================================= */}
            {/* HEADER */}
            {/* ================================================= */}

            <div className="page-header">

                <div>

                    <h3 className="page-title">
                        Staff Register Management
                    </h3>

                    <p className="page-subtitle">
                        Manage all registered staff
                    </p>

                </div>


                <button
                    className="btn btn-primary add-btn"
                    onClick={showAddPage}
                >

                    <i className="bx bx-plus me-2"></i>

                    Add Staff

                </button>

            </div>


            {/* ================================================= */}
            {/* STAFF TABLE */}
            {/* ================================================= */}

            <div className={viewPageVisible && value ? "staffregister-split with-panel" : "staffregister-split"}>

            <div className="card staffregister-card">

                {/* FILTER BAR */}
                <div className="staffregister-filter-bar">

                    <div className="filter-field">
                        <i className="bx bx-user"></i>
                        <input
                        type="text"
                        className="form-control"
                        placeholder="Search by name"
                        maxLength={SEARCH_MAX.name}
                        autoComplete="off"
                        onPaste={handlePasteFilter("name")}
                        value={filters.name}
                        onChange={(e) =>
                            handleFilter("name", e.target.value)
                        }
                    />
                    </div>

                    <div className="filter-field">
                        <i className="bx bx-building-house"></i>
                        <input
                        type="text"
                        className="form-control"
                        placeholder="Search by department"
                        maxLength={SEARCH_MAX.department}
                        autoComplete="off"
                        onPaste={handlePasteFilter("department")}
                        value={filters.department}
                        onChange={(e) =>
                            handleFilter("department", e.target.value)
                        }
                    />
                    </div>

                    <div className="filter-field">
                        <i className="bx bx-briefcase"></i>
                        <input
                        type="text"
                        className="form-control"
                        placeholder="Search by designation"
                        maxLength={SEARCH_MAX.designation}
                        autoComplete="off"
                        onPaste={handlePasteFilter("designation")}
                        value={filters.designation}
                        onChange={(e) =>
                            handleFilter("designation", e.target.value)
                        }
                    />
                    </div>

                    <div className="filter-field">
                        <i className="bx bx-phone"></i>
                        <input
                        type="text"
                        inputMode="numeric"
                        className="form-control"
                        placeholder="Search by mobile"
                        maxLength={SEARCH_MAX.mobile}
                        autoComplete="off"
                        onPaste={handlePasteFilter("mobile")}
                        value={filters.mobile}
                        onChange={(e) =>
                            handleFilter("mobile", e.target.value)
                        }
                    />

                    {mobileHint(filters.mobile) && (
                        <span className="filter-hint">
                            {mobileHint(filters.mobile)}
                        </span>
                    )}
                    </div>

                    <div className="filter-field">
                        <i className="bx bx-filter-alt"></i>
                        <select
                        className="form-select"
                        value={filters.status}
                        onChange={(e) =>
                            handleFilter("status", e.target.value)
                        }
                    >
                        <option value="">All status</option>
                        <option value="Active">Active</option>
                        <option value="Deactive">Deactive</option>
                    </select>
                    </div>

                </div>

                <div className="table-responsive">

                    <table className="table modern-table">

                        <thead>
                            <tr>
                                <th><i className="bx bx-hash me-1"></i>ID</th>
                                <th><i className="bx bx-user me-1"></i>Staff Name</th>
                                <th><i className="bx bx-phone me-1"></i>Mobile</th>
                                <th><i className="bx bx-envelope me-1"></i>Email</th>
                                <th><i className="bx bx-building-house me-1"></i>Department</th>
                                <th><i className="bx bx-briefcase me-1"></i>Designation</th>
                                <th><i className="bx bx-toggle-left me-1"></i>Status</th>
                                <th title="View" aria-label="View"><i className="bx bx-show"></i></th>
                                <th><i className="bx bx-cog me-1"></i>Action</th>
                            </tr>
                        </thead>


                        <tbody>

                            {currentStaff.length > 0 ? (

                                currentStaff.map(
                                    (staff) => (

                                        <tr
                                            key={staff.Staff_id}
                                            className={
                                                viewPageVisible && value &&
                                                value.Staff_id === staff.Staff_id
                                                    ? "row-selected"
                                                    : ""
                                            }
                                        >
                                            <td>
                                                #{staff.Staff_id}
                                            </td>


                                            <td>

                                                <div className="staff-name-cell">

                                                    {staff.Staff_photo ? (

                                                        <img
                                                            className="staff-avatar"
                                                            src={staff.Staff_photo}
                                                            alt={staff.Staff_name}
                                                        />

                                                    ) : (

                                                        <span className="staff-avatar">
                                                            {String(staff.Staff_name || "?")
                                                                .charAt(0)
                                                                .toUpperCase()}
                                                        </span>

                                                    )}

                                                    <div className="staff-name-text">

                                                        <strong title={staff.Staff_name}>
                                                            {staff.Staff_name}
                                                        </strong>

                                                        <span className="staff-sub">
                                                            {staff.Staff_gender || "-"}
                                                            {staff.Staff_age
                                                                ? ` · ${staff.Staff_age} yrs`
                                                                : ""}
                                                        </span>

                                                    </div>

                                                </div>

                                            </td>


                                            <td>
                                                {staff.Staff_mobile || "-"}
                                            </td>


                                            <td>
                                                {staff.Staff_email || "-"}
                                            </td>


                                            <td>
                                                {staff.Staff_department || "-"}
                                            </td>


                                            <td>
                                                {staff.Staff_designation || "-"}
                                            </td>


                                            <td>

                                                <button
                                                    type="button"
                                                    className={
                                                        staff.Staff_Status ===
                                                        "Active"
                                                            ? "status-toggle-btn active"
                                                            : "status-toggle-btn inactive"
                                                    }
                                                    onClick={() =>
                                                        handleToggleStatus(
                                                            staff
                                                        )
                                                    }
                                                    title="Click to switch status"
                                                >

                                                    <i
                                                        className={
                                                            staff.Staff_Status === "Active"
                                                                ? "bx bx-check-circle me-1"
                                                                : "bx bx-x-circle me-1"
                                                        }
                                                    ></i>

                                                    {staff.Staff_Status}

                                                </button>

                                            </td>


                                            <td>

                                                <button
                                                    type="button"
                                                    className="btn-view"
                                                    title="View details"
                                                    onClick={() =>
                                                        handleView(
                                                            staff
                                                        )
                                                    }
                                                >
                                                    <i className="bx bx-show"></i>
                                                </button>

                                            </td>


                                            <td>

                                                <div className="action-buttons">

                                                    <button
                                                        className="btn btn-edit"
                                                        title="Edit"
                                                        aria-label="Edit"
                                                        onClick={() =>
                                                            handleUpdate(
                                                                staff
                                                            )
                                                        }
                                                    >
                                                        <i className="bx bx-edit-alt"></i>
                                                    </button>


                                                    <button
                                                        className="btn btn-delete"
                                                        title="Delete"
                                                        aria-label="Delete"
                                                        onClick={() =>
                                                            handleDelete(
                                                                staff
                                                            )
                                                        }
                                                    >
                                                        <i className="bx bx-trash"></i>
                                                    </button>

                                                </div>

                                            </td>

                                        </tr>

                                    )
                                )

                            ) : (

                                <tr>

                                    <td
                                        colSpan="9"
                                        className="text-center py-4"
                                    >

                                        <i className="bx bx-user-x me-1"></i>
                                        No staff found.

                                    </td>

                                </tr>

                            )}

                        </tbody>

                    </table>

                </div>


                {/* ================================================= */}
                {/* PAGINATION */}
                {/* ================================================= */}

                <div className="card-footer bg-white border-0">

                    <div className="d-flex justify-content-between align-items-center flex-wrap gap-2">

                        <span className="table-count">
                            <i className="bx bx-group me-1"></i>
                            Showing{" "}
                            <strong>
                                {filteredStaff.length === 0
                                    ? 0
                                    : Math.min(indexOfLastItem, filteredStaff.length) - currentStaff.length + 1}
                                {" - "}
                                {Math.min(indexOfLastItem, filteredStaff.length)}
                            </strong>{" "}
                            of <strong>{filteredStaff.length}</strong> staff
                        </span>

                        <div className="d-flex">

                        <button
                            className="btn btn-light me-2"
                            onClick={prevPage}
                            disabled={
                                currentPage === 1
                            }
                        >

                            <i className="bx bx-chevron-left"></i>

                            Previous

                        </button>


                        <button
                            className="btn btn-primary"
                            onClick={nextPage}
                            disabled={
                                indexOfLastItem >=
                                filteredStaff.length
                            }
                        >

                            Next

                            <i className="bx bx-chevron-right ms-1"></i>

                        </button>

                        </div>

                    </div>

                </div>

            </div>

            {viewPageVisible && value && (

                <Viewstaffregister
                    className="staff-detail-margin"
                    toggle={hideViewPage}
                    data={value}
                />

            )}

            </div>

        </div>

    );

}


export default StaffRegister;
