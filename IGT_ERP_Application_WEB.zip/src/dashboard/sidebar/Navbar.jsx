import React, { useContext, useEffect, useRef, useState } from "react";
import AuthContext from "../../services/AuthContext";
// import "./sidebar.css";
import { toggleMobileMenu } from "./layoutMenu";
import avatar from "../../assets/img/avatars/images.jpeg";

const Navbar = () => {
  const { logoutUser } = useContext(AuthContext);
  const [dropdownOpen, setDropdownOpen] = useState(false); // user menu
  const [notifyOpen, setNotifyOpen] = useState(false); // bell menu
  const searchRef = useRef(null);

  const handleUpdate = async () => {
    logoutUser();
  };

  const toggleDropdown = () => {
    setNotifyOpen(false);
    setDropdownOpen((prev) => !prev);
  };

  const toggleNotify = () => {
    setDropdownOpen(false);
    setNotifyOpen((prev) => !prev);
  };

  // CTRL + K (or CMD + K) focuses the search box
  useEffect(() => {
    const onKeyDown = (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        searchRef.current?.focus();
      }
      if (e.key === "Escape") {
        setDropdownOpen(false);
        setNotifyOpen(false);
      }
    };
    document.addEventListener("keydown", onKeyDown);
    return () => document.removeEventListener("keydown", onKeyDown);
  }, []);

  // Click anywhere outside a dropdown closes it
  useEffect(() => {
    const onMouseDown = (e) => {
      if (!e.target.closest(".navbar-dropdown")) {
        setDropdownOpen(false);
        setNotifyOpen(false);
      }
    };
    document.addEventListener("mousedown", onMouseDown);
    return () => document.removeEventListener("mousedown", onMouseDown);
  }, []);

  return (
    <div>
      <nav
        className="layout-navbar container-xxl navbar navbar-expand-xl navbar-detached align-items-center bg-navbar-theme"
        id="layout-navbar"
      >
        {/* hamburger (mobile only) */}
        <div className="layout-menu-toggle navbar-nav align-items-xl-center me-3 me-xl-0 d-xl-none">
          <button
            type="button"
            className="nav-item nav-link px-0 me-xl-4 border-0 bg-transparent"
            onClick={toggleMobileMenu}
            aria-label="Open menu"
          >
            <i className="bx bx-menu bx-sm"></i>
          </button>
        </div>

        {/* search */}
        <div className="navbar-search">
          <i className="bx bx-search"></i>
          <input
            ref={searchRef}
            type="text"
            className="navbar-search-input"
            placeholder="Search [CTRL + K]"
            aria-label="Search"
          />
        </div>

        <ul className="navbar-nav flex-row align-items-center ms-auto navbar-actions">
          {/* language */}
          <li className="nav-item">
            <button type="button" className="navbar-icon-btn" title="Language">
              <i className="bx bx-globe"></i>
            </button>
          </li>

          {/* theme / display */}
          <li className="nav-item">
            <button type="button" className="navbar-icon-btn" title="Theme">
              <i className="bx bx-desktop"></i>
            </button>
          </li>

          {/* quick links */}
          <li className="nav-item">
            <button type="button" className="navbar-icon-btn" title="Shortcuts">
              <i className="bx bx-grid-alt"></i>
            </button>
          </li>

          {/* notifications */}
          <li className={`nav-item navbar-dropdown dropdown ${notifyOpen ? "show" : ""}`}>
            <button
              type="button"
              className="navbar-icon-btn"
              title="Notifications"
              onClick={toggleNotify}
              aria-expanded={notifyOpen}
            >
              <i className="bx bx-bell"></i>
              <span className="navbar-badge-dot"></span>
            </button>
            <ul className={`dropdown-menu dropdown-menu-end ${notifyOpen ? "show" : ""}`}>
              <li>
                <div className="dropdown-header fw-semibold text-body">Notifications</div>
              </li>
              <li><div className="dropdown-divider"></div></li>
              <li>
                <div className="dropdown-item text-muted">No new notifications</div>
              </li>
            </ul>
          </li>

          {/* user menu */}
          <li className={`nav-item navbar-dropdown dropdown-user dropdown ${dropdownOpen ? "show" : ""}`}>
            <button
              type="button"
              className="navbar-icon-btn navbar-avatar-btn"
              onClick={toggleDropdown}
              aria-expanded={dropdownOpen}
            >
              <div className="avatar avatar-online">
                <img src={avatar} alt="profile" className="w-px-40 h-auto  rounded-circle"/>
              </div>
            </button>
            <ul className={`dropdown-menu dropdown-menu-end ${dropdownOpen ? "show" : ""}`}>
              <li>
                <div className="dropdown-item">
                  <div className="d-flex">
                    <div className="flex-shrink-0 me-3">
                      <div className="avatar avatar-online">
                        <img src={avatar} alt="profile" className="w-px-40 h-auto rounded-circle" />
                      </div>
                    </div>
                    <div className="flex-grow-1">
                      <span className="fw-semibold d-block">John Doe</span>
                      <small className="text-muted">Admin</small>
                    </div>
                  </div>
                </div>
              </li>
              <li><div className="dropdown-divider"></div></li>
              <li>
                <button type="button" className="dropdown-item">
                  <i className="bx bx-user me-2"></i>
                  <span className="align-middle">My Profile</span>
                </button>
              </li>
              <li>
                <button type="button" className="dropdown-item">
                  <i className="bx bx-cog me-2"></i>
                  <span className="align-middle">Settings</span>
                </button>
              </li>
              <li>
                <button type="button" className="dropdown-item">
                  <span className="d-flex align-items-center align-middle">
                    <i className="flex-shrink-0 bx bx-credit-card me-2"></i>
                    <span className="flex-grow-1 align-middle">Billing</span>
                    <span className="flex-shrink-0 badge badge-center rounded-pill bg-danger w-px-20 h-px-20">4</span>
                  </span>
                </button>
              </li>
              <li><div className="dropdown-divider"></div></li>
              <li>
                <button type="button" className="dropdown-item" onClick={handleUpdate}>
                  <i className="bx bx-power-off me-2"></i>
                  <span className="align-middle">Log Out</span>
                </button>
              </li>
            </ul>
          </li>
        </ul>
      </nav>
    </div>
  );
};

export default Navbar;
