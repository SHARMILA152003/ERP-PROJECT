import React, { useEffect, useMemo, useState } from "react";
import { Link, NavLink, useLocation } from "react-router-dom";
import SidebarData from "../../assets/json/sidebar.json";
import "./sidebar.css";
import logoFull from "../../assets/img/logo/igt_logo.png";
import logoMark from "../../assets/img/logo/igt_logo_mark.png";
import {
  closeMobileMenu,
  isCollapsed,
  isDesktop,
  setHover,
  toggleSidebar,
} from "./layoutMenu";

// Icon shown before each section name (MASTER, ACADEMIC ...)
const SECTION_ICONS = {
  Master: "bx bx-data",
  Admission: "bx bx-user-plus",
  Academic: "bx bx-book-reader",
  Payment: "bx bx-rupee",
  Staff: "bx bx-group",
  Report: "bx bx-bar-chart-alt-2",
  Settings: "bx bx-cog",
};

// true when this menu item (or anything nested under it) is the current page
const isBranchActive = (item, pathname) =>
  item.path === pathname ||
  (Array.isArray(item.subNav) &&
    item.subNav.some((sub) => isBranchActive(sub, pathname)));

// keys ("3", "3-1", "3-1-0" ...) of every parent that must be open to show the current page
const collectOpenKeys = (items, pathname, prefix = "") => {
  let keys = [];
  items.forEach((item, i) => {
    const key = prefix === "" ? `${i}` : `${prefix}-${i}`;
    if (Array.isArray(item.subNav) && isBranchActive(item, pathname)) {
      keys.push(key);
      keys = keys.concat(collectOpenKeys(item.subNav, pathname, key));
    }
  });
  return keys;
};

const Sidebar = () => {
  const location = useLocation();

  // Group the flat menu into sections (Master, Admission, ...).
  // A new section starts at every item that has a "main" heading.
  const sections = useMemo(() => {
    const groups = [];
    SidebarData.forEach((item, index) => {
      if (item.main || groups.length === 0) {
        groups.push({ name: item.main || "Menu", items: [] });
      }
      groups[groups.length - 1].items.push({ item, index });
    });
    return groups;
  }, []);

  // open / closed state of every expandable menu, by key
  // (the page you are on starts open, so nothing animates on first load)
  const [openMenus, setOpenMenus] = useState(() => {
    const initial = {};
    collectOpenKeys(SidebarData, location.pathname).forEach((k) => {
      initial[k] = true;
    });
    return initial;
  });

  // Sections (Master, Admission ...) are opened / closed one by one
  const [openSections, setOpenSections] = useState(() => {
    const found = sections.findIndex(({ items }) =>
      items.some(({ item }) => isBranchActive(item, location.pathname))
    );
    return found >= 0 ? { [found]: true } : {};
  });

  // Open the section + parent menus that contain the page currently shown
  useEffect(() => {
    const found = sections.findIndex(({ items }) =>
      items.some(({ item }) => isBranchActive(item, location.pathname))
    );

    if (found >= 0) {
      setOpenSections((prev) => ({ ...prev, [found]: true }));
    }

    const keys = collectOpenKeys(SidebarData, location.pathname);
    if (keys.length) {
      setOpenMenus((prev) => {
        const next = { ...prev };
        keys.forEach((k) => {
          next[k] = true;
        });
        return next;
      });
    }
  }, [location.pathname, sections]);

  // Click on a section heading: open it or close it (other sections stay as they are)
  const toggleSection = (sectionIndex) =>
    setOpenSections((prev) => ({ ...prev, [sectionIndex]: !prev[sectionIndex] }));

  // Click on an expandable menu. Top-level menus work like an accordion
  // (opening one closes the other top-level menus); nested ones are independent.
  const toggleMenu = (key, level) =>
    setOpenMenus((prev) => {
      const next = { ...prev };
      if (level === 0) {
        Object.keys(next).forEach((k) => {
          if (!k.includes("-")) next[k] = false;
        });
      }
      next[key] = !prev[key];
      return next;
    });

  // Clicking a plain top-level page closes the other top-level menus
  const closeTopLevelMenus = () =>
    setOpenMenus((prev) => {
      const next = { ...prev };
      Object.keys(next).forEach((k) => {
        if (!k.includes("-")) next[k] = false;
      });
      return next;
    });

  // Desktop (>= 1200px): the round chevron collapses the menu to icons only.
  // Mobile / tablet (< 1200px): the menu is a drawer - the chevron, the dark
  // overlay, the Escape key and opening any page all close it.
  // The state lives on <html> (see layoutMenu.js) so the navbar hamburger and
  // this component always agree.
  useEffect(() => {
    const onResize = () => {
      if (isDesktop()) closeMobileMenu(); // drawer mode ended - unlock the page
      else setHover(false); // hover-expand only exists on desktop
    };
    const onKeyDown = (e) => {
      if (e.key === "Escape") closeMobileMenu();
    };
    window.addEventListener("resize", onResize);
    document.addEventListener("keydown", onKeyDown);
    return () => {
      window.removeEventListener("resize", onResize);
      document.removeEventListener("keydown", onKeyDown);
      closeMobileMenu();
      setHover(false);
    };
  }, []);

  // Every page change closes the mobile drawer
  useEffect(() => {
    closeMobileMenu();
  }, [location.pathname]);

  // When collapsed, hovering the menu temporarily expands it (desktop only)
  const handleMouseEnter = () => {
    if (isDesktop() && isCollapsed()) setHover(true);
  };
  const handleMouseLeave = () => setHover(false);

  // One menu row. Works for any depth: level 0 = main menu, 1 = sub menu,
  // 2 = sub-sub menu ... (anything with a "subNav" list becomes expandable)
  const renderItem = (item, key, level) => {
    const hasSub = Array.isArray(item.subNav) && item.subNav.length > 0;
    const isOpen = !!openMenus[key];
    const isCurrent = item.path === location.pathname;
    const isActive = isBranchActive(item, location.pathname);
    const title = (item.title || "").trim();

    return (
      <li
        key={key}
        className={`menu-item menu-level-${level} ${isActive ? "active" : ""} ${
          isCurrent ? "is-current" : ""
        } ${hasSub && isOpen ? "open" : ""}`}
      >
        {hasSub ? (
          <a
            href="#!"
            className="menu-link menu-toggle"
            onClick={(e) => {
              e.preventDefault();
              toggleMenu(key, level);
            }}
            aria-expanded={isOpen ? "true" : "false"}
          >
            {level === 0 && item.icon && <i className={item.icon}></i>}
            <div>{title}</div>
          </a>
        ) : (
          <NavLink
            to={item.path}
            className={`menu-link ${isCurrent ? "current" : ""}`}
            onClick={() => {
              if (level === 0) closeTopLevelMenus();
              closeMobileMenu(); // also covers clicking the page you are already on
            }}
          >
            {level === 0 && item.icon && <i className={item.icon}></i>}
            <div>{title}</div>
          </NavLink>
        )}

        {hasSub && (
          <div className="menu-collapse" aria-hidden={!isOpen}>
            <div className="menu-collapse-inner">
              <ul className="menu-sub">
                {item.subNav.map((sub, i) =>
                  renderItem(sub, `${key}-${i}`, level + 1)
                )}
              </ul>
            </div>
          </div>
        )}
      </li>
    );
  };

  return (
    <>
      <div
        id="layout-menu"
        className="layout-menu menu-vertical menu bg-menu-theme"
        onMouseEnter={handleMouseEnter}
        onMouseLeave={handleMouseLeave}
      >
        <div className="app-brand demo">
          <Link to="/dashboard" className="app-brand-link" aria-label="IGT Infogro Technology - Dashboard">
            {/* full logo when the menu is open; the theme (core.css) swaps in the IGT emblem when it is collapsed */}
            <img className="app-brand-img" src={logoFull} alt="IGT Infogro Technology" />
            <img className="app-brand-img-collapsed" src={logoMark} alt="IGT" />
          </Link>

          {/* round collapse button on the sidebar edge */}
          <button
            type="button"
            className="layout-menu-toggle-btn"
            onClick={toggleSidebar}
            aria-label="Toggle menu"
          >
            <i className="bx bx-chevron-left"></i>
          </button>
        </div>

        <div className="menu-inner-shadow"></div>

        <ul className="menu-scroll-container">
          {/* DASHBOARD */}
          <li
            className={`menu-item menu-dashboard ${
              location.pathname === "/dashboard" ? "active is-current" : ""
            }`}
          >
            <Link to="/dashboard" className="menu-link" onClick={closeMobileMenu}>
              <i className="menu-icon tf-icons bx bx-home-circle"></i>
              <div>Dashboard</div>
            </Link>
          </li>

          {/* SECTIONS: every section is a card with a +/- button */}
          {sections.map((section, sectionIndex) => {
            const open = !!openSections[sectionIndex];

            return (
              <li
                key={section.name}
                className={`menu-section ${open ? "open" : ""}`}
              >
                <div
                  className="menu-header menu-section-toggle"
                  role="button"
                  tabIndex={0}
                  aria-expanded={open ? "true" : "false"}
                  onClick={() => toggleSection(sectionIndex)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" || e.key === " ") {
                      e.preventDefault();
                      toggleSection(sectionIndex);
                    }
                  }}
                >
                  <span className="menu-section-label">
                    <i
                      className={`${
                        SECTION_ICONS[section.name] || "bx bx-folder"
                      } menu-section-title-icon`}
                    ></i>
                    <span className="menu-header-text">{section.name}</span>
                  </span>

                  <span className="menu-section-icon">
                    <i className={`bx ${open ? "bx-minus" : "bx-plus"}`}></i>
                  </span>
                </div>

                <div className="menu-collapse" aria-hidden={!open}>
                  <div className="menu-collapse-inner">
                    <ul className="menu-section-items">
                      {section.items.map(({ item, index }) =>
                        renderItem(item, `${index}`, 0)
                      )}
                    </ul>
                  </div>
                </div>
              </li>
            );
          })}
        </ul>
      </div>
      {/* dark backdrop behind the mobile drawer - tap it to close */}
      <div className="layout-overlay" onClick={closeMobileMenu} aria-hidden="true"></div>
    </>
  );
};

export default Sidebar;
