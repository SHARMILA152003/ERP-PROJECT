import React, { useContext, useEffect, useRef, useState } from "react";
import AuthContext from "../../services/AuthContext";
// import "./sidebar.css";
import { toggleMobileMenu } from "./layoutMenu";
import { useTheme } from "../../services/ThemeContext";
import avatar from "../../assets/img/avatars/images.jpeg";

// choices shown in the theme menu (icon = boxicons class)
const THEME_OPTIONS = [
  { value: "light", label: "Light", icon: "bx-sun" },
  { value: "dark", label: "Dark", icon: "bx-moon" },
  { value: "system", label: "System", icon: "bx-desktop" },
];

// ---- logged-in user (name + role shown in the profile dropdown) ----
// Uses the AuthContext user first, then the "user" saved in localStorage at login.
const readStored = (key) => {
  try {
    return JSON.parse(localStorage.getItem(key));
  } catch (e) {
    return null;
  }
};

const getUserInfo = (ctxUser) => {
  const u =
    (ctxUser && typeof ctxUser === "object" ? ctxUser : null) ||
    readStored("user") ||
    {};

  const full = [u.first_name, u.last_name].filter(Boolean).join(" ");
  const name =
    u.full_name || u.name || full || u.username || u.user_name || u.email || "User";
  const role =
    u.role || u.user_type || u.designation || (u.is_superuser ? "Admin" : "") || "Admin";

  return { name: String(name), role: String(role) };
};

const Navbar = () => {
  const { logoutUser, user } = useContext(AuthContext);
  const { name: userName, role: userRole } = getUserInfo(user);
  const { mode, setMode } = useTheme();
  const [dropdownOpen, setDropdownOpen] = useState(false); // user menu
  const [notifyOpen, setNotifyOpen] = useState(false); // bell menu
  const [themeOpen, setThemeOpen] = useState(false); // theme menu
  const currentTheme = THEME_OPTIONS.find((o) => o.value === mode) || THEME_OPTIONS[0];
  const searchRef = useRef(null);

  const handleUpdate = async () => {
    logoutUser();
  };

  const toggleDropdown = () => {
    setNotifyOpen(false);
    setThemeOpen(false);
    setDropdownOpen((prev) => !prev);
  };

  const toggleNotify = () => {
    setDropdownOpen(false);
    setThemeOpen(false);
    setNotifyOpen((prev) => !prev);
  };

  const toggleThemeMenu = () => {
    setDropdownOpen(false);
    setNotifyOpen(false);
    setThemeOpen((prev) => !prev);
  };

  const chooseTheme = (value) => {
    setMode(value);
    setThemeOpen(false);
  };

  // CTRL + K (or CMD + K) focuses the search box
  useEffect(() => {
    const onKeyDown = (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        searchRef.current?.focus();
      }
      if (e.key === "Escape") {
        setDropdownOpen(false);
        setNotifyOpen(false);
        setThemeOpen(false);
      }
    };
    document.addEventListener("keydown", onKeyDown);
    return () => document.removeEventListener("keydown", onKeyDown);
  }, []);

  // Click anywhere outside a dropdown closes it
  useEffect(() => {
    const onMouseDown = (e) => {
      if (!e.target.closest(".navbar-dropdown")) {
        setDropdownOpen(false);
        setNotifyOpen(false);
        setThemeOpen(false);
      }
    };
    document.addEventListener("mousedown", onMouseDown);
    return () => document.removeEventListener("mousedown", onMouseDown);
  }, []);

  return (
    <div>
      <nav
        className="layout-navbar container-xxl navbar navbar-expand-xl navbar-detached align-items-center bg-navbar-theme"
        id="layout-navbar"
      >
        {/* hamburger (mobile only) */}
        <div className="layout-menu-toggle navbar-nav align-items-xl-center me-3 me-xl-0 d-xl-none">
          <button
            type="button"
            className="nav-item nav-link px-0 me-xl-4 border-0 bg-transparent"
            onClick={toggleMobileMenu}
            aria-label="Open menu"
          >
            <i className="bx bx-menu bx-sm"></i>
          </button>
        </div>

        {/* search */}
        <div className="navbar-search">
          <i className="bx bx-search"></i>
          <input
            ref={searchRef}
            type="text"
            className="navbar-search-input"
            placeholder="Search [CTRL + K]"
            aria-label="Search"
          />
        </div>

        <ul className="navbar-nav flex-row align-items-center ms-auto navbar-actions">
          {/* language */}
          <li className="nav-item">
            <button type="button" className="navbar-icon-btn" title="Language">
              <i className="bx bx-globe"></i>
            </button>
          </li>

          {/* theme: Light / Dark / System */}
          <li className={`nav-item navbar-dropdown navbar-theme dropdown ${themeOpen ? "show" : ""}`}>
            <button
              type="button"
              className="navbar-icon-btn"
              title={`Theme: ${currentTheme.label}`}
              aria-label={`Theme: ${currentTheme.label}. Change theme`}
              aria-haspopup="menu"
              aria-expanded={themeOpen}
              onClick={toggleThemeMenu}
            >
              <i className={`bx ${currentTheme.icon}`}></i>
            </button>
            <ul
              className={`dropdown-menu dropdown-menu-end navbar-theme-menu ${themeOpen ? "show" : ""}`}
              role="menu"
            >
              {THEME_OPTIONS.map((option) => (
                <li key={option.value}>
                  <button
                    type="button"
                    role="menuitemradio"
                    aria-checked={mode === option.value}
                    className={`dropdown-item theme-option ${mode === option.value ? "active" : ""}`}
                    onClick={() => chooseTheme(option.value)}
                  >
                    <i className={`bx ${option.icon} me-2`}></i>
                    <span className="align-middle">{option.label}</span>
                  </button>
                </li>
              ))}
            </ul>
          </li>

          {/* quick links */}
          <li className="nav-item">
            <button type="button" className="navbar-icon-btn" title="Shortcuts">
              <i className="bx bx-grid-alt"></i>
            </button>
          </li>

          {/* notifications */}
          <li className={`nav-item navbar-dropdown dropdown ${notifyOpen ? "show" : ""}`}>
            <button
              type="button"
              className="navbar-icon-btn"
              title="Notifications"
              onClick={toggleNotify}
              aria-expanded={notifyOpen}
            >
              <i className="bx bx-bell"></i>
              <span className="navbar-badge-dot"></span>
            </button>
            <ul className={`dropdown-menu dropdown-menu-end ${notifyOpen ? "show" : ""}`}>
              <li>
                <div className="dropdown-header fw-semibold text-body">Notifications</div>
              </li>
              <li><div className="dropdown-divider"></div></li>
              <li>
                <div className="dropdown-item text-muted">No new notifications</div>
              </li>
            </ul>
          </li>

          {/* user menu */}
          <li className={`nav-item navbar-dropdown dropdown-user dropdown ${dropdownOpen ? "show" : ""}`}>
            <button
              type="button"
              className="navbar-icon-btn navbar-avatar-btn"
              onClick={toggleDropdown}
              aria-expanded={dropdownOpen}
            >
              <div className="avatar avatar-online">
                <img src={avatar} alt="profile" className="w-px-40 h-auto  rounded-circle"/>
              </div>
            </button>
            <ul className={`dropdown-menu dropdown-menu-end ${dropdownOpen ? "show" : ""}`}>
              <li>
                <div className="dropdown-item">
                  <div className="d-flex">
                    <div className="flex-shrink-0 me-3">
                      <div className="avatar avatar-online">
                        <img src={avatar} alt="profile" className="w-px-40 h-auto rounded-circle" />
                      </div>
                    </div>
                    <div className="flex-grow-1">
                      <span className="fw-semibold d-block">{userName}</span>
                      <small className="text-muted">{userRole}</small>
                    </div>
                  </div>
                </div>
              </li>
              <li><div className="dropdown-divider"></div></li>
              <li>
                <button type="button" className="dropdown-item">
                  <i className="bx bx-user me-2"></i>
                  <span className="align-middle">My Profile</span>
                </button>
              </li>
              <li>
                <button type="button" className="dropdown-item">
                  <i className="bx bx-cog me-2"></i>
                  <span className="align-middle">Settings</span>
                </button>
              </li>
              <li>
                <button type="button" className="dropdown-item">
                  <span className="d-flex align-items-center align-middle">
                    <i className="flex-shrink-0 bx bx-credit-card me-2"></i>
                    <span className="flex-grow-1 align-middle">Billing</span>
                    <span className="flex-shrink-0 badge badge-center rounded-pill bg-danger w-px-20 h-px-20">4</span>
                  </span>
                </button>
              </li>
              <li><div className="dropdown-divider"></div></li>
              <li>
                <button type="button" className="dropdown-item" onClick={handleUpdate}>
                  <i className="bx bx-power-off me-2"></i>
                  <span className="align-middle">Log Out</span>
                </button>
              </li>
            </ul>
          </li>
        </ul>
      </nav>
    </div>
  );
};

export default Navbar;
