// Shared sidebar state.
//
// The state lives on <html> (the same classes Sneat's own JS uses), so the
// sidebar, the navbar hamburger and the CSS always agree - there is no second
// copy of the state that can get out of sync.
//
//   layout-menu-collapsed  desktop (>= 1200px): menu shrunk to icons only
//   layout-menu-hover      desktop: collapsed menu temporarily opened by hover
//   layout-menu-expanded   mobile / tablet (< 1200px): drawer is open

const root = () => document.documentElement;

export const DESKTOP_MIN_WIDTH = 1200; // Bootstrap "xl" - same breakpoint as the CSS

export const isDesktop = () => window.innerWidth >= DESKTOP_MIN_WIDTH;

// ---- mobile / tablet drawer ----
export const isMobileMenuOpen = () =>
  root().classList.contains("layout-menu-expanded");

export const openMobileMenu = () => root().classList.add("layout-menu-expanded");

export const closeMobileMenu = () =>
  root().classList.remove("layout-menu-expanded");

export const toggleMobileMenu = () =>
  isMobileMenuOpen() ? closeMobileMenu() : openMobileMenu();

// ---- desktop collapse ----
export const isCollapsed = () =>
  root().classList.contains("layout-menu-collapsed");

export const setHover = (on) =>
  root().classList.toggle("layout-menu-hover", on);

export const setCollapsed = (collapsed) => {
  root().classList.toggle("layout-menu-collapsed", collapsed);
  if (!collapsed) setHover(false);
};

// The round chevron on the sidebar edge:
// desktop -> collapse / expand, mobile -> close the drawer
export const toggleSidebar = () => {
  if (isDesktop()) setCollapsed(!isCollapsed());
  else closeMobileMenu();
};
