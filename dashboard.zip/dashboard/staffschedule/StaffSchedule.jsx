import React, {
    useState,
    useContext,
    useEffect,
    useCallback,
    useMemo
} from "react";

import "./StaffSchedule.css";

import Addstaffschedule, {
    staffCode,
    toDateKey,
    formatDate,
    formatTime
} from "./addstaffschedule/Addstaffschedule";
import Updatestaffschedule from "./updatestaffschedule/Updatestaffschedule";
import Addstaffpermission from "./addstaffpermission/Addstaffpermission";
import Deletestaffschedule from "./deletestaffschedule/Deletestaffschedule";
import Viewstaffpermission from "./viewstaffpermission/Viewstaffpermission";

import AuthContext from "../../services/AuthContext";


// =====================================================
// HELPERS
// =====================================================

const show = (v) =>
    v === null || v === undefined || String(v).trim() === ""
        ? "-"
        : String(v);

const asArray = (d) => (Array.isArray(d) ? d : []);


// =====================================================
// SEARCH BOX VALIDATION (same rules as Staff Register)
// =====================================================

const SEARCH_MAX = 50;

// remove leading space + collapse repeated spaces
const tidySpaces = (v) =>
    v.replace(/^\s+/, "").replace(/\s{2,}/g, " ");

// Name: letters, space and ONE "." only
const sanitizeName = (v) => {

    let text = tidySpaces(v.replace(/[^A-Za-z .]/g, ""))
        .replace(/^\.+/, "");

    let dotSeen = false;

    text = text.replace(/\./g, () => {
        if (dotSeen) return "";
        dotSeen = true;
        return ".";
    });

    return text.slice(0, SEARCH_MAX);

};

const startsWith = (value, term) =>
    String(value || "")
        .toLowerCase()
        .startsWith(term.trim().toLowerCase());


function StaffSchedule() {

    // ---------------- page switching (same pattern as Staff Attendance) ----------------
    const [addPageVisible, setAddPageVisible] = useState(false);
    const [permissionPageVisible, setPermissionPageVisible] = useState(false);
    const [updatePageVisible, setUpdatePageVisible] = useState(false);
    const [deletePageVisible, setDeletePageVisible] = useState(false);
    const [viewStaff, setViewStaff] = useState(null);   // staff whose permission popup is open

    const [value, setValue] = useState(null);   // schedule being edited / deleted

    // ---------------- filters ----------------
    const [search, setSearch] = useState({ name: "" });

    const [currentPage, setCurrentPage] = useState(1);

    // ---------------- data ----------------
    const { getData } = useContext(AuthContext);

    const [staffList, setStaffList] = useState([]);
    const [scheduleList, setScheduleList] = useState([]);


    // =====================================================
    // FETCH
    // =====================================================

    const fetchAll = useCallback(async () => {

        try {

            const [staff, schedules] = await Promise.all([
                getData("fetch_staffregister_datail"),
                getData("fetch_staffschedule_datail")
            ]);

            console.log("Schedule data fetched:", { staff, schedules });

            setStaffList(asArray(staff));
            setScheduleList(asArray(schedules));

        } catch (err) {

            console.error("Failed to fetch schedule data:", err);

        }

    }, [getData]);

    useEffect(() => {

        fetchAll();

    }, [fetchAll]);


    // =====================================================
    // LOOKUPS
    // =====================================================

    // only Active staff can be picked in the form
    const activeStaff = useMemo(
        () => staffList.filter((s) => s.Staff_Status !== "Deactive"),
        [staffList]
    );

    // staffId -> staff row
    const staffMap = useMemo(() => {

        const map = {};

        staffList.forEach((s) => {
            map[String(s.Staff_id)] = s;
        });

        return map;

    }, [staffList]);

    // one row per schedule, newest date range first
    const rows = useMemo(
        () =>
            scheduleList
                .map((sch) => ({
                    ...sch,
                    staff: staffMap[String(sch.Staff_id)] || {}
                }))
                .sort((a, b) =>
                    toDateKey(b.Schedule_start_date).localeCompare(
                        toDateKey(a.Schedule_start_date)
                    )
                ),
        [scheduleList, staffMap]
    );


    const handleSearch = (key, sanitize) => (e) => {

        setSearch((prev) => ({ ...prev, [key]: sanitize(e.target.value) }));

        setCurrentPage(1);

    };


    // =====================================================
    // PAGINATION
    // =====================================================

    const itemsPerPage = 10;

    const filteredRows = rows.filter(
        (r) => startsWith(r.staff.Staff_name, search.name)
    );

    const indexOfLastItem = currentPage * itemsPerPage;

    const indexOfFirstItem = indexOfLastItem - itemsPerPage;

    const currentRows = filteredRows.slice(indexOfFirstItem, indexOfLastItem);

    const nextPage = () => {

        if (indexOfLastItem < filteredRows.length) setCurrentPage(currentPage + 1);

    };

    const prevPage = () => {

        if (currentPage > 1) setCurrentPage(currentPage - 1);

    };


    // =====================================================
    // ADD / EDIT / DELETE PAGES
    // =====================================================

    const showAddPage = () => setAddPageVisible(true);

    const hideAddPage = () => setAddPageVisible(false);

    const showPermissionPage = () => setPermissionPageVisible(true);

    const hidePermissionPage = () => setPermissionPageVisible(false);

    const handleScheduleSaved = async () => {

        await fetchAll();

        setAddPageVisible(false);

        setUpdatePageVisible(false);

    };

    const showUpdatePage = (row) => {

        setValue(row);

        setUpdatePageVisible(true);

    };

    const hideUpdatePage = () => setUpdatePageVisible(false);

    const showDeletePage = (row) => {

        setValue(row);

        setDeletePageVisible(true);

    };

    const showDeleteFromUpdate = () => {

        setUpdatePageVisible(false);

        setDeletePageVisible(true);

    };

    const hideDeletePage = () => setDeletePageVisible(false);

    const showViewPage = (row) =>
        setViewStaff(row.staff && row.staff.Staff_id ? row.staff : staffMap[String(row.Staff_id)] || {});

    const hideViewPage = () => setViewStaff(null);

    const handleScheduleDeleted = async () => {

        await fetchAll();

        setDeletePageVisible(false);

    };


    // =====================================================
    // ADD PAGE VIEW
    // =====================================================

    if (permissionPageVisible) {

        return (

            <Addstaffpermission
                toggle={hidePermissionPage}
                onSuccess={hidePermissionPage}
                staffList={activeStaff}
                existingSchedules={scheduleList}
            />

        );

    }


    if (addPageVisible) {

        return (

            <Addstaffschedule
                toggle={hideAddPage}
                onSuccess={handleScheduleSaved}
                staffList={activeStaff}
                existingSchedules={scheduleList}
            />

        );

    }


    // =====================================================
    // EDIT PAGE VIEW
    // =====================================================

    if (updatePageVisible && value) {

        return (

            <Updatestaffschedule
                toggle={hideUpdatePage}
                onSuccess={handleScheduleSaved}
                onDelete={showDeleteFromUpdate}
                data={value}
                staffList={staffList}
                existingSchedules={scheduleList}
            />

        );

    }


    // =====================================================
    // DELETE PAGE VIEW
    // =====================================================

    if (deletePageVisible && value) {

        return (

            <Deletestaffschedule
                toggle={hideDeletePage}
                onSuccess={handleScheduleDeleted}
                data={value}
                staff={value.staff || staffMap[String(value.Staff_id)]}
            />

        );

    }


    const firstShown =
        filteredRows.length === 0 ? 0 : indexOfFirstItem + 1;

    const lastShown = Math.min(indexOfLastItem, filteredRows.length);


    return (

        <div className="staffschedule-page container-xxl flex-grow-1 container-p-y">


            {/* ================================================= */}
            {/* HEADER */}
            {/* ================================================= */}

            <div className="page-header">

                <div>

                    <h3 className="page-title">
                        Manage Staff Schedule
                    </h3>

                    <p className="page-subtitle">
                        Set shift timings for each staff
                    </p>

                </div>


                <div className="sch-header-actions">

                    <button
                        type="button"
                        className="btn add-btn add-btn-outline"
                        onClick={showPermissionPage}
                    >

                        <i className="bx bx-time-five me-2"></i>

                        Add Permission

                    </button>

                    <button
                        type="button"
                        className="btn btn-primary add-btn"
                        onClick={showAddPage}
                    >

                        <i className="bx bx-plus me-2"></i>

                        Add Schedule

                    </button>

                </div>

            </div>


            {/* ================================================= */}
            {/* INFO BANNER */}
            {/* ================================================= */}

           
           


            {/* ================================================= */}
            {/* SCHEDULE CARD */}
            {/* ================================================= */}

            <div className="card staffschedule-card">

                {/* TOOLBAR */}
                <div className="sch-toolbar">

                    <div className="filter-field">
                        <i className="bx bx-user"></i>
                        <input
                            type="text"
                            className="form-control"
                            placeholder="Search by name"
                            maxLength={SEARCH_MAX}
                            autoComplete="off"
                            value={search.name}
                            onChange={handleSearch("name", sanitizeName)}
                        />
                    </div>

                </div>


                {/* ================================================= */}
                {/* SCHEDULE TABLE */}
                {/* ================================================= */}

                <div className="table-responsive">

                    <table className="sch-grid">

                        <thead>

                            <tr>
                                <th><i className="bx bx-hash"></i>S.No</th>
                                <th className="sch-col-name"><i className="bx bx-user"></i>Staff Name</th>
                                <th><i className="bx bx-time-five"></i>Permission</th>
                                <th><i className="bx bx-calendar"></i>Date Range</th>
                                <th><i className="bx bx-log-in-circle"></i>Shift Start</th>
                                <th><i className="bx bx-log-out-circle"></i>Shift End</th>
                                <th>Actions</th>
                            </tr>

                        </thead>


                        <tbody>

                            {currentRows.length > 0 ? (

                                currentRows.map((row, index) => (

                                    <tr key={row.Schedule_id}>

                                        <td>{indexOfFirstItem + index + 1}</td>


                                        <td className="sch-col-name">

                                            <div className="staff-name-cell">

                                                {row.staff.Staff_photo ? (

                                                    <img
                                                        className="staff-avatar"
                                                        src={row.staff.Staff_photo}
                                                        alt={row.staff.Staff_name}
                                                    />

                                                ) : (

                                                    <span className="staff-avatar">
                                                        {String(row.staff.Staff_name || "?")
                                                            .charAt(0)
                                                            .toUpperCase()}
                                                    </span>

                                                )}

                                                <div className="staff-name-text">

                                                    <strong title={row.staff.Staff_name}>
                                                        {show(row.staff.Staff_name)}
                                                    </strong>

                                                    <span className="staff-sub">
                                                        {staffCode(row.staff)}
                                                    </span>

                                                </div>

                                            </div>

                                        </td>


                                        <td>
                                            <button
                                                type="button"
                                                className="sch-view-btn"
                                                title="View permissions"
                                                onClick={() => showViewPage(row)}
                                            >
                                                <i className="bx bx-show"></i>
                                                View
                                            </button>
                                        </td>


                                        <td>
                                            <span className="sch-range">
                                                {formatDate(row.Schedule_start_date)}
                                                <i className="bx bx-right-arrow-alt"></i>
                                                {formatDate(row.Schedule_end_date)}
                                            </span>
                                        </td>

                                        <td>{formatTime(row.Schedule_shift_start)}</td>

                                        <td>{formatTime(row.Schedule_shift_end)}</td>





                                        <td>

                                            <div className="sch-actions">

                                                <button
                                                    type="button"
                                                    className="sch-icon-btn is-edit"
                                                    title="Edit schedule"
                                                    onClick={() => showUpdatePage(row)}
                                                >
                                                    <i className="bx bx-edit-alt"></i>
                                                </button>

                                                <button
                                                    type="button"
                                                    className="sch-icon-btn is-delete"
                                                    title="Delete schedule"
                                                    onClick={() => showDeletePage(row)}
                                                >
                                                    <i className="bx bx-trash"></i>
                                                </button>

                                            </div>

                                        </td>

                                    </tr>

                                ))

                            ) : (

                                <tr>

                                    <td colSpan={7} className="text-center py-4">

                                        No schedules found.

                                    </td>

                                </tr>

                            )}

                        </tbody>

                    </table>

                </div>


                {/* ================================================= */}
                {/* PAGINATION */}
                {/* ================================================= */}

                <div className="card-footer bg-white border-0">

                    <div className="d-flex justify-content-between align-items-center flex-wrap gap-2">

                        <span className="table-count">
                            <i className="bx bx-calendar-edit me-1"></i>
                            Showing{" "}
                            <strong>{firstShown} - {lastShown}</strong>{" "}
                            of <strong>{filteredRows.length}</strong> schedules
                        </span>

                        <div className="d-flex">

                            <button
                                className="btn btn-light me-2"
                                onClick={prevPage}
                                disabled={currentPage === 1}
                            >

                                <i className="bx bx-chevron-left"></i>

                                Previous

                            </button>


                            <button
                                className="btn btn-primary"
                                onClick={nextPage}
                                disabled={indexOfLastItem >= filteredRows.length}
                            >

                                Next

                                <i className="bx bx-chevron-right ms-1"></i>

                            </button>

                        </div>

                    </div>

                </div>

            </div>


            {/* ================================================= */}
            {/* PERMISSION POPUP */}
            {/* ================================================= */}

            {viewStaff && (
                <Viewstaffpermission
                    toggle={hideViewPage}
                    staff={viewStaff}
                />
            )}

        </div>

    );

}


export default StaffSchedule;
