import React, { useState, useContext } from "react";
import AuthContext from "../../../services/AuthContext";
import "../addstaffschedule/addstaffschedule.css";
import {
    staffCode,
    todayKey,
    toDateKey,
    shiftHours
} from "../addstaffschedule/Addstaffschedule";

// =====================================================
// ADD PERMISSION PAGE
//
// Staff + date + start time + end time.
// Hours and the salary-cut type are shown while typing
// (the server works them out again when saving).
//
// props:
//   toggle             : back to the list
//   onSuccess          : refresh list + close
//   staffList          : active staff
//   existingSchedules  : saved schedules (permission limits)
// =====================================================

const DEFAULT_LIMIT = 2;
const DEFAULT_HALF_DAY = 4;

const emptyPermission = () => ({
    Staff_id: "",
    Permission_date: todayKey(),
    Permission_start_time: "",
    Permission_end_time: ""
});

const validateField = (name, value, all) => {

    const v = typeof value === "string" ? value.trim() : value;

    switch (name) {

        case "Staff_id":
            return v ? "" : "Staff is required.";

        case "Permission_date":
            if (!v) return "Date is required.";
            if (Number.isNaN(new Date(v).getTime())) return "Enter a valid date.";
            return "";

        case "Permission_start_time":
            return v ? "" : "Start time is required.";

        case "Permission_end_time":
            if (!v) return "End time is required.";
            if (all.Permission_start_time && v <= all.Permission_start_time)
                return "End time must be after start time.";
            return "";

        default:
            return "";
    }
};

// "1.5" -> "1.5 hrs", 2 -> "2 hrs", 0.75 -> "0.75 hrs"
const hoursText = (h) => `${Number(h.toFixed(2))} hrs`;

const Addstaffpermission = (props) => {

    const { insert } = useContext(AuthContext);

    const [values, setValues] = useState(emptyPermission);
    const [errors, setErrors] = useState({});
    const [loading, setLoading] = useState(false);
    const [popup, setPopup] = useState("");

    const staffList = props.staffList || [];

    const setField = (name, value) => {

        setValues((prev) => ({ ...prev, [name]: value }));

        setErrors((prev) => ({
            ...prev,
            [name]: validateField(name, value, { ...values, [name]: value }),
            // end time depends on start time
            ...(name === "Permission_start_time" && values.Permission_end_time
                ? {
                    Permission_end_time: validateField(
                        "Permission_end_time",
                        values.Permission_end_time,
                        { ...values, [name]: value }
                    )
                }
                : {})
        }));
    };

    const handleChange = (name) => (e) => setField(name, e.target.value);


    // ---------- hours + cut type shown under the times ----------
    const hours = shiftHours(
        values.Permission_start_time,
        values.Permission_end_time
    );

    const schedule = (props.existingSchedules || []).find(
        (s) =>
            String(s.Staff_id) === String(values.Staff_id) &&
            values.Permission_date &&
            toDateKey(s.Schedule_start_date) <= values.Permission_date &&
            toDateKey(s.Schedule_end_date) >= values.Permission_date
    );

    const limit = schedule && Number(schedule.Schedule_permission_limit_hours)
        ? Number(schedule.Schedule_permission_limit_hours)
        : DEFAULT_LIMIT;

    const halfDay = schedule && Number(schedule.Schedule_half_day_hours)
        ? Number(schedule.Schedule_half_day_hours)
        : DEFAULT_HALF_DAY;

    let cutText = "";

    if (hours > 0) {

        if (hours <= limit) cutText = `Salary cut: ${hoursText(hours)} × hourly rate`;
        else if (hours <= halfDay) cutText = "Salary cut: 0.5 day";
        else cutText = "Salary cut: 1 full day";
    }


    const validateAll = () => {

        const found = {};

        Object.keys(emptyPermission()).forEach((name) => {

            const msg = validateField(name, values[name], values);

            if (msg) found[name] = msg;
        });

        return found;
    };


    const handleSubmit = async (e) => {

        e.preventDefault();

        const found = validateAll();

        if (Object.keys(found).length > 0) {

            setErrors(found);

            setPopup(Object.values(found)[0]);

            return;
        }

        try {

            setLoading(true);

            const payload = {};

            Object.keys(values).forEach((k) => {
                payload[k] = typeof values[k] === "string" ? values[k].trim() : values[k];
            });

            const response = await insert(payload, "staffpermission_create");

            console.log("Permission created:", response);

            if (props.onSuccess) {
                await props.onSuccess();
            } else {
                props.toggle();
            }

        } catch (err) {

            console.error("Permission save failed:", err);

            const data = err && err.responseData;

            let message = "Permission could not be saved. Please try again.";

            if (data) {

                const firstKey = Object.keys(data).find((k) => k !== "detail");

                if (data.detail) {
                    message = data.detail;
                } else if (data.message) {
                    message = data.message;
                } else if (firstKey) {
                    message = Array.isArray(data[firstKey]) ? data[firstKey][0] : String(data[firstKey]);
                }
            }

            setPopup(message);

        } finally {

            setLoading(false);
        }
    };


    // ---------------- small field helpers ----------------
    const err = (name) => errors[name];

    const cls = (base, name) => base + (err(name) ? " is-invalid" : "");

    const Label = ({ text, required, htmlFor }) => (
        <label htmlFor={htmlFor} className="sch-field-label">
            {text}
            {required && <span className="req">*</span>}
        </label>
    );

    const FieldError = ({ name }) =>
        err(name) ? <div className="invalid-feedback d-block">{err(name)}</div> : null;


    return (

        <div className="staffschedule-page centered-form-page container-xxl flex-grow-1 container-p-y">

            <div className="centered-form-wrap">

                {/* ================= PAGE HEADER ================= */}
                <div className="page-header">

                    <h3 className="page-title">
                        Add Permission
                    </h3>

                    <button
                        type="button"
                        className="sch-back-btn"
                        onClick={props.toggle}
                        disabled={loading}
                    >
                        <i className="bx bx-arrow-back me-2"></i>
                        Back to list
                    </button>

                </div>


                <div className="card staffschedule-card">

                    <div className="card-body">

                        <form onSubmit={handleSubmit} noValidate>

                            <div className="row sch-form-grid">

                                {/* ---------- Staff | Date ---------- */}
                                <div className="col-md-6 mb-3">
                                    <Label text="Staff Name" required htmlFor="Staff_id" />
                                    <div className="sch-input-icon">
                                        <i className="bx bx-user"></i>
                                        <select
                                            id="Staff_id"
                                            className={cls("form-select", "Staff_id")}
                                            value={values.Staff_id}
                                            onChange={handleChange("Staff_id")}
                                        >
                                            <option value="">Select Staff</option>
                                            {staffList.map((s) => (
                                                <option key={s.Staff_id} value={s.Staff_id}>
                                                    {staffCode(s)} - {s.Staff_name}
                                                </option>
                                            ))}
                                        </select>
                                    </div>
                                    <FieldError name="Staff_id" />
                                </div>

                                <div className="col-md-6 mb-3">
                                    <Label text="Date" required htmlFor="Permission_date" />
                                    <div className="sch-input-icon">
                                        <i className="bx bx-calendar"></i>
                                        <input
                                            id="Permission_date"
                                            type="date"
                                            className={cls("form-control", "Permission_date")}
                                            value={values.Permission_date}
                                            onChange={handleChange("Permission_date")}
                                        />
                                    </div>
                                    <FieldError name="Permission_date" />
                                </div>


                                {/* ---------- Start Time | End Time ---------- */}
                                <div className="col-md-6 mb-3">
                                    <Label text="Start Time" required htmlFor="Permission_start_time" />
                                    <div className="sch-input-icon">
                                        <i className="bx bx-log-in-circle"></i>
                                        <input
                                            id="Permission_start_time"
                                            type="time"
                                            className={cls("form-control", "Permission_start_time")}
                                            value={values.Permission_start_time}
                                            onChange={handleChange("Permission_start_time")}
                                        />
                                    </div>
                                    <FieldError name="Permission_start_time" />
                                </div>

                                <div className="col-md-6 mb-3">
                                    <Label text="End Time" required htmlFor="Permission_end_time" />
                                    <div className="sch-input-icon">
                                        <i className="bx bx-log-out-circle"></i>
                                        <input
                                            id="Permission_end_time"
                                            type="time"
                                            className={cls("form-control", "Permission_end_time")}
                                            value={values.Permission_end_time}
                                            onChange={handleChange("Permission_end_time")}
                                        />
                                    </div>
                                    <FieldError name="Permission_end_time" />
                                </div>


                                {/* ---------- hours + salary cut ---------- */}
                                {hours > 0 && (
                                    <div className="col-12 mb-2">
                                        <div className="sch-note">
                                            <i className="bx bx-timer"></i>
                                            <span>
                                                Permission: <strong>{hoursText(hours)}</strong>. {cutText}.
                                            </span>
                                        </div>
                                    </div>
                                )}

                            </div>


                            {/* ================= FOOTER ================= */}
                            <div className="sch-form-footer">

                                <button
                                    type="button"
                                    className="btn btn-outline-secondary"
                                    onClick={props.toggle}
                                    disabled={loading}
                                >
                                    Cancel
                                </button>

                                <button
                                    type="submit"
                                    className="btn btn-primary"
                                    disabled={loading}
                                >
                                    {loading ? (
                                        <>
                                            <span
                                                className="spinner-border spinner-border-sm me-2"
                                                role="status"
                                                aria-hidden="true"
                                            ></span>
                                            Saving...
                                        </>
                                    ) : (
                                        "Save Permission"
                                    )}
                                </button>

                            </div>

                        </form>

                    </div>

                </div>

            </div>


            {/* ================= ERROR POPUP ================= */}
            {popup && (

                <div
                    className="sch-popup-backdrop"
                    onClick={() => setPopup("")}
                >

                    <div
                        className="sch-popup"
                        role="alertdialog"
                        aria-modal="true"
                        onClick={(e) => e.stopPropagation()}
                    >

                        <div className="sch-popup-icon">⚠</div>

                        <h5>{popup}</h5>

                        <button
                            type="button"
                            className="btn btn-primary mt-3"
                            onClick={() => setPopup("")}
                            autoFocus
                        >
                            OK
                        </button>

                    </div>

                </div>

            )}

        </div>

    );
};

export default Addstaffpermission;
