import React, { useContext, useEffect, useMemo, useState } from "react";
import AuthContext from "../../../services/AuthContext";
import "../addstaffschedule/addstaffschedule.css";

const Deletestaffschedule = (props) => {

    const { Delete, getData } = useContext(AuthContext);

    const [error, setError] = useState("");
    const [loading, setLoading] = useState(false);

    // option: also delete the permissions of this schedule
    const [deletePermissions, setDeletePermissions] = useState(false);
    const [permissions, setPermissions] = useState([]);

    // props.data is the schedule record; props.staff is its staff (for the name)
    const record = props.data || {};
    const staff = props.staff || {};


    // permissions of this staff that fall inside the schedule dates
    useEffect(() => {

        let alive = true;

        (async () => {

            try {

                const data = await getData("fetch_staffpermission_datail");

                if (alive) setPermissions(Array.isArray(data) ? data : []);

            } catch (err) {

                console.error("Failed to fetch permissions:", err);

            }

        })();

        return () => { alive = false; };

    }, [getData]);

    const key = (d) => (d ? String(d).split("T")[0] : "");

    const permissionCount = useMemo(
        () =>
            permissions.filter(
                (p) =>
                    String(p.Staff_id) === String(record.Staff_id) &&
                    key(p.Permission_date) >= key(record.Schedule_start_date) &&
                    key(p.Permission_date) <= key(record.Schedule_end_date)
            ).length,
        [permissions, record]
    );


    const handleSubmit = async () => {

        setError("");

        try {

            if (!record.Schedule_id) {

                throw new Error(
                    "Missing or invalid data for deletion"
                );

            }

            setLoading(true);

            await Delete(
                {
                    Schedule_id: record.Schedule_id,
                    Delete_permissions: deletePermissions
                },
                "delete_staffschedule_datail",
                "/staffschedule"
            );

            // Refresh the list and go back to it
            if (props.onSuccess) {

                await props.onSuccess();

            } else {

                props.toggle();

            }

        } catch (error) {

            console.error(
                "Delete operation failed:",
                error
            );

            setError(
                "Schedule could not be deleted. Please try again."
            );

        } finally {

            setLoading(false);

        }
    };


    return (

        <div className="staffschedule-page centered-form-page container-xxl flex-grow-1 container-p-y">

            <div className="centered-form-wrap">


                {/* ================================================= */}
                {/* HEADER */}
                {/* ================================================= */}

                <div className="page-header">

                    <div>

                        <h3 className="page-title">
                            Delete Schedule
                        </h3>

                        <p className="page-subtitle">
                            Please confirm before deleting
                        </p>

                    </div>


                    <button
                        type="button"
                        className="btn btn-outline-secondary add-btn"
                        onClick={props.toggle}
                        disabled={loading}
                    >

                        <i className="bx bx-arrow-back me-2"></i>

                        Back to List

                    </button>

                </div>


                {/* ================================================= */}
                {/* CONFIRM CARD */}
                {/* ================================================= */}

                <div className="card staffschedule-card">

                    <div className="card-body text-center">

                        {/* ERROR */}
                        {error && (
                            <div
                                className="alert alert-danger text-start"
                                role="alert"
                            >
                                <strong>Error!</strong>{" "}
                                {error}
                            </div>
                        )}

                        <div
                            className="text-danger mb-3"
                            style={{ fontSize: "40px" }}
                        >
                            <i className="bx bx-error"></i>
                        </div>

                        <h5>
                            Are you sure you want to delete the schedule
                            {staff.Staff_name
                                ? ` of "${staff.Staff_name}"`
                                : ""}
                            {record.Schedule_start_date
                                ? ` (${String(record.Schedule_start_date).split("T")[0]} to ${String(record.Schedule_end_date || "").split("T")[0]})`
                                : ""}
                            ?
                        </h5>

                        <p className="text-muted mb-0">
                            This action cannot be undone.
                        </p>


                        {/* OPTION: also delete the permissions of this schedule */}
                        <label className="sch-delete-option">

                            <input
                                type="checkbox"
                                checked={deletePermissions}
                                onChange={(e) => setDeletePermissions(e.target.checked)}
                                disabled={loading || permissionCount === 0}
                            />

                            <span>
                                {permissionCount > 0
                                    ? `Also delete ${permissionCount} permission${permissionCount > 1 ? "s" : ""} of this schedule (kept in Deleted records)`
                                    : "No permissions in this schedule"}
                            </span>

                        </label>


                        <div className="d-flex justify-content-center gap-2 mt-4">

                            <button
                                type="button"
                                className="btn btn-outline-secondary"
                                onClick={props.toggle}
                                disabled={loading}
                            >
                                <i className="bx bx-x me-1"></i>
                                Cancel
                            </button>

                            <button
                                type="button"
                                onClick={handleSubmit}
                                className="btn btn-danger"
                                disabled={loading}
                            >

                                {loading ? (
                                    <>
                                        <span
                                            className="spinner-border spinner-border-sm me-2"
                                            role="status"
                                            aria-hidden="true"
                                        ></span>

                                        Deleting...
                                    </>
                                ) : (
                                    <>
                                        <i className="bx bx-trash me-1"></i>
                                        Delete
                                    </>
                                )}

                            </button>

                        </div>

                    </div>

                </div>

            </div>

        </div>
    );
};

export default Deletestaffschedule;
