import React, { useContext } from "react";
import AuthContext from "../../../services/AuthContext";
import {
    ScheduleForm,
    buildSchedulePayload,
    toDateKey,
    toTimeKey
} from "../addstaffschedule/Addstaffschedule";

const Updatestaffschedule = (props) => {

    const { update } = useContext(AuthContext);

    // props.data is the schedule row clicked in the list.
    const initialValues = {
        ...props.data,
        Schedule_start_date: toDateKey(props.data.Schedule_start_date),
        Schedule_end_date: toDateKey(props.data.Schedule_end_date),
        Schedule_shift_start: toTimeKey(props.data.Schedule_shift_start),
        Schedule_shift_end: toTimeKey(props.data.Schedule_shift_end)
    };

    // null -> "" so inputs stay controlled
    Object.keys(initialValues).forEach((k) => {

        if (initialValues[k] === null || initialValues[k] === undefined) {

            initialValues[k] = "";

        }

    });

    const handleSave = async (values) => {

        const payload = buildSchedulePayload(values, {
            Schedule_id: props.data.Schedule_id
        });

        await update(
            payload,
            "update_staffschedule_datail",
            "/staffschedule"
        );

        // Refresh the list and go back to it
        if (props.onSuccess) {

            await props.onSuccess();

        } else {

            props.toggle();

        }

    };

    return (

        <ScheduleForm
            title="Edit Schedule"
            submitLabel="Update Schedule"
            failMessage="Schedule could not be updated. Please try again."
            initialValues={initialValues}
            staffList={props.staffList}
            existingSchedules={props.existingSchedules}
            currentId={props.data.Schedule_id}
            onSubmit={handleSave}
            onBack={props.toggle}
            onDelete={props.onDelete}
        />

    );
};

export default Updatestaffschedule;
