import React, { useState, useContext, useEffect } from "react";
import AuthContext from "../../../services/AuthContext";
import "./addstaffschedule.css";

// =====================================================
// SHARED HELPERS (also used by the list page)
// =====================================================


const MONTHS_SHORT = [
    "Jan", "Feb", "Mar", "Apr", "May", "Jun",
    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
];

const pad = (n) => String(n).padStart(2, "0");

// Staff ID shown in the list, e.g. "IGT E001" (same as the attendance page)
export const staffCode = (staff) =>
    staff && staff.Staff_code
        ? staff.Staff_code
        : `IGT E${String((staff && staff.Staff_id) || 0).padStart(3, "0")}`;

// yyyy-mm-dd (local time, no timezone shift)
export const dateKey = (y, m, d) => `${y}-${pad(m + 1)}-${pad(d)}`;

export const todayKey = () => {
    const t = new Date();
    return dateKey(t.getFullYear(), t.getMonth(), t.getDate());
};

// Django may send "2026-10-05" or "2026-10-05T00:00:00Z"
export const toDateKey = (d) => (d ? String(d).split("T")[0] : "");

// "10:00:00" -> "10:00" (value for <input type="time">)
export const toTimeKey = (t) => (t ? String(t).slice(0, 5) : "");

// "2026-10-12" -> "12 Oct 2026"
export const formatDate = (d) => {
    const key = toDateKey(d);
    if (!key) return "-";
    const [y, m, day] = key.split("-").map(Number);
    return `${pad(day)} ${MONTHS_SHORT[m - 1]} ${y}`;
};

// "10:00" / "10:00:00" -> "10:00 AM"
export const formatTime = (t) => {
    if (!t) return "-";
    const [h, m] = String(t).split(":").map(Number);
    if (Number.isNaN(h)) return "-";
    const suffix = h >= 12 ? "PM" : "AM";
    const hour = h % 12 === 0 ? 12 : h % 12;
    return `${pad(hour)}:${pad(m || 0)} ${suffix}`;
};

// hours between two "HH:MM" values (0 when not valid) - used by the permission page
export const shiftHours = (start, end) => {
    if (!start || !end) return 0;
    const [sh, sm] = start.split(":").map(Number);
    const [eh, em] = end.split(":").map(Number);
    const diff = (eh * 60 + em) - (sh * 60 + sm);
    return diff > 0 ? diff / 60 : 0;
};

export const emptySchedule = () => ({
    Staff_id: "",
    Schedule_start_date: "",
    Schedule_end_date: "",
    Schedule_shift_start: "",
    Schedule_shift_end: ""
});


// =====================================================
// VALIDATION (one place: used while typing and on submit)
// ctx = { existingSchedules, currentId }
// =====================================================

export const validateField = (name, value, all, ctx) => {

    const v = typeof value === "string" ? value.trim() : value;

    switch (name) {

        case "Staff_id":
            return v ? "" : "Staff is required.";

        case "Schedule_start_date":
            if (!v) return "From date is required.";
            if (Number.isNaN(new Date(v).getTime())) return "Enter a valid date.";
            return "";

        case "Schedule_end_date": {

            if (!v) return "To date is required.";

            if (Number.isNaN(new Date(v).getTime())) return "Enter a valid date.";

            if (all.Schedule_start_date && v < all.Schedule_start_date)
                return "To date cannot be before from date.";

            // two schedules of the same staff must not share a day
            if (all.Staff_id && all.Schedule_start_date) {

                const clash = (ctx.existingSchedules || []).some(
                    (s) =>
                        String(s.Staff_id) === String(all.Staff_id) &&
                        Number(s.Schedule_id) !== Number(ctx.currentId) &&
                        all.Schedule_start_date <= toDateKey(s.Schedule_end_date) &&
                        v >= toDateKey(s.Schedule_start_date)
                );

                if (clash)
                    return "This date range overlaps another schedule of this staff.";

            }

            return "";
        }

        case "Schedule_shift_start":
            return v ? "" : "Shift start is required.";

        case "Schedule_shift_end":
            if (!v) return "Shift end is required.";
            if (all.Schedule_shift_start && v <= all.Schedule_shift_start)
                return "Shift end must be after shift start.";
            return "";

        default:
            return "";
    }
};

// Plain JSON object for AuthContext insert / update (same style as attendance).
export const buildSchedulePayload = (values, extra = {}) => {

    const payload = {};

    Object.keys(values).forEach((key) => {

        const v = values[key];

        if (typeof v === "string") payload[key] = v.trim();
        else if (v !== null && v !== undefined) payload[key] = v;

    });

    return { ...payload, ...extra };
};


// =====================================================
// SHARED FORM (Add + Update use this)
//
// props: title, submitLabel, failMessage, initialValues,
//        staffList, existingSchedules, currentId,
//        onSubmit(values), onBack, onDelete (optional)
// =====================================================

export const ScheduleForm = (props) => {

    const [values, setValues] = useState(() => ({
        ...emptySchedule(),
        ...(props.initialValues || {})
    }));

    const [errors, setErrors] = useState({});
    const [loading, setLoading] = useState(false);

    // Error popup (same style as the delete popup)
    const [popup, setPopup] = useState("");

    const ctx = {
        existingSchedules: props.existingSchedules,
        currentId: props.currentId
    };

    const staffList = props.staffList || [];

    // Re-check the date range whenever staff / dates change (overlap rule)
    useEffect(() => {

        if (!values.Schedule_end_date) return;

        setErrors((prev) => ({
            ...prev,
            Schedule_end_date: validateField(
                "Schedule_end_date", values.Schedule_end_date, values, ctx
            )
        }));

        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [values.Staff_id, values.Schedule_start_date, values.Schedule_end_date]);

    // Re-check shift end when shift start changes
    useEffect(() => {

        if (!values.Schedule_shift_end) return;

        setErrors((prev) => ({
            ...prev,
            Schedule_shift_end: validateField(
                "Schedule_shift_end", values.Schedule_shift_end, values, ctx
            )
        }));

        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [values.Schedule_shift_start]);


    const setField = (name, value) => {

        setValues((prev) => ({ ...prev, [name]: value }));

        setErrors((prev) => ({
            ...prev,
            [name]: validateField(name, value, { ...values, [name]: value }, ctx)
        }));

    };

    const handleChange = (name) => (e) => setField(name, e.target.value);


    const validateAll = () => {

        const found = {};

        Object.keys(emptySchedule()).forEach((name) => {

            const msg = validateField(name, values[name], values, ctx);

            if (msg) found[name] = msg;

        });

        return found;
    };


    const handleSubmit = async (e) => {

        e.preventDefault();

        const found = validateAll();

        if (Object.keys(found).length > 0) {

            setErrors(found);

            setPopup(Object.values(found)[0]);

            return;
        }

        try {

            setLoading(true);

            await props.onSubmit(values);

        } catch (err) {

            console.error("Schedule save failed:", err);

            const data = err && err.responseData;

            let message = props.failMessage || "Schedule could not be saved. Please try again.";

            if (data) {

                const firstKey = Object.keys(data).find((k) => k !== "detail");

                if (data.detail) {
                    message = data.detail;
                } else if (firstKey) {
                    message = Array.isArray(data[firstKey]) ? data[firstKey][0] : String(data[firstKey]);
                }

            }

            setPopup(message);

        } finally {

            setLoading(false);

        }
    };


    // ---------------- small field helpers ----------------
    const err = (name) => errors[name];

    const cls = (base, name) => base + (err(name) ? " is-invalid" : "");

    const Label = ({ text, required, htmlFor }) => (
        <label htmlFor={htmlFor} className="sch-field-label">
            {text}
            {required && <span className="req">*</span>}
        </label>
    );

    const FieldError = ({ name }) =>
        err(name) ? <div className="invalid-feedback d-block">{err(name)}</div> : null;


    return (

        <div className="staffschedule-page centered-form-page container-xxl flex-grow-1 container-p-y">

            <div className="centered-form-wrap">

                {/* ================= PAGE HEADER ================= */}
                <div className="page-header">

                    <h3 className="page-title">
                        {props.title}
                    </h3>

                    <button
                        type="button"
                        className="sch-back-btn"
                        onClick={props.onBack}
                        disabled={loading}
                    >
                        <i className="bx bx-arrow-back me-2"></i>
                        Back to list
                    </button>

                </div>


                <div className="card staffschedule-card">

                    <div className="card-body">

                        <form onSubmit={handleSubmit} noValidate>

                            <div className="row sch-form-grid">

                                {/* ---------- Staff ---------- */}
                                <div className="col-12 mb-3">
                                    <Label text="Staff" required htmlFor="Staff_id" />
                                    <div className="sch-input-icon">
                                        <i className="bx bx-user"></i>
                                        <select
                                            id="Staff_id"
                                            className={cls("form-select", "Staff_id")}
                                            value={values.Staff_id}
                                            onChange={handleChange("Staff_id")}
                                        >
                                            <option value="">Select Staff</option>
                                            {staffList.map((s) => (
                                                <option key={s.Staff_id} value={s.Staff_id}>
                                                    {staffCode(s)} - {s.Staff_name}
                                                </option>
                                            ))}
                                        </select>
                                    </div>
                                    <FieldError name="Staff_id" />
                                </div>


                                {/* ---------- From Date | To Date ---------- */}
                                <div className="col-md-6 mb-3">
                                    <Label text="From Date" required htmlFor="Schedule_start_date" />
                                    <div className="sch-input-icon">
                                        <i className="bx bx-calendar"></i>
                                        <input
                                            id="Schedule_start_date"
                                            type="date"
                                            className={cls("form-control", "Schedule_start_date")}
                                            value={values.Schedule_start_date}
                                            onChange={handleChange("Schedule_start_date")}
                                        />
                                    </div>
                                    <FieldError name="Schedule_start_date" />
                                </div>

                                <div className="col-md-6 mb-3">
                                    <Label text="To Date" required htmlFor="Schedule_end_date" />
                                    <div className="sch-input-icon">
                                        <i className="bx bx-calendar-check"></i>
                                        <input
                                            id="Schedule_end_date"
                                            type="date"
                                            className={cls("form-control", "Schedule_end_date")}
                                            min={values.Schedule_start_date || undefined}
                                            value={values.Schedule_end_date}
                                            onChange={handleChange("Schedule_end_date")}
                                        />
                                    </div>
                                    <FieldError name="Schedule_end_date" />
                                </div>


                                {/* ---------- Shift Start | Shift End ---------- */}
                                <div className="col-md-6 mb-3">
                                    <Label text="Shift Start" required htmlFor="Schedule_shift_start" />
                                    <div className="sch-input-icon">
                                        <i className="bx bx-log-in-circle"></i>
                                        <input
                                            id="Schedule_shift_start"
                                            type="time"
                                            className={cls("form-control", "Schedule_shift_start")}
                                            value={values.Schedule_shift_start}
                                            onChange={handleChange("Schedule_shift_start")}
                                        />
                                    </div>
                                    <FieldError name="Schedule_shift_start" />
                                </div>

                                <div className="col-md-6 mb-3">
                                    <Label text="Shift End" required htmlFor="Schedule_shift_end" />
                                    <div className="sch-input-icon">
                                        <i className="bx bx-log-out-circle"></i>
                                        <input
                                            id="Schedule_shift_end"
                                            type="time"
                                            className={cls("form-control", "Schedule_shift_end")}
                                            value={values.Schedule_shift_end}
                                            onChange={handleChange("Schedule_shift_end")}
                                        />
                                    </div>
                                    <FieldError name="Schedule_shift_end" />
                                </div>

                            </div>


                            {/* ================= FOOTER ================= */}
                            <div className="sch-form-footer">

                                <div>

                                    <button
                                        type="button"
                                        className="btn btn-outline-secondary"
                                        onClick={props.onBack}
                                        disabled={loading}
                                    >
                                        Cancel
                                    </button>

                                    {props.onDelete && (
                                        <button
                                            type="button"
                                            className="btn btn-outline-danger ms-2"
                                            onClick={props.onDelete}
                                            disabled={loading}
                                        >
                                            Delete
                                        </button>
                                    )}

                                </div>

                                <button
                                    type="submit"
                                    className="btn btn-primary"
                                    disabled={loading}
                                >

                                    {loading ? (
                                        <>
                                            <span
                                                className="spinner-border spinner-border-sm me-2"
                                                role="status"
                                                aria-hidden="true"
                                            ></span>
                                            Saving...
                                        </>
                                    ) : (
                                        props.submitLabel
                                    )}

                                </button>

                            </div>

                        </form>

                    </div>

                </div>

            </div>


            {/* ================= ERROR POPUP ================= */}
            {popup && (

                <div
                    className="sch-popup-backdrop"
                    onClick={() => setPopup("")}
                >

                    <div
                        className="sch-popup"
                        role="alertdialog"
                        aria-modal="true"
                        onClick={(e) => e.stopPropagation()}
                    >

                        <div className="sch-popup-icon">⚠</div>

                        <h5>{popup}</h5>

                        <button
                            type="button"
                            className="btn btn-primary mt-3"
                            onClick={() => setPopup("")}
                            autoFocus
                        >
                            OK
                        </button>

                    </div>

                </div>

            )}

        </div>

    );
};


// =====================================================
// ADD PAGE
//
// props:
//   toggle             : back to the list
//   onSuccess          : refresh list + close
//   staffList          : active staff
//   existingSchedules  : all saved schedules (overlap check)
// =====================================================

const Addstaffschedule = (props) => {

    const { insert } = useContext(AuthContext);

    const handleSave = async (values) => {

        const payload = buildSchedulePayload(values);

        const response = await insert(
            payload,
            "staffschedule_create"
        );

        console.log("Schedule created:", response);

        // Refresh the list and go back to it
        if (props.onSuccess) {

            await props.onSuccess();

        } else {

            props.toggle();

        }

    };

    return (

        <ScheduleForm
            title="Add Schedule"
            submitLabel="Save Schedule"
            failMessage="Schedule could not be saved. Please try again."
            staffList={props.staffList}
            existingSchedules={props.existingSchedules}
            onSubmit={handleSave}
            onBack={props.toggle}
        />

    );
};

export default Addstaffschedule;
