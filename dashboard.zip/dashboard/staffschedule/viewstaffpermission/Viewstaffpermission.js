import React, { useState, useContext, useEffect, useCallback, useMemo } from "react";
import AuthContext from "../../../services/AuthContext";
import "./viewstaffpermission.css";
import {
    staffCode,
    toDateKey,
    toTimeKey,
    formatDate,
    formatTime,
    shiftHours
} from "../addstaffschedule/Addstaffschedule";

// =====================================================
// VIEW PERMISSION POPUP (permission table of one staff)
//
// list   : table with edit / delete buttons
// edit   : date + start time + end time (hours worked out again)
// delete : confirm before removing
//
// props:
//   toggle : close the popup
//   staff  : the staff row (Staff_id, Staff_name, ...)
// =====================================================

const show = (v) =>
    v === null || v === undefined || String(v).trim() === "" ? "-" : String(v);

const hoursText = (h) => {
    const n = Number(h);
    return Number.isNaN(n) ? "-" : `${Number(n.toFixed(2))} Hrs`;
};

// "2026-10-28T14:05:11" -> "28 Oct 2026, 02:05 PM"
const deletedOn = (v) => {
    if (!v) return "-";
    const [day, time] = String(v).split("T");
    return `${formatDate(day)}${time ? `, ${formatTime(time.slice(0, 5))}` : ""}`;
};

// first readable message from an API error
const errorMessage = (err, fallback) => {

    const data = err && err.responseData;

    if (!data) return fallback;

    if (data.detail) return data.detail;
    if (data.message) return data.message;

    const firstKey = Object.keys(data)[0];

    if (firstKey) {
        return Array.isArray(data[firstKey]) ? data[firstKey][0] : String(data[firstKey]);
    }

    return fallback;
};

const validateEdit = (v) => {

    const found = {};

    if (!v.Permission_date) found.Permission_date = "Date is required.";
    else if (Number.isNaN(new Date(v.Permission_date).getTime()))
        found.Permission_date = "Enter a valid date.";

    if (!v.Permission_start_time) found.Permission_start_time = "Start time is required.";

    if (!v.Permission_end_time) found.Permission_end_time = "End time is required.";
    else if (v.Permission_start_time && v.Permission_end_time <= v.Permission_start_time)
        found.Permission_end_time = "End time must be after start time.";

    return found;
};

const Viewstaffpermission = (props) => {

    const { getData, update, Delete } = useContext(AuthContext);

    const staff = props.staff || {};

    const [permissions, setPermissions] = useState([]);
    const [deletedList, setDeletedList] = useState([]);

    // "active" | "deleted" (which table the list shows)
    const [tab, setTab] = useState("active");
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState("");

    // "list" | "edit" | "delete"
    const [mode, setMode] = useState("list");
    const [selected, setSelected] = useState(null);
    const [values, setValues] = useState({});
    const [errors, setErrors] = useState({});
    const [saving, setSaving] = useState(false);
    const [message, setMessage] = useState("");


    // ---------------- fetch ----------------
    const fetchPermissions = useCallback(async () => {

        try {

            setLoading(true);
            setError("");

            const [active, removed] = await Promise.all([
                getData("fetch_staffpermission_datail"),
                getData("fetch_deleted_staffpermission_datail")
            ]);

            setPermissions(Array.isArray(active) ? active : []);
            setDeletedList(Array.isArray(removed) ? removed : []);

        } catch (err) {

            console.error("Failed to fetch permissions:", err);
            setError("Permissions could not be loaded. Try again.");

        } finally {

            setLoading(false);
        }

    }, [getData]);

    useEffect(() => {
        fetchPermissions();
    }, [fetchPermissions]);


    // close on Esc
    useEffect(() => {

        const onKey = (e) => {
            if (e.key === "Escape" && !saving) props.toggle();
        };

        document.addEventListener("keydown", onKey);

        return () => document.removeEventListener("keydown", onKey);

    }, [props, saving]);


    // only this staff, newest date first
    const rows = useMemo(
        () =>
            permissions
                .filter((p) => String(p.Staff_id) === String(staff.Staff_id))
                .sort((a, b) =>
                    toDateKey(b.Permission_date).localeCompare(
                        toDateKey(a.Permission_date)
                    )
                ),
        [permissions, staff.Staff_id]
    );


    // deleted records of this staff, latest deletion first
    const deletedRows = useMemo(
        () =>
            deletedList
                .filter((p) => String(p.Staff_id) === String(staff.Staff_id))
                .sort((a, b) =>
                    String(b.Deleted_at || "").localeCompare(String(a.Deleted_at || ""))
                ),
        [deletedList, staff.Staff_id]
    );


    // ---------------- mode switching ----------------
    const backToList = () => {
        setMode("list");
        setSelected(null);
        setErrors({});
        setMessage("");
    };

    const startEdit = (p) => {

        setSelected(p);

        setValues({
            Permission_date: toDateKey(p.Permission_date),
            Permission_start_time: toTimeKey(p.Permission_start_time),
            Permission_end_time: toTimeKey(p.Permission_end_time)
        });

        setErrors({});
        setMessage("");
        setMode("edit");
    };

    const startDelete = (p) => {
        setSelected(p);
        setMessage("");
        setMode("delete");
    };


    // ---------------- edit ----------------
    const setField = (name, value) => {

        const next = { ...values, [name]: value };

        setValues(next);

        // re-check this field + end time (it depends on start time)
        const found = validateEdit(next);

        setErrors((prev) => ({
            ...prev,
            [name]: found[name] || "",
            ...(name === "Permission_start_time" && next.Permission_end_time
                ? { Permission_end_time: found.Permission_end_time || "" }
                : {})
        }));
    };

    const handleSave = async () => {

        const found = validateEdit(values);

        if (Object.keys(found).length > 0) {
            setErrors(found);
            return;
        }

        try {

            setSaving(true);
            setMessage("");

            await update(
                {
                    Permission_id: selected.Permission_id,
                    Permission_date: values.Permission_date,
                    Permission_start_time: values.Permission_start_time,
                    Permission_end_time: values.Permission_end_time
                },
                "update_staffpermission_datail",
                "/staffschedule"
            );

            await fetchPermissions();

            backToList();

        } catch (err) {

            console.error("Permission update failed:", err);

            setMessage(errorMessage(err, "Permission could not be updated. Try again."));

        } finally {

            setSaving(false);
        }
    };


    // ---------------- delete ----------------
    const handleDelete = async () => {

        try {

            setSaving(true);
            setMessage("");

            await Delete(
                { Permission_id: selected.Permission_id },
                "delete_staffpermission_datail",
                "/staffschedule"
            );

            await fetchPermissions();

            backToList();

        } catch (err) {

            console.error("Permission delete failed:", err);

            setMessage(errorMessage(err, "Permission could not be deleted. Try again."));

        } finally {

            setSaving(false);
        }
    };


    const editHours = shiftHours(values.Permission_start_time, values.Permission_end_time);

    const title =
        mode === "edit" ? "Edit permission"
            : mode === "delete" ? "Delete permission"
                : "Permissions";

    const subtitle =
        mode === "list"
            ? `${staffCode(staff)} · Permissions taken by this staff`
            : `${show(staff.Staff_name)} · ${staffCode(staff)}`;

    const headerIcon =
        mode === "edit" ? "bx-edit-alt"
            : mode === "delete" ? "bx-trash"
                : "bx-time-five";


    return (

        <div className="vp-backdrop" onClick={() => !saving && props.toggle()}>

            <div
                className="vp-modal"
                role="dialog"
                aria-modal="true"
                onClick={(e) => e.stopPropagation()}
            >

                <button
                    type="button"
                    className="vp-close-x"
                    aria-label="Close"
                    onClick={props.toggle}
                    disabled={saving}
                >
                    <i className="bx bx-x"></i>
                </button>


                {/* ---------- HEADER ---------- */}
                {mode !== "delete" && (
                <div className="vp-header">

                    <span className={"vp-header-icon" + (mode === "delete" ? " is-danger" : "")}>
                        <i className={"bx " + headerIcon}></i>
                    </span>

                    <div>
                        <h5 className="vp-title">
                            {mode === "list"
                                ? `${show(staff.Staff_name)} — ${title}`
                                : title}
                        </h5>
                        <p className="vp-subtitle">{subtitle}</p>
                    </div>

                </div>
                )}


                {/* ================= LIST ================= */}
                {mode === "list" && (

                    <>
                        <div className="vp-tabs">

                            <button
                                type="button"
                                className={"vp-tab" + (tab === "active" ? " is-on" : "")}
                                onClick={() => setTab("active")}
                            >
                                <i className="bx bx-time-five"></i>
                                Permissions
                                <span className="vp-tab-count">{rows.length}</span>
                            </button>

                            <button
                                type="button"
                                className={"vp-tab" + (tab === "deleted" ? " is-on is-deleted" : "")}
                                onClick={() => setTab("deleted")}
                            >
                                <i className="bx bx-trash"></i>
                                Deleted records
                                <span className="vp-tab-count">{deletedRows.length}</span>
                            </button>

                        </div>

                        <div className="vp-table-box">

                            <table className="vp-table">

                                <thead>
                                    <tr>
                                        <th><i className="bx bx-hash"></i> No</th>
                                        <th className="vp-left"><i className="bx bx-calendar"></i> Date</th>
                                        <th><i className="bx bx-time"></i> Time</th>
                                        <th><i className="bx bx-timer"></i> Duration</th>
                                        {tab === "active"
                                            ? <th>Actions</th>
                                            : <th><i className="bx bx-trash"></i> Deleted on</th>}
                                    </tr>
                                </thead>

                                <tbody>

                                    {loading ? (

                                        <tr><td colSpan={5} className="vp-empty">Loading...</td></tr>

                                    ) : error ? (

                                        <tr><td colSpan={5} className="vp-empty vp-error">{error}</td></tr>

                                    ) : (tab === "active" ? rows : deletedRows).length > 0 ? (

                                        (tab === "active" ? rows : deletedRows).map((p, index) => (

                                            <tr key={p.Permission_id} className={tab === "deleted" ? "vp-row-deleted" : ""}>

                                                <td><span className={"vp-num" + (tab === "deleted" ? " is-muted" : "")}>{index + 1}</span></td>

                                                <td className="vp-left vp-date">
                                                    <i className="bx bx-bookmark"></i>
                                                    {formatDate(p.Permission_date)}
                                                </td>

                                                <td className="vp-time">
                                                    {formatTime(p.Permission_start_time)}
                                                    <i className="bx bx-right-arrow-alt"></i>
                                                    {formatTime(p.Permission_end_time)}
                                                </td>

                                                <td>
                                                    <span className="vp-pill">
                                                        <i className="bx bx-time-five"></i>
                                                        {hoursText(p.Permission_hours)}
                                                    </span>
                                                </td>

                                                {tab === "active" ? (

                                                    <td>
                                                        <div className="vp-actions">

                                                            <button
                                                                type="button"
                                                                className="vp-icon-btn is-edit"
                                                                title="Edit permission"
                                                                onClick={() => startEdit(p)}
                                                            >
                                                                <i className="bx bx-edit-alt"></i>
                                                            </button>

                                                            <button
                                                                type="button"
                                                                className="vp-icon-btn is-delete"
                                                                title="Delete permission"
                                                                onClick={() => startDelete(p)}
                                                            >
                                                                <i className="bx bx-trash"></i>
                                                            </button>

                                                        </div>
                                                    </td>

                                                ) : (

                                                    <td className="vp-deleted-on">{deletedOn(p.Deleted_at)}</td>

                                                )}

                                            </tr>

                                        ))

                                    ) : (

                                        <tr>
                                            <td colSpan={5} className="vp-empty">
                                                {tab === "active" ? "No permissions found." : "No deleted records."}
                                            </td>
                                        </tr>

                                    )}

                                </tbody>

                            </table>

                        </div>

                        <div className="vp-footer">
                            <button type="button" className="vp-close-btn" onClick={props.toggle}>
                                Close
                            </button>
                        </div>
                    </>
                )}


                {/* ================= EDIT ================= */}
                {mode === "edit" && selected && (

                    <>
                        <div className="vp-form">

                            <div className="vp-field">
                                <label htmlFor="vp_date">Date<span className="req">*</span></label>
                                <input
                                    id="vp_date"
                                    type="date"
                                    className={"form-control" + (errors.Permission_date ? " is-invalid" : "")}
                                    value={values.Permission_date}
                                    onChange={(e) => setField("Permission_date", e.target.value)}
                                />
                                {errors.Permission_date && <div className="vp-field-error">{errors.Permission_date}</div>}
                            </div>

                            <div className="vp-field-row">

                                <div className="vp-field">
                                    <label htmlFor="vp_start">Start time<span className="req">*</span></label>
                                    <input
                                        id="vp_start"
                                        type="time"
                                        className={"form-control" + (errors.Permission_start_time ? " is-invalid" : "")}
                                        value={values.Permission_start_time}
                                        onChange={(e) => setField("Permission_start_time", e.target.value)}
                                    />
                                    {errors.Permission_start_time && <div className="vp-field-error">{errors.Permission_start_time}</div>}
                                </div>

                                <div className="vp-field">
                                    <label htmlFor="vp_end">End time<span className="req">*</span></label>
                                    <input
                                        id="vp_end"
                                        type="time"
                                        className={"form-control" + (errors.Permission_end_time ? " is-invalid" : "")}
                                        value={values.Permission_end_time}
                                        onChange={(e) => setField("Permission_end_time", e.target.value)}
                                    />
                                    {errors.Permission_end_time && <div className="vp-field-error">{errors.Permission_end_time}</div>}
                                </div>

                            </div>

                            {editHours > 0 && (
                                <div className="vp-note">
                                    <i className="bx bx-timer"></i>
                                    Duration: <strong>{Number(editHours.toFixed(2))} Hrs</strong>
                                </div>
                            )}

                            {message && <div className="vp-message">{message}</div>}

                        </div>

                        <div className="vp-footer">
                            <button type="button" className="vp-close-btn" onClick={backToList} disabled={saving}>
                                Cancel
                            </button>
                            <button type="button" className="vp-primary-btn" onClick={handleSave} disabled={saving}>
                                {saving ? "Saving..." : "Update permission"}
                            </button>
                        </div>
                    </>
                )}


                {/* ================= DELETE ================= */}
                {mode === "delete" && selected && (

                    <div className="vp-confirm">

                        <div className="vp-confirm-icon">
                            <i className="bx bx-error"></i>
                        </div>

                        <h5>
                            Are you sure you want to delete the permission of "{show(staff.Staff_name)}"
                            {` (${toDateKey(selected.Permission_date)}, ${formatTime(selected.Permission_start_time)} to ${formatTime(selected.Permission_end_time)})`}?
                        </h5>

                        <p className="vp-confirm-sub">The record will be kept in Deleted records.</p>

                        {message && <div className="vp-message">{message}</div>}

                        <div className="vp-confirm-actions">

                            <button type="button" className="vp-close-btn" onClick={backToList} disabled={saving}>
                                <i className="bx bx-x me-1"></i>
                                Cancel
                            </button>

                            <button type="button" className="vp-danger-btn" onClick={handleDelete} disabled={saving}>
                                {saving ? (
                                    "Deleting..."
                                ) : (
                                    <>
                                        <i className="bx bx-trash me-1"></i>
                                        Delete
                                    </>
                                )}
                            </button>

                        </div>

                    </div>
                )}

            </div>

        </div>
    );
};

export default Viewstaffpermission;
