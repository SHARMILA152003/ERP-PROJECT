import React, { useCallback, useContext, useEffect, useMemo, useRef, useState } from "react";
import { Link } from "react-router-dom";
import AuthContext from "../services/AuthContext";
import {
  normalizeBilling,
  num,
  money,
  getToday,
  formatDisplayDate,
} from "./billing/addbilling/Addbilling";
import "./dashboard.css";

import welcomeArt from "../assets/img/illustrations/man-with-laptop-light.png";

/* ======================================================================
   DATA SOURCES - the same AuthContext.getData() calls the module pages use
     Enquiry        -> fetch_enquiry_detail
     Registration   -> fetch_registration_datail   (registered = students)
     Billing        -> fetch_billing_detail
     Course         -> fetch_course_datail
   ====================================================================== */
const ENDPOINTS = {
  enquiries: "fetch_enquiry_detail",
  registrations: "fetch_registration_datail",
  billings: "fetch_billing_detail",
  courses: "fetch_course_datail",
};
const LABELS = {
  enquiries: "Enquiries",
  registrations: "Registrations",
  billings: "Billing",
  courses: "Courses",
};

const PALETTE = ["#696cff", "#03c3ec", "#71dd37", "#ffab00", "#ff3e1d"];
const OTHER_COLOR = "#8592a3";
const AVATAR_TONES = ["primary", "info", "success", "warning", "danger"];
const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

/* ======================================================================
   Small helpers (pure)
   ====================================================================== */
const list = (value) => (Array.isArray(value) ? value : []);
const text = (value) => (value === null || value === undefined ? "" : String(value).trim());
const norm = (value) => text(value).toLowerCase().replace(/[\s_-]+/g, "");
const idOf = (row) => Number(row && (row.enquiry_id ?? row.registration_id ?? row.id)) || 0;
const firstOf = (row, keys) => {
  for (const key of keys) {
    if (row && text(row[key])) return text(row[key]);
  }
  return "";
};

const initials = (name) =>
  text(name)
    .split(/\s+/)
    .filter(Boolean)
    .map((w) => w[0])
    .slice(0, 2)
    .join("")
    .toUpperCase() || "?";

// "2026-10-21", "2026-10-21T10:00:00Z" ... -> "2026-10"
const monthKey = (value) => {
  const t = text(value);
  const m = /^(\d{4})-(\d{2})/.exec(t);
  if (m) return `${m[1]}-${m[2]}`;
  const d = new Date(t);
  return t && !Number.isNaN(d.getTime())
    ? `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`
    : "";
};

// last N calendar months, oldest first
const lastMonths = (todayText, count = 6) => {
  const [y, m] = todayText.split("-").map(Number);
  return Array.from({ length: count }, (_, i) => {
    const d = new Date(y, m - 1 - (count - 1 - i), 1);
    return {
      key: `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`,
      label: MONTHS[d.getMonth()],
    };
  });
};

// [{ label, count }] biggest first (blank values are grouped as "Not specified")
const countBy = (rows, getter) => {
  const map = new Map();
  rows.forEach((row) => {
    const label = text(getter(row)) || "Not specified";
    const key = label.toLowerCase();
    const item = map.get(key) || { label, count: 0 };
    item.count += 1;
    map.set(key, item);
  });
  return [...map.values()].sort((a, b) => b.count - a.count);
};

const compactMoney = (value) => {
  const n = num(value);
  if (n >= 1e7) return `₹${(n / 1e7).toFixed(2)} Cr`;
  if (n >= 1e5) return `₹${(n / 1e5).toFixed(2)} L`;
  return money(n);
};

const greeting = () => {
  const h = new Date().getHours();
  return h < 12 ? "Good morning" : h < 17 ? "Good afternoon" : "Good evening";
};

/* ======================================================================
   buildStats - turns the raw API lists into everything the page shows
   ====================================================================== */
export const buildStats = (raw, today) => {
  const enquiries = list(raw.enquiries);
  const registrations = list(raw.registrations);
  const courses = list(raw.courses);

  /* ---------- enquiries ---------- */
  const followUp = enquiries.filter((e) => norm(e.status) === "followup").length;
  const converted = enquiries.filter((e) => norm(e.status) === "converted").length;

  /* ---------- students (registrations) ---------- */
  const activeStudents = registrations.filter((r) => norm(r.status) === "active").length;

  /* ---------- courses (no saved status counts as Active, like Course.jsx) ---------- */
  const activeCourses = courses.filter(
    (c) => !c.Course_Status || c.Course_Status === "Active"
  ).length;

  /* ---------- billing (same normalisation the Billing page uses) ---------- */
  const bills = list(raw.billings).map((b) => normalizeBilling(b, registrations));
  const totalFee = bills.reduce((n, b) => n + b.finalFee, 0);
  const collected = bills.reduce((n, b) => n + b.paid, 0);
  const pending = bills.reduce((n, b) => n + Math.max(b.balance, 0), 0);
  const fullyPaid = bills.filter((b) => b.isPaid).length;

  const dues = bills
    .filter((b) => !b.isPaid)
    .map((b) => {
      const open = b.installments
        .filter((i) => !i.paid)
        .sort((a, c) => String(a.date).localeCompare(String(c.date)))[0];
      const date = open ? open.date : b.balanceDueDate;
      const amount = open ? Math.max(open.amount - open.paidAmount, 0) : 0;
      return {
        id: b.id,
        name: b.name,
        course: b.course,
        date,
        amount: amount || b.balance,
        overdue: Boolean(date) && date < today,
      };
    })
    .sort((a, b) => {
      if (a.date && b.date) return a.date.localeCompare(b.date);
      return a.date ? -1 : b.date ? 1 : 0;
    });

  /* ---------- enquiries vs registrations, last 6 months ---------- */
  const enquiryDate = (e) => firstOf(e, ["created_at", "enquiry_date", "created_on", "date"]);
  const months = lastMonths(today).map((m) => ({
    ...m,
    enquiries: enquiries.filter((e) => monthKey(enquiryDate(e)) === m.key).length,
    registrations: registrations.filter(
      (r) => monthKey(firstOf(r, ["registration_date", "created_at"])) === m.key
    ).length,
  }));

  /* ---------- students by course: top 5 + Others ---------- */
  const byCourse = countBy(registrations, (r) => r.course);
  const courseSplit = byCourse.slice(0, 5).map((c, i) => ({ ...c, color: PALETTE[i] }));
  const restCount = byCourse.slice(5).reduce((n, c) => n + c.count, 0);
  if (restCount) courseSplit.push({ label: "Others", count: restCount, color: OTHER_COLOR });

  return {
    counts: {
      students: registrations.length,
      activeStudents,
      enquiries: enquiries.length,
      followUp,
      converted,
      courses: courses.length,
      activeCourses,
    },
    fees: {
      bills: bills.length,
      fullyPaid,
      totalFee,
      collected,
      pending,
      percent: totalFee > 0 ? Math.min(Math.round((collected / totalFee) * 100), 100) : 0,
      overdueCount: dues.filter((d) => d.overdue).length,
    },
    dues: dues.slice(0, 5),
    months,
    hasEnquiryDates: enquiries.some((e) => enquiryDate(e)),
    courseSplit,
    sources: countBy(enquiries, (e) => e.enquiry_source).slice(0, 5),
    recentEnquiries: [...enquiries].sort((a, b) => idOf(b) - idOf(a)).slice(0, 30),
    recentRegistrations: [...registrations].sort((a, b) => idOf(b) - idOf(a)).slice(0, 5),
  };
};

/* ======================================================================
   Small visual pieces
   ====================================================================== */
const Ring = ({ percent, color, label, size = 92, stroke = 8 }) => {
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  return (
    <div className="dsh-ring" style={{ width: size, height: size }}>
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="#eceef1" strokeWidth={stroke} />
        <circle
          cx={size / 2} cy={size / 2} r={r} fill="none" stroke={color} strokeWidth={stroke}
          strokeLinecap="round" strokeDasharray={`${(c * percent) / 100} ${c}`}
          transform={`rotate(-90 ${size / 2} ${size / 2})`}
        />
      </svg>
      <div>
        <strong>{percent}%</strong>
        <small className="text-muted">{label}</small>
      </div>
    </div>
  );
};

// grouped bars: enquiries vs registrations per month
const TrendChart = ({ months, showEnquiries }) => {
  const W = 640, H = 270, L = 36, B = 30, T = 18;
  const top = Math.max(1, ...months.map((m) => Math.max(m.enquiries, m.registrations)));
  // 4 even steps up to a round number above the biggest bar
  const rough = Math.max(top / 4, 1);
  const unit = 10 ** Math.floor(Math.log10(rough));
  const step = Math.ceil(rough / unit) * unit;
  const max = step * 4;
  const ticks = [0, 1, 2, 3, 4].map((i) => i * step);
  const plotH = H - B - T;
  const slot = (W - L) / months.length;
  const bw = 22;
  const y = (v) => T + plotH - (v / max) * plotH;
  const Bar = ({ x, value, color, name, month }) => (
    <g>
      <rect x={x} y={y(value)} width={bw} height={T + plotH - y(value)} rx="4" fill={color}>
        <title>{`${name} - ${month}: ${value}`}</title>
      </rect>
      {value > 0 && (
        <text x={x + bw / 2} y={y(value) - 4} textAnchor="middle" fontSize="11" fill="#566a7f">{value}</text>
      )}
    </g>
  );
  return (
    <svg className="dsh-trend" viewBox={`0 0 ${W} ${H}`} role="img" aria-label="Enquiries versus registrations for the last six months">
      {ticks.map((t) => (
        <g key={t}>
          <line x1={L} x2={W} y1={y(t)} y2={y(t)} stroke="#dbdade" strokeDasharray="4 4" />
          <text x={L - 8} y={y(t) + 4} textAnchor="end" fontSize="11" fill="#a1acb8">{t}</text>
        </g>
      ))}
      {months.map((d, i) => {
        const cx = L + slot * i + slot / 2;
        return (
          <g key={d.key}>
            {showEnquiries && <Bar x={cx - bw - 2} value={d.enquiries} color="#696cff" name="Enquiries" month={d.label} />}
            <Bar x={showEnquiries ? cx + 2 : cx - bw / 2} value={d.registrations} color="#71dd37" name="Registrations" month={d.label} />
            <text x={cx} y={H - 8} textAnchor="middle" fontSize="12" fill="#a1acb8">{d.label}</text>
          </g>
        );
      })}
    </svg>
  );
};

const CourseDonut = ({ split, total }) => {
  const r = 58;
  const c = 2 * Math.PI * r;
  let offset = 0;
  return (
    <div className="dsh-donut" role="img" aria-label={`${total} students by course`}>
      <svg viewBox="0 0 150 150">
        <circle cx="75" cy="75" r={r} fill="none" stroke="#eceef1" strokeWidth="18" />
        {split.map((s) => {
          const share = s.count / total;
          const el = (
            <circle
              key={s.label} cx="75" cy="75" r={r} fill="none" stroke={s.color} strokeWidth="18"
              strokeDasharray={`${Math.max(c * share - (split.length > 1 ? 2 : 0), 0)} ${c}`}
              strokeDashoffset={-offset} transform="rotate(-90 75 75)"
            />
          );
          offset += c * share;
          return el;
        })}
      </svg>
      <div>
        <strong>{total.toLocaleString("en-IN")}</strong>
        <small className="text-muted">Students</small>
      </div>
    </div>
  );
};

const Avatar = ({ name, tone }) => (
  <div className="avatar me-3">
    <span className={`avatar-initial rounded-circle bg-label-${tone}`}>{initials(name)}</span>
  </div>
);

const Empty = ({ children }) => <p className="text-muted mb-0 py-2">{children}</p>;

const STATUS_FILTERS = ["All", "Follow Up", "Converted"];

/* ======================================================================
   View - draws the page from `stats` (no data fetching in here)
   ====================================================================== */
export function DashboardView({ stats, status, userName, onRefresh }) {
  const [filter, setFilter] = useState("All");

  const loading = (key) => status[key] === "loading";
  const failed = (key) => status[key] === "error";
  // value for a card: "…" while loading, "—" when that API failed
  const show = (key, value) => (loading(key) ? "…" : failed(key) ? "—" : value);

  const anyLoading = Object.keys(ENDPOINTS).some(loading);
  const failedKeys = Object.keys(ENDPOINTS).filter(failed);

  const { counts, fees } = stats;

  const rows = useMemo(
    () =>
      stats.recentEnquiries
        .filter((e) => filter === "All" || norm(e.status) === norm(filter))
        .slice(0, 6),
    [stats.recentEnquiries, filter]
  );

  // sentence under the greeting - built only from real numbers
  const notes = [];
  if (status.enquiries === "ready" && counts.followUp > 0)
    notes.push(<span key="f"><strong>{counts.followUp}</strong> {counts.followUp === 1 ? "enquiry is" : "enquiries are"} waiting for follow-up</span>);
  if (status.billings === "ready" && fees.overdueCount > 0)
    notes.push(<span key="o"><strong>{fees.overdueCount}</strong> fee {fees.overdueCount === 1 ? "payment is" : "payments are"} overdue</span>);

  const KPIS = [
    { key: "registrations", to: "/registration", label: "Total Students", value: counts.students.toLocaleString("en-IN"), note: `${counts.activeStudents} active`, icon: "bx-user-circle", tone: "primary" },
    { key: "enquiries", to: "/enquiry", label: "Total Enquiries", value: counts.enquiries.toLocaleString("en-IN"), note: `${counts.followUp} follow up · ${counts.converted} converted`, icon: "bx-help-circle", tone: "info" },
    { key: "courses", to: "/course", label: "Active Courses", value: counts.activeCourses.toLocaleString("en-IN"), note: `${counts.courses} courses in total`, icon: "bx-book-open", tone: "success" },
    { key: "billings", to: "/billing", label: "Fee Pending", value: compactMoney(fees.pending), note: `${fees.overdueCount} overdue payment${fees.overdueCount === 1 ? "" : "s"}`, icon: "bx-wallet", tone: "warning" },
  ];

  return (
    <div className="content-wrapper">
      <div className="container-xxl flex-grow-1 container-p-y dsh-dashboard">
        <div className="d-flex flex-wrap align-items-center justify-content-between gap-2 py-3 mb-3">
          <h4 className="fw-semibold mb-0">Dashboard</h4>
          <button type="button" className="btn btn-sm btn-label-secondary" onClick={onRefresh} disabled={anyLoading}>
            <i className={`bx bx-refresh me-1 ${anyLoading ? "bx-spin" : ""}`}></i>
            Refresh
          </button>
        </div>

        {failedKeys.length > 0 && (
          <div className="alert alert-warning d-flex flex-wrap align-items-center justify-content-between gap-2" role="alert">
            <span>
              Could not load {failedKeys.map((k) => LABELS[k]).join(", ")} from the server.
              The cards that depend on it show "—".
            </span>
            <button type="button" className="btn btn-sm btn-warning" onClick={onRefresh}>Try again</button>
          </div>
        )}

        {/* ===== Welcome + fee collection ===== */}
        <div className="row g-4 mb-4">
          <div className="col-12 col-lg-8">
            <div className="card h-100 dsh-welcome">
              <div className="card-body d-flex flex-wrap align-items-center justify-content-between gap-3">
                <div className="dsh-welcome-text">
                  <h4 className="mb-2 text-primary">
                    {greeting()}, {userName}! <span aria-hidden="true">🎉</span>
                  </h4>
                  <p className="mb-4">
                    {anyLoading && "Loading your institute summary…"}
                    {!anyLoading && notes.length > 0 && (
                      <>Right now, {notes.reduce((acc, n, i) => (i ? [...acc, " and ", n] : [n]), [])}.</>
                    )}
                    {!anyLoading && notes.length === 0 && failedKeys.length === 0 &&
                      "Everything is up to date - no enquiries waiting for follow-up and no overdue fees."}
                    {!anyLoading && notes.length === 0 && failedKeys.length > 0 &&
                      "Some data could not be loaded - see the message above."}
                  </p>
                  <div className="d-flex flex-wrap gap-2">
                    <Link to="/enquiry" className="btn btn-primary">View Enquiries</Link>
                    <Link to="/registration" className="btn btn-outline-primary">Registrations</Link>
                  </div>
                </div>
                <img className="dsh-welcome-img" src={welcomeArt} alt="" />
              </div>
            </div>
          </div>

          <div className="col-12 col-lg-4">
            <div className="card h-100">
              <div className="card-header pb-0">
                <h5 className="card-title mb-0">Fee Collection</h5>
              </div>
              <div className="card-body d-flex flex-wrap align-items-center justify-content-center gap-3">
                <Ring percent={status.billings === "ready" ? fees.percent : 0} color="#71dd37" label="Collected" />
                <ul className="list-unstyled mb-0 dsh-att-list">
                  <li className="d-flex justify-content-between mb-2">
                    <span><span className="dsh-dot bg-success"></span>Collected</span>
                    <strong>{show("billings", compactMoney(fees.collected))}</strong>
                  </li>
                  <li className="d-flex justify-content-between mb-2">
                    <span><span className="dsh-dot bg-danger"></span>Pending</span>
                    <strong>{show("billings", compactMoney(fees.pending))}</strong>
                  </li>
                  <li className="d-flex justify-content-between">
                    <span><span className="dsh-dot bg-info"></span>Fully paid</span>
                    <strong>{show("billings", `${fees.fullyPaid}/${fees.bills}`)}</strong>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>

        {/* ===== Summary cards ===== */}
        <div className="row g-4 mb-4">
          {KPIS.map((k) => (
            <div className="col-12 col-sm-6 col-lg-3" key={k.label}>
              <Link to={k.to} className="card h-100 dsh-kpi text-reset text-decoration-none">
                <div className="card-body">
                  <div className="avatar mb-3">
                    <span className={`avatar-initial rounded bg-label-${k.tone}`}>
                      <i className={`bx ${k.icon} bx-sm`}></i>
                    </span>
                  </div>
                  <span className="d-block text-muted mb-1">{k.label}</span>
                  <h3 className="card-title mb-2">{show(k.key, k.value)}</h3>
                  <small className="text-muted">{status[k.key] === "ready" ? k.note : "\u00a0"}</small>
                </div>
              </Link>
            </div>
          ))}
        </div>

        {/* ===== Trend + students by course ===== */}
        <div className="row g-4 mb-4">
          <div className="col-12 col-lg-8">
            <div className="card h-100">
              <div className="card-header d-flex flex-wrap align-items-center justify-content-between gap-2">
                <div>
                  <h5 className="card-title mb-1">Enquiries vs Registrations</h5>
                  <small className="text-muted">Last 6 months</small>
                </div>
                <div className="d-flex align-items-center gap-3">
                  {stats.hasEnquiryDates && (
                    <span><span className="dsh-dot" style={{ background: "#696cff" }}></span>Enquiries</span>
                  )}
                  <span><span className="dsh-dot" style={{ background: "#71dd37" }}></span>Registrations</span>
                </div>
              </div>
              <div className="card-body pt-0">
                {(loading("registrations") || loading("enquiries")) && <Empty>Loading…</Empty>}
                {!loading("registrations") && !loading("enquiries") && (
                  <>
                    <TrendChart months={stats.months} showEnquiries={stats.hasEnquiryDates} />
                    {!stats.hasEnquiryDates && counts.enquiries > 0 && (
                      <small className="text-muted d-block mt-2">
                        Enquiry records from the server have no date field, so only registrations are plotted.
                        Add <code>created_at</code> to <code>fetch_enquiry_detail</code> to see enquiries per month.
                      </small>
                    )}
                  </>
                )}
              </div>
            </div>
          </div>

          <div className="col-12 col-lg-4">
            <div className="card h-100">
              <div className="card-header pb-0">
                <h5 className="card-title mb-0">Students by Course</h5>
              </div>
              <div className="card-body">
                {loading("registrations") && <Empty>Loading…</Empty>}
                {failed("registrations") && <Empty>Registrations could not be loaded.</Empty>}
                {status.registrations === "ready" && counts.students === 0 && <Empty>No students registered yet.</Empty>}
                {status.registrations === "ready" && counts.students > 0 && (
                  <>
                    <div className="d-flex justify-content-center mb-4">
                      <CourseDonut split={stats.courseSplit} total={counts.students} />
                    </div>
                    <ul className="list-unstyled mb-0">
                      {stats.courseSplit.map((c) => (
                        <li className="d-flex align-items-center justify-content-between mb-2" key={c.label}>
                          <span className="text-truncate me-2"><span className="dsh-dot" style={{ background: c.color }}></span>{c.label}</span>
                          <strong>{c.count}</strong>
                        </li>
                      ))}
                    </ul>
                  </>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* ===== Recent enquiries ===== */}
        <div className="row g-4 mb-4">
          <div className="col-12">
            <div className="card h-100">
              <div className="card-header d-flex flex-wrap align-items-center justify-content-between gap-3">
                <h5 className="card-title mb-0">Recent Enquiries</h5>
                <div className="d-flex flex-wrap align-items-center gap-1" role="group" aria-label="Filter by status">
                  {STATUS_FILTERS.map((f) => (
                    <button
                      type="button" key={f}
                      className={`btn btn-sm ${filter === f ? "btn-primary" : "btn-label-secondary"}`}
                      onClick={() => setFilter(f)}
                    >
                      {f}
                    </button>
                  ))}
                  <Link to="/enquiry" className="btn btn-sm btn-link ms-2">View all</Link>
                </div>
              </div>
              <div className="table-responsive">
                <table className="table dsh-table mb-0">
                  <thead>
                    <tr>
                      <th>Student</th>
                      <th>Course</th>
                      <th>Counselor</th>
                      <th>Source</th>
                      <th>Fees</th>
                      <th>Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {loading("enquiries") && (
                      <tr><td colSpan="6" className="text-center text-muted py-4">Loading…</td></tr>
                    )}
                    {failed("enquiries") && (
                      <tr><td colSpan="6" className="text-center text-muted py-4">Enquiries could not be loaded.</td></tr>
                    )}
                    {status.enquiries === "ready" && rows.length === 0 && (
                      <tr><td colSpan="6" className="text-center text-muted py-4">
                        {filter === "All" ? "No enquiries yet." : `No enquiries with status "${filter}".`}
                      </td></tr>
                    )}
                    {status.enquiries === "ready" && rows.map((e, i) => (
                      <tr key={idOf(e) || `${e.student_name}-${i}`}>
                        <td>
                          <div className="d-flex align-items-center">
                            <Avatar name={e.student_name} tone={AVATAR_TONES[i % AVATAR_TONES.length]} />
                            <div>
                              <span className="text-heading d-block">{text(e.student_name) || "-"}</span>
                              <small className="text-muted">{text(e.mobile_number)}</small>
                            </div>
                          </div>
                        </td>
                        <td>{text(e.course) || "-"}</td>
                        <td>{text(e.counselor_name) || "-"}</td>
                        <td>{text(e.enquiry_source) || "-"}</td>
                        <td>{money(e.course_fees)}</td>
                        <td>
                          <span className={`badge bg-label-${norm(e.status) === "converted" ? "success" : "warning"}`}>
                            {text(e.status) || "Follow Up"}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>

        {/* ===== Fee dues / recent registrations / enquiry sources ===== */}
        <div className="row g-4">
          <div className="col-12 col-md-6 col-lg-4">
            <div className="card h-100">
              <div className="card-header d-flex align-items-center justify-content-between">
                <h5 className="card-title mb-0">Upcoming Fee Dues</h5>
                <Link to="/billing" className="btn btn-sm btn-link p-0">View all</Link>
              </div>
              <div className="card-body pt-2">
                {loading("billings") && <Empty>Loading…</Empty>}
                {failed("billings") && <Empty>Billing could not be loaded.</Empty>}
                {status.billings === "ready" && stats.dues.length === 0 && <Empty>No pending fee payments.</Empty>}
                {status.billings === "ready" && (
                  <ul className="list-unstyled mb-0">
                    {stats.dues.map((d, i) => (
                      <li className="d-flex align-items-center mb-3" key={d.id ?? i}>
                        <Avatar name={d.name} tone={AVATAR_TONES[i % AVATAR_TONES.length]} />
                        <div className="flex-grow-1 min-w-0">
                          <h6 className="mb-0 fw-normal text-truncate">{text(d.name) || "-"}</h6>
                          <small className="text-muted d-block text-truncate">{text(d.course)}</small>
                        </div>
                        <div className="text-end ms-2">
                          <strong className="d-block">{money(d.amount)}</strong>
                          {d.overdue ? (
                            <span className="badge bg-label-danger">Overdue</span>
                          ) : (
                            <small className="text-muted">{d.date ? `Due ${formatDisplayDate(d.date)}` : "No due date"}</small>
                          )}
                        </div>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            </div>
          </div>

          <div className="col-12 col-md-6 col-lg-4">
            <div className="card h-100">
              <div className="card-header d-flex align-items-center justify-content-between">
                <h5 className="card-title mb-0">Recent Registrations</h5>
                <Link to="/registration" className="btn btn-sm btn-link p-0">View all</Link>
              </div>
              <div className="card-body pt-2">
                {loading("registrations") && <Empty>Loading…</Empty>}
                {failed("registrations") && <Empty>Registrations could not be loaded.</Empty>}
                {status.registrations === "ready" && stats.recentRegistrations.length === 0 && <Empty>No registrations yet.</Empty>}
                {status.registrations === "ready" && (
                  <ul className="list-unstyled mb-0">
                    {stats.recentRegistrations.map((r, i) => (
                      <li className="d-flex align-items-center mb-3" key={idOf(r) || i}>
                        <Avatar name={r.student_name} tone={AVATAR_TONES[(i + 2) % AVATAR_TONES.length]} />
                        <div className="flex-grow-1 min-w-0">
                          <h6 className="mb-0 fw-normal text-truncate">{text(r.student_name) || "-"}</h6>
                          <small className="text-muted d-block text-truncate">{text(r.course)}</small>
                        </div>
                        <small className="text-muted text-nowrap ms-2">
                          {formatDisplayDate(firstOf(r, ["registration_date", "created_at"]))}
                        </small>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            </div>
          </div>

          <div className="col-12 col-lg-4">
            <div className="card h-100">
              <div className="card-header pb-0">
                <h5 className="card-title mb-0">Enquiries by Source</h5>
              </div>
              <div className="card-body pt-3">
                {loading("enquiries") && <Empty>Loading…</Empty>}
                {failed("enquiries") && <Empty>Enquiries could not be loaded.</Empty>}
                {status.enquiries === "ready" && stats.sources.length === 0 && <Empty>No enquiries yet.</Empty>}
                {status.enquiries === "ready" && (
                  <ul className="list-unstyled mb-0">
                    {stats.sources.map((s, i) => (
                      <li className="mb-3" key={s.label}>
                        <div className="d-flex justify-content-between mb-1">
                          <span className="text-heading">{s.label}</span>
                          <small className="text-muted">
                            {s.count} · {Math.round((s.count / counts.enquiries) * 100)}%
                          </small>
                        </div>
                        <div className="progress" style={{ height: 6 }}>
                          <div
                            className="progress-bar" role="progressbar"
                            style={{ width: `${(s.count / counts.enquiries) * 100}%`, background: PALETTE[i % PALETTE.length] }}
                          ></div>
                        </div>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ======================================================================
   Dashboard - loads the data, then hands it to the view
   ====================================================================== */
const allLoading = () =>
  Object.fromEntries(Object.keys(ENDPOINTS).map((key) => [key, "loading"]));

function Dashboard() {
  const { getData, user } = useContext(AuthContext);

  // keep the latest getData without re-running the load on every render
  const getDataRef = useRef(getData);
  getDataRef.current = getData;
  const alive = useRef(true);

  const [raw, setRaw] = useState({});
  const [status, setStatus] = useState(allLoading);

  const load = useCallback(async () => {
    setStatus(allLoading());

    await Promise.all(
      Object.entries(ENDPOINTS).map(async ([key, endpoint]) => {
        let data;
        try {
          data = await getDataRef.current(endpoint);
        } catch (err) {
          data = undefined;
        }
        if (!alive.current) return;

        // getData() gives nothing back (or a non-list) when the request failed
        const ok = Array.isArray(data);
        if (ok) setRaw((prev) => ({ ...prev, [key]: data }));
        setStatus((prev) => ({ ...prev, [key]: ok ? "ready" : "error" }));
      })
    );
  }, []);

  useEffect(() => {
    alive.current = true;
    load();
    return () => {
      alive.current = false;
    };
  }, [load]);

  const today = getToday();
  const stats = useMemo(() => buildStats(raw, today), [raw, today]);

  const rawName = text(user && (user.username || user.name || user.first_name)) || "Admin";
  const userName = rawName.charAt(0).toUpperCase() + rawName.slice(1);

  return <DashboardView stats={stats} status={status} userName={userName} onRefresh={load} />;
}

export default Dashboard;