import React, { useContext, useState } from "react";
import AuthContext from "../../../services/AuthContext";

const Updatedesignation = (props) => {

    const { update } = useContext(AuthContext);

    const [error, setError] = useState("");

    const handleSubmit = async (e) => {

        e.preventDefault();

        setError("");

        if (!e.target.Department_id.value) {

            setError(
                "Please select a department from the list."
            );

            return;
        }

        const designationData = {
            Designation_id: e.target.Designation_id.value,
            Department_id: e.target.Department_id.value,
            Designation_name: e.target.Designation_name.value,
            Designation_Status: e.target.Designation_Status.value
        };

        console.log(designationData);

        try {

            await update(
                designationData,
                "update_designation_datail",
                "/designation"
            );

            props.toggle();

        } catch (error) {

            console.error(
                "Update operation failed:",
                error
            );

            const responseData =
                error.responseData;

            const message =
                responseData &&
                (
                    (Array.isArray(responseData.Designation_name)
                        ? responseData.Designation_name[0]
                        : responseData.Designation_name) ||
                    responseData.message ||
                    responseData.detail
                );

            setError(
                message ||
                "Designation could not be updated. Please try again."
            );

        }
    };

    return (
        <div
            className="modal fade show"
            tabIndex="-1"
            role="dialog"
            style={{
                display: "block",
                backgroundColor: "rgba(0,0,0,0.5)"
            }}
        >

            <div
                className="modal-dialog modal-dialog-centered"
                role="document"
            >

                <div className="modal-content">

                    {/* =========================
                        HEADER
                    ========================== */}

                    <div className="modal-header">

                        <h5 className="modal-title">
                            Update Designation
                        </h5>

                        <button
                            type="button"
                            className="btn-close"
                            onClick={props.toggle}
                            aria-label="Close"
                        ></button>

                    </div>


                    {/* =========================
                        BODY
                    ========================== */}

                    <div className="modal-body">

                        {error && (
                            <div
                                className="alert alert-danger"
                                role="alert"
                            >
                                <strong>Error!</strong>{" "}
                                {error}
                            </div>
                        )}

                        <form onSubmit={handleSubmit}>

                            {/* Hidden Designation ID */}

                            <input
                                type="hidden"
                                name="Designation_id"
                                defaultValue={props.data.Designation_id}
                            />


                            {/* DEPARTMENT */}
                            <div className="mb-3">

                                <label
                                    htmlFor="Department_id"
                                    className="form-label"
                                >
                                    Department
                                </label>

                                <props.DepartmentSearch
                                    departments={props.departments}
                                    defaultId={props.data.Department_id}
                                />


                            </div>


                            {/* DESIGNATION NAME */}

                            <div className="mb-3">

                                <label
                                    htmlFor="Designation_name"
                                    className="form-label"
                                >
                                    Designation
                                </label>

                                <input
                                    type="text"
                                    defaultValue={props.data.Designation_name}
                                    className="form-control"
                                    name="Designation_name"
                                    id="Designation_name"
                                    placeholder="Enter Designation"
                                    required
                                />

                            </div>

                            {/* DESIGNATION STATUS */}
                            <div className="mb-3">

                                <label
                                    htmlFor="Designation_Status"
                                    className="form-label"
                                >
                                    Status
                                </label>

                                <select
                                    id="Designation_Status"
                                    name="Designation_Status"
                                    className="form-select"
                                    required
                                    defaultValue={props.data.Designation_Status || "Active"}
                                >

                                    <option value="Active">
                                        Active
                                    </option>

                                    <option value="Deactive">
                                        Deactive
                                    </option>

                                </select>

                            </div>



                            {/* =========================
                                FOOTER
                            ========================== */}

                            <div className="modal-footer px-0 pb-0">

                                <button
                                    type="button"
                                    className="btn btn-outline-secondary"
                                    onClick={props.toggle}
                                >
                                    Cancel
                                </button>

                                <button
                                    type="submit"
                                    className="btn btn-success"
                                >
                                    Update Designation
                                </button>

                            </div>

                        </form>

                    </div>

                </div>

            </div>

        </div>
    );
};

export default Updatedesignation;