import React, {
    useState,
    useContext,
    useEffect,
    useCallback,
    useRef
} from "react";

import "./Designation.css";

import Adddesignation from "./adddesignation/Adddesignation";
import Updatedesignation from "./updatedesignation/Updatedesignation";
import Deletedesignation from "./deletedesignation/Deletedesignation";

import AuthContext from "../../services/AuthContext";

// =========================================================
// DEPARTMENT SEARCH DROPDOWN  (written once, used by the
// Add and Update forms through props)
//
//  - type to filter: a department matches when ANY WORD of its
//    name starts with the typed text ("de" -> "Tech dep")
//  - Up / Down arrows move, Enter selects, Esc closes
//  - renders a hidden input  name="Department_id"
// =========================================================

const DepartmentSearch = ({ departments, defaultId }) => {

    const [query, setQuery] = useState("");

    const [selectedId, setSelectedId] = useState(
        defaultId ? String(defaultId) : ""
    );

    const [open, setOpen] = useState(false);

    // index of the row highlighted with the arrow keys (-1 = none)
    const [active, setActive] = useState(-1);


    // Show the selected department's name once the list is loaded
    useEffect(() => {

        if (selectedId) {

            const found = departments.find(
                (d) => String(d.Department_id) === selectedId
            );

            if (found) {
                setQuery(found.Department_standard);
            }

        }

        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [departments]);


    const text = query.trim().toLowerCase();

    const filtered = departments.filter((d) =>
        d.Department_standard
            .toLowerCase()
            .split(/\s+/)
            .some((word) => word.startsWith(text))
    );


    const selectDepartment = (dep) => {

        setSelectedId(String(dep.Department_id));

        setQuery(dep.Department_standard);

        setOpen(false);

        setActive(-1);

    };


    // Up / Down arrows move, Enter selects, Esc closes
    const handleKeyDown = (e) => {

        const count = filtered.length;

        if (e.key === "ArrowDown") {

            e.preventDefault();

            setOpen(true);

            if (count > 0) {
                setActive((i) => (i + 1) % count);
            }

        } else if (e.key === "ArrowUp") {

            e.preventDefault();

            setOpen(true);

            if (count > 0) {
                setActive((i) => (i <= 0 ? count - 1 : i - 1));
            }

        } else if (e.key === "Enter") {

            // pick the highlighted row instead of submitting the form
            if (open && active >= 0 && filtered[active]) {

                e.preventDefault();

                selectDepartment(filtered[active]);

            }

        } else if (e.key === "Escape") {

            setOpen(false);

        }

    };


    // keep the highlighted row visible inside the scrolling list
    useEffect(() => {

        if (active >= 0) {

            const el = document.getElementById(
                "dept-option-" + active
            );

            if (el) {
                el.scrollIntoView({ block: "nearest" });
            }

        }

    }, [active]);


    // Closing the list moves the form (the modal re-centres), which made
    // the first click on X / Cancel miss its button.  So:
    //  - if focus is moving to a button (X, Cancel, Save) the list is left
    //    alone, the form is about to close / submit anyway;
    //  - otherwise the list closes after a short delay.
    const closeTimer = useRef(null);

    useEffect(() => {

        return () => clearTimeout(closeTimer.current);

    }, []);

    const handleBlur = (e) => {

        // exact typed name = select it
        if (!selectedId) {

            const exact = departments.find(
                (d) =>
                    d.Department_standard.toLowerCase() === text
            );

            if (exact) {
                setSelectedId(String(exact.Department_id));
                setQuery(exact.Department_standard);
            }

        }

        const next = e.relatedTarget;

        if (next && next.closest && next.closest("button")) {
            return;
        }

        closeTimer.current = setTimeout(
            () => setOpen(false),
            150
        );

    };


    return (

        <>

            <input
                type="text"
                className="form-control"
                placeholder="Search department..."
                value={query}
                onChange={(e) => {
                    setQuery(e.target.value);
                    setSelectedId("");
                    setOpen(true);
                    setActive(0);
                }}
                onKeyDown={handleKeyDown}
                onFocus={() => {
                    clearTimeout(closeTimer.current);
                    setOpen(true);
                }}
                onBlur={handleBlur}
                autoComplete="off"
            />

            <input
                type="hidden"
                name="Department_id"
                value={selectedId}
                readOnly
            />

            {open && (

                <ul
                    className="list-group mt-2"
                    style={{
                        maxHeight: "160px",
                        overflowY: "auto",
                        backgroundColor: "#fff",
                        border: "1px solid #d9dee3",
                        borderRadius: "6px"
                    }}
                >

                    {filtered.length > 0 ? (

                        filtered.map((dep, index) => (

                            <li
                                key={dep.Department_id}
                                id={"dept-option-" + index}
                                className={
                                    "list-group-item list-group-item-action" +
                                    (String(dep.Department_id) === selectedId
                                        ? " active"
                                        : "")
                                }
                                style={{
                                    cursor: "pointer",
                                    backgroundColor:
                                        String(dep.Department_id) === selectedId
                                            ? undefined
                                            : index === active
                                            ? "#e7e7ff"
                                            : "#fff"
                                }}
                                onMouseEnter={() => setActive(index)}
                                onMouseDown={(e) => {
                                    e.preventDefault();
                                    selectDepartment(dep);
                                }}
                            >
                                {dep.Department_standard}
                            </li>

                        ))

                    ) : (

                        <li
                            className="list-group-item text-muted"
                            style={{ backgroundColor: "#fff" }}
                        >
                            No departments found
                        </li>

                    )}

                </ul>

            )}

        </>

    );

};



function Designation() {

    const [addPopupVisible, setAddPopupVisible] = useState(false);
    const [updatePopupVisible, setUpdatePopupVisible] = useState(false);
    const [deletePopupVisible, setDeletePopupVisible] = useState(false);

    const [currentPage, setCurrentPage] = useState(1);

    const { getData, update } = useContext(AuthContext);

    const [designations, setDesignations] = useState([]);

    // Departments for the search dropdown (loaded once, shared by Add + Update)
    const [departments, setDepartments] = useState([]);

    useEffect(() => {

        const loadDepartments = async () => {

            try {

                const data = await getData(
                    "fetch_department_datail"
                );

                setDepartments(
                    Array.isArray(data) ? data : []
                );

            } catch (err) {

                console.error(
                    "Failed to fetch departments:",
                    err
                );

            }

        };

        loadDepartments();

    }, [getData]);

    const [value, setValue] = useState(null);


    // =====================================================
    // FETCH DESIGNATIONS
    // =====================================================

    const fetchDesignations = useCallback(async () => {

        try {

            const data = await getData(
                "fetch_designation_datail"
            );

            console.log(
                "Designations fetched:",
                data
            );

            if (Array.isArray(data)) {

                setDesignations(data);

            } else {

                setDesignations([]);

            }

        } catch (err) {

            console.error(
                "Failed to fetch designations:",
                err
            );

        }

    }, [getData]);


    // =====================================================
    // INITIAL LOAD
    // =====================================================

    useEffect(() => {

        fetchDesignations();

    }, [fetchDesignations]);


    // =====================================================
    // ADD POPUP
    // =====================================================

    const toggleAddPopup = () => {

        setAddPopupVisible(
            !addPopupVisible
        );

    };


    // =====================================================
    // UPDATE POPUP
    // =====================================================

    const toggleUpdatePopup = () => {

        setUpdatePopupVisible(
            !updatePopupVisible
        );

    };


    // =====================================================
    // DELETE POPUP
    // =====================================================

    const toggleDeletePopup = () => {

        setDeletePopupVisible(
            !deletePopupVisible
        );

    };


    // =====================================================
    // AFTER DESIGNATION CREATED
    // =====================================================

    const handleDesignationCreated = async () => {

        console.log(
            "New designation created. Refreshing list..."
        );

        // Fetch latest data from Django
        await fetchDesignations();

        // Close popup
        setAddPopupVisible(false);

        // Go back to first page
        setCurrentPage(1);

    };


    // =====================================================
    // PAGINATION
    // =====================================================

    // =====================================================
    // SEARCH  (two boxes: department + designation)
    // A row is shown when ANY WORD of the name starts with the typed
    // text.  When both boxes are filled, both must match.
    // =====================================================

    const [deptSearch, setDeptSearch] = useState("");

    const [searchText, setSearchText] = useState("");

    const matchesWord = (name, typed) => {

        const text = typed.trim().toLowerCase();

        return (name || "")
            .toLowerCase()
            .split(/\s+/)
            .some((word) => word.startsWith(text));

    };

    const filteredDesignations = designations.filter((d) =>
        matchesWord(d.Department_standard, deptSearch) &&
        matchesWord(d.Designation_name, searchText)
    );

    const handleSearch = (e) => {

        setSearchText(e.target.value);

        // always start from the first page of the results
        setCurrentPage(1);

    };

    const handleDeptSearch = (e) => {

        setDeptSearch(e.target.value);

        setCurrentPage(1);

    };


    const itemsPerPage = 4;

    const indexOfLastItem =
        currentPage * itemsPerPage;

    const indexOfFirstItem =
        indexOfLastItem - itemsPerPage;

    const currentDesignations =
        filteredDesignations.slice(
            indexOfFirstItem,
            indexOfLastItem
        );


    const nextPage = () => {

        if (
            indexOfLastItem <
            filteredDesignations.length
        ) {

            setCurrentPage(
                currentPage + 1
            );

        }

    };


    const prevPage = () => {

        if (currentPage > 1) {

            setCurrentPage(
                currentPage - 1
            );

        }

    };


    // =====================================================
    // UPDATE
    // =====================================================

    const handleUpdate = (designation) => {

        setValue(designation);

        toggleUpdatePopup();

    };


    // =====================================================
    // DELETE
    // =====================================================

    const handleDelete = (id) => {

        setValue(id);

        toggleDeletePopup();

    };


    // =====================================================
    // TOGGLE STATUS (Active <-> Deactive)
    // =====================================================

    const handleToggleStatus = async (designation) => {

        const newStatus =
            designation.Designation_Status === "Active"
                ? "Deactive"
                : "Active";

        try {

            await update(
                {
                    Designation_id: designation.Designation_id,
                    Department_id: designation.Department_id,
                    Designation_name: designation.Designation_name,
                    Designation_Status: newStatus
                },
                "update_designation_datail",
                "/designation"
            );

            // Show the change immediately, then reload from DB
            setDesignations((prev) =>
                prev.map((d) =>
                    d.Designation_id === designation.Designation_id
                        ? { ...d, Designation_Status: newStatus }
                        : d
                )
            );

            await fetchDesignations();

        } catch (err) {

            console.error(
                "Status update failed:",
                err
            );

        }

    };


    return (

        <div className="designation-page container-xxl flex-grow-1 container-p-y">


            {/* ================================================= */}
            {/* HEADER */}
            {/* ================================================= */}

            <div className="page-header">

                <div>

                    <h3 className="page-title">
                        Designation Management
                    </h3>

                    <p className="page-subtitle">
                        Manage all available designations
                    </p>

                </div>


                <button
                    className="btn btn-primary add-btn"
                    onClick={toggleAddPopup}
                >

                    <i className="bx bx-plus me-2"></i>

                    Add Designation

                </button>

            </div>


            {/* ================================================= */}
            {/* ADD DESIGNATION POPUP */}
            {/* ================================================= */}

            {addPopupVisible && (

                <Adddesignation
                    departments={departments}
                    DepartmentSearch={DepartmentSearch}
                    toggle={toggleAddPopup}
                    onSuccess={handleDesignationCreated}
                />

            )}


            {/* ================================================= */}
            {/* DESIGNATION TABLE */}
            {/* ================================================= */}

            <div className="card designation-card">

                {/* ============================================= */}
                {/* SEARCH (above the table)                       */}
                {/* ============================================= */}

                <div className="d-flex flex-wrap justify-content-start gap-3 p-3">

                    {/* Department search */}
                    <div
                        className="input-group"
                        style={{ maxWidth: "320px" }}
                    >

                        <span className="input-group-text">
                            <i className="bx bx-search"></i>
                        </span>

                        <input
                            type="text"
                            className="form-control"
                            placeholder="Search department..."
                            value={deptSearch}
                            onChange={handleDeptSearch}
                        />

                        {deptSearch && (

                            <button
                                type="button"
                                className="btn btn-outline-secondary"
                                onClick={() => {
                                    setDeptSearch("");
                                    setCurrentPage(1);
                                }}
                            >
                                &times;
                            </button>

                        )}

                    </div>


                    {/* Designation search */}
                    <div
                        className="input-group"
                        style={{ maxWidth: "320px" }}
                    >

                        <span className="input-group-text">
                            <i className="bx bx-search"></i>
                        </span>

                        <input
                            type="text"
                            className="form-control"
                            placeholder="Search designation..."
                            value={searchText}
                            onChange={handleSearch}
                        />

                        {searchText && (

                            <button
                                type="button"
                                className="btn btn-outline-secondary"
                                onClick={() => {
                                    setSearchText("");
                                    setCurrentPage(1);
                                }}
                            >
                                &times;
                            </button>

                        )}

                    </div>

                </div>


                <div className="table-responsive">

                    <table className="table modern-table">

                        <thead>

                            <tr>

                                <th>ID</th>

                                <th>
                                    Department
                                </th>

                                <th>
                                    Designation
                                </th>

                                <th>
                                    Status
                                </th>

                                <th width="180">
                                    Action
                                </th>

                            </tr>

                        </thead>


                        <tbody>

                            {currentDesignations.length > 0 ? (

                                currentDesignations.map(
                                    (designation) => (

                                        <tr
                                            key={
                                                designation.Designation_id
                                            }
                                        >

                                            <td>
                                                #{designation.Designation_id}
                                            </td>


                                            <td>
                                                {
                                                    designation.Department_standard
                                                }
                                            </td>


                                            <td>

                                                <strong>
                                                    {
                                                        designation.Designation_name
                                                    }
                                                </strong>

                                            </td>


                                            <td>

                                                <span
                                                    className={
                                                        designation.Designation_Status ===
                                                        "Active"
                                                            ? "status active"
                                                            : "status inactive"
                                                    }
                                                    style={{ cursor: "pointer" }}
                                                    title="Click to change status"
                                                    onClick={() =>
                                                        handleToggleStatus(
                                                            designation
                                                        )
                                                    }
                                                >

                                                    {
                                                        designation.Designation_Status
                                                    }

                                                </span>

                                            </td>


                                            <td>

                                                <div className="action-buttons">

                                                    <button
                                                        className="btn btn-edit"
                                                        onClick={() =>
                                                            handleUpdate(
                                                                designation
                                                            )
                                                        }
                                                    >
                                                        Edit
                                                    </button>


                                                    <button
                                                        className="btn btn-delete"
                                                        onClick={() =>
                                                            handleDelete(
                                                                designation.Designation_id
                                                            )
                                                        }
                                                    >
                                                        Delete
                                                    </button>

                                                </div>

                                            </td>

                                        </tr>

                                    )
                                )

                            ) : (

                                <tr>

                                    <td
                                        colSpan="5"
                                        className="text-center py-4"
                                    >

                                        {(searchText || deptSearch)
                                            ? "No matching designations found."
                                            : "No designations found."}

                                    </td>

                                </tr>

                            )}

                        </tbody>

                    </table>

                </div>


                {/* ================================================= */}
                {/* UPDATE */}
                {/* ================================================= */}

                {updatePopupVisible && (

                    <Updatedesignation
                        departments={departments}
                        DepartmentSearch={DepartmentSearch}
                        toggle={toggleUpdatePopup}
                        data={value}
                    />

                )}


                {/* ================================================= */}
                {/* DELETE */}
                {/* ================================================= */}

                {deletePopupVisible && (

                    <Deletedesignation
                        toggle={toggleDeletePopup}
                        data={value}
                    />

                )}


                {/* ================================================= */}
                {/* PAGINATION */}
                {/* ================================================= */}

                <div className="card-footer bg-white border-0">

                    <div className="d-flex justify-content-end">

                        <button
                            className="btn btn-light me-2"
                            onClick={prevPage}
                            disabled={
                                currentPage === 1
                            }
                        >

                            <i className="bx bx-chevron-left"></i>

                            Previous

                        </button>


                        <button
                            className="btn btn-primary"
                            onClick={nextPage}
                            disabled={
                                indexOfLastItem >=
                                filteredDesignations.length
                            }
                        >

                            Next

                            <i className="bx bx-chevron-right ms-1"></i>

                        </button>

                    </div>

                </div>

            </div>

        </div>

    );

}


export default Designation;