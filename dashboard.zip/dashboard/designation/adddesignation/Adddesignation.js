import React, { useContext, useState } from "react";
import AuthContext from "../../../services/AuthContext";
// import "./adddesignation.css";

const Adddesignation = (props) => {

    const { insert } = useContext(AuthContext);

    const [validated, setValidated] = useState(false);
    const [error, setError] = useState("");
    const [success, setSuccess] = useState("");
    const [loading, setLoading] = useState(false);


    const handleSubmit = async (e) => {

        e.preventDefault();

        const form = e.currentTarget;

        setError("");
        setSuccess("");


        // =========================
        // FORM VALIDATION
        // =========================

        if (!form.checkValidity()) {

            e.stopPropagation();

            setValidated(true);

            return;
        }


        // =========================
        // GET FORM DATA
        // =========================

        const departmentId =
            form.Department_id.value;

        if (!departmentId) {

            setError(
                "Please select a department from the list."
            );

            return;
        }

        const designationName =
            form.Designation_name.value.trim();


        // =========================
        // DESIGNATION NAME VALIDATION
        // =========================

        if (designationName.length < 2) {

            setError(
                "Designation must contain at least 2 characters."
            );

            setValidated(true);

            return;
        }


        // =========================
        // DESIGNATION DATA
        // =========================

        const designationData = {

            Department_id: Number(departmentId),

            Designation_name: designationName,

        };


        console.log(
            "Sending Designation:",
            designationData
        );


        try {

            setLoading(true);


            // =========================
            // INSERT
            // =========================

            const response = await insert(
                designationData,
                "designation_create"
            );


            console.log(
                "Designation created:",
                response
            );


            // =========================
            // SUCCESS
            // =========================

            setSuccess(
    "Designation created successfully!"
);


// Clear form
form.reset();

setValidated(false);


// Refresh parent designation list
if (props.onSuccess) {

    await props.onSuccess();

}


        } catch (error) {

            console.error(
                "Designation creation error:",
                error
            );


            // =========================
            // DJANGO ERROR
            // =========================

            const responseData =
                error.responseData;


            console.log(
                "Django Error:",
                responseData
            );


            // Designation duplicate
            if (
                responseData &&
                responseData.Designation_name
            ) {

                const message =
                    Array.isArray(
                        responseData.Designation_name
                    )
                        ? responseData.Designation_name[0]
                        : responseData.Designation_name;


                setError(message);

            }

            // Message error
            else if (
                responseData &&
                responseData.message
            ) {

                setError(
                    responseData.message
                );

            }

            // Detail error
            else if (
                responseData &&
                responseData.detail
            ) {

                setError(
                    responseData.detail
                );

            }

            // Other server error
            else {

                setError(
                    "Designation could not be created. Please try again."
                );
            }

        } finally {

            setLoading(false);

        }

    };


return (
    <div
        className="modal fade show"
        tabIndex="-1"
        role="dialog"
        style={{ display: "block", backgroundColor: "rgba(0,0,0,0.5)" }}
    >
        <div
            className="modal-dialog modal-dialog-centered"
            role="document"
        >
            <div className="modal-content">

                {/* HEADER */}
                <div className="modal-header">

                    <h5 className="modal-title">
                        Add Designation
                    </h5>

                    <button
                        type="button"
                        className="btn-close"
                        onClick={props.toggle}
                        aria-label="Close"
                    ></button>

                </div>

                {/* BODY */}
                <div className="modal-body">

                    {/* SUCCESS */}
                    {success && (
                        <div
                            className="alert alert-success"
                            role="alert"
                        >
                            <strong>Success!</strong>{" "}
                            {success}
                        </div>
                    )}

                    {/* ERROR */}
                    {error && (
                        <div
                            className="alert alert-danger"
                            role="alert"
                        >
                            <strong>Error!</strong>{" "}
                            {error}
                        </div>
                    )}

                    <form
                        onSubmit={handleSubmit}
                        noValidate
                        className={
                            validated ? "was-validated" : ""
                        }
                    >



                        {/* DEPARTMENT */}
                        <div className="mb-3">

                            <label
                                htmlFor="Department_id"
                                className="form-label"
                            >
                                Department
                            </label>

                            <props.DepartmentSearch
                                departments={props.departments}
                            />


                        </div>


                        {/* DESIGNATION NAME */}
                        <div className="mb-3">

                            <label
                                htmlFor="Designation_name"
                                className="form-label"
                            >
                                Designation
                            </label>

                            <input
                                type="text"
                                name="Designation_name"
                                id="Designation_name"
                                className="form-control"
                                placeholder="Enter Designation"
                                required
                                maxLength="255"
                            />

                            <div className="invalid-feedback">
                                Please enter a valid designation.
                            </div>

                        </div>


                        {/* FOOTER BUTTONS */}
                        <div className="modal-footer px-0 pb-0">

                            <button
                                type="button"
                                className="btn btn-outline-secondary"
                                onClick={props.toggle}
                                disabled={loading}
                            >
                                Cancel
                            </button>

                            <button
                                type="submit"
                                className="btn btn-primary"
                                disabled={loading}
                            >

                                {loading ? (
                                    <>
                                        <span
                                            className="spinner-border spinner-border-sm me-2"
                                            role="status"
                                            aria-hidden="true"
                                        ></span>

                                        Saving...
                                    </>
                                ) : (
                                    "Save Designation"
                                )}

                            </button>

                        </div>

                    </form>

                </div>

            </div>
        </div>
    </div>
);
};


export default Adddesignation;