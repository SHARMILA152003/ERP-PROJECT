import React, { useContext, useState } from "react";
import AuthContext from "../../../services/AuthContext";
import "./deleteenquiry.css";

const Deleteenquiry = (props) => {

    const { Delete } = useContext(AuthContext);

    const [loading, setLoading] = useState(false);
    const [error, setError] = useState("");

    const handleSubmit = async () => {

        try {

            if (!props.data) {
                throw new Error("Missing or invalid data for deletion");
            }

            setLoading(true);
            setError("");

            await Delete(
                { enquiry_id: props.data },
                "delete_enquiry_detail",
                "/enquiry"
            );

            if (props.onSuccess) {
                await props.onSuccess("Enquiry deleted successfully!");
            } else {
                props.toggle();
            }

        } catch (err) {

            console.error("Delete operation failed:", err);
            setError("Enquiry could not be deleted. Please try again.");
            setLoading(false);

        }
    };

    return (

        <div
            className="modal fade show"
            tabIndex="-1"
            role="dialog"
            style={{
                display: "block",
                backgroundColor: "rgba(0,0,0,0.5)"
            }}
        >

            <div
                className="modal-dialog modal-dialog-centered"
                role="document"
            >

                <div className="modal-content">

                    <div className="modal-header">

                        <h5 className="modal-title">
                            Delete Enquiry
                        </h5>

                        <button
                            type="button"
                            className="btn-close"
                            onClick={props.toggle}
                            aria-label="Close"
                        ></button>

                    </div>

                    <div className="modal-body text-center">

                        <div
                            className="text-danger mb-3"
                            style={{ fontSize: "40px" }}
                        >
                            ⚠
                        </div>

                        <h5 className="mb-0">Are you sure you want to delete?</h5>

                        {error && (
                            <div className="alert alert-danger mt-3 mb-0">
                                {error}
                            </div>
                        )}

                    </div>

                    <div className="modal-footer">

                        <button
                            type="button"
                            className="btn btn-outline-secondary"
                            onClick={props.toggle}
                            disabled={loading}
                        >
                            Cancel
                        </button>

                        <button
                            type="button"
                            onClick={handleSubmit}
                            className="btn btn-danger"
                            disabled={loading}
                        >
                            {loading ? "Deleting..." : "Delete"}
                        </button>

                    </div>

                </div>

            </div>

        </div>
    );
};

export default Deleteenquiry;
