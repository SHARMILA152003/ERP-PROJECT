import React, {
    useState,
    useContext,
    useEffect,
    useCallback,
    useMemo
} from "react";

import "./Enquiry.css";

import Addenquiry, {
    getEnquiryId,
    STATUSES,
    buildPayload,
    toFormData,
    normalizeActivity,
    splitValidity as parseValidity
} from "./addenquiry/Addenquiry";
import Updateenquiry from "./updateenquiry/Updateenquiry";
import Deleteenquiry from "./deleteenquiry/Deleteenquiry";

import AuthContext from "../../services/AuthContext";


const ITEMS_PER_PAGE = 5;

const COLUMN_COUNT = 11;

// Browser copy of the activity status. Used when the backend does not
// send an "activity_status" field yet, so the choice survives a refresh.
const ACTIVITY_STORE_KEY = "enquiry_activity_status";

const readActivityStore = () => {
    try {
        return JSON.parse(localStorage.getItem(ACTIVITY_STORE_KEY)) || {};
    } catch (err) {
        return {};
    }
};

const writeActivityStore = (map) => {
    try {
        localStorage.setItem(ACTIVITY_STORE_KEY, JSON.stringify(map));
    } catch (err) {
        /* storage not available - ignore */
    }
};

const statusClass = (status) =>
    "status status-" +
    String(status || "new").toLowerCase().replace(/\s+/g, "");

const formatMoney = (value) =>
    Number(value || 0).toLocaleString("en-IN", {
        maximumFractionDigits: 2
    });


// Value is shown only when the candidate actually gave it
const hasValue = (value) =>
    value !== null && value !== undefined && String(value).trim() !== "";

// "2026-10-01 to 2026-10-31"  ->  { start, end }
const splitValidity = (value) => {

    if (!hasValue(value)) return null;

    const [start, end] = String(value).split(" to ");

    return { start: start || "", end: end || "" };
};

// Page numbers with "…" gaps, e.g. 1 … 4 5 6 … 12
const buildPageList = (page, totalPages) => {

    if (totalPages <= 7) {
        return Array.from({ length: totalPages }, (_, i) => i + 1);
    }

    const list = [1];

    const start = Math.max(2, page - 1);
    const end = Math.min(totalPages - 1, page + 1);

    if (start > 2) list.push("gap-left");

    for (let i = start; i <= end; i += 1) list.push(i);

    if (end < totalPages - 1) list.push("gap-right");

    list.push(totalPages);

    return list;
};

// Details shown in the "+" panel (empty ones are skipped)
const buildDetails = (row) => {

    const validity = splitValidity(row.discount_validity);

    return [
        { label: "Phone", value: row.mobile_number },
        { label: "Email", value: row.email },
        { label: "Address", value: row.address },
        { label: "Qualification", value: row.qualification },
        { label: "School", value: row.school_name },
        { label: "College", value: row.college_name },
        { label: "Diploma course", value: row.diploma_course },
        { label: "Degree course", value: row.degree_course },
        { label: "Specialization", value: row.specialization },
        { label: "Year of passing", value: row.year_of_passing },

        // columns that disappear from the table on narrow screens
        {
            label: "Counselor",
            value: row.counselor_name,
            extra: "only-sm"
        },
        {
            label: "Discount validity",
            value: validity
                ? `${validity.start} to ${validity.end}`
                : "",
            extra: "only-md"
        },
        { label: "Source", value: row.enquiry_source, extra: "only-md" },
        { label: "Remarks", value: row.remarks, extra: "only-md" }
    ].filter((item) => hasValue(item.value));
};


function Enquiry() {

    // "list" | "add" | "edit"
    const [view, setView] = useState("list");

    const [deletePopupVisible, setDeletePopupVisible] = useState(false);

    const { getData, update } = useContext(AuthContext);

    const [enquiries, setEnquiries] = useState([]);
    const [selected, setSelected] = useState(null);
    const [deleteId, setDeleteId] = useState(null);

    const [searchName, setSearchName] = useState("");
    const [searchCourse, setSearchCourse] = useState("");
    const [searchMobile, setSearchMobile] = useState("");
    // Which search box is in use (the other two shrink a little)
    const [activeSearch, setActiveSearch] = useState("");
    // Random field names so the browser never offers "Saved info" here
    const searchNonce = useMemo(() => Math.random().toString(36).slice(2, 8), []);
    const [statusFilter, setStatusFilter] = useState("");
    const [currentPage, setCurrentPage] = useState(1);

    // id of the row whose "+" details are open (one at a time)
    const [expandedId, setExpandedId] = useState(null);

    const [message, setMessage] = useState("");

    // Active / Inactive toggle
    const [activityStore, setActivityStore] = useState(readActivityStore);
    const [togglingId, setTogglingId] = useState(null);


    // =====================================================
    // FETCH ENQUIRIES
    // =====================================================

    const fetchEnquiries = useCallback(async () => {

        try {

            const data = await getData("fetch_enquiry_detail");

            setEnquiries(Array.isArray(data) ? data : []);

        } catch (err) {

            console.error("Failed to fetch enquiries:", err);

        }

    }, [getData]);


    useEffect(() => {

        fetchEnquiries();

    }, [fetchEnquiries]);


    // Success pop up closes with OK, Enter or Escape
    useEffect(() => {

        if (!message) return undefined;

        const onKey = (ev) => {
            if (ev.key === "Escape" || ev.key === "Enter") setMessage("");
        };
        document.addEventListener("keydown", onKey);

        return () => document.removeEventListener("keydown", onKey);

    }, [message]);


    // =====================================================
    // NAVIGATION BETWEEN LIST / ADD / EDIT
    // =====================================================

    const openAdd = () => {
        setMessage("");
        setView("add");
    };

    const openEdit = (row) => {
        setMessage("");
        setSelected(row);
        setView("edit");
    };

    const backToList = () => {
        setSelected(null);
        setView("list");
    };

    // Called by add / update / delete with ONE success message
    const handleSaved = async (successMessage) => {

        await fetchEnquiries();

        setMessage(successMessage);
        setExpandedId(null);
        setCurrentPage(1);
        setDeletePopupVisible(false);
        setDeleteId(null);
        backToList();

    };

    const openDelete = (id) => {
        setDeleteId(id);
        setDeletePopupVisible(true);
    };

    const closeDelete = () => {
        setDeletePopupVisible(false);
        setDeleteId(null);
    };


    // =====================================================
    // ACTIVITY STATUS (click to switch Active <-> Inactive)
    // =====================================================

    const getActivity = (row) =>
        hasValue(row.activity_status)
            ? normalizeActivity(row.activity_status)
            : activityStore[getEnquiryId(row)] || "Active";

    const toggleActivity = async (row) => {

        const id = getEnquiryId(row);

        if (togglingId === id) return;

        const previous = getActivity(row);
        const next = previous === "Active" ? "Inactive" : "Active";

        const oldStore = activityStore;
        const newStore = { ...activityStore, [id]: next };

        const setRowActivity = (value) =>
            setEnquiries((list) =>
                list.map((item) =>
                    getEnquiryId(item) === id
                        ? { ...item, activity_status: value }
                        : item
                )
            );

        // show the new colour straight away
        setTogglingId(id);
        setRowActivity(next);
        setActivityStore(newStore);
        writeActivityStore(newStore);

        try {

            await update(
                {
                    ...buildPayload(
                        toFormData(row),
                        parseValidity(row.discount_validity)
                    ),
                    enquiry_id: id,
                    activity_status: next
                },
                "update_enquiry_detail",
                "/enquiry"
            );

        } catch (err) {

            console.error("Failed to change activity status:", err);

            // put everything back
            setRowActivity(previous);
            setActivityStore(oldStore);
            writeActivityStore(oldStore);

        } finally {

            setTogglingId(null);

        }
    };


    // =====================================================
    // SEARCH + FILTER + PAGINATION
    // =====================================================

    const filtered = useMemo(() => {

        const nameText = searchName.trim().toLowerCase();
        const courseText = searchCourse.trim().toLowerCase();
        const mobileText = searchMobile.trim();

        const starts = (value, text) =>
            !text || String(value || "").toLowerCase().startsWith(text);

        return enquiries.filter((row) => {

            if (statusFilter && row.status !== statusFilter) {
                return false;
            }

            return (
                starts(row.student_name, nameText) &&
                starts(row.course, courseText) &&
                starts(row.mobile_number, mobileText)
            );
        });

    }, [enquiries, searchName, searchCourse, searchMobile, statusFilter]);

    const totalPages = Math.max(
        1,
        Math.ceil(filtered.length / ITEMS_PER_PAGE)
    );

    const page = Math.min(currentPage, totalPages);

    const indexOfFirstItem = (page - 1) * ITEMS_PER_PAGE;

    const currentEnquiries = filtered.slice(
        indexOfFirstItem,
        indexOfFirstItem + ITEMS_PER_PAGE
    );

    const goToPage = (target) => {
        setExpandedId(null);
        setCurrentPage(target);
    };

    const nextPage = () => {
        if (page < totalPages) goToPage(page + 1);
    };

    const prevPage = () => {
        if (page > 1) goToPage(page - 1);
    };

    const toggleExpand = (id) =>
        setExpandedId((current) => (current === id ? null : id));

    const pageList = buildPageList(page, totalPages);

    const showingFrom = filtered.length === 0 ? 0 : indexOfFirstItem + 1;
    const showingTo = indexOfFirstItem + currentEnquiries.length;


    // =====================================================
    // ADD / EDIT PAGES
    // =====================================================

    if (view === "add") {

        return (
            <div className="enquiry-page container-xxl flex-grow-1 container-p-y">
                <Addenquiry
                    toggle={backToList}
                    onSuccess={handleSaved}
                />
            </div>
        );

    }

    if (view === "edit" && selected) {

        return (
            <div className="enquiry-page container-xxl flex-grow-1 container-p-y">
                <Updateenquiry
                    toggle={backToList}
                    data={selected}
                    onSuccess={handleSaved}
                />
            </div>
        );

    }


    // =====================================================
    // LIST PAGE
    // =====================================================

    return (

        <div className="enquiry-page container-xxl flex-grow-1 container-p-y">

            {/* HEADER */}

            <div className="page-header">

                <div>

                    <h3 className="page-title">
                        Enquiry Management
                    </h3>

                </div>

                <button
                    className="btn btn-primary add-btn"
                    onClick={openAdd}
                >

                    <i className="bx bx-plus me-2"></i>

                    Add Enquiry

                </button>

            </div>


            {/* SUCCESS MESSAGE */}

            {message && (

                <div
                    className="enquiry-success-backdrop"
                    onClick={() => setMessage("")}
                >
                    <div
                        className="enquiry-success-box"
                        role="alertdialog"
                        aria-modal="true"
                        onClick={(ev) => ev.stopPropagation()}
                    >
                        <div className="enquiry-success-icon">
                            <i className="bx bx-check"></i>
                        </div>
                        <h5 className="enquiry-success-title">Success</h5>
                        <p className="enquiry-success-text">{message}</p>
                        <button
                            type="button"
                            className="btn btn-primary btn-sm enquiry-success-ok"
                            onClick={() => setMessage("")}
                            autoFocus
                        >
                            OK
                        </button>
                    </div>
                </div>

            )}


            {/* TABLE CARD */}

            <div className="card enquiry-card">

                {/* TOOLBAR */}

                <div className="enquiry-toolbar">

                    <input
                        type="search"
                        autoComplete="new-password"
                        className={
                            "form-control form-control-sm search-box" +
                            (activeSearch === "name" ? " search-active" : "") +
                            (activeSearch && activeSearch !== "name" ? " search-minimized" : "")
                        }
                        placeholder="Search by name"
                        name={"s_name__" + searchNonce}
                        value={searchName}
                        onFocus={() => setActiveSearch("name")}
                        onBlur={() => setActiveSearch("")}
                        onChange={(e) => {
                            setSearchName(e.target.value);
                            setExpandedId(null);
                            setCurrentPage(1);
                        }}
                    />

                    <input
                        type="search"
                        autoComplete="new-password"
                        className={
                            "form-control form-control-sm search-box" +
                            (activeSearch === "course" ? " search-active" : "") +
                            (activeSearch && activeSearch !== "course" ? " search-minimized" : "")
                        }
                        placeholder="Search by course"
                        name={"s_course__" + searchNonce}
                        value={searchCourse}
                        onFocus={() => setActiveSearch("course")}
                        onBlur={() => setActiveSearch("")}
                        onChange={(e) => {
                            setSearchCourse(e.target.value);
                            setExpandedId(null);
                            setCurrentPage(1);
                        }}
                    />

                    <input
                        type="search"
                        autoComplete="new-password" inputMode="numeric"
                        className={
                            "form-control form-control-sm search-box" +
                            (activeSearch === "mobile" ? " search-active" : "") +
                            (activeSearch && activeSearch !== "mobile" ? " search-minimized" : "")
                        }
                        placeholder="Search by mobile"
                        name={"s_mobile__" + searchNonce}
                        value={searchMobile}
                        onFocus={() => setActiveSearch("mobile")}
                        onBlur={() => setActiveSearch("")}
                        onChange={(e) => {
                            setSearchMobile(e.target.value.replace(/\D/g, "").slice(0, 10));
                            setExpandedId(null);
                            setCurrentPage(1);
                        }}
                    />

                    <select
                        className="form-select form-select-sm status-filter"
                        value={statusFilter}
                        onChange={(e) => {
                            setStatusFilter(e.target.value);
                            setExpandedId(null);
                            setCurrentPage(1);
                        }}
                    >

                        <option value="">All status</option>

                        {STATUSES.map((item) => (
                            <option key={item} value={item}>
                                {item}
                            </option>
                        ))}

                    </select>

                </div>


                <div className="table-responsive">

                    <table className="table modern-table">

                        <colgroup>
                            <col className="c-id" />
                            <col className="c-student" />
                            <col className="c-counselor col-sm-hide" />
                            <col className="c-course" />
                            <col className="c-fees" />
                            <col className="c-validity col-md-hide" />
                            <col className="c-remarks col-md-hide" />
                            <col className="c-status" />
                            <col className="c-activity" />
                            <col className="c-source col-md-hide" />
                            <col className="c-action" />
                        </colgroup>

                        <thead>

                            <tr>

                                <th className="th-id">ID</th>
                                <th>Student Name</th>
                                <th className="col-sm-hide">Counselor</th>
                                <th>Course</th>
                                <th>Fees</th>
                                <th className="col-md-hide th-wrap">Discount Validity</th>
                                <th className="col-md-hide">Remarks</th>
                                <th>Status</th>
                                <th className="th-wrap">Activity Status</th>
                                <th className="col-md-hide">Source</th>
                                <th>Action</th>

                            </tr>

                        </thead>


                        <tbody>

                            {currentEnquiries.length > 0 ? (

                                currentEnquiries.map((row) => {

                                    const id = getEnquiryId(row);

                                    const isOpen = expandedId === id;

                                    const fees = Number(row.course_fees || 0);
                                    const discount = Number(
                                        row.discount_percentage || 0
                                    );
                                    const net = fees - (fees * discount) / 100;

                                    const validity = splitValidity(
                                        row.discount_validity
                                    );

                                    const details = buildDetails(row);

                                    const activity = getActivity(row);

                                    return (

                                        <React.Fragment key={id}>

                                            <tr className={isOpen ? "row-open" : ""}>

                                                <td>

                                                    <div className="id-cell">

                                                        <button
                                                            type="button"
                                                            className="expand-btn"
                                                            onClick={() => toggleExpand(id)}
                                                            aria-expanded={isOpen}
                                                            aria-label={
                                                                isOpen
                                                                    ? "Hide details"
                                                                    : "Show details"
                                                            }
                                                        >
                                                            {isOpen ? "−" : "+"}
                                                        </button>

                                                        <span>{id}</span>

                                                    </div>

                                                </td>

                                                <td>

                                                    <div
                                                        className="cell-main"
                                                        title={row.student_name}
                                                    >
                                                        {row.student_name}
                                                    </div>

                                                </td>

                                                <td className="col-sm-hide">

                                                    <div
                                                        className="cell-ellipsis"
                                                        title={row.counselor_name}
                                                    >
                                                        {row.counselor_name || "-"}
                                                    </div>

                                                </td>

                                                <td>

                                                    <div
                                                        className="cell-clamp"
                                                        title={row.course}
                                                    >
                                                        {row.course || "-"}
                                                    </div>

                                                </td>

                                                <td>

                                                    <div className="cell-main">
                                                        ₹ {formatMoney(net)}
                                                    </div>

                                                    {discount > 0 && (
                                                        <div className="cell-sub">
                                                            {discount}% off
                                                        </div>
                                                    )}

                                                </td>

                                                <td className="col-md-hide">

                                                    {validity ? (
                                                        <>
                                                            <div className="cell-ellipsis">
                                                                {validity.start}
                                                            </div>

                                                            <div className="cell-sub">
                                                                to {validity.end}
                                                            </div>
                                                        </>
                                                    ) : (
                                                        "-"
                                                    )}

                                                </td>

                                                <td className="col-md-hide">

                                                    <div
                                                        className="cell-clamp"
                                                        title={row.remarks}
                                                    >
                                                        {row.remarks || "-"}
                                                    </div>

                                                </td>

                                                <td>

                                                    <span className={statusClass(row.status)}>
                                                        {row.status}
                                                    </span>

                                                </td>

                                                <td>

                                                    <button
                                                        type="button"
                                                        className={
                                                            "activity-btn " +
                                                            (activity === "Active"
                                                                ? "activity-active"
                                                                : "activity-inactive")
                                                        }
                                                        onClick={() => toggleActivity(row)}
                                                        disabled={togglingId === id}
                                                        title="Click to change"
                                                        aria-pressed={activity === "Active"}
                                                    >
                                                        <span className="activity-dot"></span>
                                                        {activity}
                                                    </button>

                                                </td>

                                                <td className="col-md-hide">

                                                    <div
                                                        className="cell-clamp"
                                                        title={row.enquiry_source}
                                                    >
                                                        {row.enquiry_source || "-"}
                                                    </div>

                                                </td>

                                                <td>

                                                    <div className="action-buttons">

                                                        <button
                                                            className="btn btn-edit"
                                                            onClick={() => openEdit(row)}
                                                        >
                                                            Edit
                                                        </button>

                                                        <button
                                                            className="btn btn-delete"
                                                            onClick={() => openDelete(id)}
                                                        >
                                                            Delete
                                                        </button>

                                                    </div>

                                                </td>

                                            </tr>

                                            {isOpen && (

                                                <tr className="detail-row">

                                                    <td colSpan={COLUMN_COUNT}>

                                                        <div className="detail-grid">

                                                            {details.map((item) => (

                                                                <div
                                                                    key={item.label}
                                                                    className={
                                                                        "detail-item " +
                                                                        (item.extra || "")
                                                                    }
                                                                >

                                                                    <span className="detail-label">
                                                                        {item.label}
                                                                    </span>

                                                                    <span className="detail-value">
                                                                        {String(item.value)}
                                                                    </span>

                                                                </div>

                                                            ))}

                                                        </div>

                                                    </td>

                                                </tr>

                                            )}

                                        </React.Fragment>

                                    );
                                })

                            ) : (

                                <tr>

                                    <td
                                        colSpan={COLUMN_COUNT}
                                        className="text-center py-4"
                                    >
                                        No enquiries found.
                                    </td>

                                </tr>

                            )}

                        </tbody>

                    </table>

                </div>


                {/* PAGINATION */}

                <div className="card-footer bg-white border-0">

                    <span className="page-info">
                        Showing {showingFrom}-{showingTo} of {filtered.length}
                    </span>

                    <div className="pager">

                        <button
                            type="button"
                            className="page-btn page-btn-nav"
                            onClick={prevPage}
                            disabled={page === 1}
                        >
                            Previous
                        </button>

                        {pageList.map((item) =>

                            typeof item === "number" ? (

                                <button
                                    key={item}
                                    type="button"
                                    className={
                                        "page-btn" +
                                        (item === page ? " active" : "")
                                    }
                                    onClick={() => goToPage(item)}
                                    aria-current={item === page ? "page" : undefined}
                                >
                                    {item}
                                </button>

                            ) : (

                                <span key={item} className="page-gap">
                                    …
                                </span>

                            )

                        )}

                        <button
                            type="button"
                            className="page-btn page-btn-nav"
                            onClick={nextPage}
                            disabled={page >= totalPages}
                        >
                            Next
                        </button>

                    </div>

                </div>

            </div>


            {/* DELETE (outside the card so the popup covers the whole screen) */}

            {deletePopupVisible && (

                <Deleteenquiry
                    toggle={closeDelete}
                    data={deleteId}
                    onSuccess={handleSaved}
                />

            )}

        </div>

    );

}


export default Enquiry;
