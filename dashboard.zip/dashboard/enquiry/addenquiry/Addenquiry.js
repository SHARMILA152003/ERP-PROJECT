import React, { useContext, useEffect, useRef, useState } from "react";
import AuthContext from "../../../services/AuthContext";
import "./addenquiry.css";

// =====================================================
// SHARED CONSTANTS (also used by Updateenquiry.js)
// =====================================================

export const EMPTY_FORM = {
    student_name: "",
    mobile_number: "",
    email: "",
    address: "",
    qualification: "",
    school_name: "",
    college_name: "",
    diploma_course: "",
    degree_course: "",
    specialization: "",
    year_of_passing: "",
    education_details: [],
    course: "",
    counselor_name: "",
    course_fees: "",
    discount_percentage: "",
    discount_validity: "",
    enquiry_source: "",
    status: "Follow Up",
    activity_status: "Active",
    remarks: ""
};

// One row of the education table. Same structure as the Registration module,
// so a registration can pick the list up from the enquiry as it is.
export const EMPTY_EDU = {
    qualification: "",
    institute: "",
    board: "",
    percentage: "",
    yop: "",
    degree: "",
    department: ""
};

const EDU_KEYS = Object.keys(EMPTY_EDU);

const WORD_NUMBERS = {
    first: 1, second: 2, third: 3, fourth: 4, fifth: 5, sixth: 6,
    seventh: 7, eighth: 8, ninth: 9, tenth: 10, eleventh: 11, twelfth: 12
};

const ordinal = (n) => {
    const endings = ["th", "st", "nd", "rd"];
    const v = n % 100;
    return n + (endings[(v - 20) % 10] || endings[v] || endings[0]);
};

// "6", "6th", "sixth" -> "6th" (1st to 12th); "ug" -> "UG"; "diploma" -> "Diploma"
export const normalizeQualification = (text) => {
    const original = str(text).trim();
    const t = original.toLowerCase().replace(/\s+/g, " ");
    if (!t) return "";

    const m = t.match(/^(\d{1,2})\s?(st|nd|rd|th)?$/);
    if (m) {
        const n = Number(m[1]);
        return n >= 1 && n <= 12 ? ordinal(n) : original;
    }
    if (WORD_NUMBERS[t]) return ordinal(WORD_NUMBERS[t]);
    if (t === "diploma") return "Diploma";
    if (t === "degree") return "Degree";
    if (t === "ug" || t === "undergraduate") return "UG";
    if (t === "pg" || t === "postgraduate") return "PG";
    if (t === "phd" || t === "doctorate") return "PhD";
    return original;
};

// 1st..12th = 1..12, Diploma = 13, UG / Degree = 14, PG = 15, PhD = 16,
// anything else = 0 (not recognised)
const qualRank = (q) => {
    const n = normalizeQualification(q);
    const m = n.match(/^(\d{1,2})(st|nd|rd|th)$/);
    if (m) return Number(m[1]);
    if (n === "Diploma") return 13;
    if (n === "UG" || n === "Degree") return 14;
    if (n === "PG") return 15;
    if (n === "PhD") return 16;
    return 0;
};

// School class (12th or below), diploma or degree level ("" = not recognised)
const qualKind = (q) => {
    const r = qualRank(q);
    if (!r) return "";
    if (r <= 12) return "school";
    return r === 13 ? "diploma" : "degree";
};

const MAX_EDUCATIONS = 15;
const YEAR_MIN = 1980;

// Rows shown for a new enquiry
const defaultEducations = () => [{ ...EMPTY_EDU, qualification: "10th" }];

// The highest qualification of the list (shown in the enquiry list page)
export const highestEducation = (list) =>
    (list || [])
        .filter((e) => e && qualRank(e.qualification))
        .reduce(
            (best, e) =>
                !best || qualRank(e.qualification) > qualRank(best.qualification)
                    ? e
                    : best,
            null
        );

// The single qualification fields of the backend always hold the HIGHEST
// qualification, so the list page and the existing API keep working
const legacyFromHighest = (top) => {
    const out = {
        qualification: "",
        school_name: "",
        college_name: "",
        diploma_course: "",
        degree_course: "",
        specialization: "",
        year_of_passing: ""
    };
    if (!top) return out;

    const kind = qualKind(top.qualification);
    out.year_of_passing = top.yop;

    if (kind === "school") {
        out.qualification = normalizeQualification(top.qualification);
        out.school_name = top.institute;
    } else {
        out.qualification = kind === "diploma" ? "Diploma" : "Degree";
        out.college_name = top.institute;
        out.specialization = top.department;
        if (kind === "diploma") out.diploma_course = top.degree;
        else out.degree_course = top.degree;
    }
    return out;
};

export const COUNSELORS = ["Priya", "Senthilan"];

export const QUALIFICATIONS = ["10th", "12th", "UG", "PG", "Diploma", "PhD"];

export const SOURCES = [
    "Walk-in",
    "Phone Call",
    "Website",
    "Social Media",
    "Referral",
    "Newspaper / Advertisement",
    "Other"
];

export const STATUSES = ["Follow Up", "Converted"];

const STEPS = [
    { title: "Personal details" },
    { title: "Educational details" },
    { title: "Course details" }
];

// Backend primary key (adjust here if your API uses a different name)
export const getEnquiryId = (row) =>
    row ? (row.enquiry_id ?? row.id) : undefined;

const str = (v) =>
    v === null || v === undefined ? "" : String(v);

// Activity status is always handled as "Active" / "Inactive"
// (a missing value, or a backend true/false, is converted here)
export const normalizeActivity = (value) => {
    if (value === null || value === undefined || value === "") {
        return "Active";
    }
    if (value === false || value === 0) return "Inactive";

    const text = String(value).trim().toLowerCase();

    return text === "inactive" || text === "false" || text === "0"
        ? "Inactive"
        : "Active";
};

// Browser copy of all education rows. The list API may return only the
// highest qualification (the single qualification fields), so the complete
// list is also kept here, per enquiry id and per mobile number, to show every
// row again when the enquiry is edited.
const EDU_STORE_KEY = "enquiry_education_details";

const readEduStore = () => {
    try {
        return JSON.parse(localStorage.getItem(EDU_STORE_KEY)) || {};
    } catch (err) {
        return {};
    }
};

export const saveEducationLocal = (payload, id) => {
    try {
        const list = payload && payload.education_details;
        if (!Array.isArray(list) || list.length === 0) return;

        const store = readEduStore();
        if (id !== undefined && id !== null && id !== "") {
            store[`id:${id}`] = list;
        }
        if (payload.mobile_number) {
            store[`mobile:${payload.mobile_number}`] = list;
        }
        localStorage.setItem(EDU_STORE_KEY, JSON.stringify(store));
    } catch (err) {
        /* storage not available - ignore */
    }
};

// A row coming from the API / registration, whatever its field names are
const rowFromRecord = (item) => {
    const pick = (keys) => {
        for (const key of keys) {
            const value = item && item[key];
            if (
                value !== null &&
                value !== undefined &&
                String(value).trim() !== ""
            ) {
                return String(value).trim();
            }
        }
        return "";
    };

    const row = {
        qualification: normalizeQualification(
            pick(["qualification", "level", "type", "name"])
        ),
        institute: pick([
            "institute",
            "institute_name",
            "school_name",
            "college_name",
            "institution",
            "school"
        ]),
        board: pick(["board", "board_name", "university"]),
        percentage: pick(["percentage", "marks", "percent", "cgpa", "gpa"]),
        yop: pick(["yop", "year_of_passing", "passing_year", "year"]),
        degree: pick(["degree", "degree_course", "diploma_course", "course"]),
        department: pick(["department", "specialization", "branch", "stream"])
    };

    // Degree / Department are not used for 12th or below
    if (qualKind(row.qualification) === "school") {
        row.degree = "";
        row.department = "";
    }
    return row;
};

const sameLevel = (a, b) => {
    const ka = qualKind(a);
    const kb = qualKind(b);
    if (!ka || !kb || ka !== kb) return false;
    return ka !== "school" || qualRank(a) === qualRank(b);
};

const lookupEducationLocal = (row) => {
    if (!row) return null;

    const store = readEduStore();
    const id = row.enquiry_id ?? row.id;

    const candidates = [
        id !== undefined && id !== null ? store[`id:${id}`] : null,
        row.mobile_number ? store[`mobile:${row.mobile_number}`] : null
    ];

    for (const list of candidates) {
        if (!Array.isArray(list) || list.length === 0) continue;
        // ignore a copy that no longer matches the saved highest qualification
        const top = highestEducation(list.map(rowFromRecord));
        if (row.qualification && (!top || !sameLevel(top.qualification, row.qualification))) {
            continue;
        }
        return list;
    }
    return null;
};

// Education rows of a saved enquiry. Older enquiries only have the single
// qualification fields, so those become one row.
export const toEducations = (row) => {
    let list = row && row.education_details;

    if (typeof list === "string") {
        try {
            list = JSON.parse(list);
        } catch (err) {
            list = null;
        }
    }

    if (!(Array.isArray(list) && list.length > 0)) {
        list = lookupEducationLocal(row);
    }

    if (Array.isArray(list) && list.length > 0) {
        return list.map(rowFromRecord);
    }

    const single = rowFromRecord(row || {});
    return EDU_KEYS.some((k) => single[k]) ? [single] : defaultEducations();
};

// Converts a row from the API into form state
export const toFormData = (row = {}) => {
    const out = { ...EMPTY_FORM };
    Object.keys(EMPTY_FORM).forEach((key) => {
        if (key === "education_details") return;
        out[key] = str(row[key]) || EMPTY_FORM[key];
    });
    out.education_details = toEducations(row);
    out.activity_status = normalizeActivity(row.activity_status);
    if (!STATUSES.includes(out.status)) out.status = "Follow Up";
    return out;
};

// "2026-10-01 to 2026-12-31"  ->  { start, end }
export const splitValidity = (value) => {
    const text = str(value);
    if (text.includes(" to ")) {
        const [start, end] = text.split(" to ");
        return { start: start.trim(), end: end.trim() };
    }
    return { start: "", end: "" };
};

// Today's date as YYYY-MM-DD in the local time zone (for the date input)
const todayLocal = () => {
    const d = new Date();
    const pad = (n) => String(n).padStart(2, "0");
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
};

const cleanEducation = (list) =>
    (list || [])
        .filter((e) => e && str(e.qualification).trim())
        .map((e) => {
            const out = {};
            EDU_KEYS.forEach((k) => {
                out[k] = str(e[k]).trim();
            });
            out.qualification = normalizeQualification(e.qualification);

            // Degree / Department are not used for 12th or below
            if (qualKind(out.qualification) === "school") {
                out.degree = "";
                out.department = "";
            }
            return out;
        });

export const buildPayload = (formData, validity, educations) => {
    const education_details = cleanEducation(
        educations || formData.education_details
    );
    const top = highestEducation(education_details);

    return {
        ...formData,
        ...(top ? legacyFromHighest(top) : {}),
        education_details,
        student_name: formData.student_name.trim(),
        email: formData.email.trim().toLowerCase(),
        address: formData.address.trim(),
        counselor_name: formData.counselor_name.trim(),
        remarks: formData.remarks.trim(),
        course_fees: Number(formData.course_fees),
        discount_percentage: Number(formData.discount_percentage) || 0,
        discount_validity:
            validity.start && validity.end
                ? `${validity.start} to ${validity.end}`
                : ""
    };
};

const extractError = (error) => {
    const data =
        (error && error.responseData) ||
        (error && error.response && error.response.data);

    const status =
        (error && error.status) ||
        (error && error.response && error.response.status);

    if (typeof data === "string" && data.trim() && !data.startsWith("<")) {
        return data;
    }

    if (data && data.detail) return data.detail;

    if (data && typeof data === "object") {
        const firstKey = Object.keys(data)[0];
        if (firstKey) {
            const value = data[firstKey];
            const message = Array.isArray(value) ? value[0] : value;
            return `${firstKey.replace(/_/g, " ")}: ${message}`;
        }
    }

    const reason = [status && `status ${status}`, error && error.message]
        .filter(Boolean)
        .join(" - ");

    return (
        "Enquiry could not be saved" +
        (reason ? ` (${reason})` : "") +
        ". Check the browser console / Network tab for the exact response."
    );
};

// Fields that accept letters only (no digits). Spaces and . , \' & - are allowed.
const LETTERS_ONLY = {
    student_name: "Student name",
    school_name: "School name",
    college_name: "College name"
};
const LETTERS_REGEX = /^[A-Za-z][A-Za-z .,'&-]*$/;

// Cleans typed text and returns a warning when something was not allowed
const filterInput = (name, raw) => {
    if (name === "mobile_number") {
        let value = raw.replace(/\D/g, "");
        let warning = "";
        if (value !== raw) {
            warning = "Only digits are allowed (no spaces or characters).";
        }
        if (value && !/^[6-9]/.test(value)) {
            return {
                value: "",
                warning: "Mobile number must start with 6, 7, 8 or 9."
            };
        }
        value = value.slice(0, 10);
        return { value, warning };
    }

    if (name === "email") {
        const value = raw.replace(/[^A-Za-z0-9._%+@-]/g, "");
        return {
            value,
            warning:
                value !== raw
                    ? "Email accepts letters, numbers and . _ % + - only."
                    : ""
        };
    }

    if (name === "year_of_passing") {
        const digits = raw.replace(/\D/g, "");
        return {
            value: digits.slice(0, 4),
            warning: digits !== raw ? "Only digits are allowed in year." : ""
        };
    }

    if (name === "course_fees") {
        let value = raw.replace(/[^0-9.]/g, "");
        const parts = value.split(".");
        if (parts.length > 2) value = parts[0] + "." + parts.slice(1).join("");
        const [whole, decimals] = value.split(".");
        if (decimals !== undefined) value = whole + "." + decimals.slice(0, 2);
        return {
            value,
            warning:
                value !== raw ? "Only numbers are allowed in course fees." : ""
        };
    }

    if (name === "qualification") {
        const value = raw.replace(/[^A-Za-z0-9 ]/g, "").slice(0, 12);
        return {
            value,
            warning:
                value !== raw
                    ? "Qualification accepts letters and numbers only."
                    : ""
        };
    }

    if (LETTERS_ONLY[name]) {
        const value = raw.replace(/[^A-Za-z .,'&-]/g, "").replace(/^[^A-Za-z]+/, "");
        return {
            value,
            warning:
                value !== raw
                    ? `${LETTERS_ONLY[name]} accepts letters only (no numbers).`
                    : ""
        };
    }

    return { value: raw, warning: "" };
};

// =====================================================
// VALIDATION (per step)
// =====================================================

// A higher qualification must be passed in a LATER year than a lower one
// (1st..12th < Diploma < UG < PG < PhD). Returns a message, or "" when fine.
const yearOrderError = (edu, i, all) => {
    if (!qualRank(edu.qualification)) return "";
    if (!/^\d{4}$/.test(edu.yop)) return "";

    const year = Number(edu.yop);

    for (let j = 0; j < all.length; j += 1) {
        const other = all[j];
        if (
            j === i ||
            !qualRank(other.qualification) ||
            !/^\d{4}$/.test(other.yop)
        ) {
            continue;
        }

        const otherYear = Number(other.yop);
        const lower = qualRank(other.qualification) < qualRank(edu.qualification);
        const mine = normalizeQualification(edu.qualification);
        const theirs = normalizeQualification(other.qualification);

        if (lower && year <= otherYear) {
            return `${mine} year must be after ${theirs} (${otherYear}).`;
        }
        if (!lower && year >= otherYear) {
            return `${mine} year must be before ${theirs} (${otherYear}).`;
        }
    }

    return "";
};

// Checks one education row. Error keys look like "edu_0_institute" so every
// cell shows its own message.
const validateEducation = (edu, i, all) => {
    const e = {};
    const thisYear = new Date().getFullYear();
    const key = (name) => `edu_${i}_${name}`;

    const qualification = normalizeQualification(edu.qualification);
    const kind = qualKind(qualification);

    if (!qualification) {
        e[key("qualification")] = "Select the qualification.";
    } else if (!kind) {
        e[key("qualification")] =
            "Enter a valid qualification (1st to 12th, Diploma, UG, PG or PhD).";
    } else if (
        all.some(
            (other, j) =>
                j !== i && qualRank(other.qualification) === qualRank(qualification)
        )
    ) {
        e[key("qualification")] = `${qualification} is already added.`;
    }

    if (!kind) return e;

    if (!edu.institute.trim()) {
        e[key("institute")] =
            kind === "school"
                ? "Enter the school name."
                : "Enter the college name.";
    } else if (!LETTERS_REGEX.test(edu.institute.trim())) {
        e[key("institute")] = "Name accepts letters only (no numbers).";
    }

    if (edu.percentage !== "") {
        const n = Number(edu.percentage);
        if (!/^\d{1,3}(\.\d{1,2})?$/.test(edu.percentage) || n > 100) {
            e[key("percentage")] = "Enter 0 to 100.";
        }
    }

    if (kind !== "school") {
        if (!edu.degree.trim()) e[key("degree")] = "Enter the degree / course.";
        if (!edu.department.trim()) {
            e[key("department")] = "Enter the department.";
        }
    }

    const year = Number(edu.yop);
    if (!/^\d{4}$/.test(edu.yop) || year < YEAR_MIN || year > thisYear + 5) {
        e[key("yop")] = `Select a year (${YEAR_MIN} to ${thisYear + 5}).`;
    } else {
        const order = yearOrderError(edu, i, all);
        if (order) e[key("yop")] = order;
    }

    return e;
};

const validateStep = (step, d, validity, educations = []) => {
    const e = {};

    if (step === 0) {
        if (!d.student_name.trim()) {
            e.student_name = "Enter the student name.";
        } else if (!/^[A-Za-z][A-Za-z .,'&-]+$/.test(d.student_name.trim())) {
            e.student_name = "Use letters and spaces only (min 2 characters).";
        }

        if (!/^[6-9]\d{9}$/.test(d.mobile_number)) {
            e.mobile_number =
                "Enter a 10 digit number starting with 6, 7, 8 or 9.";
        }

        if (!d.email.trim()) {
            e.email = "Enter the email address.";
        } else if (
            !/^[A-Za-z0-9._%+-]+@(gmail\.com|yahoo\.in|uk\.co\.in)$/i.test(
                d.email.trim()
            )
        ) {
            e.email =
                "Email must end with @gmail.com, @yahoo.in or @uk.co.in.";
        }

        if (d.address.trim().length < 5) {
            e.address = "Enter the address (min 5 characters).";
        }
    }

    if (step === 1) {
        educations.forEach((edu, i) => {
            Object.assign(e, validateEducation(edu, i, educations));
        });
    }

    if (step === 2) {
        if (!d.course) e.course = "Select the course.";

        if (!COUNSELORS.includes(d.counselor_name)) {
            e.counselor_name = "Select the counselor.";
        }

        if (d.course_fees === "") {
            e.course_fees = "Enter the course fees.";
        } else if (!/^\d+(\.\d{1,2})?$/.test(String(d.course_fees))) {
            e.course_fees = "Course fees accepts numbers only.";
        }

        const discount = Number(d.discount_percentage || 0);
        if (discount < 0 || discount > 100) {
            e.discount_percentage = "Discount must be between 0 and 100.";
        }

        // The start date alone (today by default) does not make validity required
        if (discount > 0 || validity.end) {
            if (!validity.end) {
                e.discount_validity = "Select the validity end date.";
            } else if (validity.end < validity.start) {
                e.discount_validity =
                    `End date cannot be before ${validity.start}.`;
            }
        }

        if (!d.enquiry_source) {
            e.enquiry_source = "Select the enquiry source.";
        }

        if (!d.status) e.status = "Select the status.";
    }

    return e;
};

// Typing rules of the education table boxes. Characters that are not
// allowed are removed and a warning is shown under the box.
const EDU_RULES = {
    qualification: {
        label: "Qualification",
        strip: /[^A-Za-z0-9 .\-/()]/g,
        max: 30,
        hint: "letters, numbers and . - / ( )"
    },
    institute: {
        label: "School / Institute name",
        strip: /[^A-Za-z .,'&-]/g,
        max: 150,
        hint: "letters only (no numbers)"
    },
    board: {
        label: "Board / University",
        strip: /[^A-Za-z0-9 .,&'\-/()]/g,
        max: 100,
        hint: "letters, numbers and . , & ' - / ( )"
    },
    degree: {
        label: "Degree",
        strip: /[^A-Za-z0-9 .&\-/()]/g,
        max: 100,
        hint: "letters, numbers and . & - / ( )"
    },
    department: {
        label: "Department",
        strip: /[^A-Za-z .,&\-/()]/g,
        max: 100,
        hint: "letters and . , & - / ( )"
    }
};

const eduFilter = (field, raw, prev) => {
    if (field === "percentage") {
        if (!/^\d*\.?\d{0,2}$/.test(raw)) {
            return {
                value: prev,
                warning: "Numbers only (maximum 2 decimal places)."
            };
        }
        if (raw !== "" && Number(raw) > 100) {
            return { value: prev, warning: "Cannot be more than 100." };
        }
        return { value: raw, warning: "" };
    }

    if (field === "yop") return { value: raw, warning: "" };

    const rule = EDU_RULES[field];
    let value = raw.replace(rule.strip, "");
    value = value.replace(/^\s+/, "").replace(/\s{2,}/g, " ");
    if (field === "institute") value = value.replace(/^[^A-Za-z]+/, "");
    if (value.length > rule.max) value = value.slice(0, rule.max);

    return {
        value,
        warning: value !== raw ? `${rule.label} accepts ${rule.hint}.` : ""
    };
};

// =====================================================
// YEAR PICKER (YOP) - a small popup with 12 years per page,
// like the Registration module
// =====================================================

const YEAR_PAGE = 12;

const YearPicker = ({ value, onChange, isDisabled, invalid, maxYear }) => {
    const buttonRef = useRef(null);
    const popupRef = useRef(null);

    const [open, setOpen] = useState(false);
    const [pageStart, setPageStart] = useState(0);
    const [pos, setPos] = useState({ top: 0, left: 0 });

    const thisYear = new Date().getFullYear();
    const selectedYear = /^\d{4}$/.test(String(value || ""))
        ? Number(value)
        : 0;

    const blockStart = (year) => Math.floor(year / YEAR_PAGE) * YEAR_PAGE;

    const openPicker = () => {
        if (open) {
            setOpen(false);
            return;
        }

        const rect = buttonRef.current.getBoundingClientRect();
        const width = 244;
        const height = 292;

        const left = Math.max(
            8,
            Math.min(
                rect.left + rect.width / 2 - width / 2,
                window.innerWidth - width - 8
            )
        );

        // open below the box, or above it when there is no space below
        const below = rect.bottom + 6;
        const top =
            below + height > window.innerHeight && rect.top - height - 6 > 8
                ? rect.top - height - 6
                : below;

        setPos({ top, left });
        setPageStart(blockStart(selectedYear || thisYear));
        setOpen(true);
    };

    // close on outside click, Esc, scroll or resize
    useEffect(() => {
        if (!open) return undefined;

        const onDown = (e) => {
            if (
                popupRef.current &&
                !popupRef.current.contains(e.target) &&
                buttonRef.current &&
                !buttonRef.current.contains(e.target)
            ) {
                setOpen(false);
            }
        };
        const onKey = (e) => {
            if (e.key === "Escape") setOpen(false);
        };
        const onMove = (e) => {
            if (popupRef.current && popupRef.current.contains(e.target)) return;
            setOpen(false);
        };

        document.addEventListener("mousedown", onDown);
        document.addEventListener("keydown", onKey);
        window.addEventListener("scroll", onMove, true);
        window.addEventListener("resize", onMove);

        return () => {
            document.removeEventListener("mousedown", onDown);
            document.removeEventListener("keydown", onKey);
            window.removeEventListener("scroll", onMove, true);
            window.removeEventListener("resize", onMove);
        };
    }, [open]);

    const choose = (year) => {
        onChange(String(year));
        setOpen(false);
    };

    const years = [];
    for (let i = 0; i < YEAR_PAGE; i += 1) years.push(pageStart + i);

    const canGoBack = pageStart > blockStart(YEAR_MIN);
    const canGoForward = pageStart + YEAR_PAGE <= maxYear;

    return (
        <div className="year-picker">
            <button
                type="button"
                ref={buttonRef}
                className={
                    "year-picker-btn" +
                    (value ? " has-value" : "") +
                    (open ? " is-open" : "") +
                    (invalid ? " is-invalid" : "")
                }
                onClick={openPicker}
            >
                <span>{value || "Year"}</span>
                <i className="bx bx-calendar year-picker-icon" />
            </button>

            {open && (
                <div
                    ref={popupRef}
                    className="year-picker-popup"
                    style={{ top: pos.top, left: pos.left }}
                >
                    <div className="year-picker-head">
                        <button
                            type="button"
                            className="year-nav-btn"
                            disabled={!canGoBack}
                            onClick={() => setPageStart((p) => p - YEAR_PAGE)}
                            aria-label="Earlier years"
                        >
                            &#8249;
                        </button>

                        <span className="year-picker-range">
                            {pageStart} – {pageStart + YEAR_PAGE - 1}
                        </span>

                        <button
                            type="button"
                            className="year-nav-btn"
                            disabled={!canGoForward}
                            onClick={() => setPageStart((p) => p + YEAR_PAGE)}
                            aria-label="Later years"
                        >
                            &#8250;
                        </button>
                    </div>

                    <div className="year-picker-grid">
                        {years.map((year) => {
                            const blocked = isDisabled(year);

                            return (
                                <button
                                    type="button"
                                    key={year}
                                    disabled={blocked}
                                    title={
                                        blocked &&
                                        year >= YEAR_MIN &&
                                        year <= maxYear
                                            ? "Qualification years must be in order"
                                            : undefined
                                    }
                                    className={
                                        "year-cell" +
                                        (year === selectedYear ? " selected" : "") +
                                        (year === thisYear ? " current" : "")
                                    }
                                    onClick={() => choose(year)}
                                >
                                    {year}
                                </button>
                            );
                        })}
                    </div>

                    <div className="year-picker-foot">
                        <button
                            type="button"
                            className="year-link"
                            onClick={() => {
                                onChange("");
                                setOpen(false);
                            }}
                        >
                            Clear
                        </button>

                        <button
                            type="button"
                            className="year-link"
                            disabled={isDisabled(thisYear)}
                            onClick={() => choose(thisYear)}
                        >
                            This year
                        </button>
                    </div>
                </div>
            )}
        </div>
    );
};

// =====================================================
// QUALIFICATION BOX - a text box (type anything valid) with a drop-down
// button that lists 10th, 12th, UG, PG, Diploma, PhD
// =====================================================

const QualificationBox = ({
    value,
    options,
    invalid,
    name,
    onType,
    onPick,
    onBlurValue
}) => {
    const inputRef = useRef(null);
    const menuRef = useRef(null);

    const [open, setOpen] = useState(false);
    const [hi, setHi] = useState(0);
    const [pos, setPos] = useState({ top: 0, left: 0, width: 170 });

    const typed = value.trim().toLowerCase();
    const exact = options.some((o) => o.toLowerCase() === typed);
    const shown = options.filter(
        (o) => exact || !typed || o.toLowerCase().startsWith(typed)
    );

    const openMenu = () => {
        const rect = inputRef.current.getBoundingClientRect();
        const height = options.length * 38 + 12;

        const below = rect.bottom + 4;
        const top =
            below + height > window.innerHeight && rect.top - height - 4 > 8
                ? rect.top - height - 4
                : below;

        setPos({ top, left: rect.left, width: Math.max(rect.width, 150) });
        setHi(0);
        setOpen(true);
    };

    // close on outside click, Esc, scroll or resize
    useEffect(() => {
        if (!open) return undefined;

        const onDown = (e) => {
            if (
                menuRef.current &&
                !menuRef.current.contains(e.target) &&
                inputRef.current &&
                !inputRef.current.parentNode.contains(e.target)
            ) {
                setOpen(false);
            }
        };
        const onKey = (e) => {
            if (e.key === "Escape") setOpen(false);
        };
        const onMove = (e) => {
            if (menuRef.current && menuRef.current.contains(e.target)) return;
            setOpen(false);
        };

        document.addEventListener("mousedown", onDown);
        document.addEventListener("keydown", onKey);
        window.addEventListener("scroll", onMove, true);
        window.addEventListener("resize", onMove);

        return () => {
            document.removeEventListener("mousedown", onDown);
            document.removeEventListener("keydown", onKey);
            window.removeEventListener("scroll", onMove, true);
            window.removeEventListener("resize", onMove);
        };
    }, [open]);

    const handleKey = (e) => {
        if (e.key === "ArrowDown") {
            e.preventDefault();
            if (!open) openMenu();
            else setHi((h) => Math.min(h + 1, Math.max(shown.length - 1, 0)));
        } else if (e.key === "ArrowUp") {
            e.preventDefault();
            setHi((h) => Math.max(h - 1, 0));
        } else if (e.key === "Enter" && open && shown[hi]) {
            // pick the highlighted one; Enter then moves on as usual
            onPick(shown[hi]);
            setOpen(false);
        }
    };

    return (
        <div className="qual-box">
            <input
                ref={inputRef}
                type="text"
                name={name}
                autoComplete="new-password"
                className={"form-control" + (invalid ? " is-invalid" : "")}
                placeholder="Qualification"
                value={value}
                onChange={(e) => {
                    onType(e.target.value);
                    if (!open) openMenu();
                    setHi(0);
                }}
                onBlur={onBlurValue}
                onKeyDown={handleKey}
            />

            <button
                type="button"
                tabIndex={-1}
                className={"qual-toggle" + (open ? " is-open" : "")}
                aria-label="Choose qualification"
                title="Choose qualification"
                onMouseDown={(e) => e.preventDefault()}
                onClick={() => (open ? setOpen(false) : openMenu())}
            >
                <svg
                    width="14"
                    height="14"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="3"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                >
                    <polyline points="6 9 12 15 18 9" />
                </svg>
            </button>

            {open && shown.length > 0 && (
                <div
                    ref={menuRef}
                    className="qual-menu"
                    style={{ top: pos.top, left: pos.left, width: pos.width }}
                >
                    {shown.map((opt, n) => (
                        <button
                            type="button"
                            key={opt}
                            className={
                                "qual-option" +
                                (opt === value ? " selected" : "") +
                                (n === hi && opt !== value ? " highlight" : "")
                            }
                            onMouseDown={(e) => e.preventDefault()}
                            onClick={() => {
                                onPick(opt);
                                setOpen(false);
                            }}
                        >
                            {opt}
                        </button>
                    ))}
                </div>
            )}
        </div>
    );
};

// =====================================================
// SMALL FIELD WRAPPER
// =====================================================

const Field = ({ label, error, required, className, children }) => (
    <div className={className || "col-md-6"}>
        <label className="form-label">
            {label}
            {required && <span className="text-danger"> *</span>}
        </label>
        {children}
        {error && <div className="invalid-feedback d-block">{error}</div>}
    </div>
);

// =====================================================
// STEPPED FORM (used for both Add and Edit)
// =====================================================

export const EnquiryStepForm = ({
    initialData,
    title,
    submitLabel,
    onSubmit,
    onCancel
}) => {
    const { getData } = useContext(AuthContext);

    const [step, setStep] = useState(0);
    const [formData, setFormData] = useState(
        initialData ? toFormData(initialData) : { ...EMPTY_FORM }
    );
    const [educations, setEducations] = useState(
        initialData
            ? toEducations(initialData)
            : defaultEducations()
    );
    // Bumped after "+" so the cursor jumps to the new row (eduFocusRow)
    const [eduAddTick, setEduAddTick] = useState(0);
    const eduFocusRow = useRef(0);
    const [validity, setValidity] = useState(
        // The start date is fixed (today for a new enquiry, the saved one when
        // editing) and is not shown; only the end date is chosen
        initialData
            ? (() => {
                  const saved = splitValidity(initialData.discount_validity);
                  return {
                      start: saved.start || todayLocal(),
                      end: saved.end
                  };
              })()
            : { start: todayLocal(), end: "" }
    );
    const [errors, setErrors] = useState({});
    const [visited, setVisited] = useState({ 0: true });
    const [serverError, setServerError] = useState("");
    const [loading, setLoading] = useState(false);
    const [courses, setCourses] = useState([]);
    const [showCourseModal, setShowCourseModal] = useState(false);
    const [pickerField, setPickerField] = useState("course");
    const [courseSearch, setCourseSearch] = useState("");
    const [highlight, setHighlight] = useState(0);
    // Bumped whenever the cursor should jump to the first unfilled field
    const [focusTick, setFocusTick] = useState(0);

    // Close the course pop up with the Escape key
    useEffect(() => {
        if (!showCourseModal) {
            setCourseSearch("");
            return undefined;
        }
        const onKey = (ev) => {
            if (ev.key === "Escape") setShowCourseModal(false);
        };
        document.addEventListener("keydown", onKey);
        return () => document.removeEventListener("keydown", onKey);
    }, [showCourseModal]);

    // Courses for the dropdown come from the Course Fees table.
    // Only courses that have an ACTIVE fee are offered, and each one
    // carries its fee from that table. The course NAME is looked up in
    // the Course master by Course_id (the fee table stores only the id).
    useEffect(() => {
        let active = true;

        const toList = (data) =>
            Array.isArray(data)
                ? data
                : Array.isArray(data && data.results)
                ? data.results
                : Array.isArray(data && data.data)
                ? data.data
                : [];

        (async () => {
            try {
                const [feeData, courseData] = await Promise.all([
                    getData("fetch_coursefee_datail"),
                    getData("fetch_course_datail")
                ]);

                const fees = toList(feeData);
                const masterCourses = toList(courseData);

                // A fee with no saved status counts as Active
                // (same rule as the Course Fee page)
                const activeFees = fees.filter(
                    (f) => !f.Status || f.Status === "Active"
                );

                const list = [];
                const seen = new Set();

                activeFees.forEach((fee) => {
                    const course = masterCourses.find(
                        (c) => Number(c.Course_id) === Number(fee.Course_id)
                    );
                    if (!course || !course.Course_name) return;
                    if (seen.has(Number(fee.Course_id))) return;
                    seen.add(Number(fee.Course_id));

                    list.push({
                        Course_id: fee.Course_id,
                        Course_name: course.Course_name,
                        Course_Fees: fee.Course_Fees
                    });
                });

                list.sort((x, y) =>
                    String(x.Course_name).localeCompare(String(y.Course_name))
                );

                if (active) setCourses(list);
            } catch (err) {
                console.error("Failed to fetch course fees:", err);
            }
        })();

        return () => {
            active = false;
        };
    }, [getData]);

    const handleChange = (e) => {
        const name = String(e.target.name).split("__")[0];
        let { value } = e.target;

        const filtered = filterInput(name, value);
        value = filtered.value;

        const next = { ...formData, [name]: value };
        const touched = [name];

        // Changing the qualification clears the fields that no longer apply
        if (name === "qualification") {
            next.school_name = "";
            next.college_name = "";
            next.diploma_course = "";
            next.degree_course = "";
            next.specialization = "";
            setErrors((prev) => {
                const cleaned = { ...prev };
                [
                    "school_name",
                    "college_name",
                    "diploma_course",
                    "degree_course",
                    "specialization"
                ].forEach((n) => delete cleaned[n]);
                return cleaned;
            });
        }

        // Picking a course fills in its standard fees
        if (name === "course") {
            const match = courses.find((c) => c.Course_name === value);
            if (match) next.course_fees = str(match.Course_Fees);
            touched.push("course_fees");
        }

        // Discount affects whether the validity dates are required
        if (name === "discount_percentage") touched.push("discount_validity");

        setFormData(next);

        // While typing, only a warning for a character that was not allowed
        // is shown. Required / format checks run when Next or Save is pressed.
        setErrors((prev) => {
            const cleaned = { ...prev };
            touched.forEach((n) => delete cleaned[n]);
            if (filtered.warning) {
                cleaned[name] = filtered.warning;
            } else if (name === "year_of_passing") {
                // Year is checked while typing: an error shows as soon as no
                // valid year (1980 to this year + 5) can start with these digits
                const maxYear = new Date().getFullYear() + 5;
                const low = Number(value.padEnd(4, "0"));
                const high = Number(value.padEnd(4, "9"));
                if (value && (high < 1980 || low > maxYear)) {
                    cleaned[name] = `Enter a year between 1980 and ${maxYear}.`;
                }
            }
            return cleaned;
        });
    };

    // ---------- EDUCATION TABLE ----------
    const handleEduChange = (index, name, raw) => {
        const prefix = `edu_${index}_`;
        const filtered = eduFilter(name, raw, educations[index][name]);
        const value = filtered.value;

        const nextList = educations.map((row, i) => {
            if (i !== index) return row;
            const next = { ...row, [name]: value };
            // 12th or below: Degree and Department are cleared (and locked)
            if (name === "qualification" && qualKind(value) === "school") {
                next.degree = "";
                next.department = "";
            }
            return next;
        });
        setEducations(nextList);

        setErrors((prev) => {
            const cleaned = { ...prev };

            if (name === "qualification") {
                Object.keys(cleaned).forEach((k) => {
                    if (k.startsWith(prefix)) delete cleaned[k];
                });
            } else {
                delete cleaned[prefix + name];
            }

            if (filtered.warning) cleaned[prefix + name] = filtered.warning;

            if (name === "yop" || name === "qualification") {
                // compare with the other qualifications
                const order = yearOrderError(nextList[index], index, nextList);
                if (order && !cleaned[prefix + "yop"]) {
                    cleaned[prefix + "yop"] = order;
                }
                // older "year must be before/after" messages of other rows
                // may no longer apply
                Object.keys(cleaned).forEach((k) => {
                    if (
                        k.startsWith("edu_") &&
                        k.endsWith("_yop") &&
                        k !== prefix + "yop" &&
                        / year must be (after|before) /.test(cleaned[k])
                    ) {
                        delete cleaned[k];
                    }
                });
            }
            return cleaned;
        });
    };

    // "6", "sixth", "ug" ... are written in the standard way when the box is left
    const normalizeEduQualification = (index) => {
        setEducations((list) =>
            list.map((row, i) =>
                i === index
                    ? {
                          ...row,
                          qualification: normalizeQualification(
                              row.qualification
                          )
                      }
                    : row
            )
        );
    };

    // "+" : the clicked row must be complete first, then a new row opens
    // right below it
    const addEducation = (index) => {
        if (educations.length >= MAX_EDUCATIONS) return;

        const found = validateEducation(educations[index], index, educations);

        if (Object.keys(found).length > 0) {
            setErrors((prev) => ({ ...prev, ...found }));
            setFocusTick((t) => t + 1);
            return;
        }

        setEducations((list) => {
            const next = [...list];
            next.splice(index + 1, 0, { ...EMPTY_EDU });
            return next;
        });
        eduFocusRow.current = index + 1;
        setEduAddTick((t) => t + 1);
    };

    // "-" : removes the clicked row (at least one row stays)
    const removeEducation = (index) => {
        if (educations.length <= 1) return;

        setEducations((list) => list.filter((_, i) => i !== index));
        setErrors((prev) => {
            const cleaned = { ...prev };
            Object.keys(cleaned).forEach((k) => {
                if (k.startsWith("edu_")) delete cleaned[k];
            });
            return cleaned;
        });
    };

    // Picking a course in the pop up reuses the normal change handling
    const openPicker = (field) => {
        setPickerField(field);
        setShowCourseModal(true);
    };

    const pickCourse = (name) => {
        handleChange({ target: { name: pickerField, value: name } });
        setShowCourseModal(false);
        setTimeout(() => {
            const el = document.querySelector(
                pickerField === "course"
                    ? '.enquiry-form [data-picker="counselor_name"]'
                    : '.enquiry-form [name^="course_fees__"]'
            );
            if (el) el.focus();
        }, 0);
    };

    const handleValidity = (field) => (e) => {
        const nextValidity = { ...validity, [field]: e.target.value };
        setValidity(nextValidity);
        setErrors((prev) => {
            const cleaned = { ...prev };
            delete cleaned.discount_validity;
            return cleaned;
        });
    };

    const formRef = useRef(null);

    // Edge / Chrome keep "Saved info" per field name. A random name on every
    // visit means they never find (or store) suggestions for these fields.
    const nonce = useRef(Math.random().toString(36).slice(2, 8)).current;
    const fieldName = (n) => `${n}__${nonce}`;

    const fieldList = () =>
        formRef.current
            ? Array.from(
                  formRef.current.querySelectorAll(
                      "input:not([type=hidden]):not([disabled]), select:not([disabled]), textarea:not([disabled]), button.course-picker, button.year-picker-btn"
                  )
              )
            : [];

    // Enter moves to the next field (no validation); on the last field it
    // behaves like the Next / Save button
    const handleKeyDown = (e) => {
        // Shift+Enter still adds a new line in the Address / Remarks boxes
        if (e.key !== "Enter" || e.shiftKey) return;
        const tag = e.target.tagName;
        if (tag === "BUTTON") return;
        if (e.target.type === "submit") return;

        e.preventDefault();
        const fields = fieldList();
        const index = fields.indexOf(e.target);
        if (index >= 0 && index < fields.length - 1) {
            fields[index + 1].focus();
        } else if (formRef.current) {
            formRef.current.requestSubmit();
        }
    };

    // Remember which steps have been opened (for the tick / cross marks)
    useEffect(() => {
        setVisited((v) => (v[step] ? v : { ...v, [step]: true }));
    }, [step]);

    // Start each step on its first field
    useEffect(() => {
        const first = fieldList()[0];
        if (first) first.focus();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [step]);

    // After "+" : move the cursor to the qualification of the new row
    useEffect(() => {
        if (eduAddTick === 0) return;
        const input = formRef.current
            ? formRef.current.querySelectorAll(".edu-table tbody tr")[
                  eduFocusRow.current
              ]
            : null;
        const el = input ? input.querySelector(".qual-box input") : null;
        if (el) {
            el.scrollIntoView({ behavior: "smooth", block: "center" });
            el.focus({ preventScroll: true });
        }
    }, [eduAddTick]);

    // After a failed Next / Save: move the cursor to the first unfilled
    // field (declared after the effect above so it wins on a step change)
    useEffect(() => {
        if (focusTick === 0) return undefined;
        const timer = setTimeout(() => {
            const bad = formRef.current
                ? formRef.current.querySelector(".is-invalid")
                : null;
            if (!bad) return;
            bad.scrollIntoView({ behavior: "smooth", block: "center" });
            bad.focus({ preventScroll: true });
        }, 0);
        return () => clearTimeout(timer);
    }, [focusTick]);

    // Errors of every step, grouped by step (used by Save and the stepper)
    const allStepErrors = () =>
        STEPS.map((_, i) => validateStep(i, formData, validity, educations));

    const goNext = () => {
        const found = validateStep(step, formData, validity, educations);
        setErrors(found);
        if (Object.keys(found).length === 0) {
            setStep(step + 1);
        } else {
            setFocusTick((t) => t + 1);
        }
    };

    const goBack = () => {
        setErrors({});
        setStep(step - 1);
    };

    // Clicking a step in the header opens that page
    const goToStep = (index) => {
        if (loading || index === step) return;

        setStep(index);
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setServerError("");

        if (step < STEPS.length - 1) {
            goNext();
            return;
        }

        // Re-check every step before saving. If anything is unfilled, show
        // all the messages, open the first step that has a problem and move
        // the cursor to its first unfilled field.
        const perStep = allStepErrors();
        const firstBad = perStep.findIndex(
            (found) => Object.keys(found).length > 0
        );

        if (firstBad >= 0) {
            setErrors(Object.assign({}, ...perStep));
            setStep(firstBad);
            setFocusTick((t) => t + 1);
            return;
        }

        try {
            setLoading(true);
            const payload = buildPayload(formData, validity, educations);
            await onSubmit(payload);
            // keep the full list in this browser for the next Edit
            saveEducationLocal(
                payload,
                initialData ? getEnquiryId(initialData) : undefined
            );
        } catch (error) {
            console.error("Enquiry save error:", error, error && error.responseData);
            setServerError(extractError(error));
            setLoading(false);
        }
    };

    const fees = Number(formData.course_fees) || 0;
    const discount = Number(formData.discount_percentage) || 0;
    const netFees = Math.round(fees - (fees * discount) / 100);
    const currentYear = new Date().getFullYear();
    const maxYear = currentYear + 5;

    const cls = (name) =>
        "form-control" + (errors[name] ? " is-invalid" : "");
    const selCls = (name) =>
        "form-select" + (errors[name] ? " is-invalid" : "");

    // Only the courses that have an Active fee in the Course Fees table
    const courseOptions = [
        ...new Set(courses.map((c) => c.Course_name).filter(Boolean))
    ];

    const courseKnown = courseOptions.includes(formData.course);

    // Course list for the pop up: the currently saved course (if not in the
    // master list) first, then everything else, filtered by the search box
    const isCounselor = pickerField === "counselor_name";
    const allCourseNames = isCounselor
        ? COUNSELORS
        : formData.course && !courseKnown
        ? [formData.course, ...courseOptions]
        : courseOptions;
    const filteredCourses = allCourseNames.filter((name) =>
        String(name)
            .toLowerCase()
            .startsWith(courseSearch.trim().toLowerCase())
    );

    // Keep the highlighted row inside the list and in view
    useEffect(() => {
        setHighlight(0);
    }, [courseSearch, showCourseModal]);

    useEffect(() => {
        if (!showCourseModal) return;
        const row = document.querySelector(".course-table tbody tr.highlight");
        if (row && row.scrollIntoView) row.scrollIntoView({ block: "nearest" });
    }, [highlight, showCourseModal, courseSearch]);

    const handleCourseKey = (ev) => {
        if (ev.key === "ArrowDown") {
            ev.preventDefault();
            setHighlight((h) =>
                Math.min(h + 1, Math.max(filteredCourses.length - 1, 0))
            );
        } else if (ev.key === "ArrowUp") {
            ev.preventDefault();
            setHighlight((h) => Math.max(h - 1, 0));
        } else if (ev.key === "Enter") {
            ev.preventDefault();
            if (filteredCourses[highlight]) pickCourse(filteredCourses[highlight]);
        }
    };

    return (
        <div className="enquiry-form">

            <div className="page-header">
                <div>
                    <h3 className="page-title">{title}</h3>
                </div>

                <button
                    type="button"
                    className="btn btn-light"
                    onClick={onCancel}
                    disabled={loading}
                >
                    <i className="bx bx-arrow-back me-1"></i>
                    Back to list
                </button>
            </div>

            <div className="card form-card">

                {/* STEP HEADER */}
                <div className="stepper">
                    {STEPS.map((s, index) => {
                        // Each section is judged only on its own fields:
                        // all filled -> green tick, opened but unfilled -> red cross
                        const stepFilled =
                            Object.keys(
                                validateStep(
                                    index,
                                    formData,
                                    validity,
                                    educations
                                )
                            ).length === 0;

                        const state =
                            index === step
                                ? stepFilled
                                    ? "current filled"
                                    : "current"
                                : stepFilled
                                ? "done"
                                : visited[index]
                                ? "error"
                                : "todo";

                        return (
                            <div
                                key={s.title}
                                className={`stepper-item ${state}`}
                                role="button"
                                tabIndex={0}
                                aria-current={
                                    index === step ? "step" : undefined
                                }
                                onClick={() => goToStep(index)}
                                onKeyDown={(ev) => {
                                    if (ev.key === "Enter" || ev.key === " ") {
                                        ev.preventDefault();
                                        goToStep(index);
                                    }
                                }}
                            >
                                <span className="stepper-dot">
                                    {state === "done" || state === "current filled" ? (
                                        <i className="bx bx-check"></i>
                                    ) : state === "error" ? (
                                        <i className="bx bx-x"></i>
                                    ) : (
                                        index + 1
                                    )}
                                </span>

                                <span className="stepper-text">
                                    <span className="stepper-title">
                                        {s.title}
                                    </span>
                                </span>
                            </div>
                        );
                    })}
                </div>

                <form
                    ref={formRef}
                    onSubmit={handleSubmit}
                    onKeyDown={handleKeyDown}
                    noValidate
                    autoComplete="off"
                    className="card-body"
                >

                    {serverError && (
                        <div className="alert alert-danger" role="alert">
                            <strong>Error!</strong> {serverError}
                        </div>
                    )}

                    {/* ---------- STEP 1 : PERSONAL ---------- */}
                    {step === 0 && (
                        <div className="row g-3">

                            <Field
                                label="Student name"
                                required
                                error={errors.student_name}
                            >
                                <input
                                    type="text"
                                    name={fieldName("student_name")}
                                    autoComplete="new-password"
                                    className={cls("student_name")}
                                    placeholder="Enter student name"
                                    value={formData.student_name}
                                    onChange={handleChange}
                                    maxLength="100"
                                />
                            </Field>

                            <Field
                                label="Mobile number"
                                required
                                error={errors.mobile_number}
                            >
                                <input
                                    type="tel"
                                    inputMode="numeric"
                                    name={fieldName("mobile_number")}
                                    autoComplete="new-password"
                                    className={cls("mobile_number")}
                                    placeholder="10 digit mobile number"
                                    value={formData.mobile_number}
                                    onChange={handleChange}
                                />
                            </Field>

                            <Field
                                label="Email"
                                required
                                error={errors.email}
                            >
                                <input
                                    type="text"
                                    inputMode="email"
                                    name={fieldName("email")}
                                    autoComplete="new-password"
                                    className={cls("email")}
                                    placeholder="name@gmail.com"
                                    value={formData.email}
                                    onChange={handleChange}
                                />
                            </Field>

                            <Field
                                label="Address"
                                required
                                error={errors.address}
                                className="col-12"
                            >
                                <textarea
                                    name={fieldName("address")}
                                    autoComplete="new-password"
                                    rows="3"
                                    className={cls("address")}
                                    placeholder="Enter address"
                                    value={formData.address}
                                    onChange={handleChange}
                                />
                            </Field>

                        </div>
                    )}

                    {/* ---------- STEP 2 : EDUCATION ---------- */}
                    {step === 1 && (
                        <div>
                            <p className="edu-hint">
                                Qualification, school / institute name and year
                                are required. Degree and Department are needed
                                for Diploma, UG, PG and PhD. Use + to add a
                                qualification and - to remove it.
                            </p>

                            <div className="edu-table-wrap">
                                <table className="edu-table">
                                    <thead>
                                        <tr>
                                            <th>S.No</th>
                                            <th>Qualification</th>
                                            <th>School/Institute Name</th>
                                            <th>Board/University</th>
                                            <th>Percentage</th>
                                            <th>YOP</th>
                                            <th>Degree</th>
                                            <th>Department</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>

                                    <tbody>
                                        {educations.map((edu, i) => {
                                            const k = (name) => `edu_${i}_${name}`;
                                            const kind = qualKind(edu.qualification);
                                            const locked = kind === "school";
                                            const usedElsewhere = educations
                                                .filter((_, j) => j !== i)
                                                .map((x) => qualRank(x.qualification))
                                                .filter(Boolean);
                                            const options = QUALIFICATIONS.filter(
                                                (o) => !usedElsewhere.includes(qualRank(o))
                                            );
                                            const box = (name) =>
                                                "form-control" +
                                                (errors[k(name)] ? " is-invalid" : "");
                                            const note = (name) =>
                                                errors[k(name)] ? (
                                                    <div className="edu-err">
                                                        {errors[k(name)]}
                                                    </div>
                                                ) : null;

                                            return (
                                                <tr key={i}>
                                                    <td className="edu-sno">{i + 1}</td>

                                                    <td className="edu-col-qualification">
                                                        <QualificationBox
                                                            name={fieldName(`edu${i}_qualification`)}
                                                            value={edu.qualification}
                                                            options={options}
                                                            invalid={!!errors[k("qualification")]}
                                                            onType={(text) =>
                                                                handleEduChange(i, "qualification", text)
                                                            }
                                                            onPick={(text) =>
                                                                handleEduChange(i, "qualification", text)
                                                            }
                                                            onBlurValue={() => normalizeEduQualification(i)}
                                                        />
                                                        {note("qualification")}
                                                    </td>

                                                    <td className="edu-col-institute">
                                                        <input
                                                            type="text"
                                                            name={fieldName(`edu${i}_institute`)}
                                                            autoComplete="new-password"
                                                            className={box("institute")}
                                                            value={edu.institute}
                                                            onChange={(ev) =>
                                                                handleEduChange(i, "institute", ev.target.value)
                                                            }
                                                        />
                                                        {note("institute")}
                                                    </td>

                                                    <td className="edu-col-board">
                                                        <div className="edu-board-wrap">
                                                            <input
                                                                type="text"
                                                                name={fieldName(`edu${i}_board`)}
                                                                autoComplete="new-password"
                                                                className={box("board") + " edu-board-input"}
                                                                placeholder="Board / University"
                                                                title={edu.board}
                                                                value={edu.board}
                                                                onChange={(ev) =>
                                                                    handleEduChange(i, "board", ev.target.value)
                                                                }
                                                            />
                                                        </div>
                                                        {note("board")}
                                                    </td>

                                                    <td className="edu-col-percentage">
                                                        <input
                                                            type="text"
                                                            inputMode="decimal"
                                                            name={fieldName(`edu${i}_percentage`)}
                                                            autoComplete="new-password"
                                                            className={box("percentage")}
                                                            value={edu.percentage}
                                                            onChange={(ev) =>
                                                                handleEduChange(i, "percentage", ev.target.value)
                                                            }
                                                        />
                                                        {note("percentage")}
                                                    </td>

                                                    <td className="edu-col-yop">
                                                        <YearPicker
                                                            value={edu.yop}
                                                            invalid={!!errors[k("yop")]}
                                                            maxYear={maxYear}
                                                            isDisabled={(y) =>
                                                                y < YEAR_MIN ||
                                                                y > maxYear ||
                                                                !!yearOrderError(
                                                                    { ...edu, yop: String(y) },
                                                                    i,
                                                                    educations
                                                                )
                                                            }
                                                            onChange={(year) =>
                                                                handleEduChange(i, "yop", year)
                                                            }
                                                        />
                                                        {note("yop")}
                                                    </td>

                                                    <td className="edu-col-degree">
                                                        <input
                                                            type="text"
                                                            name={fieldName(`edu${i}_degree`)}
                                                            autoComplete="new-password"
                                                            className={box("degree") + (locked ? " edu-readonly" : "")}
                                                            value={locked ? "" : edu.degree}
                                                            disabled={locked}
                                                            title={locked ? "Not needed for 12th or below" : ""}
                                                            onChange={(ev) =>
                                                                handleEduChange(i, "degree", ev.target.value)
                                                            }
                                                        />
                                                        {note("degree")}
                                                    </td>

                                                    <td className="edu-col-department">
                                                        <input
                                                            type="text"
                                                            name={fieldName(`edu${i}_department`)}
                                                            autoComplete="new-password"
                                                            className={box("department") + (locked ? " edu-readonly" : "")}
                                                            value={locked ? "" : edu.department}
                                                            disabled={locked}
                                                            title={locked ? "Not needed for 12th or below" : ""}
                                                            onChange={(ev) =>
                                                                handleEduChange(i, "department", ev.target.value)
                                                            }
                                                        />
                                                        {note("department")}
                                                    </td>

                                                    <td className="edu-col-actions">
                                                        <div className="edu-actions">
                                                            <button
                                                                type="button"
                                                                className="edu-add-btn"
                                                                title="Add qualification"
                                                                aria-label="Add qualification"
                                                                disabled={educations.length >= MAX_EDUCATIONS}
                                                                onClick={() => addEducation(i)}
                                                            >
                                                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round">
                                                                    <line x1="12" y1="5" x2="12" y2="19" />
                                                                    <line x1="5" y1="12" x2="19" y2="12" />
                                                                </svg>
                                                            </button>

                                                            <button
                                                                type="button"
                                                                className="edu-remove-btn"
                                                                title="Remove qualification"
                                                                aria-label="Remove qualification"
                                                                disabled={educations.length <= 1}
                                                                onClick={() => removeEducation(i)}
                                                            >
                                                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round">
                                                                    <line x1="5" y1="12" x2="19" y2="12" />
                                                                </svg>
                                                            </button>
                                                        </div>
                                                    </td>
                                                </tr>
                                            );
                                        })}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    )}

                    {/* ---------- STEP 3 : COURSE ---------- */}
                    {step === 2 && (
                        <div className="row g-3">

                            <Field
                                label="Course"
                                required
                                error={errors.course}
                            >
                                <button
                                    type="button"
                                    className={
                                        selCls("course") + " course-picker"
                                    }
                                    data-picker="course"
                                    onClick={() => openPicker("course")}
                                >
                                    <span
                                        className={
                                            formData.course
                                                ? ""
                                                : "course-picker-placeholder"
                                        }
                                    >
                                        {formData.course || "Select course"}
                                    </span>
                                </button>
                            </Field>

                            <Field
                                label="Counselor name"
                                required
                                error={errors.counselor_name}
                            >
                                <button
                                    type="button"
                                    className={
                                        selCls("counselor_name") +
                                        " course-picker"
                                    }
                                    data-picker="counselor_name"
                                    onClick={() => openPicker("counselor_name")}
                                >
                                    <span
                                        className={
                                            formData.counselor_name
                                                ? ""
                                                : "course-picker-placeholder"
                                        }
                                    >
                                        {formData.counselor_name ||
                                            "Select counselor"}
                                    </span>
                                </button>
                            </Field>

                            <Field
                                label="Course fees (₹)"
                                required
                                error={errors.course_fees}
                            >
                                <input
                                    type="text"
                                    inputMode="decimal"
                                    name={fieldName("course_fees")}
                                    autoComplete="new-password"
                                    className={cls("course_fees")}
                                    placeholder="Enter course fees"
                                    value={formData.course_fees}
                                    onChange={handleChange}
                                />
                            </Field>

                            <Field
                                label="Discount (%)"
                                error={errors.discount_percentage}
                            >
                                <input
                                    type="number"
                                    name={fieldName("discount_percentage")}
                                    autoComplete="new-password"
                                    min="0"
                                    max="100"
                                    step="0.01"
                                    className={cls("discount_percentage")}
                                    placeholder="0"
                                    value={formData.discount_percentage}
                                    onChange={handleChange}
                                />
                                {fees > 0 && discount > 0 && (
                                    <div className="form-text">
                                        Fees after discount: ₹ {netFees}
                                    </div>
                                )}
                            </Field>

                            <Field
                                label="Discount validity (valid till)"
                                error={errors.discount_validity}
                                className="col-md-6"
                            >
                                <input
                                    type="date"
                                    aria-label="Validity end date"
                                    className={cls("discount_validity")}
                                    min={validity.start || undefined}
                                    value={validity.end}
                                    onChange={handleValidity("end")}
                                />
                            </Field>

                            <Field
                                label="Enquiry source"
                                required
                                error={errors.enquiry_source}
                            >
                                <select
                                    name={fieldName("enquiry_source")}
                                    autoComplete="new-password"
                                    className={selCls("enquiry_source")}
                                    value={formData.enquiry_source}
                                    onChange={handleChange}
                                >
                                    <option value="">Select source</option>
                                    {SOURCES.map((item) => (
                                        <option key={item} value={item}>
                                            {item}
                                        </option>
                                    ))}
                                </select>
                            </Field>

                            <Field
                                label="Status"
                                required
                                error={errors.status}
                            >
                                <select
                                    name={fieldName("status")}
                                    autoComplete="new-password"
                                    className={selCls("status")}
                                    value={formData.status}
                                    onChange={handleChange}
                                >
                                    {STATUSES.map((item) => (
                                        <option key={item} value={item}>
                                            {item}
                                        </option>
                                    ))}
                                </select>
                            </Field>

                            <Field label="Remarks" className="col-12">
                                <textarea
                                    name={fieldName("remarks")}
                                    autoComplete="new-password"
                                    rows="3"
                                    className="form-control"
                                    placeholder="Any notes about this enquiry"
                                    value={formData.remarks}
                                    onChange={handleChange}
                                />
                            </Field>

                        </div>
                    )}

                    {/* ---------- BUTTONS ---------- */}
                    <div className="form-actions">

                        {step === 0 ? (
                            <button
                                type="button"
                                className="btn btn-outline-secondary"
                                onClick={onCancel}
                                disabled={loading}
                            >
                                Cancel
                            </button>
                        ) : (
                            <button
                                type="button"
                                className="btn btn-outline-secondary"
                                onClick={goBack}
                                disabled={loading}
                            >
                                <i className="bx bx-chevron-left"></i>
                                Previous
                            </button>
                        )}

                        {step < STEPS.length - 1 ? (
                            <button type="submit" className="btn btn-primary">
                                Next
                                <i className="bx bx-chevron-right ms-1"></i>
                            </button>
                        ) : (
                            <button
                                type="submit"
                                className="btn btn-primary"
                                disabled={loading}
                            >
                                {loading ? (
                                    <>
                                        <span
                                            className="spinner-border spinner-border-sm me-2"
                                            role="status"
                                            aria-hidden="true"
                                        ></span>
                                        Saving...
                                    </>
                                ) : (
                                    submitLabel
                                )}
                            </button>
                        )}

                    </div>

                </form>
            </div>

            {/* ---------- COURSE PICK-UP POP UP ---------- */}
            {showCourseModal && (
                <div
                    className="course-modal-backdrop"
                    onClick={() => setShowCourseModal(false)}
                >
                    <div
                        className="course-modal"
                        role="dialog"
                        aria-modal="true"
                        aria-label={isCounselor ? "Select counselor" : "Select course"}
                        onClick={(ev) => ev.stopPropagation()}
                    >
                        <div className="course-modal-header">
                            <div>
                                <h5 className="course-modal-title">
                                    {isCounselor ? "Select Counselor" : "Select Course"}
                                </h5>
                            </div>
                            <button
                                type="button"
                                className="btn-close"
                                aria-label="Close"
                                onClick={() => setShowCourseModal(false)}
                            ></button>
                        </div>

                        <div className="course-modal-search">
                            <label>{isCounselor ? "SEARCH BY COUNSELOR" : "SEARCH BY COURSE"}</label>
                            <div className="course-search-box">
                                <i className="bx bx-search"></i>
                                <input
                                    type="text"
                                    placeholder={isCounselor ? "Counselor" : "Course"}
                                    value={courseSearch}
                                    onChange={(ev) =>
                                        setCourseSearch(ev.target.value)
                                    }
                                    onKeyDown={handleCourseKey}
                                    autoFocus
                                />
                            </div>
                        </div>

                        <div className="course-modal-body">
                            <table className="course-table">
                                <thead>
                                    <tr>
                                        <th className="course-sno">S.NO</th>
                                        <th>{isCounselor ? "COUNSELOR NAME" : "COURSE NAME"}</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {filteredCourses.length === 0 ? (
                                        <tr>
                                            <td
                                                colSpan="2"
                                                className="course-empty"
                                            >
                                                {isCounselor ? "No counselors found" : "No courses found"}
                                            </td>
                                        </tr>
                                    ) : (
                                        filteredCourses.map((name, index) => (
                                            <tr
                                                key={name}
                                                className={
                                                    (name === formData[pickerField]
                                                        ? "active "
                                                        : "") +
                                                    (index === highlight
                                                        ? "highlight"
                                                        : "")
                                                }
                                                onClick={() => pickCourse(name)}
                                            >
                                                <td className="course-sno">
                                                    {index + 1}
                                                </td>
                                                <td>{name}</td>
                                            </tr>
                                        ))
                                    )}
                                </tbody>
                            </table>
                        </div>

                        <div className="course-modal-footer">
                            <span>
                                {filteredCourses.length} {isCounselor ? "counselors" : "courses"} found
                            </span>
                            <button
                                type="button"
                                className="course-close-btn"
                                onClick={() => setShowCourseModal(false)}
                            >
                                Close
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

// =====================================================
// ADD ENQUIRY PAGE
// =====================================================

const Addenquiry = (props) => {

    const { insert } = useContext(AuthContext);

    const handleSubmit = async (payload) => {

        await insert(payload, "enquiry_create");

        // Parent shows one success message and returns to the list
        if (props.onSuccess) {
            await props.onSuccess("Enquiry submitted successfully!");
        }
    };

    return (
        <EnquiryStepForm
            title="Add Enquiry"
            submitLabel="Save Enquiry"
            onSubmit={handleSubmit}
            onCancel={props.toggle}
        />
    );
};

export default Addenquiry;