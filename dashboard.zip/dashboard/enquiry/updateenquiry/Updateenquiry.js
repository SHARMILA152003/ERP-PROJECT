import React, { useContext } from "react";
import AuthContext from "../../../services/AuthContext";
import { EnquiryStepForm, getEnquiryId } from "../addenquiry/Addenquiry";
import "./updateenquiry.css";

const Updateenquiry = (props) => {

    const { update } = useContext(AuthContext);

    const handleSubmit = async (payload) => {

        const enquiryData = {
            ...payload,
            enquiry_id: getEnquiryId(props.data)
        };

        console.log("Updating enquiry:", enquiryData);

        await update(
            enquiryData,
            "update_enquiry_detail",
            "/enquiry"
        );

        // Parent shows one success message and returns to the list
        if (props.onSuccess) {
            await props.onSuccess("Enquiry updated successfully!");
        }
    };

    return (
        <EnquiryStepForm
            title="Update Enquiry"
            submitLabel="Update Enquiry"
            initialData={props.data}
            onSubmit={handleSubmit}
            onCancel={props.toggle}
        />
    );
};

export default Updateenquiry;
