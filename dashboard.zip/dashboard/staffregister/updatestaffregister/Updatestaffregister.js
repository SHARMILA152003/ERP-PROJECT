import React, { useContext } from "react";
import AuthContext from "../../../services/AuthContext";
import { StaffForm, buildStaffPayload, FILE_FIELD_NAMES } from "../addstaffregister/Addstaffregister";

const Updatestaffregister = (props) => {

    const { update } = useContext(AuthContext);

    // props.data is the whole staff object from the list.
    // Date fields are cut to yyyy-mm-dd so the date inputs accept them.
    const toDate = (d) => (d ? String(d).split("T")[0] : "");

    const initialValues = {
        ...props.data,
        Staff_dob: toDate(props.data.Staff_dob),
        Staff_joining_date: toDate(props.data.Staff_joining_date)
    };

    // null -> "" so inputs stay controlled
    Object.keys(initialValues).forEach((k) => {

        if (initialValues[k] === null || initialValues[k] === undefined) {

            initialValues[k] = FILE_FIELD_NAMES.includes(k) ? null : "";

        }

    });

    const handleSave = async (values) => {

        const payload = await buildStaffPayload(values, {
            Staff_id: props.data.Staff_id
        });

        await update(
            payload,
            "update_staffregister_datail",
            "/staffregister"
        );

        // Refresh the list and go back to it
        if (props.onSuccess) {

            await props.onSuccess();

        } else {

            props.toggle();

        }

    };

    return (

        <StaffForm
            title="Edit Staff"
            submitLabel="Update Staff"
            failMessage="Staff could not be updated. Please try again."
            initialValues={initialValues}
            existingStaff={props.existingStaff}
            currentId={props.data.Staff_id}
            onSubmit={handleSave}
            onBack={props.toggle}
        />

    );
};

export default Updatestaffregister;
