import React, { useContext, useEffect, useMemo, useState } from "react";
import AuthContext from "../../../services/AuthContext";
// The edit page re-uses the exact look of the "Staff Pay Form" (add page).
import "../addstaffpay/addstaffpay.css";
import "./updatestaffpay.css";

/* ============================================================
   FIELD DEFINITIONS  (same as the Add page)
   ============================================================ */

const EARNINGS_FIELDS = [
    { key: "Overtime", label: "Overtime (OT) Pay", placeholder: "Enter amount" },
    { key: "Bonus", label: "Bonus", placeholder: "Enter amount" },
    { key: "Conveyance_Allowance", label: "Conveyance Allowance", placeholder: "Enter amount" },
    { key: "Medical_Allowance", label: "Medical Allowance", placeholder: "Enter amount" },
    { key: "Special_Allowance", label: "Special Allowance", placeholder: "Enter amount" }
];

const DEDUCTIONS_FIELDS = [
    { key: "PF", label: "PF (%)", placeholder: "Enter %", defaultAmount: "12" },
    { key: "ESI", label: "ESI (%)", placeholder: "Enter %" },
    { key: "CL", label: "CL (Casual Leave)", placeholder: "Enter days", defaultAmount: "1" },
    { key: "EL", label: "EL (Earned Leave)", placeholder: "Enter days" },
    { key: "Tax", label: "Tax", placeholder: "Enter amount" },
    { key: "Late_Coming_Penalty", label: "Late Coming Penalty", placeholder: "Enter amount" }
];

// Deductions that are money / percentage (CL and EL are days, not money)
const DEDUCTION_AMOUNT_KEYS = DEDUCTIONS_FIELDS
    .map((f) => f.key)
    .filter((key) => key !== "CL" && key !== "EL");

const PERCENT_KEYS = ["PF", "ESI"];

/* ============================================================
   HELPERS
   ============================================================ */

const round2 = (num) =>
    Math.round((Number(num || 0) + Number.EPSILON) * 100) / 100;

const getDaysInMonth = (salaryMonth) => {
    if (!salaryMonth) return 30;
    const [year, month] = String(salaryMonth).split("-").map(Number);
    if (!year || !month) return 30;
    return new Date(year, month, 0).getDate();
};

const getFirstValue = (record, keys, fallback = "") => {
    for (const key of keys) {
        if (record[key] !== undefined && record[key] !== null && record[key] !== "") {
            return record[key];
        }
    }
    return fallback;
};

const getDeductionRupees = (key, amount, salary) => {
    const value = Number(amount || 0);
    if (PERCENT_KEYS.includes(key)) return round2((Number(salary || 0) * value) / 100);
    return value;
};

const getUnit = (key) => {
    if (PERCENT_KEYS.includes(key)) return "%";
    if (key === "CL" || key === "EL") return "days";
    return "\u20B9";
};

// A saved record stores only amounts. A row is shown ticked when it has a
// value, so a payslip opens exactly as it was generated.
const groupFromRecord = (record, fields) =>
    fields.reduce((acc, f) => {
        const raw = record[`${f.key}_Amount`];
        const hasValue = raw !== undefined && raw !== null && raw !== "" && Number(raw) > 0;
        acc[f.key] = {
            checked: hasValue,
            amount: hasValue ? String(raw) : ""
        };
        return acc;
    }, {});

// The update API can answer one or two levels deep, so check every layer.
const readUpdateResponse = (response) => {
    const layers = [response, response && response.data, response && response.data && response.data.data]
        .filter((l) => l && typeof l === "object");
    const find = (key) => {
        const layer = layers.find((l) => l[key] !== undefined && l[key] !== null);
        return layer ? layer[key] : undefined;
    };
    return {
        notApplicable: find("payslip_applicable") === false,
        pdfFailed: find("payslip_generated") === false && find("payslip_applicable") !== false,
        pdfError: find("payslip_error") || "",
        mailSent: find("email_sent"),
        mailError: find("email_error") || ""
    };
};

/* ============================================================
   COMPONENT
   ============================================================ */

const Updatestaffpay = ({ data, toggle, onSuccess, onCancel }) => {
    const { getData, update } = useContext(AuthContext);

    const record = data || {};
    const staffId = record.Staff_id;
    const handleBack = onCancel || toggle;

    const [validated, setValidated] = useState(false);
    const [error, setError] = useState("");
    const [loading, setLoading] = useState(false);

    const [staffName, setStaffName] = useState(record.Staff_name || "");
    const [department, setDepartment] = useState(record.Department || "");
    const [salaryMonth, setSalaryMonth] = useState(record.Salary_month || "");
    const [paymentDate, setPaymentDate] = useState(record.Payment_date || "");

    // Salary comes from Staff Master and is locked (the backend enforces it too).
    const salary = Number(record.Salary || 0);

    const [presentDays, setPresentDays] = useState(
        Number(getFirstValue(record, ["Present_days", "present_days"], 0))
    );
    const [absentDays, setAbsentDays] = useState(
        Number(getFirstValue(record, ["Absent_days", "absent_days"], 0))
    );

    const [earnings, setEarnings] = useState(() => groupFromRecord(record, EARNINGS_FIELDS));
    const [deductions, setDeductions] = useState(() => groupFromRecord(record, DEDUCTIONS_FIELDS));

    /*
     * Attendance: show the saved values first, then refresh them from
     * Staff Attendance for the chosen month (same totals the Add page uses:
     * present days, and the unpaid days from absent / half day / late rules).
     * If the staff has no attendance for that month the saved values stay.
     */
    useEffect(() => {
        let cancelled = false;

        const loadAttendance = async () => {
            if (!staffId || !salaryMonth) return;

            try {
                const response = await getData(
                    `fetch_staff_datail?salary_month=${encodeURIComponent(salaryMonth)}`
                );

                const rows = Array.isArray(response)
                    ? response
                    : response && Array.isArray(response.data)
                        ? response.data
                        : [];

                const mine = rows.find(
                    (row) => String(row.Staff_id) === String(staffId)
                );

                if (!mine || cancelled) return;

                setPresentDays(Number(mine.Present_days || 0));
                setAbsentDays(Number(mine.Absent_days || 0));
            } catch (err) {
                console.error("Unable to load attendance for payslip edit:", err);
            }
        };

        loadAttendance();

        return () => {
            cancelled = true;
        };
    }, [getData, staffId, salaryMonth]);

    /* ----------------------------------------------------------
       LIVE CALCULATION  (identical formula to the Add page)
       Net = Salary - LOP + Earnings - (PF + ESI + Tax + Late)
       ---------------------------------------------------------- */
    const calculation = useMemo(() => {
        const cl = deductions.CL.checked ? Number(deductions.CL.amount || 0) : 0;
        const el = deductions.EL.checked ? Number(deductions.EL.amount || 0) : 0;
        const lopDays = Math.max(0, Number(absentDays || 0) - cl - el);

        const daysInMonth = getDaysInMonth(salaryMonth);
        const perDay = daysInMonth > 0 ? salary / daysInMonth : 0;
        const lop = round2(perDay * lopDays);

        const earningsTotal = EARNINGS_FIELDS.reduce((sum, f) => {
            const field = earnings[f.key];
            return sum + (field && field.checked ? Number(field.amount || 0) : 0);
        }, 0);

        const deductionsTotal = DEDUCTION_AMOUNT_KEYS.reduce((sum, key) => {
            const field = deductions[key];
            if (!field || !field.checked) return sum;
            return sum + getDeductionRupees(key, field.amount, salary);
        }, 0);

        return {
            lopDays,
            lop,
            earningsTotal: round2(earningsTotal),
            deductionsTotal: round2(deductionsTotal),
            calculatedSalary: round2(salary - lop + earningsTotal - deductionsTotal)
        };
    }, [salary, salaryMonth, absentDays, earnings, deductions]);

    /* ----------------------------------------------------------
       CHECKBOX / AMOUNT HANDLERS
       ---------------------------------------------------------- */
    const handleCheckboxChange = (group, field) => (e) => {
        const checked = e.target.checked;
        const setter = group === "earnings" ? setEarnings : setDeductions;

        setter((prev) => ({
            ...prev,
            [field.key]: {
                checked,
                amount: checked ? (field.defaultAmount ?? "") : ""
            }
        }));
    };

    const handleAmountChange = (group, key) => (e) => {
        const value = e.target.value;
        const setter = group === "earnings" ? setEarnings : setDeductions;

        setter((prev) => ({
            ...prev,
            [key]: { ...prev[key], amount: value }
        }));
    };

    /* ----------------------------------------------------------
       SUBMIT
       The keys below (Overtime_Amount, PF_Amount ...) are exactly the
       names the backend serializer expects.
       ---------------------------------------------------------- */
    const amountOf = (state, key) =>
        state[key] && state[key].checked ? round2(state[key].amount) : 0;

    const handleSubmit = async (event) => {
        event.preventDefault();
        setError("");

        if (!staffName.trim() || !salaryMonth || !paymentDate) {
            setValidated(true);
            setError("Please fill the staff name, salary month and payment date.");
            return;
        }

        const missingAmount = [...EARNINGS_FIELDS, ...DEDUCTIONS_FIELDS].find((f) => {
            const state = EARNINGS_FIELDS.includes(f) ? earnings : deductions;
            return state[f.key].checked && String(state[f.key].amount).trim() === "";
        });

        if (missingAmount) {
            setValidated(true);
            setError(`Please enter a value for ${missingAmount.label}.`);
            return;
        }

        const payload = {
            Staff_pay_id: record.Staff_pay_id,
            Staff_id: record.Staff_id,
            Staff_name: staffName.trim(),
            Department: department,
            Salary_month: salaryMonth,
            Present_days: Number(presentDays || 0),
            Absent_days: Number(absentDays || 0),
            Loss_of_pay: round2(calculation.lop),
            Salary: round2(salary),
            Payment_date: paymentDate,

            Overtime_Amount: amountOf(earnings, "Overtime"),
            Bonus_Amount: amountOf(earnings, "Bonus"),
            Conveyance_Allowance_Amount: amountOf(earnings, "Conveyance_Allowance"),
            Medical_Allowance_Amount: amountOf(earnings, "Medical_Allowance"),
            Special_Allowance_Amount: amountOf(earnings, "Special_Allowance"),

            PF_Amount: amountOf(deductions, "PF"),
            ESI_Amount: amountOf(deductions, "ESI"),
            CL_Amount: amountOf(deductions, "CL"),
            EL_Amount: amountOf(deductions, "EL"),
            Tax_Amount: amountOf(deductions, "Tax"),
            Late_Coming_Penalty_Amount: amountOf(deductions, "Late_Coming_Penalty")
        };

        try {
            setLoading(true);

            const response = await update(payload, "update_staff_pay_datail", "/staffpay");
            const info = readUpdateResponse(response);

            if (info.notApplicable) {
                alert("Saved. Payslip not applicable because this employee has 0 present days.");
                if (onSuccess) await onSuccess(record.Staff_pay_id, { notApplicable: true });
                return;
            }

            if (info.pdfFailed) {
                alert(
                    `Salary saved, but the payslip could not be generated.${info.pdfError ? `\n${info.pdfError}` : ""}`
                );
                if (onSuccess) await onSuccess(record.Staff_pay_id);
                return;
            }

            if (info.mailSent === false) {
                alert(
                    `Payslip updated, but the mail was NOT sent.${info.mailError ? `\n${info.mailError}` : ""}`
                );
            }

            if (onSuccess) {
                await onSuccess(record.Staff_pay_id, { openPayslip: true });
            }
        } catch (err) {
            console.error("Unable to update staff pay:", err);

            const responseData = err?.responseData || err?.response?.data || {};

            setError(
                responseData.message ||
                responseData.detail ||
                err?.message ||
                "Unable to update Staff Pay."
            );
        } finally {
            setLoading(false);
        }
    };

    /* ----------------------------------------------------------
       RENDER HELPERS
       ---------------------------------------------------------- */
    const renderCheckGroup = (group, fields, state) =>
        fields.map((f) => {
            const checked = state[f.key].checked;
            const unit = getUnit(f.key);
            const isPrefix = unit === "\u20B9";

            return (
                <div
                    className={`pay-row ${group}-row ${checked ? "is-checked" : ""}`}
                    key={f.key}
                >
                    <label className="pay-row-label" htmlFor={`${group}_${f.key}`}>
                        <input
                            className="pay-checkbox"
                            type="checkbox"
                            name={f.key}
                            id={`${group}_${f.key}`}
                            checked={checked}
                            onChange={handleCheckboxChange(group, f)}
                            disabled={loading}
                        />
                        <span className="pay-row-text">{f.label}</span>
                    </label>

                    {checked && (
                        <div className={`pay-amount ${isPrefix ? "has-prefix" : "has-suffix"}`}>
                            {isPrefix && <span className="pay-unit">{unit}</span>}
                            <input
                                type="number"
                                className="pay-amount-input"
                                name={`${f.key}_Amount`}
                                min="0"
                                step="0.01"
                                placeholder={f.placeholder || "Enter amount"}
                                value={state[f.key].amount}
                                onChange={handleAmountChange(group, f.key)}
                                disabled={loading}
                                required
                            />
                            {!isPrefix && <span className="pay-unit">{unit}</span>}
                        </div>
                    )}
                </div>
            );
        });

    return (
        <div className="staff-pay-add-page">
            <div className="staff-pay-add-card">
                <div className="staff-pay-add-header">
                    <button
                        type="button"
                        className="back-button"
                        onClick={handleBack}
                        title="Back to Staff Pay"
                        disabled={loading}
                    >
                        <i className="bx bx-left-arrow-alt"></i>
                    </button>
                    <h2>Staff Pay Form</h2>
                    <div className="header-spacer"></div>
                </div>

                {error && (
                    <div className="alert alert-danger" role="alert">
                        <strong>Error!</strong> {error}
                    </div>
                )}

                <form
                    onSubmit={handleSubmit}
                    noValidate
                    className={validated ? "was-validated" : ""}
                >
                    <div className="row g-3">
                        {/* SELECT STAFF (locked - an existing payslip belongs to one employee) */}
                        <div className="col-md-8">
                            <label className="form-label">Select Staff</label>
                            <div className="staff-multi-select">
                                <button
                                    type="button"
                                    className="staff-multi-select-button is-locked"
                                    disabled
                                    title="Staff cannot be changed on an existing payslip"
                                >
                                    <span>{`${record.Staff_id || ""} - ${record.Staff_name || ""}`}</span>
                                    <i className="bx bx-lock-alt"></i>
                                </button>
                            </div>
                        </div>

                        {/* SALARY MONTH */}
                        <div className="col-md-4">
                            <label htmlFor="Salary_month" className="form-label">Select Salary Month</label>
                            <input
                                type="month"
                                name="Salary_month"
                                id="Salary_month"
                                className="form-control"
                                value={salaryMonth}
                                onChange={(e) => setSalaryMonth(e.target.value)}
                                required
                                disabled={loading}
                            />
                        </div>

                        <div className="col-md-6">
                            <label htmlFor="Staff_id" className="form-label">Staff ID</label>
                            <input
                                type="text"
                                id="Staff_id"
                                className="form-control"
                                value={record.Staff_id || ""}
                                readOnly
                            />
                        </div>

                        <div className="col-md-6">
                            <label htmlFor="Staff_name" className="form-label">Name</label>
                            <input
                                type="text"
                                id="Staff_name"
                                className="form-control"
                                value={staffName}
                                onChange={(e) => setStaffName(e.target.value)}
                                required
                                disabled={loading}
                            />
                        </div>

                        <div className="col-md-6">
                            <label htmlFor="Department" className="form-label">Department</label>
                            <input
                                type="text"
                                id="Department"
                                className="form-control"
                                value={department}
                                onChange={(e) => setDepartment(e.target.value)}
                                disabled={loading}
                            />
                        </div>

                        <div className="col-md-6">
                            <label htmlFor="Staff_email" className="form-label">Email</label>
                            <input
                                type="text"
                                id="Staff_email"
                                className="form-control"
                                value={record.Email || ""}
                                readOnly
                            />
                        </div>

                        <div className="col-md-6">
                            <label htmlFor="Present_days" className="form-label">Present Days (Attendance)</label>
                            <input
                                type="number"
                                id="Present_days"
                                className="form-control"
                                value={presentDays}
                                readOnly
                            />
                        </div>

                        <div className="col-md-6">
                            <label htmlFor="Absent_days" className="form-label">Absent Days (Attendance)</label>
                            <input
                                type="number"
                                id="Absent_days"
                                className="form-control"
                                step="any"
                                value={absentDays}
                                readOnly
                            />
                        </div>

                        <div className="col-md-6">
                            <label htmlFor="Loss_of_pay" className="form-label text-danger">Loss of Pay</label>
                            <input
                                type="number"
                                id="Loss_of_pay"
                                className="form-control"
                                value={round2(calculation.lop).toFixed(2)}
                                readOnly
                            />
                        </div>

                        <div className="col-md-6">
                            <label htmlFor="Salary" className="form-label">Salary</label>
                            <input
                                type="number"
                                id="Salary"
                                className="form-control"
                                value={salary}
                                readOnly
                                disabled
                                aria-readonly="true"
                                title="Salary comes from Staff Master and cannot be edited"
                            />
                        </div>

                        <div className="col-md-6">
                            <label htmlFor="Payment_date" className="form-label">Payment Date</label>
                            <input
                                type="date"
                                id="Payment_date"
                                className="form-control"
                                value={paymentDate}
                                onChange={(e) => setPaymentDate(e.target.value)}
                                required
                                disabled={loading}
                            />
                        </div>

                        {/* EARNINGS | DEDUCTIONS */}
                        <div className="col-12 mt-4">
                            <div className="earnings-deductions-grid">
                                <div className="earnings-deductions-column">
                                    <h6 className="section-title earnings-title">Earnings</h6>
                                    <div className="check-group earnings-check-group">
                                        {renderCheckGroup("earnings", EARNINGS_FIELDS, earnings)}
                                    </div>
                                </div>

                                <div className="earnings-deductions-column">
                                    <h6 className="section-title deductions-title">Deductions</h6>
                                    <div className="check-group deductions-check-group">
                                        {renderCheckGroup("deductions", DEDUCTIONS_FIELDS, deductions)}
                                    </div>
                                </div>
                            </div>
                        </div>

                        {/* CALCULATED SALARY */}
                        <div className="col-12 mt-4">
                            <label htmlFor="Calculated_Salary" className="form-label">Calculated Salary</label>
                            <input
                                type="text"
                                id="Calculated_Salary"
                                className="form-control calculated-salary-input"
                                value={round2(calculation.calculatedSalary).toFixed(2)}
                                readOnly
                            />
                        </div>
                    </div>

                    <div className="staff-pay-add-actions">
                        <button
                            type="button"
                            className="btn btn-outline-secondary"
                            onClick={handleBack}
                            disabled={loading}
                        >
                            Cancel
                        </button>
                        <button
                            type="submit"
                            className="btn btn-success generate-batch-btn"
                            disabled={loading}
                        >
                            {loading ? "Updating Payslip..." : "Update Payslip"}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default Updatestaffpay;