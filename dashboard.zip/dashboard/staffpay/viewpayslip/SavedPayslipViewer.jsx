import React, { useRef } from "react";
import "./SavedPayslipViewer.css";

/*
 * SavedPayslipViewer
 * -------------------
 * Full-window viewer for a payslip PDF that was loaded from the file path
 * stored in the database (staff_pay.PayslipPath).
 *
 * PROPS
 *   url       blob: URL of the PDF
 *   fileName  name used for the Download button
 *   title     text shown in the top bar
 *   onBack    called when Back is clicked
 */
const SavedPayslipViewer = ({ url, fileName, title, onBack }) => {
    const frameRef = useRef(null);

    const handlePrint = () => {
        try {
            frameRef.current.contentWindow.focus();
            frameRef.current.contentWindow.print();
        } catch (err) {
            // fallback: open the PDF in a new tab and print from there
            window.open(url, "_blank", "noopener,noreferrer");
        }
    };

    return (
        <div className="saved-payslip-viewer">
            <div className="saved-payslip-topbar">
                <button type="button" className="saved-payslip-btn light" onClick={onBack} title="Back">
                    <i className="bx bx-left-arrow-alt"></i> Back
                </button>

                <h5 className="saved-payslip-title">{title || fileName || "Payslip"}</h5>

                <div className="saved-payslip-actions">
                    <a className="saved-payslip-btn light" href={url} download={fileName || "payslip.pdf"}>
                        <i className="bx bx-download"></i> Download
                    </a>
                    <button type="button" className="saved-payslip-btn" onClick={handlePrint}>
                        <i className="bx bx-printer"></i> Print
                    </button>
                </div>
            </div>

            <iframe ref={frameRef} className="saved-payslip-frame" src={url} title="Payslip PDF" />
        </div>
    );
};

export default SavedPayslipViewer;
