import React, {
    useState,
    useContext,
    useEffect,
    useCallback,
    useRef,
    useMemo
} from "react";

import "./Staffpay.css";

import Addstaffpay from "./addstaffpay/Addstaffpay";
import PayslipPreview from "./addstaffpay/PayslipPreview";
import Updatestaffpay from "./updatestaffpay/Updatestaffpay";
import Deletestaffpay from "./deletestaffpay/Deletestaffpay";
import SavedPayslipViewer from "./viewpayslip/SavedPayslipViewer";

import AuthContext from "../../services/AuthContext";


const MONTHS = [
    { number: 1, name: "Jan" },
    { number: 2, name: "Feb" },
    { number: 3, name: "Mar" },
    { number: 4, name: "Apr" },
    { number: 5, name: "May" },
    { number: 6, name: "Jun" },
    { number: 7, name: "Jul" },
    { number: 8, name: "Aug" },
    { number: 9, name: "Sep" },
    { number: 10, name: "Oct" },
    { number: 11, name: "Nov" },
    { number: 12, name: "Dec" }
];


const formatSalaryMonthLabel = (salaryMonth) => {
    if (!salaryMonth) return "";

    const [year, month] = String(salaryMonth)
        .split("-")
        .map(Number);

    if (!year || !month) return salaryMonth;

    return new Date(
        year,
        month - 1,
        1
    ).toLocaleString("en-US", {
        month: "long",
        year: "numeric"
    });
};


const NOT_APPLICABLE = "Not applicable";


const getSalaryMonth = (item) =>
    item.Salary_month ||
    item.salary_month ||
    "";


const getYear = (item) => {
    const value = getSalaryMonth(item);

    if (/^\d{4}-\d{2}$/.test(value)) {
        return Number(value.slice(0, 4));
    }

    const date = new Date(value);

    return Number.isNaN(date.getTime())
        ? null
        : date.getFullYear();
};


const getMonthNumber = (item) => {
    const value = getSalaryMonth(item);

    if (/^\d{4}-\d{2}$/.test(value)) {
        return Number(value.slice(5, 7));
    }

    const date = new Date(value);

    return Number.isNaN(date.getTime())
        ? null
        : date.getMonth() + 1;
};


const isNotApplicable = (pay) =>
    String(
        pay.Payslip_file_name ??
        pay.PayslipFileName ??
        pay.payslipfilename ??
        ""
    ).trim() === NOT_APPLICABLE;


const base64PdfToUrl = (base64) => {
    const binary = atob(base64);

    const bytes = new Uint8Array(
        binary.length
    );

    for (let i = 0; i < binary.length; i++) {
        bytes[i] =
            binary.charCodeAt(i);
    }

    return URL.createObjectURL(
        new Blob(
            [bytes],
            {
                type: "application/pdf"
            }
        )
    );
};


/* =========================================================
   SEARCH HIGHLIGHT
========================================================= */

const escapeRegExp = (value) =>
    value.replace(
        /[.*+?^${}()|[\]\\]/g,
        "\\$&"
    );


const HighlightText = ({
    text,
    query
}) => {
    const value =
        String(text ?? "");

    if (!query || !value) {
        return <>{value}</>;
    }

    const terms = query
        .trim()
        .split(/\s+/)
        .filter(Boolean)
        .map(escapeRegExp);

    if (!terms.length) {
        return <>{value}</>;
    }

    const regex = new RegExp(
        `(${terms.join("|")})`,
        "gi"
    );

    const parts =
        value.split(regex);

    return (
        <>
            {parts.map(
                (part, index) => {
                    const matched =
                        terms.some(
                            (term) =>
                                part.toLowerCase() ===
                                term.toLowerCase()
                        );

                    return matched ? (
                        <mark
                            key={index}
                            className="staff-search-highlight"
                        >
                            {part}
                        </mark>
                    ) : (
                        <React.Fragment
                            key={index}
                        >
                            {part}
                        </React.Fragment>
                    );
                }
            )}
        </>
    );
};


/* =========================================================
   SEARCH SCORE
========================================================= */

const getSearchScore = (
    staff,
    query
) => {
    const id =
        String(
            staff.Staff_id ?? ""
        )
            .toLowerCase()
            .trim();

    const name =
        String(
            staff.Staff_name ?? ""
        )
            .toLowerCase()
            .trim();

    const terms = query
        .toLowerCase()
        .trim()
        .split(/\s+/)
        .filter(Boolean);

    if (!terms.length) {
        return 0;
    }

    let score = 0;

    terms.forEach(
        (term) => {
            const nameWords =
                name
                    .split(/\s+/)
                    .filter(Boolean);

            if (id === term) {
                score += 1000;
            } else if (
                id.startsWith(term)
            ) {
                score += 800;
            } else if (
                name.startsWith(term)
            ) {
                score += 700;
            } else if (
                nameWords.some(
                    (word) =>
                        word.startsWith(term)
                )
            ) {
                score += 600;
            } else if (
                name.includes(term)
            ) {
                score += 300;
            } else if (
                id.includes(term)
            ) {
                score += 200;
            }
        }
    );

    return score;
};


function Staffpay() {

    const [
        addViewVisible,
        setAddViewVisible
    ] = useState(false);

    const [
        deletePopupVisible,
        setDeletePopupVisible
    ] = useState(false);

    const [
        currentPage,
        setCurrentPage
    ] = useState(1);

    const [
        year,
        setYear
    ] = useState(
        new Date().getFullYear()
    );

    const [
        monthPage,
        setMonthPage
    ] = useState(0);

    const [
        staffPays,
        setStaffPays
    ] = useState([]);

    const [
        value,
        setValue
    ] = useState(null);

    const [
        searchTerm,
        setSearchTerm
    ] = useState("");

    const [
        payslip,
        setPayslip
    ] = useState(null);

    const [
        editRecord,
        setEditRecord
    ] = useState(null);

    const [
        viewer,
        setViewer
    ] = useState(null);

    const viewerUrlRef =
        useRef(null);

    const {
        getData
    } = useContext(
        AuthContext
    );

    const itemsPerPage = 10;


    /* =========================================================
       FETCH
    ========================================================= */

    const fetchStaffPays =
        useCallback(
            async () => {
                try {
                    const data =
                        await getData(
                            "fetch_staff_pay_datail"
                        );

                    setStaffPays(
                        Array.isArray(data)
                            ? data
                            : []
                    );

                } catch (err) {
                    console.error(
                        "Failed to fetch staff pay:",
                        err
                    );

                    setStaffPays([]);
                }
            },
            [getData]
        );


    useEffect(() => {
        fetchStaffPays();
    }, [fetchStaffPays]);


    useEffect(() => {
        return () => {
            if (
                viewerUrlRef.current
            ) {
                URL.revokeObjectURL(
                    viewerUrlRef.current
                );
            }
        };
    }, []);


    /* =========================================================
       ADD
    ========================================================= */

    const openAddView =
        () =>
            setAddViewVisible(true);


    const closeAddView =
        () =>
            setAddViewVisible(false);


    const handleStaffPayCreated =
        async (newPayslip) => {

            setAddViewVisible(false);

            setCurrentPage(1);

            if (newPayslip) {

                const salaryYear =
                    Number(
                        String(
                            newPayslip.salaryMonth ||
                            ""
                        ).slice(0, 4)
                    );

                if (salaryYear) {
                    setYear(
                        salaryYear
                    );
                }

                setPayslip(
                    newPayslip
                );
            }

            await fetchStaffPays();
        };


    const closePayslip =
        () =>
            setPayslip(null);


    /* =========================================================
       VIEW SAVED PAYSLIP
    ========================================================= */

    const openSavedPayslip =
        async (pay) => {

            const payId =
                pay.Staff_pay_id;

            if (
                isNotApplicable(pay)
            ) {

                alert(
                    "Not applicable - no payslip was generated because this employee had 0 present days."
                );

                return;
            }

            try {

                const res =
                    await getData(
                        `payslip_file_data/${payId}`
                    );

                const body =
                    (
                        res &&
                        res.data &&
                        res.data.pdf_base64
                    )
                        ? res.data
                        : res || {};

                if (
                    !body.pdf_base64
                ) {

                    alert(
                        body.message ||
                        "Payslip PDF is not available for this salary record."
                    );

                    return;
                }

                if (
                    viewerUrlRef.current
                ) {

                    URL.revokeObjectURL(
                        viewerUrlRef.current
                    );
                }

                const url =
                    base64PdfToUrl(
                        body.pdf_base64
                    );

                viewerUrlRef.current =
                    url;

                setViewer({
                    url,
                    fileName:
                        body.file_name ||
                        `Payslip_${pay.Staff_id}.pdf`,

                    title:
                        `${pay.Staff_id} - ${pay.Staff_name} - ${formatSalaryMonthLabel(
                            pay.Salary_month
                        )}`
                });

            } catch (err) {

                console.error(
                    "Unable to open payslip:",
                    err
                );

                alert(
                    "Payslip PDF could not be opened. Please try again."
                );
            }
        };


    /* =========================================================
       DOWNLOAD
    ========================================================= */

    const downloadSavedPayslip =
        async (pay) => {

            if (
                isNotApplicable(pay)
            ) {

                alert(
                    "Not applicable - there is no payslip to download for this employee."
                );

                return;
            }

            try {

                const res =
                    await getData(
                        `payslip_file_data/${pay.Staff_pay_id}`
                    );

                const body =
                    (
                        res &&
                        res.data &&
                        res.data.pdf_base64
                    )
                        ? res.data
                        : res || {};

                if (
                    !body.pdf_base64
                ) {

                    alert(
                        body.message ||
                        "Payslip PDF is not available for this salary record."
                    );

                    return;
                }

                const url =
                    base64PdfToUrl(
                        body.pdf_base64
                    );

                const link =
                    document.createElement(
                        "a"
                    );

                link.href = url;

                link.download =
                    body.file_name ||
                    `Payslip_${pay.Staff_id}.pdf`;

                document.body.appendChild(
                    link
                );

                link.click();

                link.remove();

                setTimeout(
                    () =>
                        URL.revokeObjectURL(
                            url
                        ),
                    1000
                );

            } catch (err) {

                console.error(
                    "Unable to download payslip:",
                    err
                );

                alert(
                    "Payslip PDF could not be downloaded. Please try again."
                );
            }
        };


    /* =========================================================
       VIEWER
    ========================================================= */

    const closeViewer = () => {

        if (
            viewerUrlRef.current
        ) {

            URL.revokeObjectURL(
                viewerUrlRef.current
            );

            viewerUrlRef.current =
                null;
        }

        setViewer(null);
    };


    /* =========================================================
       EDIT
    ========================================================= */

    const handleEdit = (pay) => {
        setEditRecord(pay);
    };


    const closeEdit = () => {
        setEditRecord(null);
    };


    /*
     * IMPORTANT:
     * Keep Edit available even after the payslip has been generated.
     */
    const handleStaffPayUpdated =
        async (
            staffPayId,
            options = {}
        ) => {

            const edited =
                editRecord;

            setEditRecord(null);

            await fetchStaffPays();

            if (
                options.notApplicable
            ) {
                return;
            }

            /*
             * Do NOT remove the edit option.
             * After updating, open the newly saved payslip
             * only when requested by the update component.
             */
            if (
                staffPayId &&
                options.openPayslip
            ) {

                await openSavedPayslip({
                    Staff_pay_id:
                        staffPayId,

                    Staff_id:
                        edited &&
                        edited.Staff_id,

                    Staff_name:
                        edited &&
                        edited.Staff_name,

                    Salary_month:
                        edited &&
                        edited.Salary_month
                });
            }
        };


    /* =========================================================
       DELETE
    ========================================================= */

    const toggleDeletePopup =
        () =>
            setDeletePopupVisible(
                (prev) => !prev
            );


    const handleDelete =
        (payId) => {

            setValue(payId);

            setDeletePopupVisible(
                true
            );
        };


    /* =========================================================
       YEAR
    ========================================================= */

    const yearPays =
        useMemo(
            () =>
                staffPays.filter(
                    (item) =>
                        getYear(item) ===
                        year
                ),
            [staffPays, year]
        );


    /* =========================================================
       GROUP
    ========================================================= */

    const groupedStaff =
        useMemo(() => {

            const grouped =
                new Map();

            yearPays.forEach(
                (item) => {

                    const key =
                        String(
                            item.Staff_id ??
                            item.staff_id ??
                            ""
                        );

                    if (
                        !grouped.has(
                            key
                        )
                    ) {

                        grouped.set(
                            key,
                            {
                                Staff_id:
                                    item.Staff_id ??
                                    item.staff_id,

                                Staff_name:
                                    item.Staff_name ??
                                    item.Name ??
                                    item.name ??
                                    "",

                                months: {}
                            }
                        );
                    }

                    const month =
                        getMonthNumber(
                            item
                        );

                    if (month) {

                        grouped
                            .get(key)
                            .months[
                                month
                            ] = item;
                    }
                }
            );

            return Array.from(
                grouped.values()
            );

        }, [yearPays]);


    /* =========================================================
       SEARCH
    ========================================================= */

    const filteredStaff =
        useMemo(() => {

            const query =
                searchTerm
                    .trim()
                    .toLowerCase();

            if (!query) {
                return groupedStaff;
            }

            const terms =
                query
                    .split(/\s+/)
                    .filter(Boolean);

            const filtered =
                groupedStaff.filter(
                    (staff) => {

                        const id =
                            String(
                                staff.Staff_id ??
                                ""
                            ).toLowerCase();

                        const name =
                            String(
                                staff.Staff_name ??
                                ""
                            ).toLowerCase();

                        return terms.every(
                            (term) =>
                                id.includes(
                                    term
                                ) ||
                                name.includes(
                                    term
                                )
                        );
                    }
                );

            return filtered.sort(
                (a, b) =>
                    getSearchScore(
                        b,
                        query
                    ) -
                    getSearchScore(
                        a,
                        query
                    )
            );

        }, [
            groupedStaff,
            searchTerm
        ]);


    /* =========================================================
       MONTHS
    ========================================================= */

    const visibleMonths =
        useMemo(
            () =>
                MONTHS.slice(
                    monthPage * 6,
                    monthPage * 6 + 6
                ),
            [monthPage]
        );


    /* =========================================================
       RESET
    ========================================================= */

    useEffect(() => {
        setCurrentPage(1);
    }, [
        searchTerm,
        year
    ]);


    useEffect(() => {
        setMonthPage(0);
    }, [year]);


    /* =========================================================
       PAGINATION
    ========================================================= */

    const indexOfLastItem =
        currentPage *
        itemsPerPage;

    const indexOfFirstItem =
        indexOfLastItem -
        itemsPerPage;

    const currentStaff =
        filteredStaff.slice(
            indexOfFirstItem,
            indexOfLastItem
        );


    const nextPage = () => {

        if (
            indexOfLastItem <
            filteredStaff.length
        ) {

            setCurrentPage(
                currentPage + 1
            );
        }
    };


    const prevPage = () => {

        if (
            currentPage > 1
        ) {

            setCurrentPage(
                currentPage - 1
            );
        }
    };


    const changeYear =
        (amount) => {

            setYear(
                (currentYear) =>
                    currentYear +
                    amount
            );

            setCurrentPage(1);

            setMonthPage(0);
        };


    const changeMonthPage =
        (amount) => {

            setMonthPage(
                (currentPage) =>
                    Math.min(
                        1,
                        Math.max(
                            0,
                            currentPage +
                            amount
                        )
                    )
            );
        };


    const monthRangeLabel =
        monthPage === 0
            ? "Jan - Jun"
            : "Jul - Dec";


    /* =========================================================
       FULL SCREEN
    ========================================================= */

    if (viewer) {

        return (
            <SavedPayslipViewer
                url={viewer.url}
                fileName={
                    viewer.fileName
                }
                title={
                    viewer.title
                }
                onBack={
                    closeViewer
                }
            />
        );
    }


    if (payslip) {

        return (
            <PayslipPreview
                payslip={
                    payslip
                }
                onBack={
                    closePayslip
                }
            />
        );
    }


    if (editRecord) {

        return (
            <div className="staff-pay-full-view">

                <Updatestaffpay
                    data={
                        editRecord
                    }

                    toggle={
                        closeEdit
                    }

                    onCancel={
                        closeEdit
                    }

                    onSuccess={
                        handleStaffPayUpdated
                    }
                />

            </div>
        );
    }


    if (addViewVisible) {

        return (
            <div className="staff-pay-full-view">

                <Addstaffpay
                    toggle={
                        closeAddView
                    }

                    onSuccess={
                        handleStaffPayCreated
                    }
                />

            </div>
        );
    }


    /* =========================================================
       DASHBOARD
    ========================================================= */

    return (

        <div className="staff-pay-page container-xxl flex-grow-1 container-p-y">

            <div className="page-header">

                <div>

                    <h3 className="page-title">
                        VIEW STAFF PAY
                    </h3>

                    <p className="page-subtitle">
                        View and manage monthly staff salary payments
                    </p>

                </div>


                <button
                    className="btn btn-primary add-btn"
                    onClick={
                        openAddView
                    }
                >

                    <i className="bx bx-user-plus me-2"></i>

                    Add staff pay

                </button>

            </div>


            <div className="card staff-pay-card">


                {/* =================================================
                    TOOLBAR
                ================================================= */}

                <div className="dashboard-toolbar">

                    <div className="staff-search-box">

                        <i className="bx bx-search"></i>

                        <input
                            type="text"
                            value={
                                searchTerm
                            }
                            onChange={
                                (e) =>
                                    setSearchTerm(
                                        e.target.value
                                    )
                            }
                            placeholder="Search staff by ID or name"
                            aria-label="Search staff by ID or name"
                        />

                        {searchTerm && (

                            <button
                                type="button"
                                className="search-clear-btn"
                                onClick={() =>
                                    setSearchTerm(
                                        ""
                                    )
                                }
                                title="Clear search"
                            >

                                <i className="bx bx-x"></i>

                            </button>

                        )}

                    </div>


                    <div className="year-navigation">

                        <button
                            className="year-arrow"
                            onClick={() =>
                                changeYear(
                                    -1
                                )
                            }
                            title="Previous year"
                        >
                            <i className="bx bx-chevron-left"></i>
                        </button>


                        <span className="year">
                            {year}
                        </span>


                        <button
                            className="year-arrow"
                            onClick={() =>
                                changeYear(
                                    1
                                )
                            }
                            title="Next year"
                        >
                            <i className="bx bx-chevron-right"></i>
                        </button>

                    </div>


                    <div className="month-navigation">

                        <button
                            className="month-arrow"
                            onClick={() =>
                                changeMonthPage(
                                    -1
                                )
                            }
                            disabled={
                                monthPage ===
                                0
                            }
                            title="Previous six months"
                        >

                            <i className="bx bx-chevron-left"></i>

                        </button>


                        <span className="month-range">
                            {
                                monthRangeLabel
                            }
                        </span>


                        <button
                            className="month-arrow"
                            onClick={() =>
                                changeMonthPage(
                                    1
                                )
                            }
                            disabled={
                                monthPage ===
                                1
                            }
                            title="Next six months"
                        >

                            <i className="bx bx-chevron-right"></i>

                        </button>

                    </div>

                </div>


                {/* =================================================
                    TABLE
                ================================================= */}

                <div className="staff-pay-table-wrapper">

                    <table className="table modern-table">

                        {/* Fixed widths: Staff ID and Staff Name never change
                            when the six-month window is switched. */}
                        <colgroup>
                            <col className="col-staff-id" />
                            <col className="col-staff-name" />
                            {visibleMonths.map((month) => (
                                <col
                                    key={month.number}
                                    className="col-month"
                                />
                            ))}
                        </colgroup>

                        <thead>

                            <tr>

                                <th className="staff-id-column">
                                    Staff ID
                                </th>

                                <th className="staff-name-column">
                                    Staff Name
                                </th>

                                {visibleMonths.map(
                                    (month) => (

                                        <th
                                            key={
                                                month.number
                                            }
                                            className="month-cell"
                                        >
                                            {
                                                month.name
                                            }
                                        </th>

                                    )
                                )}

                            </tr>

                        </thead>


                        <tbody>

                            {currentStaff.length >
                            0 ? (

                                currentStaff.map(
                                    (staff) => (

                                        <tr
                                            key={
                                                staff.Staff_id
                                            }
                                        >

                                            <td className="staff-id-column">

                                                <strong>

                                                    <HighlightText
                                                        text={
                                                            staff.Staff_id
                                                        }
                                                        query={
                                                            searchTerm
                                                        }
                                                    />

                                                </strong>

                                            </td>


                                            <td className="staff-name-column">

                                                <span className="staff-name-text">

                                                    <HighlightText
                                                        text={
                                                            staff.Staff_name
                                                        }
                                                        query={
                                                            searchTerm
                                                        }
                                                    />

                                                </span>

                                            </td>


                                            {visibleMonths.map(
                                                (
                                                    month
                                                ) => {

                                                    const pay =
                                                        staff
                                                            .months[
                                                            month
                                                                .number
                                                        ];

                                                    return (

                                                        <td
                                                            key={
                                                                month.number
                                                            }
                                                            className="month-cell"
                                                        >

                                                            {pay ? (

                                                                <div className="month-cell-content">

                                                                    <div className="month-action-buttons">


                                                                        {/* VIEW */}

                                                                        <button
                                                                            type="button"
                                                                            className="month-action view-action"
                                                                            title="View payslip"
                                                                            aria-label="View payslip"
                                                                            onClick={() =>
                                                                                openSavedPayslip(
                                                                                    pay
                                                                                )
                                                                            }
                                                                        >

                                                                            {/* Changed ONLY the view icon */}

                                                                            <i className="bx bx-show-alt"></i>

                                                                        </button>


                                                                        {/* DOWNLOAD */}

                                                                        <button
                                                                            type="button"
                                                                            className="month-action download-action"
                                                                            title="Download payslip"
                                                                            aria-label="Download payslip"
                                                                            onClick={() =>
                                                                                downloadSavedPayslip(
                                                                                    pay
                                                                                )
                                                                            }
                                                                        >

                                                                            <i className="bx bx-cloud-download"></i>

                                                                        </button>


                                                                        {/* EDIT - RESTORED */}

                                                                        <button
                                                                            type="button"
                                                                            className="month-action edit-action"
                                                                            title="Edit payslip"
                                                                            aria-label="Edit payslip"
                                                                            onClick={() =>
                                                                                handleEdit(
                                                                                    pay
                                                                                )
                                                                            }
                                                                        >

                                                                            <i className="bx bx-edit"></i>

                                                                        </button>


                                                                        {/* DELETE */}

                                                                        <button
                                                                            type="button"
                                                                            className="month-action delete-action"
                                                                            title="Delete payslip"
                                                                            aria-label="Delete payslip"
                                                                            onClick={() =>
                                                                                handleDelete(
                                                                                    pay.Staff_pay_id
                                                                                )
                                                                            }
                                                                        >

                                                                            <i className="bx bx-trash-alt"></i>

                                                                        </button>

                                                                    </div>

                                                                </div>

                                                            ) : (

                                                                <span className="empty-month">
                                                                    -
                                                                </span>

                                                            )}

                                                        </td>

                                                    );
                                                }
                                            )}

                                        </tr>

                                    )
                                )

                            ) : (

                                <tr>

                                    <td
                                        colSpan={
                                            2 + visibleMonths.length
                                        }
                                        className="empty-table-message"
                                    >

                                        {searchTerm
                                            ? `No staff found for "${searchTerm}".`
                                            : `No staff pay records found for ${year}.`}

                                    </td>

                                </tr>

                            )}

                        </tbody>

                    </table>

                </div>


                {/* =================================================
                    DELETE
                ================================================= */}

                {deletePopupVisible && (

                    <Deletestaffpay
                        toggle={
                            toggleDeletePopup
                        }
                        data={
                            value
                        }
                        onSuccess={
                            fetchStaffPays
                        }
                    />

                )}


                {/* =================================================
                    FOOTER
                ================================================= */}

                <div className="card-footer bg-white border-0 staff-pay-footer">

                    <div className="d-flex justify-content-end align-items-center gap-2">

                        <span className="page-count">

                            {filteredStaff.length ===
                            0
                                ? "0 staff"
                                : `${indexOfFirstItem + 1}-${Math.min(
                                      indexOfLastItem,
                                      filteredStaff.length
                                  )} of ${filteredStaff.length} staff`}

                        </span>


                        <button
                            className="btn btn-light pagination-btn"
                            onClick={
                                prevPage
                            }
                            disabled={
                                currentPage ===
                                1
                            }
                            title="Previous page"
                        >

                            <i className="bx bx-chevron-left"></i>

                        </button>


                        <button
                            className="btn btn-primary pagination-btn"
                            onClick={
                                nextPage
                            }
                            disabled={
                                indexOfLastItem >=
                                filteredStaff.length
                            }
                            title="Next page"
                        >

                            <i className="bx bx-chevron-right"></i>

                        </button>

                    </div>

                </div>

            </div>

        </div>
    );
}


export default Staffpay;