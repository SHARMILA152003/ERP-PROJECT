import React, { useContext, useState } from "react";
import AuthContext from "../../../services/AuthContext";

const Deletestaffpay = (props) => {
    const { Delete } = useContext(AuthContext);
    const [deleting, setDeleting] = useState(false);
    const [error, setError] = useState("");

    const handleSubmit = async () => {
        try {
            if (!props.data) throw new Error("Missing staff pay ID");

            setDeleting(true);
            setError("");

            await Delete(
                { Staff_pay_id: props.data },
                "delete_staff_pay_datail",
                "/staffpay"
            );

            // Refresh the dashboard from the database before closing the
            // confirmation dialog, so the deleted payslip disappears
            // immediately from the table.
            if (props.onSuccess) await props.onSuccess();
            props.toggle();
        } catch (error) {
            console.error("Delete operation failed:", error);
            setError(
                error?.responseData?.message ||
                error?.message ||
                "Payslip could not be deleted. Please try again."
            );
        } finally {
            setDeleting(false);
        }
    };

    return (
        <div className="modal fade show" tabIndex="-1" role="dialog" style={{ display: "block", backgroundColor: "rgba(0,0,0,0.5)" }}>
            <div className="modal-dialog modal-dialog-centered" role="document">
                <div className="modal-content">
                    <div className="modal-header">
                        <h5 className="modal-title">Warning Message</h5>
                        <button type="button" className="btn-close" onClick={props.toggle} aria-label="Close"></button>
                    </div>
                    <div className="modal-body text-center">
                        {error && (
                            <div className="alert alert-danger py-2">{error}</div>
                        )}
                        <div className="mb-3">
                            <div className="text-danger mb-3" style={{ fontSize: "40px" }}>⚠</div>
                            <h5>Are you sure you want to delete?</h5>
                            <p className="text-muted mb-0">This action cannot be undone.</p>
                        </div>
                    </div>
                    <div className="modal-footer">
                        <button type="button" className="btn btn-outline-secondary" onClick={props.toggle} disabled={deleting}>Cancel</button>
                        <button type="button" onClick={handleSubmit} className="btn btn-danger" disabled={deleting}>
                            {deleting ? "Deleting..." : "Delete"}
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Deletestaffpay;
