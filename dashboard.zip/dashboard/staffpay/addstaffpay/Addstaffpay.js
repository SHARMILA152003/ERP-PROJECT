import React, { useContext, useEffect, useMemo, useRef, useState } from "react";
import ReactDOM from "react-dom";
import AuthContext from "../../../services/AuthContext";
import "./addstaffpay.css";

const EARNINGS_FIELDS = [
    { key: "Overtime", label: "Overtime (OT) Pay", placeholder: "Enter amount" },
    { key: "Bonus", label: "Bonus", placeholder: "Enter amount" },
    { key: "Conveyance_Allowance", label: "Conveyance Allowance", placeholder: "Enter amount" },
    { key: "Medical_Allowance", label: "Medical Allowance", placeholder: "Enter amount" },
    { key: "Special_Allowance", label: "Special Allowance", placeholder: "Enter amount" }
];

const DEDUCTIONS_FIELDS = [
    { key: "PF", label: "PF (%)", placeholder: "Enter %", defaultChecked: true, defaultAmount: "12" },
    { key: "ESI", label: "ESI (%)", placeholder: "Enter %" },
    { key: "CL", label: "CL (Casual Leave)", placeholder: "Enter days", defaultChecked: true, defaultAmount: "1" },
    { key: "EL", label: "EL (Earned Leave)", placeholder: "Enter days" },
    { key: "Tax", label: "Tax", placeholder: "Enter amount", defaultChecked: true, defaultAmount: "208" },
    { key: "Late_Coming_Penalty", label: "Late Coming Penalty", placeholder: "Enter amount" }
];

const DEDUCTION_AMOUNT_KEYS = DEDUCTIONS_FIELDS
    .map((f) => f.key)
    .filter((key) => key !== "CL" && key !== "EL");

const PERCENT_KEYS = ["PF", "ESI"];

const emptyGroupState = (fields) =>
    fields.reduce((acc, f) => {
        const checked = f.defaultChecked ?? false;
        acc[f.key] = {
            checked,
            amount: checked ? (f.defaultAmount ?? "") : ""
        };
        return acc;
    }, {});

const getDaysInMonth = (salaryMonth) => {
    if (!salaryMonth) return null;
    const [year, month] = salaryMonth.split("-").map(Number);
    if (!year || !month) return null;
    return new Date(year, month, 0).getDate();
};

const getPreviousMonthYYYYMM = (date) => {
    const d = new Date(date.getFullYear(), date.getMonth() - 1, 1);
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
};

const formatSalaryMonthLabel = (salaryMonth) => {
    if (!salaryMonth) return "";
    const [year, month] = salaryMonth.split("-").map(Number);
    if (!year || !month) return salaryMonth;
    return new Date(year, month - 1, 1).toLocaleString("en-US", {
        month: "long",
        year: "numeric"
    });
};

const round2 = (num) => Math.round((Number(num || 0) + Number.EPSILON) * 100) / 100;
// Amounts keep their paise (2 decimals) everywhere - form, database, preview
// and saved PDF. roundRupee is kept as an alias so nothing else has to change,
// but it no longer rounds to whole rupees.
const roundRupee = (num) => round2(num);

// "1,234.50" style text (Indian grouping, always 2 decimals)
const formatMoney = (num) =>
    Number(num || 0).toLocaleString("en-IN", {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    });

const pick = (obj, keys, fallback = "-") => {
    for (const k of keys) {
        if (obj && obj[k] !== undefined && obj[k] !== null && obj[k] !== "") return obj[k];
    }
    return fallback;
};

// Text stored in the staff_pay.payslipfilename column (and shown to the user)
// when an employee has 0 present days and therefore gets no payslip.
const NOT_APPLICABLE = "Not applicable";

const hasNoPresentDays = (staff) => Number(staff?.Present_days || 0) <= 0;

// Reads the result of the create API. The backend returns:
//   payslip_applicable  false when present days = 0 (row saved, no PDF, no mail)
//   payslip_generated   false when the PDF could not be built
//   email_sent          true / false
//   email_error         reason when the mail was not sent
// The payload can sit one or two levels deep depending on the insert() helper,
// so every layer is checked.
const readCreateResponse = (response) => {
    const layers = [response, response && response.data, response && response.data && response.data.data]
        .filter((l) => l && typeof l === "object");
    const find = (key) => {
        const layer = layers.find((l) => l[key] !== undefined && l[key] !== null);
        return layer ? layer[key] : undefined;
    };

    const mailFlag = find("email_sent");

    return {
        notApplicable:
            find("payslip_applicable") === false ||
            String(find("payslip_file") || "").trim() === NOT_APPLICABLE,
        pdfFailed: find("payslip_generated") === false && find("payslip_applicable") !== false,
        pdfError: find("payslip_error") || "",
        mailSent: mailFlag === undefined ? null : mailFlag === true,
        mailError: find("email_error") || ""
    };
};

const describeOutcome = (item) => {
    if (item.notApplicable) return `${NOT_APPLICABLE} (0 present days) - payslip not generated, mail not sent`;
    if (item.pdfFailed) return `Salary saved, payslip NOT generated${item.pdfError ? ` (${item.pdfError})` : ""} - mail not sent`;
    if (item.mailSent === true) return "Payslip generated - mail sent";
    if (item.mailSent === false) return `Payslip generated - mail NOT sent${item.mailError ? ` (${item.mailError})` : ""}`;
    return "Payslip generated";
};

const getDeductionRupees = (key, amount, salaryValue) => {
    const value = Number(amount || 0);
    if (PERCENT_KEYS.includes(key)) return round2((salaryValue * value) / 100);
    return value;
};

// Designation / department come from the staff table in the database.
const getStaffDesignation = (staff) =>
    String(staff?.Designation ?? staff?.designation ?? staff?.Role ?? staff?.Position ?? "").trim();

const getStaffDepartment = (staff) =>
    String(staff?.Department ?? staff?.department ?? "").trim();

// Search boxes shown in the "Select Staff" popup
const STAFF_SEARCH_FIELDS = [
    { key: "id", label: "Search by Staff ID", placeholder: "Staff ID", icon: "bx-id-card" },
    { key: "name", label: "Search by Staff Name", placeholder: "Staff name", icon: "bx-search" },
    { key: "department", label: "Search by Department", placeholder: "Department", icon: "bx-buildings" },
    { key: "designation", label: "Search by Designation", placeholder: "Designation", icon: "bx-briefcase" }
];

const EMPTY_STAFF_FILTERS = { id: "", name: "", department: "", designation: "" };

// "starts-with" match on the whole text OR on any word inside it
// (typing "kum" finds "Ravi Kumar", typing "hr" finds "HR Department").
const startsWithAnyWord = (value, query) => {
    const text = String(value ?? "").toLowerCase();
    return text.startsWith(query) || text.split(/\s+/).some((word) => word.startsWith(query));
};

const makeStaffEntry = (staff) => ({
    Staff_id: staff.Staff_id,
    Staff_name: staff.Staff_name ?? "",
    Department: staff.Department ?? "",
    Email: staff.Email ?? "",
    Designation: getStaffDesignation(staff),
    Bank_Name: staff.Bank_Name ?? "",
    Account_Number: staff.Account_Number ?? "",
    PAN_Number: staff.PAN_Number ?? "",
    Date_of_Joining: staff.Date_of_Joining ?? "",
    Date_of_Relieving: staff.Date_of_Relieving ?? "",
    Salary: staff.Salary ?? "",
    Present_days: staff.Present_days ?? "",
    Absent_days: staff.Absent_days ?? ""
});

const Addstaffpay = (props) => {
    const { insert, getData } = useContext(AuthContext);

    const [validated, setValidated] = useState(false);
    const [error, setError] = useState("");
    const [success, setSuccess] = useState("");
    const [loading, setLoading] = useState(false);
    const [staffList, setStaffList] = useState([]);
    const [existingStaffPays, setExistingStaffPays] = useState([]);
    const [selectedStaff, setSelectedStaff] = useState([]);
    const [staffEntries, setStaffEntries] = useState({});
    const [staffDropdownOpen, setStaffDropdownOpen] = useState(false);
    const [staffFilters, setStaffFilters] = useState(EMPTY_STAFF_FILTERS);
    const searchInputRef = useRef(null);

    const [paymentDate, setPaymentDate] = useState(() => new Date().toISOString().slice(0, 10));
    const [salaryMonth, setSalaryMonth] = useState(() => getPreviousMonthYYYYMM(new Date()));

    const [earnings, setEarnings] = useState(emptyGroupState(EARNINGS_FIELDS));
    const [deductions, setDeductions] = useState(emptyGroupState(DEDUCTIONS_FIELDS));

    useEffect(() => {
        const loadStaff = async () => {
            try {
                // The backend returns only active employees who have at least
                // one PRESENT attendance record in the selected salary month.
                const [staffData, staffPayData] = await Promise.all([
                    getData(`fetch_staff_datail?salary_month=${encodeURIComponent(salaryMonth)}`),
                    getData("fetch_staff_pay_datail")
                ]);

                setStaffList(
                    (Array.isArray(staffData) ? staffData : []).filter(
                        (staff) => !staff.Date_of_Relieving
                    )
                );
                setExistingStaffPays(Array.isArray(staffPayData) ? staffPayData : []);
            } catch (err) {
                console.error("Failed to fetch staff/pay records:", err);
                setStaffList([]);
                setExistingStaffPays([]);
            }
        };

        setSelectedStaff([]);
        setStaffEntries({});
        loadStaff();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [salaryMonth]);

    // Staff popup: focus the first search box, lock page scroll behind it,
    // close on Esc, and reset the search boxes when it closes.
    useEffect(() => {
        if (!staffDropdownOpen) {
            setStaffFilters(EMPTY_STAFF_FILTERS);
            return undefined;
        }

        const t = setTimeout(() => searchInputRef.current?.focus(), 0);
        const previousOverflow = document.body.style.overflow;
        document.body.style.overflow = "hidden";

        const handleKeyDown = (event) => {
            if (event.key === "Escape") setStaffDropdownOpen(false);
        };
        document.addEventListener("keydown", handleKeyDown);

        return () => {
            clearTimeout(t);
            document.body.style.overflow = previousOverflow;
            document.removeEventListener("keydown", handleKeyDown);
        };
    }, [staffDropdownOpen]);

    const availableStaffList = useMemo(() => {
        return staffList.filter((staff) => !existingStaffPays.some(
            (pay) =>
                String(pay.Staff_id) === String(staff.Staff_id) &&
                String(pay.Salary_month || pay.salary_month || "") === String(salaryMonth)
        ));
    }, [staffList, existingStaffPays, salaryMonth]);

    // Remove employees from the current selection if the month is changed
    // to a month in which they already have a payslip.
    useEffect(() => {
        const availableIds = new Set(availableStaffList.map((s) => String(s.Staff_id)));
        setSelectedStaff((prev) => prev.filter((id) => availableIds.has(String(id))));
    }, [availableStaffList]);

    const selectedStaffRows = useMemo(
        () => selectedStaff
            .map((id) => staffEntries[String(id)])
            .filter(Boolean),
        [selectedStaff, staffEntries]
    );

    // Live "starts-with" search. Every letter typed narrows the list.
    // Filled boxes work together: a staff member must match ALL of them.
    const isSearching = Object.values(staffFilters).some((v) => v.trim());

    const visibleStaffList = useMemo(() => {
        const idQ = staffFilters.id.trim().toLowerCase();
        const nameQ = staffFilters.name.trim().toLowerCase();
        const deptQ = staffFilters.department.trim().toLowerCase();
        const desigQ = staffFilters.designation.trim().toLowerCase();
        if (!idQ && !nameQ && !deptQ && !desigQ) return availableStaffList;

        return availableStaffList.filter((staff) => {
            const id = String(staff.Staff_id ?? "").toLowerCase();

            return (
                (!idQ || id.startsWith(idQ) || (/^\d+$/.test(idQ) && id.includes(idQ))) &&
                (!nameQ || startsWithAnyWord(staff.Staff_name, nameQ)) &&
                (!deptQ || startsWithAnyWord(getStaffDepartment(staff), deptQ)) &&
                (!desigQ || startsWithAnyWord(getStaffDesignation(staff), desigQ))
            );
        });
    }, [availableStaffList, staffFilters]);

    // With no search text this is identical to "all available staff".
    const allSelected = visibleStaffList.length > 0 &&
        visibleStaffList.every((staff) => selectedStaff.includes(String(staff.Staff_id)));

    const toggleStaff = (staff) => {
        const id = String(staff.Staff_id);
        setError("");
        setSuccess("");

        setSelectedStaff((prev) => {
            if (prev.includes(id)) return prev.filter((item) => item !== id);
            return [...prev, id];
        });

        setStaffEntries((prev) => ({
            ...prev,
            [id]: prev[id] || makeStaffEntry(staff)
        }));
    };

    const toggleSelectAll = () => {
        setError("");
        setSuccess("");

        const visibleIds = visibleStaffList.map((staff) => String(staff.Staff_id));

        if (allSelected) {
            // Unselect only what is currently listed (everything, if no search text).
            setSelectedStaff((prev) => prev.filter((id) => !visibleIds.includes(String(id))));
            return;
        }

        setSelectedStaff((prev) => [
            ...prev,
            ...visibleIds.filter((id) => !prev.includes(id))
        ]);
        setStaffEntries((prev) => {
            const next = { ...prev };
            visibleStaffList.forEach((staff) => {
                const id = String(staff.Staff_id);
                next[id] = prev[id] || makeStaffEntry(staff);
            });
            return next;
        });
    };

    const removeSelectedStaff = (staffId) => {
        setSelectedStaff((prev) => prev.filter((id) => String(id) !== String(staffId)));
    };

    const calculateStaff = (staff) => {
        const absent = Number(staff.Absent_days || 0);
        const cl = deductions.CL.checked ? Number(deductions.CL.amount || 0) : 0;
        const el = deductions.EL.checked ? Number(deductions.EL.amount || 0) : 0;
        const lopDays = Math.max(0, absent - cl - el);

        const totalDaysInMonth = getDaysInMonth(salaryMonth) ||
            Number(staff.Present_days || 0) + Number(staff.Absent_days || 0) || 30;

        const salaryValue = Number(staff.Salary || 0);
        const perDaySalary = totalDaysInMonth > 0 ? salaryValue / totalDaysInMonth : 0;
        const lop = round2(perDaySalary * lopDays);

        const earningsTotal = EARNINGS_FIELDS.reduce((sum, f) => {
            const field = earnings[f.key];
            return sum + (field && field.checked ? Number(field.amount || 0) : 0);
        }, 0);

        const deductionsTotal = DEDUCTION_AMOUNT_KEYS.reduce((sum, key) => {
            const field = deductions[key];
            if (!field || !field.checked) return sum;
            return sum + getDeductionRupees(key, field.amount, salaryValue);
        }, 0);

        const calculatedSalary = round2(
            salaryValue - lop + earningsTotal - deductionsTotal
        );

        return {
            lopDays,
            lop,
            earningsTotal: round2(earningsTotal),
            deductionsTotal: round2(deductionsTotal),
            calculatedSalary,
            daysInMonth: totalDaysInMonth
        };
    };

    const handleCheckboxChange = (group, field) => (e) => {
        const checked = e.target.checked;
        const setter = group === "earnings" ? setEarnings : setDeductions;

        setter((prev) => ({
            ...prev,
            [field.key]: {
                checked,
                amount: checked ? (field.defaultAmount ?? "") : ""
            }
        }));
    };

    const handleAmountChange = (group, key) => (e) => {
        const value = e.target.value;
        const setter = group === "earnings" ? setEarnings : setDeductions;

        setter((prev) => ({
            ...prev,
            [key]: { ...prev[key], amount: value }
        }));
    };

    const buildStaffPayData = (staff) => {
        const calculated = calculateStaff(staff);

        return {
            Staff_id: staff.Staff_id,
            Staff_name: String(staff.Staff_name || "").trim(),
            Department: String(staff.Department || "").trim(),
            Salary_month: salaryMonth,
            Present_days: Number(staff.Present_days || 0),
            Absent_days: Number(staff.Absent_days || 0),
            Loss_of_pay_days: calculated.lopDays,
            Loss_of_pay: roundRupee(calculated.lop),
            Salary: roundRupee(staff.Salary),
            Total_Earnings_Amount: roundRupee(calculated.earningsTotal),
            Total_Deductions_Amount: roundRupee(calculated.deductionsTotal),
            Calculated_Salary: roundRupee(calculated.calculatedSalary),
            Payment_date: paymentDate,

            Overtime: earnings.Overtime.checked,
            Overtime_Amount: roundRupee(earnings.Overtime.amount),
            Bonus: earnings.Bonus.checked,
            Bonus_Amount: roundRupee(earnings.Bonus.amount),
            Conveyance_Allowance: earnings.Conveyance_Allowance.checked,
            Conveyance_Allowance_Amount: roundRupee(earnings.Conveyance_Allowance.amount),
            Medical_Allowance: earnings.Medical_Allowance.checked,
            Medical_Allowance_Amount: roundRupee(earnings.Medical_Allowance.amount),
            Special_Allowance: earnings.Special_Allowance.checked,
            Special_Allowance_Amount: roundRupee(earnings.Special_Allowance.amount),

            PF: deductions.PF.checked,
            PF_Amount: roundRupee(deductions.PF.amount),
            ESI: deductions.ESI.checked,
            ESI_Amount: roundRupee(deductions.ESI.amount),
            CL: deductions.CL.checked,
            CL_Amount: roundRupee(deductions.CL.amount),
            EL: deductions.EL.checked,
            EL_Amount: roundRupee(deductions.EL.amount),
            Tax: deductions.Tax.checked,
            Tax_Amount: roundRupee(deductions.Tax.amount),
            Late_Coming_Penalty: deductions.Late_Coming_Penalty.checked,
            Late_Coming_Penalty_Amount: roundRupee(deductions.Late_Coming_Penalty.amount)
        };
    };

    // Build the same payslip preview object used by the older single-staff workflow.
    // This is intentionally used only when exactly one staff member is selected.
    const buildSinglePayslipPreview = (staff, staffPayData, calculated) => {
        const salaryValue = Number(staffPayData.Salary || 0);

        // Same 50% / 25% / remainder split the PDF uses, kept to 2 decimals.
        const basicSplit = round2(salaryValue * 0.5);
        const hraSplit = round2(basicSplit * 0.5);
        const othersSplit = round2(salaryValue - basicSplit - hraSplit);

        return {
            companyAddress:
                "161, Alapakkam Main Rd, Janaki Nagar, Maduravoyal, Chennai, Tamil Nadu 600095",
            salaryMonth,
            payslipMonthLabel: formatSalaryMonthLabel(salaryMonth),

            staffId: staffPayData.Staff_id,
            staffName: staffPayData.Staff_name,
            department: staffPayData.Department || "-",
            designation: pick(
                staff,
                ["Designation", "designation", "Role", "Position"]
            ),
            dateOfJoining: pick(
                staff,
                [
                    "Date_of_Joining",
                    "Date_of_joining",
                    "Joining_date",
                    "Joining_Date",
                    "DOJ"
                ],
                ""
            ),
            bankName: pick(staff, ["Bank_Name", "BankName"]),
            accountNumber: pick(staff, ["Account_Number", "AccountNumber"]),
            panNumber: pick(staff, ["PAN_Number", "PanNumber", "Pan_Number"]),

            calendarDays: calculated.daysInMonth,
            paidDays: Math.max(0, calculated.daysInMonth - calculated.lopDays),
            lopDays: calculated.lopDays,

            earnings: [
                { label: "Basic", amount: basicSplit },
                { label: "HRA", amount: hraSplit },
                { label: "Others", amount: othersSplit },
                ...EARNINGS_FIELDS
                    .filter((f) => earnings[f.key].checked)
                    .map((f) => ({
                        label: f.label,
                        amount: roundRupee(earnings[f.key].amount)
                    }))
            ],

            deductions: [
                ...DEDUCTIONS_FIELDS
                    .filter(
                        (f) =>
                            DEDUCTION_AMOUNT_KEYS.includes(f.key) &&
                            deductions[f.key].checked
                    )
                    .map((f) => ({
                        label: f.label.replace(/\s*\(%\)/, ""),
                        amount: roundRupee(
                            getDeductionRupees(
                                f.key,
                                deductions[f.key].amount,
                                salaryValue
                            )
                        )
                    })),
                {
                    label: "LOP",
                    amount: roundRupee(staffPayData.Loss_of_pay)
                }
            ]
        };
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError("");
        setSuccess("");

        if (!salaryMonth || !paymentDate) {
            setValidated(true);
            setError("Please select salary month and payment date.");
            return;
        }

        if (selectedStaffRows.length === 0) {
            setValidated(true);
            setError("Please select at least one staff member.");
            return;
        }

        const invalidStaff = selectedStaffRows.find((staff) =>
            !String(staff.Staff_name || "").trim() ||
            Number(staff.Salary || 0) < 0 ||
            Number(staff.Present_days || 0) < 0 ||
            Number(staff.Absent_days || 0) < 0
        );

        if (invalidStaff) {
            setValidated(true);
            setError(`Please check the salary/attendance details for ${invalidStaff.Staff_name || invalidStaff.Staff_id}.`);
            return;
        }

        try {
            setLoading(true);

            const results = [];
            const failures = [];

            // Sequential requests intentionally use the existing create API.
            // Each successful request therefore uses the same backend flow:
            // database save -> PDF generation -> PDF path save -> email.
            for (const staff of selectedStaffRows) {
                try {
                    const payload = buildStaffPayData(staff);
                    const response = await insert(payload, "staff_pay_create");

                    const info = readCreateResponse(response);

                    results.push({
                        staff,
                        response,
                        // 0 present days => backend saves the row with
                        // "Not applicable" and skips the PDF and the mail.
                        notApplicable: info.notApplicable || hasNoPresentDays(staff),
                        pdfFailed: info.pdfFailed,
                        pdfError: info.pdfError,
                        mailSent: info.mailSent,
                        mailError: info.mailError
                    });
                } catch (err) {
                    const responseData = err.responseData || {};
                    const message =
                        responseData.detail ||
                        responseData.message ||
                        (Array.isArray(responseData.Staff_id) ? responseData.Staff_id[0] : responseData.Staff_id) ||
                        "Could not generate payslip.";

                    failures.push({
                        staff,
                        message
                    });
                }
            }

            const generated = results.filter((item) => !item.notApplicable);
            const skipped = results.filter((item) => item.notApplicable);

            // One line per employee: payslip generated / not applicable, mail sent / not sent
            const outcomeLines = [
                ...results.map(
                    (item) => `${item.staff.Staff_name || item.staff.Staff_id}: ${describeOutcome(item)}`
                ),
                ...failures.map(
                    (item) => `${item.staff.Staff_name || item.staff.Staff_id}: FAILED - ${item.message}`
                )
            ];

            if (results.length === selectedStaffRows.length) {
                const monthLabel = formatSalaryMonthLabel(salaryMonth);

                // SINGLE STAFF with payslip: preserve the older workflow and
                // open the full payslip preview.
                if (selectedStaffRows.length === 1 && generated.length === 1) {
                    const staff = selectedStaffRows[0];
                    const staffPayData = buildStaffPayData(staff);
                    const calculated = calculateStaff(staff);
                    const payslip = buildSinglePayslipPreview(
                        staff,
                        staffPayData,
                        calculated
                    );

                    if (generated[0].mailSent === false) {
                        alert(`Payslip generated, but the mail was NOT sent.${generated[0].mailError ? `\n${generated[0].mailError}` : ""}`);
                    }

                    if (props.onSuccess) {
                        await props.onSuccess(payslip);
                    }
                    return;
                }

                // Everything else (batch, or the only employee has 0 present days)
                alert(
                    `Payslip result for ${monthLabel}\n\n` +
                    `Generated: ${generated.length}   Not applicable: ${skipped.length}\n\n` +
                    outcomeLines.join("\n")
                );

                if (props.onSuccess) {
                    await props.onSuccess(null);
                }
                return;
            }

            if (results.length > 0) {
                const failedNames = failures.map((item) => item.staff.Staff_name || item.staff.Staff_id).join(", ");
                alert(
                    `Generated: ${generated.length}   Not applicable: ${skipped.length}   Failed: ${failures.length}\n\n` +
                    outcomeLines.join("\n") +
                    `\n\nPlease check the error and generate the failed payslips again.`
                );

                setSuccess(`${generated.length} payslip(s) generated, ${skipped.length} not applicable.`);
                setError(`Failed for: ${failedNames}`);

                // Refresh existing records so successfully generated staff
                // disappear from the selectable list for this month.
                try {
                    const refreshed = await getData("fetch_staff_pay_datail");
                    setExistingStaffPays(Array.isArray(refreshed) ? refreshed : []);
                } catch (refreshError) {
                    console.error("Unable to refresh staff pays after batch generation:", refreshError);
                }
                return;
            }

            const messages = failures.map((item) => `${item.staff.Staff_name || item.staff.Staff_id}: ${item.message}`);
            setError(messages.join(" | ") || "No payslip could be generated.");
        } finally {
            setLoading(false);
        }
    };

    // Bold the part of the text that matches what the user has typed.
    const highlightMatch = (text, query) => {
        const value = String(text ?? "");
        const q = String(query || "").trim();
        if (!q) return value;
        const idx = value.toLowerCase().indexOf(q.toLowerCase());
        if (idx === -1) return value;
        return (
            <>
                {value.slice(0, idx)}
                <mark className="staff-match">{value.slice(idx, idx + q.length)}</mark>
                {value.slice(idx + q.length)}
            </>
        );
    };

    const getUnit = (key) => {
        if (PERCENT_KEYS.includes(key)) return "%";
        if (key === "CL" || key === "EL") return "days";
        return "\u20B9";
    };

    const renderCheckGroup = (group, fields, state) =>
        fields.map((f) => {
            const checked = state[f.key].checked;
            const unit = getUnit(f.key);
            const isPrefix = unit === "\u20B9";

            return (
                <div
                    className={`pay-row ${group}-row ${checked ? "is-checked" : ""}`}
                    key={f.key}
                >
                    <label className="pay-row-label" htmlFor={`${group}_${f.key}`}>
                        <input
                            className="pay-checkbox"
                            type="checkbox"
                            name={f.key}
                            id={`${group}_${f.key}`}
                            checked={checked}
                            onChange={handleCheckboxChange(group, f)}
                        />
                        <span className="pay-row-text">{f.label}</span>
                    </label>

                    {checked && (
                        <div className={`pay-amount ${isPrefix ? "has-prefix" : "has-suffix"}`}>
                            {isPrefix && <span className="pay-unit">{unit}</span>}
                            <input
                                type="number"
                                className="pay-amount-input"
                                name={`${f.key}_Amount`}
                                min="0"
                                step="0.01"
                                placeholder={f.placeholder || "Enter amount"}
                                value={state[f.key].amount}
                                onChange={handleAmountChange(group, f.key)}
                                required
                            />
                            {!isPrefix && <span className="pay-unit">{unit}</span>}
                        </div>
                    )}
                </div>
            );
        });

    const singleStaff = selectedStaffRows.length === 1 ? selectedStaffRows[0] : null;
    const singleCalculation = singleStaff ? calculateStaff(singleStaff) : null;

    return (
        <div className="staff-pay-add-page">
            <div className="staff-pay-add-card">
                <div className="staff-pay-add-header">
                    <button
                        type="button"
                        className="back-button"
                        onClick={props.toggle}
                        title="Back to Staff Pay"
                        disabled={loading}
                    >
                        <i className="bx bx-left-arrow-alt"></i>
                    </button>
                    <h2>Staff Pay Form</h2>
                    <div className="header-spacer"></div>
                </div>

                {success && (
                    <div className="alert alert-success" role="alert">
                        <strong>Success!</strong> {success}
                    </div>
                )}
                {error && (
                    <div className="alert alert-danger" role="alert">
                        <strong>Error!</strong> {error}
                    </div>
                )}

                <form
                    onSubmit={handleSubmit}
                    noValidate
                    className={validated ? "was-validated" : ""}
                >
                    <div className="row g-3">
                        <div className="col-md-8">
                            <label className="form-label">Select Staff</label>
                            <div className="staff-multi-select">
                                <button
                                    type="button"
                                    className={`staff-multi-select-button ${staffDropdownOpen ? "open" : ""}`}
                                    onClick={() => setStaffDropdownOpen(true)}
                                    disabled={loading}
                                >
                                    <span>
                                        {selectedStaff.length === 0
                                            ? "-- Select Staff --"
                                            : selectedStaff.length === 1
                                                ? `${selectedStaffRows[0]?.Staff_id || selectedStaff[0]} - ${selectedStaffRows[0]?.Staff_name || "Staff selected"}`
                                                : `${selectedStaff.length} staff selected`}
                                    </span>
                                    <i className="bx bx-chevron-down"></i>
                                </button>

                                {staffDropdownOpen && ReactDOM.createPortal(
                                    <div
                                        className="staff-modal-backdrop"
                                        onMouseDown={(e) => {
                                            if (e.target === e.currentTarget) setStaffDropdownOpen(false);
                                        }}
                                    >
                                        <div className="staff-modal" role="dialog" aria-modal="true" aria-labelledby="staffModalTitle">
                                            <div className="staff-modal-header">
                                                <div>
                                                    <h5 id="staffModalTitle">Select Staff</h5>
                                                    <p>Search and select staff for {formatSalaryMonthLabel(salaryMonth)}</p>
                                                </div>
                                                <button
                                                    type="button"
                                                    className="staff-modal-close"
                                                    title="Close"
                                                    onClick={() => setStaffDropdownOpen(false)}
                                                >
                                                    <i className="bx bx-x"></i>
                                                </button>
                                            </div>

                                            <div className="staff-modal-filters">
                                                {STAFF_SEARCH_FIELDS.map((field, index) => (
                                                    <div className="staff-filter" key={field.key}>
                                                        <label htmlFor={`staffSearch_${field.key}`}>{field.label}</label>
                                                        <div className="staff-filter-input">
                                                            <i className={`bx ${field.icon}`}></i>
                                                            <input
                                                                ref={index === 0 ? searchInputRef : null}
                                                                id={`staffSearch_${field.key}`}
                                                                type="text"
                                                                placeholder={field.placeholder}
                                                                value={staffFilters[field.key]}
                                                                onChange={(e) =>
                                                                    setStaffFilters((prev) => ({ ...prev, [field.key]: e.target.value }))
                                                                }
                                                                onKeyDown={(e) => {
                                                                    // Enter must never submit the payslip form
                                                                    if (e.key === "Enter") {
                                                                        e.preventDefault();
                                                                        if (visibleStaffList.length === 1) toggleStaff(visibleStaffList[0]);
                                                                    }
                                                                }}
                                                                autoComplete="off"
                                                            />
                                                            {staffFilters[field.key] && (
                                                                <button
                                                                    type="button"
                                                                    title="Clear"
                                                                    onClick={() =>
                                                                        setStaffFilters((prev) => ({ ...prev, [field.key]: "" }))
                                                                    }
                                                                >
                                                                    <i className="bx bx-x"></i>
                                                                </button>
                                                            )}
                                                        </div>
                                                    </div>
                                                ))}
                                            </div>

                                            <div className="staff-modal-table-wrap">
                                                <table className="staff-modal-table">
                                                    <thead>
                                                        <tr>
                                                            <th className="col-check">
                                                                <input
                                                                    type="checkbox"
                                                                    title={isSearching ? "Select all results" : "Select all"}
                                                                    checked={allSelected}
                                                                    onChange={toggleSelectAll}
                                                                    disabled={visibleStaffList.length === 0}
                                                                />
                                                            </th>
                                                            <th>ID</th>
                                                            <th>Staff Name</th>
                                                            <th>Department</th>
                                                            <th>Designation</th>
                                                            <th>Email</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        {visibleStaffList.length > 0 ? visibleStaffList.map((staff) => {
                                                            const id = String(staff.Staff_id);
                                                            const isChecked = selectedStaff.includes(id);
                                                            const department = getStaffDepartment(staff);
                                                            const designation = getStaffDesignation(staff);
                                                            return (
                                                                <tr
                                                                    key={id}
                                                                    className={isChecked ? "is-selected" : ""}
                                                                    onClick={() => toggleStaff(staff)}
                                                                >
                                                                    <td className="col-check">
                                                                        <input type="checkbox" checked={isChecked} readOnly />
                                                                    </td>
                                                                    <td className="cell-id">#{highlightMatch(staff.Staff_id, staffFilters.id)}</td>
                                                                    <td className="cell-name">{highlightMatch(staff.Staff_name, staffFilters.name)}</td>
                                                                    <td>{department ? highlightMatch(department, staffFilters.department) : "-"}</td>
                                                                    <td>{designation ? highlightMatch(designation, staffFilters.designation) : "-"}</td>
                                                                    <td>{staff.Email || "-"}</td>
                                                                </tr>
                                                            );
                                                        }) : (
                                                            <tr className="staff-empty-row">
                                                                <td colSpan={6}>
                                                                    {availableStaffList.length === 0
                                                                        ? `No active staff with present attendance for ${formatSalaryMonthLabel(salaryMonth)}.`
                                                                        : "No staff match your search."}
                                                                </td>
                                                            </tr>
                                                        )}
                                                    </tbody>
                                                </table>
                                            </div>

                                            <div className="staff-modal-footer">
                                                <span className="staff-modal-count">
                                                    {isSearching
                                                        ? `${visibleStaffList.length} of ${availableStaffList.length} staff found`
                                                        : `${availableStaffList.length} staff available`}
                                                    {" \u00B7 "}
                                                    <strong>{selectedStaff.length}</strong> selected
                                                </span>
                                                <button
                                                    type="button"
                                                    className="staff-modal-ok"
                                                    onClick={() => setStaffDropdownOpen(false)}
                                                >
                                                    OK
                                                </button>
                                            </div>
                                        </div>
                                    </div>,
                                    document.body
                                )}
                            </div>
                            
                        </div>

                        <div className="col-md-4">
                            <label htmlFor="Salary_month" className="form-label">Select Salary Month</label>
                            <input
                                type="month"
                                name="Salary_month"
                                id="Salary_month"
                                className="form-control"
                                value={salaryMonth}
                                onChange={(e) => setSalaryMonth(e.target.value)}
                                required
                                disabled={loading}
                            />
                        </div>

                        {/* =====================================================
                            SINGLE STAFF: ORIGINAL FULL-PAGE FORM
                           ===================================================== */}
                        {selectedStaffRows.length === 1 && singleStaff && (
                            <>
                                <div className="col-md-6">
                                    <label htmlFor="Staff_id" className="form-label">Staff ID</label>
                                    <input
                                        type="text"
                                        name="Staff_id"
                                        id="Staff_id"
                                        className="form-control"
                                        value={singleStaff.Staff_id}
                                        readOnly
                                        required
                                    />
                                </div>

                                <div className="col-md-6">
                                    <label htmlFor="Staff_name" className="form-label">Name</label>
                                    <input
                                        type="text"
                                        name="Staff_name"
                                        id="Staff_name"
                                        className="form-control"
                                        value={singleStaff.Staff_name}
                                        readOnly
                                        required
                                    />
                                </div>

                                <div className="col-md-6">
                                    <label htmlFor="Department" className="form-label">Department</label>
                                    <input
                                        type="text"
                                        name="Department"
                                        id="Department"
                                        className="form-control"
                                        value={singleStaff.Department || ""}
                                        readOnly
                                    />
                                </div>

                                <div className="col-md-6">
                                    <label htmlFor="Staff_email" className="form-label">Email</label>
                                    <input
                                        type="text"
                                        name="Staff_email"
                                        id="Staff_email"
                                        className="form-control"
                                        value={singleStaff.Email || ""}
                                        readOnly
                                    />
                                </div>

                                <div className="col-md-6">
                                    <label htmlFor="Present_days" className="form-label">Present Days (Attendance)</label>
                                    <input
                                        type="number"
                                        name="Present_days"
                                        id="Present_days"
                                        className="form-control"
                                        min="0"
                                        max="31"
                                        step="1"
                                        value={singleStaff.Present_days}
                                        readOnly
                                        required
                                        disabled={loading}
                                    />
                                    <div className="invalid-feedback">Please enter present days.</div>
                                </div>

                                <div className="col-md-6">
                                    <label htmlFor="Absent_days" className="form-label">Absent Days (Attendance)</label>
                                    <input
                                        type="number"
                                        name="Absent_days"
                                        id="Absent_days"
                                        className="form-control"
                                        min="0"
                                        max="31"
                                        step="any"
                                        value={singleStaff.Absent_days}
                                        readOnly
                                        required
                                        disabled={loading}
                                    />
                                    <div className="invalid-feedback">Please enter absent days.</div>
                                </div>

                                <div className="col-md-6">
                                    <label htmlFor="Loss_of_pay" className="form-label text-danger">Loss of Pay</label>
                                    <input
                                        type="number"
                                        name="Loss_of_pay"
                                        id="Loss_of_pay"
                                        className="form-control"
                                        value={round2(singleCalculation.lop).toFixed(2)}
                                        readOnly
                                    />
                                </div>

                                <div className="col-md-6">
                                    <label htmlFor="Salary" className="form-label">Salary</label>
                                    <input
                                        type="number"
                                        name="Salary"
                                        id="Salary"
                                        className="form-control"
                                        min="0"
                                        step="0.01"
                                        value={singleStaff.Salary}
                                        readOnly
                                        disabled
                                        aria-readonly="true"
                                        required
                                        title="Salary comes from Staff Master and cannot be edited"
                                    />
                                </div>

                                <div className="col-md-6">
                                    <label htmlFor="Payment_date" className="form-label">Payment Date</label>
                                    <input
                                        type="date"
                                        name="Payment_date"
                                        id="Payment_date"
                                        className="form-control"
                                        value={paymentDate}
                                        onChange={(e) => setPaymentDate(e.target.value)}
                                        required
                                        disabled={loading}
                                    />
                                </div>
                            </>
                        )}

                        {/* =====================================================
                            MULTIPLE STAFF: CURRENT TABLE WORKFLOW
                            Salary and attendance are read-only; they come from Staff Master / Attendance.
                           ===================================================== */}
                        {selectedStaffRows.length > 1 && (
                            <>
                                <div className="col-12">
                                    <div className="selected-staff-header">
                                        <div>
                                            <h6 className="selected-staff-title">Selected Staff Details</h6>
                                            <span>{selectedStaffRows.length} employee(s) selected</span>
                                        </div>
                                        <span className="month-badge">{formatSalaryMonthLabel(salaryMonth)}</span>
                                    </div>

                                    <div className="selected-staff-table-wrap">
                                        <table className="selected-staff-table">
                                            <thead>
                                                <tr>
                                                    <th>Staff ID</th>
                                                    <th>Name</th>
                                                    <th>Department</th>
                                                    <th>Email</th>
                                                    <th>Salary</th>
                                                    <th>Present (Attendance)</th>
                                                    <th>Absent (Attendance)</th>
                                                    <th>LOP</th>
                                                    <th>Calculated Salary</th>
                                                    <th></th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {selectedStaffRows.map((staff) => {
                                                    const calc = calculateStaff(staff);
                                                    return (
                                                        <tr key={staff.Staff_id}>
                                                            <td><strong>{staff.Staff_id}</strong></td>
                                                            <td>{staff.Staff_name}</td>
                                                            <td>{staff.Department || "-"}</td>
                                                            <td>{staff.Email || "-"}</td>
                                                            <td>
                                                                <input
                                                                    type="number"
                                                                    min="0"
                                                                    step="0.01"
                                                                    value={staff.Salary}
                                                                    readOnly
                                                                    disabled
                                                                    aria-readonly="true"
                                                                    title="Salary comes from Staff Master and cannot be edited"
                                                                />
                                                            </td>
                                                            <td>
                                                                <input
                                                                    type="number"
                                                                    min="0"
                                                                    max="31"
                                                                    step="1"
                                                                    value={staff.Present_days}
                                                                    readOnly
                                                                    disabled={loading}
                                                                />
                                                            </td>
                                                            <td>
                                                                <input
                                                                    type="number"
                                                                    min="0"
                                                                    max="31"
                                                                    step="any"
                                                                    value={staff.Absent_days}
                                                                    readOnly
                                                                    disabled={loading}
                                                                />
                                                            </td>
                                                            <td className="text-danger fw-semibold">₹ {formatMoney(calc.lop)}</td>
                                                            <td className="calculated-cell">₹ {formatMoney(calc.calculatedSalary)}</td>
                                                            <td>
                                                                <button
                                                                    type="button"
                                                                    className="remove-staff-btn"
                                                                    title="Remove staff"
                                                                    onClick={() => removeSelectedStaff(staff.Staff_id)}
                                                                    disabled={loading}
                                                                >
                                                                    <i className="bx bx-x"></i>
                                                                </button>
                                                            </td>
                                                        </tr>
                                                    );
                                                })}
                                            </tbody>
                                        </table>
                                    </div>
                                </div>

                                <div className="col-md-6">
                                    <label htmlFor="Payment_date" className="form-label">Payment Date</label>
                                    <input
                                        type="date"
                                        name="Payment_date"
                                        id="Payment_date"
                                        className="form-control"
                                        value={paymentDate}
                                        onChange={(e) => setPaymentDate(e.target.value)}
                                        required
                                        disabled={loading}
                                    />
                                </div>

                               {/* <div className="col-md-6">
                                    <div className="batch-info-box">
                                        <strong>{selectedStaffRows.filter((st) => !hasNoPresentDays(st)).length}</strong>
                                        <span>payslips will be generated</span>
                                        {selectedStaffRows.some(hasNoPresentDays) && (
                                            <span className="text-danger d-block">
                                                {selectedStaffRows.filter(hasNoPresentDays).length} employee(s) with 0 present days: {NOT_APPLICABLE}
                                            </span>
                                        )}
                                    </div>
                                </div>*/}
                            </>
                        )}

                        {/* Earnings + Deductions live inside ONE full-width block so they
                            always start on the same line, side by side, below the form fields */}
                        <div className="col-12 mt-4">
                            <div className="earnings-deductions-grid">
                                <div className="earnings-deductions-column">
                                    <h6 className="section-title earnings-title">Earnings</h6>
                                    <div className="check-group earnings-check-group">
                                        {renderCheckGroup("earnings", EARNINGS_FIELDS, earnings)}
                                    </div>
                                </div>

                                <div className="earnings-deductions-column">
                                    <h6 className="section-title deductions-title">Deductions</h6>
                                    <div className="check-group deductions-check-group">
                                        {renderCheckGroup("deductions", DEDUCTIONS_FIELDS, deductions)}
                                    </div>
                                </div>
                            </div>
                        </div>

                        {selectedStaffRows.length === 1 && singleCalculation && (
                            <div className="col-12 mt-4">
                                <label htmlFor="Calculated_Salary" className="form-label">Calculated Salary</label>
                                <input
                                    type="text"
                                    name="Calculated_Salary"
                                    id="Calculated_Salary"
                                    className="form-control calculated-salary-input"
                                    value={round2(singleCalculation.calculatedSalary).toFixed(2)}
                                    readOnly
                                />
                            </div>
                        )}
                    </div>

                    <div className="staff-pay-add-actions">
                        <button
                            type="button"
                            className="btn btn-outline-secondary"
                            onClick={props.toggle}
                            disabled={loading}
                        >
                            Cancel
                        </button>
                        <button
                            type="submit"
                            className="btn btn-success generate-batch-btn"
                            disabled={loading || selectedStaffRows.length === 0}
                        >
                            {loading
                                ? "Generating Payslips..."
                                : `Generate Payslip${selectedStaffRows.length > 1 ? "s" : ""}`}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default Addstaffpay;