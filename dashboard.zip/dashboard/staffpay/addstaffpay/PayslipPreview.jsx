import React, { useRef, useState } from "react";
import html2canvas from "html2canvas";
import { Document, Packer, Paragraph, ImageRun } from "docx";
import { saveAs } from "file-saver";

import { IGT_LOGO } from "./payslipLogo";
import "./PayslipPreview.css";

/*
 * PayslipPreview
 * ---------------
 * Full-screen (NOT a popup/modal) payslip preview, styled to match the
 * exact reference payslip PDF, with the new IGT / Infogro Technology logo.
 *
 * npm packages this file needs (install once in your project):
 *   npm install html2canvas docx file-saver
 *
 * HOW TO OPEN IT
 * ---------------
 * Render it as a full page the same way Addstaffpay.js is already
 * rendered as a full page in Staffpay.jsx (NOT as a Bootstrap modal):
 *
 *   {showPayslip && (
 *     <PayslipPreview payslip={generatedPayslip} onBack={handleBackFromPayslip} />
 *   )}
 *
 * PROPS
 * ---------------
 * payslip = {
 *   companyName: "IGT",
 *   companyAddress: "161, Alapakkam Main Rd, Janaki Nagar, Maduravoyal, Chennai, Tamil Nadu 600095",
 *   payslipMonthLabel: "September 2026",     // pre-formatted "Month YYYY"
 *
 *   staffId: "101",
 *   staffName: "Senthilan",
 *   department: "IT",
 *   designation: "CEO",
 *
 *   dateOfJoining: "01-04-2026",             // already formatted DD-MM-YYYY
 *   calendarDays: 30,
 *   paidDays: 25,
 *   lopDays: 5,
 *
 *   earnings: [                              // any number of rows, fully data-driven
 *     { label: "Basic", amount: 50000 },
 *     { label: "HRA", amount: 25000 },
 *     { label: "DA", amount: 6000 },
 *     { label: "Others", amount: 19000 }
 *   ],
 *
 *   deductions: [
 *     { label: "PF", amount: 6000 },
 *     { label: "Tax", amount: 208 },
 *     { label: "LOP", amount: 16667 }
 *   ]
 * }
 *
 * onBack = () => void   -- called when the Back button is clicked
 */

// Amounts keep their paise (always 2 decimals) so the preview matches the
// database and the saved PDF exactly.
const round2 = (num) => Math.round((Number(num || 0) + Number.EPSILON) * 100) / 100;

const formatPlainINR = (num) =>
    round2(num).toLocaleString("en-IN", {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    });

const formatINR = (num) => "Rs. " + formatPlainINR(num);

// ---- Number -> Indian-English words (for "Amount in Words") -------------
const ONES = [
    "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine",
    "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen",
    "Seventeen", "Eighteen", "Nineteen"
];
const TENS = [
    "", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"
];

function twoDigitsToWords(n) {
    if (n < 20) return ONES[n];
    const tens = Math.floor(n / 10);
    const ones = n % 10;
    return TENS[tens] + (ones ? "-" + ONES[ones] : "");
}

function threeDigitsToWords(n) {
    const hundred = Math.floor(n / 100);
    const rest = n % 100;
    let str = "";
    if (hundred) str += ONES[hundred] + " Hundred" + (rest ? " " : "");
    if (rest) str += twoDigitsToWords(rest);
    return str;
}

// Indian numbering: crore / lakh / thousand / hundred
function numberToIndianWords(num) {
    let n = Math.round(Math.abs(Number(num) || 0));
    if (n === 0) return "Zero";

    const crore = Math.floor(n / 10000000);
    n %= 10000000;
    const lakh = Math.floor(n / 100000);
    n %= 100000;
    const thousand = Math.floor(n / 1000);
    n %= 1000;
    const hundred = n;

    const parts = [];
    if (crore) parts.push(threeDigitsToWords(crore) + " Crore");
    if (lakh) parts.push(threeDigitsToWords(lakh) + " Lakh");
    if (thousand) parts.push(threeDigitsToWords(thousand) + " Thousand");
    if (hundred) parts.push(threeDigitsToWords(hundred));

    return parts.join(" ");
}

function amountInWords(num) {
    const total = Math.round(Math.abs(round2(num)) * 100); // paise
    const rupees = Math.floor(total / 100);
    const paise = total % 100;

    if (rupees === 0 && paise === 0) return "RUPEES ZERO ONLY";

    let text = `Rupees ${rupees ? numberToIndianWords(rupees) : "Zero"}`;
    if (paise) text += ` and ${twoDigitsToWords(paise)} Paise`;
    return `${text} Only`.toUpperCase();
}

const PayslipPreview = ({ payslip, onBack }) => {
    const payslipRef = useRef(null);
    const [busy, setBusy] = useState(""); // "" | "image" | "word" | "whatsapp" | "gmail"

    const data = payslip || {};
    const earnings = data.earnings || [];
    const deductions = data.deductions || [];

    const grossEarnings = round2(earnings.reduce((sum, e) => sum + Number(e.amount || 0), 0));
    const totalDeductions = round2(deductions.reduce((sum, d) => sum + Number(d.amount || 0), 0));
    const netAmount = round2(grossEarnings - totalDeductions);

    // Renders the payslip card to a PNG canvas. Kept as one shared helper
    // so Print / Download Image / Download Word / WhatsApp all produce the
    // exact same flattened snapshot -- this is what makes the exported
    // file "a complete image" that cannot be edited afterwards.
    const captureCanvas = async () => {
        const node = payslipRef.current;
        return html2canvas(node, {
            scale: 3, // high-res export
            useCORS: true,
            backgroundColor: "#ffffff"
        });
    };

    const handlePrint = () => {
        window.print();
    };

    const handleDownloadImage = async () => {
        try {
            setBusy("image");
            const canvas = await captureCanvas();
            canvas.toBlob((blob) => {
                if (!blob) return;
                saveAs(blob, `Payslip_${data.staffId || ""}_${(data.payslipMonthLabel || "").replace(/\s+/g, "_")}.png`);
            }, "image/png");
        } finally {
            setBusy("");
        }
    };

    // Builds a .docx file that contains NOTHING but the flattened payslip
    // image. Because the payslip itself is a picture (not live text/tables),
    // opening it in Word gives the user a document they cannot edit the
    // contents of -- exactly the "convert to Word but not editable / must
    // be a complete image" requirement.
    const handleDownloadWord = async () => {
        try {
            setBusy("word");
            const canvas = await captureCanvas();
            const pngDataUrl = canvas.toDataURL("image/png");
            const base64 = pngDataUrl.split(",")[1];
            const binary = atob(base64);
            const bytes = new Uint8Array(binary.length);
            for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);

            // Scale the image to fit a standard A4 page width in the docx (in px @96dpi -> EMU handled by docx lib via width/height)
            const pageWidthPx = 690;
            const scaleRatio = pageWidthPx / canvas.width;
            const pageHeightPx = Math.round(canvas.height * scaleRatio);

            const doc = new Document({
                sections: [
                    {
                        properties: {
                            page: {
                                margin: { top: 720, bottom: 720, left: 720, right: 720 }
                            }
                        },
                        children: [
                            new Paragraph({
                                children: [
                                    new ImageRun({
                                        type: "png",
                                        data: bytes,
                                        transformation: {
                                            width: pageWidthPx,
                                            height: pageHeightPx
                                        }
                                    })
                                ]
                            })
                        ]
                    }
                ]
            });

            const blob = await Packer.toBlob(doc);
            saveAs(blob, `Payslip_${data.staffId || ""}_${(data.payslipMonthLabel || "").replace(/\s+/g, "_")}.docx`);
        } finally {
            setBusy("");
        }
    };

    // WhatsApp cannot receive a file through a plain URL/link -- browsers
    // don't allow that for privacy/security reasons. The reliable path is
    // the Web Share API (works on most mobile browsers and shows WhatsApp
    // as a share target directly). If that isn't available (most desktop
    // browsers), we fall back to downloading the image and opening
    // WhatsApp Web so the user can attach the file themselves.
    const handleShareWhatsApp = async () => {
        try {
            setBusy("whatsapp");
            const canvas = await captureCanvas();
            const blob = await new Promise((resolve) => canvas.toBlob(resolve, "image/png"));
            const fileName = `Payslip_${data.staffId || ""}.png`;
            const file = new File([blob], fileName, { type: "image/png" });

            if (navigator.canShare && navigator.canShare({ files: [file] })) {
                await navigator.share({
                    files: [file],
                    title: "Payslip",
                    text: `Payslip for ${data.staffName || ""} - ${data.payslipMonthLabel || ""}`
                });
            } else {
                saveAs(blob, fileName);
                window.open("https://web.whatsapp.com/", "_blank", "noopener,noreferrer");
            }
        } finally {
            setBusy("");
        }
    };

    // Gmail's compose window (mail.google.com/mail/?view=cm) cannot be
    // pre-loaded with an attachment from JavaScript either -- that's a
    // browser security restriction, not something any web app can bypass.
    // So we download the image for the user and open Gmail compose with
    // the subject/body pre-filled, ready for them to attach the file that
    // just downloaded.
    const handleShareGmail = async () => {
        try {
            setBusy("gmail");
            const canvas = await captureCanvas();
            const blob = await new Promise((resolve) => canvas.toBlob(resolve, "image/png"));
            saveAs(blob, `Payslip_${data.staffId || ""}.png`);

            const subject = encodeURIComponent(`Payslip - ${data.payslipMonthLabel || ""}`);
            const body = encodeURIComponent(
                `Hi ${data.staffName || ""},\n\nPlease find attached your payslip for ${data.payslipMonthLabel || ""}.\n(The payslip image has been downloaded to your device -- please attach it here.)\n\nRegards,\n${data.companyName || ""}`
            );
            window.open(
                `https://mail.google.com/mail/?view=cm&fs=1&su=${subject}&body=${body}`,
                "_blank",
                "noopener,noreferrer"
            );
        } finally {
            setBusy("");
        }
    };

    return (
        <div className="payslip-fullscreen">
            {/* Top action bar: Back (top-left) + Print (top-right, same row) */}
            <div className="payslip-topbar no-print">
                <button type="button" className="payslip-back-btn" onClick={onBack} title="Back">
                    <i className="bx bx-left-arrow-alt"></i>
                    <span>Back</span>
                </button>

                <button type="button" className="payslip-print-btn" onClick={handlePrint} title="Print">
                    <i className="bx bx-printer"></i>
                    <span>Print</span>
                </button>
            </div>

            <div className="payslip-scroll-area">
                {/* ===== The actual payslip card -- this exact node is what gets
                    captured to an image for Print / Download / Share ===== */}
                <div className="payslip-card" ref={payslipRef} id="payslip-print-area">
                    <div className="payslip-header-row">
                        <img src={IGT_LOGO} alt="Company Logo" className="payslip-logo" />
                        <div className="payslip-title-block">
                            <div className="payslip-title">PAYSLIP</div>
                            <div className="payslip-month">{data.payslipMonthLabel}</div>
                        </div>
                    </div>

                    <div className="payslip-address">{data.companyAddress}</div>

                    <div className="payslip-box payslip-details-three-column">
                        <div className="payslip-details-section">
                            <div className="payslip-box-title">EMPLOYEE DETAILS</div>
                            <div className="payslip-kv-row">
                                <span className="k">Employee ID:</span>
                                <span className="v">{data.staffId}</span>
                            </div>
                            <div className="payslip-kv-row">
                                <span className="k">Employee Name:</span>
                                <span className="v">{data.staffName}</span>
                            </div>
                            <div className="payslip-kv-row">
                                <span className="k">Date of Joining:</span>
                                <span className="v">{data.dateOfJoining}</span>
                            </div>
                            <div className="payslip-kv-row">
                                <span className="k">Department:</span>
                                <span className="v">{data.department}</span>
                            </div>
                            <div className="payslip-kv-row">
                                <span className="k">Designation:</span>
                                <span className="v">{data.designation}</span>
                            </div>
                        </div>

                        <div className="payslip-details-section">
                            <div className="payslip-box-title">BANK DETAILS</div>
                            <div className="payslip-kv-row">
                                <span className="k">Bank Name:</span>
                                <span className="v">{data.bankName}</span>
                            </div>
                            <div className="payslip-kv-row">
                                <span className="k">Account Number:</span>
                                <span className="v">{data.accountNumber}</span>
                            </div>
                            <div className="payslip-kv-row">
                                <span className="k">PAN Number:</span>
                                <span className="v">{data.panNumber}</span>
                            </div>
                        </div>

                        <div className="payslip-details-section attendance">
                            <div className="payslip-box-title">ATTENDANCE DETAILS</div>
                            <div className="payslip-kv-row">
                                <span className="k">Calendar Days:</span>
                                <span className="v">{data.calendarDays}</span>
                            </div>
                            <div className="payslip-kv-row">
                                <span className="k">Paid Days:</span>
                                <span className="v">{data.paidDays}</span>
                            </div>
                            <div className="payslip-kv-row">
                                <span className="k">LOP:</span>
                                <span className="v">{data.lopDays}</span>
                            </div>
                        </div>
                    </div>

                    <div className="payslip-grid-2">
                        <div className="payslip-box">
                            <div className="payslip-table-head">
                                <span>EARNINGS</span>
                                <span>AMOUNTS</span>
                            </div>
                            {earnings.map((row, idx) => (
                                <div className="payslip-table-row" key={idx}>
                                    <span>{row.label}</span>
                                    <span>{formatPlainINR(row.amount)}</span>
                                </div>
                            ))}
                            <div className="payslip-table-total">
                                <span>GROSS EARNINGS</span>
                                <span>{formatINR(grossEarnings)}</span>
                            </div>
                        </div>

                        <div className="payslip-box">
                            <div className="payslip-table-head">
                                <span>DEDUCTIONS</span>
                                <span>AMOUNTS</span>
                            </div>
                            {deductions.map((row, idx) => (
                                <div className="payslip-table-row" key={idx}>
                                    <span>{row.label}</span>
                                    <span>{formatPlainINR(row.amount)}</span>
                                </div>
                            ))}
                            <div className="payslip-table-total">
                                <span>TOTAL DEDUCTIONS</span>
                                <span>{formatINR(totalDeductions)}</span>
                            </div>
                        </div>
                    </div>

                    <div className="payslip-grid-2">
                        <div className="payslip-box payslip-words-box">
                            <div className="payslip-box-title small">AMOUNT IN WORDS</div>
                            <div className="payslip-words-text">{amountInWords(netAmount)}</div>
                        </div>

                        <div className="payslip-box payslip-net-box">
                            <div className="payslip-box-title small">NET AMOUNT</div>
                            <div className="payslip-net-amount">{formatINR(netAmount)}</div>
                        </div>
                    </div>

                    <div className="payslip-footer">
                        <div className="payslip-footer-main">This is an auto-generated payslip.</div>
                        <div className="payslip-footer-sub">This document does not require a signature.</div>
                    </div>
                </div>

                {/* Share row */}
                <div className="payslip-share-row no-print">
                    <button
                        type="button"
                        className="payslip-share-btn whatsapp"
                        onClick={handleShareWhatsApp}
                        disabled={busy !== ""}
                    >
                        <i className="bx bxl-whatsapp"></i>
                        {busy === "whatsapp" ? "Preparing..." : "Share via WhatsApp"}
                    </button>

                    <button
                        type="button"
                        className="payslip-share-btn gmail"
                        onClick={handleShareGmail}
                        disabled={busy !== ""}
                    >
                        <i className="bx bxl-gmail"></i>
                        {busy === "gmail" ? "Preparing..." : "Share via Gmail"}
                    </button>

                    <button
                        type="button"
                        className="payslip-share-btn image"
                        onClick={handleDownloadImage}
                        disabled={busy !== ""}
                    >
                        <i className="bx bx-image"></i>
                        {busy === "image" ? "Preparing..." : "Download as Image"}
                    </button>

                    <button
                        type="button"
                        className="payslip-share-btn word"
                        onClick={handleDownloadWord}
                        disabled={busy !== ""}
                    >
                        <i className="bx bxs-file-pdf"></i>
                        {busy === "word" ? "Preparing..." : "Download as PDF"}
                    </button>
                </div>
            </div>
        </div>
    );
};

export default PayslipPreview;