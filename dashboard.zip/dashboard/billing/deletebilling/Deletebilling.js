import React, { useContext, useState } from "react";
import AuthContext from "../../../services/AuthContext";
import "./deletebilling.css";

/*
 * Delete uses insert({ billing_id }, "delete_billing_detail")
 * from AuthContext (same flow as Deleteregistration.js). insert() is the
 * AuthContext helper that throws the Django error (error.responseData),
 * so the message can be shown.
 * There is no axios call in this file.
 *
 * NOTE: the import path of AuthContext is for
 *   src/<folder>/billing/deletebilling/Deletebilling.js
 * If your file is in a different folder, change "../../../services/AuthContext".
 *
 * Props
 *   billing   : the billing record (normalized) to delete
 *   onClose   : called when the user cancels
 *   onSuccess : called after the billing is deleted
 */

function Deletebilling({ billing, onClose, onSuccess }) {
  const { insert } = useContext(AuthContext);

  const [deleting, setDeleting] = useState(false);
  const [error, setError] = useState("");

  const id = billing.id;

  const handleDelete = async () => {
    if (!id) {
      setError("Billing ID not found.");
      return;
    }

    setDeleting(true);
    setError("");

    try {
      const response = await insert(
        { billing_id: id },
        "delete_billing_detail"
      );

      /* a delete with no body (204) is also a success */
      if (response && response.success === false) {
        const failure = new Error("Delete failed");
        failure.responseData = response;
        throw failure;
      }

      if (onSuccess) {
        onSuccess();
      }
    } catch (err) {
      console.error("Delete billing error:", err, err.responseData);

      const data = err.responseData;

      setError(
        (data && (data.message || data.error || data.detail)) ||
          err.message ||
          "Unable to delete billing."
      );
    } finally {
      setDeleting(false);
    }
  };

  return (
    <div className="delete-billing-overlay">
      <div className="delete-billing-modal">
        <div className="delete-icon">🗑</div>

        <h2>Delete Billing?</h2>

        <p>
          Are you sure you want to delete the billing of
          <strong> {billing.name} </strong>
          {billing.course ? `(${billing.course})` : ""}?
        </p>

        <p className="delete-warning">
          All payments and installments of this bill will be removed.
          This action cannot be undone.
        </p>

        {error && (
          <p className="delete-warning" style={{ color: "#ff3e1d" }}>
            {error}
          </p>
        )}

        <div className="delete-actions">
          <button
            type="button"
            className="delete-cancel"
            onClick={onClose}
            disabled={deleting}
          >
            Cancel
          </button>

          <button
            type="button"
            className="delete-confirm"
            onClick={handleDelete}
            disabled={deleting}
          >
            {deleting ? "Deleting..." : "Delete"}
          </button>
        </div>
      </div>
    </div>
  );
}

export default Deletebilling;
