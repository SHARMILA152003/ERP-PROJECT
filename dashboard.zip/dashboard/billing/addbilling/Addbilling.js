import React, { useContext, useEffect, useRef, useState } from "react";
import AuthContext from "../../../services/AuthContext";
import "./addbilling.css";
import Invoice, { invoiceDate } from "../invoice/Invoice";

/*
 * ALL server calls come from AuthContext (same flow as Addregistration.js).
 * There is no axios / fetch call inside this file.
 *
 *   getData(...)              -> lists  : "fetch_registration_datail" [student picker],
 *                                         "fetch_billing_detail"      [hides already billed]
 *   insert(payload, ...)      -> create : "billing_create"
 *                                update : "update_billing_detail"
 *
 * AuthContext is shared by every module, so it is used as it is. It can
 * only send JSON, so the form is converted by formDataToPayload() below
 * (same helper as Addregistration.js). insert() is used for update too,
 * because it is the helper that throws the Django error
 * (err.responseData) so the message can be shown in the popup.
 *
 * NOTE: the import path of AuthContext above is for
 *   src/<folder>/billing/addbilling/Addbilling.js
 * If your file is in a different folder, change "../../../services/AuthContext".
 *
 * Add mode  : <Addbilling onBack={...} onSaved={...} />
 * Edit mode : <Addbilling billing={record} onBack={...} onSaved={...} />
 *             (record = one item of the list, already passed through normalizeBilling)
 */

/* File -> base64 text (without the "data:...;base64," start) */
const readFileAsBase64 = (file) =>
  new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.onload = () => resolve(String(reader.result).split(",")[1] || "");
    reader.onerror = () => reject(reader.error);

    reader.readAsDataURL(file);
  });

/*
 * FormData -> plain object for AuthContext.insert (JSON).
 * Text boxes stay text; a chosen file (none in billing today) becomes
 *   { name, type, data: "<base64>" }
 */
const formDataToPayload = async (formData) => {
  const payload = {};

  for (const [key, value] of formData.entries()) {
    if (typeof value === "object" && value !== null && "size" in value) {
      payload[key] = {
        name: value.name,
        type: value.type,
        data: await readFileAsBase64(value)
      };
    } else {
      payload[key] = value;
    }
  }

  return payload;
};

/* =====================================================
   SHARED HELPERS  (Billing.jsx imports these too)
===================================================== */

export const num = (v) => {
  const n = parseFloat(v);
  return Number.isFinite(n) ? n : 0;
};

export const money = (v) => `₹${num(v).toLocaleString("en-IN")}`;

const isFilled = (value) =>
  value !== null && value !== undefined && String(value).trim() !== "";

/* today as YYYY-MM-DD */
export const getToday = () => {
  const date = new Date();
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
};

/* "2026-10-21T10:00:00Z" -> "2026-10-21" (value for <input type="date">) */
export const toDateInput = (value) => {
  if (!value) {
    return "";
  }
  const text = String(value);
  return /^\d{4}-\d{2}-\d{2}/.test(text) ? text.slice(0, 10) : "";
};

/* 2026-10-21 -> 21-10-2026 */
export const formatDisplayDate = (value) => {
  const text = toDateInput(value);
  if (!text) {
    return value ? String(value) : "-";
  }
  const [y, m, d] = text.split("-");
  return `${d}-${m}-${y}`;
};

/* date + N months (day is kept inside the month, 31 Jan + 1 = 28/29 Feb) */
export const addMonths = (dateText, months) => {
  const [y, m, d] = dateText.split("-").map(Number);
  const target = new Date(y, m - 1 + months, 1);
  const lastDay = new Date(
    target.getFullYear(),
    target.getMonth() + 1,
    0
  ).getDate();
  target.setDate(Math.min(d, lastDay));
  const mm = String(target.getMonth() + 1).padStart(2, "0");
  const dd = String(target.getDate()).padStart(2, "0");
  return `${target.getFullYear()}-${mm}-${dd}`;
};

/* date + N days */
const addDays = (dateText, days) => {
  const [y, m, d] = dateText.split("-").map(Number);
  const target = new Date(y, m - 1, d + days);
  const mm = String(target.getMonth() + 1).padStart(2, "0");
  const dd = String(target.getDate()).padStart(2, "0");
  return `${target.getFullYear()}-${mm}-${dd}`;
};

const toCents = (value) => Math.round(num(value) * 100);

/*
 * FINAL FEE = course fees - (course fees x discount % / 100)
 * Returns "" when the course fees is empty / not a number.
 * (same rule as Registration.jsx)
 */
export const calcFinalFee = (fees, discount) => {
  const amount = parseFloat(fees);
  if (!Number.isFinite(amount)) {
    return "";
  }
  let percent = parseFloat(discount);
  if (!Number.isFinite(percent) || percent < 0) {
    percent = 0;
  }
  if (percent > 100) {
    percent = 100;
  }
  return (amount - (amount * percent) / 100).toFixed(2);
};

/* the discount offer is over when the billing date is after the validity end date */
const isValidityCrossed = (billingDate, validity) =>
  Boolean(validity) && (billingDate || getToday()) > validity;

export const PLAN_LABEL = {
  full: "Full",
  advance: "Advance",
  installment: "Installment"
};

export const PAYMENT_METHODS = ["UPI", "Cash", "Card", "Bank Transfer"];

/* value sent to the backend for each plan - change here if your backend differs */
const PLAN_VALUE = {
  full: "full",
  advance: "advance",
  installment: "installment"
};

/* first filled value of the given keys */
const pick = (obj, keys, fallback = "") => {
  for (const key of keys) {
    const value = obj ? obj[key] : undefined;
    if (value !== undefined && value !== null && value !== "") {
      return value;
    }
  }
  return fallback;
};

const normalizePlan = (value) => {
  const text = String(value || "").toLowerCase();
  if (text.includes("install")) {
    return "installment";
  }
  if (text.includes("adv")) {
    return "advance";
  }
  return "full";
};

const parseList = (value) => {
  if (Array.isArray(value)) {
    return value;
  }
  if (typeof value === "string" && value.trim().startsWith("[")) {
    try {
      const parsed = JSON.parse(value);
      return Array.isArray(parsed) ? parsed : [];
    } catch (err) {
      return [];
    }
  }
  return [];
};

/* =====================================================
   REGISTRATION HELPERS (same IGT0001 numbering as Registration.jsx)
===================================================== */

const sortRegistrations = (list) =>
  [...list].sort((a, b) => {
    const idA = Number(a.id);
    const idB = Number(b.id);
    if (!Number.isNaN(idA) && !Number.isNaN(idB)) {
      return idA - idB;
    }
    const timeA = new Date(a.created_at).getTime();
    const timeB = new Date(b.created_at).getTime();
    if (!Number.isNaN(timeA) && !Number.isNaN(timeB)) {
      return timeA - timeB;
    }
    return 0;
  });

/* one person (enquiry no) = one registration id: IGT0001, IGT0002 ... */
export const buildPersonRegIds = (list) => {
  const map = {};
  let count = 0;
  sortRegistrations(list).forEach((record) => {
    const key = String(record.enquiry_no || "");
    if (key && !map[key]) {
      count += 1;
      map[key] = `IGT${String(count).padStart(4, "0")}`;
    }
  });
  return map;
};

export const getDisplayRegistrationId = (item, personRegIds = {}) => {
  if (!item) {
    return "-";
  }
  if (item.enquiry_no && personRegIds[String(item.enquiry_no)]) {
    return personRegIds[String(item.enquiry_no)];
  }
  const rawId = item.registration_id || item.id || "";
  const numericPart = String(rawId).match(/(\d+)$/);
  if (numericPart) {
    return `IGT${String(numericPart[1]).padStart(3, "0")}`;
  }
  return rawId || "-";
};

/* the key a billing record uses to point to its registration */
const REGISTRATION_KEYS = [
  "registration",
  "registration_id",
  "register_id",
  "registerid",
  "reg_id"
];

const billingRegistrationKey = (billing) => {
  const key = pick(billing, REGISTRATION_KEYS);
  if (key && typeof key === "object") {
    return String(key.id ?? key.registration_id ?? "");
  }
  return String(key);
};

export const findRegistration = (billing, registrations = []) => {
  const key = billingRegistrationKey(billing);
  if (!key) {
    return null;
  }
  return (
    registrations.find(
      (r) => String(r.id) === key || String(r.registration_id) === key
    ) || null
  );
};

/* =====================================================
   NORMALIZE ONE BILLING RECORD
   Backend field names are not fixed, so each value tries a few
   common names. Adjust here if your serializer uses different ones.
===================================================== */

export const normalizeBilling = (b, registrations = []) => {
  const reg = findRegistration(b, registrations) || {};

  const courseFee = num(
    pick(b, ["course_fees", "course_fee", "base_fee", "total_fees"], reg.course_fees)
  );
  const discount = num(
    pick(b, ["discount_percentage", "discount", "discount_percent"], 0)
  );
  const calculated = num(calcFinalFee(courseFee, discount));
  const finalFee = num(
    pick(b, ["final_fee", "final_net_payable"], calculated)
  );
  const paid = num(pick(b, ["paid_amount", "paid", "total_paid"], 0));
  const balance = num(
    pick(b, ["balance", "balance_amount", "total_remaining"], finalFee - paid)
  );

  const installments = parseList(b.installments).map((i, index) => ({
    id: i.id ?? index,
    no: i.installment_no ?? index + 1,
    amount: num(i.amount),
    date: toDateInput(i.due_date ?? i.date),
    paid:
      i.is_paid ??
      i.paid ??
      String(i.status || "").toLowerCase() === "paid",
    /* money received so far against this installment (partial payments) */
    paidAmount: num(
      i.paid_amount ??
        ((i.is_paid ?? i.paid) ? i.amount : 0)
    )
  }));

  return {
    raw: b,
    id: b.id ?? b.billing_id,
    regPk: reg.id ?? "",
    enquiryNo: reg.enquiry_no ?? b.enquiry_no ?? "",
    registration: reg,
    name: pick(b, ["student_name", "name"], reg.student_name),
    phone: pick(b, ["mobile_number", "phone"], reg.mobile_number),
    email: pick(b, ["email"], reg.email),
    course: pick(b, ["course", "course_name"], reg.course),
    billingDate: toDateInput(
      pick(b, ["billing_date", "bill_date", "created_at"], "")
    ),
    courseFee,
    discount,
    discountValidity: toDateInput(
      pick(b, ["discount_validity"], reg.discount_validity)
    ),
    finalFee,
    /* extra amount shown in the invoice notes (each bill keeps its own) */
    registrationFee: num(pick(b, ["registration_fee"], 200)),
    paid,
    balance,
    isPaid: balance <= 0,
    plan: normalizePlan(pick(b, ["payment_plan", "plan"], "")),
    advance: num(pick(b, ["advance_amount", "advance"], 0)),
    balanceDueDate: toDateInput(pick(b, ["balance_due_date"], "")),
    installments,
    remarks: pick(b, ["remarks"], ""),
    createdAt: pick(b, ["created_at"], "")
  };
};

/*
 * Backend error text. When the backend sends the failed fields
 * (for example { message: "...", errors: { course_fees: ["..."] } })
 * the field names are shown too, so it is clear what the server rejected.
 */
const getErrorMessage = (data, fallback) => {
  if (!data) {
    return fallback;
  }
  if (typeof data === "string") {
    return data.length < 300 ? data : fallback;
  }
  const parts = [];
  const base = data.message || data.error || data.detail;
  if (base) {
    parts.push(String(base));
  }
  const fieldErrors =
    data.errors && typeof data.errors === "object"
      ? data.errors
      : !base
      ? data
      : null;
  if (fieldErrors) {
    Object.entries(fieldErrors).forEach(([key, value]) => {
      const text = Array.isArray(value) ? value[0] : value;
      if (text && typeof text !== "object") {
        parts.push(`${key.replace(/_/g, " ")}: ${text}`);
      }
    });
  }
  return parts.length ? parts.join(" – ") : fallback;
};

const startsWithText = (value, query) =>
  String(value || "").toLowerCase().startsWith(String(query).trim().toLowerCase());

/* installment rows used by the form (amount is kept as text while typing) */
const rowsFromBilling = (billing) =>
  ((billing && billing.installments) || []).map((i) => ({
    id: i.id,
    amount: String(i.amount ?? ""),
    due_date: i.date || "",
    paid: Boolean(i.paid)
  }));

/* =====================================================
   COMPONENT
===================================================== */

function Addbilling({ onBack, onSaved, billing, registration }) {
  /* ALL API calls come from AuthContext */
  const { getData, insert } = useContext(AuthContext);

  /* a list from AuthContext -> getData(endpoint) (nothing back = failed) */
  const loadList = async (endpoint) => {
    const list = await getData(endpoint);

    if (!Array.isArray(list)) {
      throw new Error("Unable to load data from server.");
    }

    return list;
  };

  const getRegistrations = () => loadList("fetch_registration_datail");
  const getBillings = () => loadList("fetch_billing_detail");

  const isEdit = Boolean(billing);
  const initial = billing || {};
  const billingId = isEdit ? billing.id : null;

  /* =====================================================
     VALIDATION POPUP (replaces the browser alert box)
  ===================================================== */

  const [popup, setPopup] = useState(null);

  const showAlert = (text, title = "Validation Error", type = "error") => {
    setPopup({ text, title, type });
  };

  const closePopup = () => setPopup(null);

  /* Esc key closes the popup */
  useEffect(() => {
    if (!popup) {
      return undefined;
    }

    const onKey = (e) => {
      if (e.key === "Escape") {
        setPopup(null);
      }
    };

    window.addEventListener("keydown", onKey);

    return () => window.removeEventListener("keydown", onKey);
  }, [popup]);

  /* =====================================================
     REGISTRATION POPUP
  ===================================================== */

  const [showRegistrationPopup, setShowRegistrationPopup] = useState(false);
  const [registrations, setRegistrations] = useState([]);
  const [billings, setBillings] = useState([]);

  const [searchName, setSearchName] = useState("");
  const [searchPhone, setSearchPhone] = useState("");
  const [searchCourse, setSearchCourse] = useState("");
  const [searchDate, setSearchDate] = useState("");

  const [activeStep, setActiveStep] = useState(1);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  /* invoice popup: filled after a NEW billing is saved */
  const [invoiceData, setInvoiceData] = useState(null);

  const [selectedRegistration, setSelectedRegistration] = useState(
    isEdit ? initial.registration || {} : null
  );

  /* IGT0001 style id of the selected registration (edit mode: filled after the list loads) */
  const [registrationNo, setRegistrationNo] = useState(
    isEdit && initial.registration && initial.registration.id !== undefined
      ? getDisplayRegistrationId(initial.registration)
      : ""
  );

  /* =====================================================
     FORM
  ===================================================== */

  /*
   * installment bill (edit): the 1st installment goes to the top boxes (amount + date),
   * the other installments stay in the table below
   */
  const instEdit =
    isEdit &&
    initial.plan === "installment" &&
    Boolean(initial.installments && initial.installments.length);

  const firstRowMeta = useRef(
    instEdit
      ? {
          id: initial.installments[0].id,
          paid: Boolean(initial.installments[0].paid)
        }
      : {}
  );

  /* true when the first installment amount was typed by hand (no more 60% auto fill) */
  const advanceTouched = useRef(false);

  /*
   * advance plan: the 40% pool (in paise) = total of every due date after
   * the first one. The first due date is the 60% (balance - pool).
   * + / - buttons share this pool between the rows after the first one,
   * and a changed advance changes only the first due date.
   */
  const poolCents = useRef(null);

  const [form, setForm] = useState({
    registration: initial.regPk ?? "",
    billing_date: initial.billingDate || getToday(),
    student_name: initial.name ?? "",
    mobile_number: initial.phone ?? "",
    email: initial.email ?? "",
    course: initial.course ?? "",
    course_fees: isEdit ? String(initial.courseFee ?? "") : "",
    discount_percentage: isEdit ? String(initial.discount ?? "") : "",
    discount_validity: initial.discountValidity || "",
    /* registration fee printed in the invoice notes (default 200) */
    registration_fee: isEdit ? String(initial.registrationFee ?? 200) : "200",
    payment_plan: initial.plan || "full",
    advance_amount: instEdit
      ? String(initial.installments[0].amount ?? "")
      : initial.advance
      ? String(initial.advance)
      : "",
    balance_due_date: instEdit
      ? initial.installments[0].date || ""
      : initial.balanceDueDate || "",
    installment_count:
      initial.installments && initial.installments.length
        ? String(initial.installments.length)
        : "2",
    first_due_date: initial.installments && initial.installments.length
      ? initial.installments[0].date
      : "",
    initial_payment: "",
    payment_method: "UPI",
    payment_date: getToday(),
    remarks: initial.remarks ?? ""
  });

  const [installments, setInstallments] = useState(
    instEdit ? rowsFromBilling(initial).slice(1) : rowsFromBilling(initial)
  );

  /*
   * REGISTRATION FEE DEFAULT (new bill only).
   * The box starts with the registration fee of the LATEST saved bill, so a
   * value changed once (for example 200 -> 300) becomes the default for the
   * next bills too. With no bill yet it starts at 200. A value the user has
   * already typed is never replaced.
   */
  const registrationFeeTouched = useRef(false);

  useEffect(() => {
    if (isEdit) {
      return undefined;
    }

    let active = true;

    (async () => {
      try {
        const list = await getBillings();

        const latest = list
          .filter((b) => b && b.registration_fee !== undefined && b.registration_fee !== null && b.registration_fee !== "")
          .sort(
            (a, b) =>
              Number(b.billing_id ?? b.id ?? 0) - Number(a.billing_id ?? a.id ?? 0)
          )[0];

        if (active && latest && !registrationFeeTouched.current) {
          setForm((previous) => ({
            ...previous,
            registration_fee: String(num(latest.registration_fee))
          }));
        }
      } catch (err) {
        console.error("Could not read the last registration fee:", err);
      }
    })();

    return () => {
      active = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /* the display id of an edited bill needs the registration list */
  useEffect(() => {
    if (!isEdit) {
      return;
    }

    (async () => {
      try {
        const list = await getRegistrations();
        setRegistrations(list);

        if (initial.registration && initial.registration.id !== undefined) {
          setRegistrationNo(
            getDisplayRegistrationId(
              initial.registration,
              buildPersonRegIds(list)
            )
          );
        }
      } catch (err) {
        console.error("Error fetching registrations:", err);
      }
    })();

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /*
   * Opened from the registration page (right after Save Registration):
   * the student + fee details are filled from that registration and the
   * form goes straight to the Payment Plan step.
   */
  useEffect(() => {
    if (isEdit || !registration) {
      return;
    }

    (async () => {
      let list = [];

      try {
        list = await getRegistrations();
        setRegistrations(list);
      } catch (err) {
        console.error("Error fetching registrations:", err);
      }

      const key = String(registration.id ?? registration.registration_id ?? "");

      const item =
        list.find((r) => String(r.id ?? r.registration_id) === key) ||
        registration;

      handleSelectRegistration(item, list);
      setActiveStep(3);
    })();

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /* =====================================================
     OPEN REGISTRATION POPUP
     (registrations that do not have a bill yet)
  ===================================================== */

  const openRegistrationPopup = async () => {
    setError("");
    setMessage("");
    setSearchName("");
    setSearchPhone("");
    setSearchCourse("");
    setSearchDate("");
    setShowRegistrationPopup(true);

    try {
      const [registrationList, billingList] = await Promise.all([
        getRegistrations(),
        getBillings()
      ]);

      setRegistrations(registrationList);
      setBillings(billingList);
    } catch (err) {
      console.error("Error fetching registrations:", err);
      setRegistrations([]);
      setBillings([]);
      setError("Unable to load registrations from server.");
      showAlert("Unable to load registrations from server.", "Server Error");
    }
  };

  /* =====================================================
     SELECT A REGISTRATION -> fills student + fee details
  ===================================================== */

  const handleSelectRegistration = (item, list = registrations) => {
    advanceTouched.current = false;
    setSelectedRegistration(item);

    setRegistrationNo(
      getDisplayRegistrationId(item, buildPersonRegIds(list))
    );

    setForm((previous) => ({
      ...previous,
      registration: item.id ?? item.registration_id ?? "",
      student_name: item.student_name ?? "",
      mobile_number: item.mobile_number ?? "",
      email: item.email ?? "",
      course: item.course ?? "",
      course_fees: item.course_fees ?? "",
      discount_percentage: item.discount_percentage ?? "",
      discount_validity: toDateInput(item.discount_validity),
      /* a new student = a new plan */
      advance_amount: previous.payment_plan === "advance" ? "5000" : "",
      /* the registration date comes into the date box */
      balance_due_date: toDateInput(item.registration_date),
      initial_payment: ""
    }));

    setInstallments([]);
    setShowRegistrationPopup(false);
  };

  /* =====================================================
     FIELD HANDLERS
  ===================================================== */

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((previous) => ({ ...previous, [name]: value }));
  };

  /* only digits and one dot (money boxes) */
  const handleMoneyChange = (e) => {
    const { name, value } = e.target;

    /* once the user types a registration fee, the remembered default must not replace it */
    if (name === "registration_fee") {
      registrationFeeTouched.current = true;
    }
    const cleaned = value.replace(/[^\d.]/g, "").replace(/(\..*)\./g, "$1");
    setForm((previous) => ({ ...previous, [name]: cleaned }));
  };

  const handleDiscountChange = (e) => {
    const cleaned = e.target.value
      .replace(/[^\d.]/g, "")
      .replace(/(\..*)\./g, "$1");

    if (cleaned !== "" && parseFloat(cleaned) > 100) {
      showAlert("Discount cannot be more than 100%.");
      return;
    }

    setForm((previous) => ({ ...previous, discount_percentage: cleaned }));
  };

  /* first installment = 60% of the final fee */
  const firstInstallmentShare = () =>
    (Math.round(finalFeeCents * 0.6) / 100).toFixed(2);

  const handlePlanChange = (plan) => {
    if (plan === form.payment_plan) {
      return;
    }

    setInstallments([]);
    advanceTouched.current = false;

    setForm((previous) => ({
      ...previous,
      payment_plan: plan,
      /* advance starts at 5000, first installment starts at 60% (both can be edited) */
      advance_amount:
        plan === "advance"
          ? "5000"
          : plan === "installment"
          ? firstInstallmentShare()
          : "",
      balance_due_date:
        plan === "full" ? previous.balance_due_date : previous.balance_due_date || regDate
    }));
  };

  /* =====================================================
     FEES (final fee, discount offer)
  ===================================================== */

  const validityCrossed = isValidityCrossed(
    form.billing_date,
    form.discount_validity
  );

  const offeredDiscount = parseFloat(form.discount_percentage);
  const endedDiscount =
    Number.isFinite(offeredDiscount) && offeredDiscount > 0
      ? String(offeredDiscount)
      : "";

  /* when the offer is over the discount is not applied */
  const appliedDiscount = validityCrossed ? 0 : form.discount_percentage;

  const finalFee = calcFinalFee(form.course_fees, appliedDiscount);
  const finalFeeCents = toCents(finalFee);

  /* money already collected (edit mode) */
  const alreadyPaid = isEdit ? num(initial.paid) : 0;

  /* advance amount (advance plan) / first installment amount (installment plan) */
  const advanceCents =
    form.payment_plan === "full" ? 0 : toCents(form.advance_amount);

  /* registration date of the selected student (billing date when it is not available) */
  const regDate =
    toDateInput(selectedRegistration && selectedRegistration.registration_date) ||
    form.billing_date;

  /* what the installments have to add up to */
  const installmentTargetCents =
    form.payment_plan !== "full" ? finalFeeCents - advanceCents : 0;

  const installmentSumCents = installments.reduce(
    (sum, row) => sum + toCents(row.amount),
    0
  );

  /* =====================================================
     INSTALLMENT SCHEDULE
  ===================================================== */

  /*
   * the 40% of the final fee (kept when the advance changes).
   * When the advance is more than the 60% there is nothing left for the
   * first due date, so the balance is split 60% / 40% instead.
   */
  const defaultPool = (balanceCents) => {
    const forty = finalFeeCents - Math.round(finalFeeCents * 0.6);

    return forty > 0 && forty < balanceCents
      ? forty
      : balanceCents - Math.round(balanceCents * 0.6);
  };

  const generateSchedule = () => {
    /*
     * advance plan     : 2 due dates by default
     * installment plan : 1 due date (the 2nd installment) below the first installment
     * (more rows with the + button)
     */
    const count = form.payment_plan === "installment" ? 1 : 2;

    if (finalFeeCents <= 0) {
      showAlert(
        "Enter the course fees in Fee Details first.",
        "Required Field",
        "warning"
      );
      return;
    }

    const remaining = installmentTargetCents;

    if (remaining <= 0) {
      showAlert("The advance amount is already the full fee.");
      return;
    }

    /* paid rows are kept, the rest of the amount is split in the new rows */
    const paidRows = installments.filter((row) => row.paid);
    const paidCents = paidRows.reduce((sum, row) => sum + toCents(row.amount), 0);
    const newCount = count - paidRows.length;
    const toSplit = remaining - paidCents;

    if (newCount < 1 || toSplit <= 0) {
      showAlert(
        "Installments already paid cover this plan. Increase the number of installments.",
        "Cannot Generate"
      );
      return;
    }

    /*
     * installment plan : first row (2nd installment) = one month after the registration date
     * advance plan     : first due date = 7 days after the registration date
     * every next due date = one month after the one before
     */
    const firstDueDate =
      form.payment_plan === "advance" ? addDays(regDate, 7) : addMonths(regDate, 1);

    const base = Math.floor(toSplit / newCount);
    const rows = [...paidRows];

    /* advance plan: balance after the advance = 60% (1st due date) + 40% (2nd) */
    const sixtyForty =
      form.payment_plan === "advance" && paidRows.length === 0 && newCount === 2;

    /*
     * advance plan: 60% / 40% of the FINAL FEE (same as the installment plan),
     * the advance is taken out of the 60% only -> 2nd due date = 40% of the fee
     */
    const fortyCents = defaultPool(toSplit);
    const firstCents = toSplit - fortyCents;

    poolCents.current = sixtyForty ? fortyCents : null;

    for (let i = 0; i < newCount; i += 1) {
      const cents = sixtyForty
        ? i === 0
          ? firstCents
          : fortyCents
        : i === newCount - 1
        ? toSplit - base * (newCount - 1)
        : base;

      rows.push({
        id: undefined,
        amount: (cents / 100).toFixed(2),
        due_date: addMonths(firstDueDate, paidRows.length + i),
        paid: false
      });
    }

    setInstallments(rows);
  };

  const updateRow = (index, key, value) => {
    /*
     * an amount typed in a due date row -> the other open rows are adjusted so the
     * total stays equal to the balance (final fee - advance):
     *   rows after the edited one share what is left equally,
     *   the last row edited -> the closest open row before it takes what is left
     */
    if (key === "amount") {
      const rows = installments.map((row, i) =>
        i === index ? { ...row, amount: value } : row
      );

      const fixedCents = rows.reduce(
        (sum, row, i) => (row.paid || i === index ? sum + toCents(row.amount) : sum),
        0
      );

      let targets = rows
        .map((row, i) => i)
        .filter((i) => i > index && !rows[i].paid);

      if (targets.length === 0) {
        const before = rows.map((row, i) => i).filter((i) => i < index && !rows[i].paid);
        targets = before.length ? [before[before.length - 1]] : [];
      }

      let result = rows;

      if (targets.length > 0) {
        /* money that stays on the rows that are not adjusted */
        const keptCents = rows.reduce(
          (sum, row, i) =>
            row.paid || i === index || targets.includes(i) ? sum : sum + toCents(row.amount),
          0
        );
        const left = Math.max(installmentTargetCents - fixedCents - keptCents, 0);
        const base = Math.floor(left / targets.length);

        result = rows.map((row, i) => {
          const at = targets.indexOf(i);
          if (at === -1) {
            return row;
          }
          const cents = at === targets.length - 1 ? left - base * (targets.length - 1) : base;
          return { ...row, amount: (cents / 100).toFixed(2) };
        });
      }

      /* advance plan: the 40% pool = the rows after the first one */
      if (form.payment_plan === "advance") {
        poolCents.current = result.reduce(
          (sum, row, i) => (i === 0 ? sum : sum + toCents(row.amount)),
          0
        );
      }

      setInstallments(result);
      return;
    }

    setInstallments((previous) =>
      previous.map((row, i) => (i === index ? { ...row, [key]: value } : row))
    );
  };

  /* the amount (final fee - advance - paid rows) is split equally between the unpaid rows */
  const splitRows = (rows) => {
    const paidCents = rows
      .filter((row) => row.paid)
      .reduce((sum, row) => sum + toCents(row.amount), 0);
    const openCount = rows.filter((row) => !row.paid).length;
    const toSplit = installmentTargetCents - paidCents;

    if (openCount < 1 || toSplit <= 0) {
      return rows;
    }

    const base = Math.floor(toSplit / openCount);
    let seen = 0;

    return rows.map((row) => {
      if (row.paid) {
        return row;
      }
      seen += 1;
      const cents = seen === openCount ? toSplit - base * (openCount - 1) : base;
      return { ...row, amount: (cents / 100).toFixed(2) };
    });
  };

  /* true when the advance plan 60% / 40% rules can be used (new bill, nothing paid) */
  const advanceRules = (rows) =>
    form.payment_plan === "advance" && !rows.some((row) => row.paid);

  /* the pool (the 40%) is split equally between the rows after the first one */
  const spreadPool = (rows, pool) => {
    const others = rows.length - 1;
    const base = Math.floor(pool / others);

    return rows.map((row, index) => {
      if (index === 0) {
        return row;
      }
      const cents = index === others ? pool - base * (others - 1) : base;
      return { ...row, amount: (cents / 100).toFixed(2) };
    });
  };

  /*
   * advance plan, + / - buttons:
   *   1 row   -> it is the whole balance
   *   2+ rows -> the first due date stays the 60% (balance - pool), the
   *              pool (the 40%) is shared between the other rows
   * (a single row that gets a new row starts again as 60% / 40%)
   */
  const layoutAdvance = (rows) => {
    if (rows.length === 0) {
      return rows;
    }

    if (rows.length === 1) {
      poolCents.current = null;
      return [{ ...rows[0], amount: (installmentTargetCents / 100).toFixed(2) }];
    }

    let pool = poolCents.current;

    if (pool === null || pool <= 0 || pool >= installmentTargetCents) {
      pool = defaultPool(installmentTargetCents);
      poolCents.current = pool;
    }

    const spread = spreadPool(rows, pool);

    return spread.map((row, index) =>
      index === 0
        ? { ...row, amount: ((installmentTargetCents - pool) / 100).toFixed(2) }
        : row
    );
  };

  /*
   * advance plan, advance changed by hand: ONLY the first due date
   * (the 60%) changes, the other due dates (the 40%) are not touched.
   * When the advance is so big that the first due date would be 0 or less,
   * the balance is split equally instead.
   */
  const adjustFirstRow = (rows) => {
    if (!advanceRules(rows)) {
      return splitRows(rows);
    }

    if (rows.length < 2) {
      return layoutAdvance(rows);
    }

    const pool =
      poolCents.current !== null
        ? poolCents.current
        : rows.reduce((sum, row, i) => (i === 0 ? sum : sum + toCents(row.amount)), 0);

    const firstCents = installmentTargetCents - pool;

    if (firstCents <= 0) {
      return splitRows(rows);
    }

    const othersSum = rows.reduce(
      (sum, row, i) => (i === 0 ? sum : sum + toCents(row.amount)),
      0
    );

    /* the other rows were changed by the equal split above -> give the pool back */
    const base = othersSum === pool ? rows : spreadPool(rows, pool);

    return base.map((row, index) =>
      index === 0 ? { ...row, amount: (firstCents / 100).toFixed(2) } : row
    );
  };

  /* a row is removed -> the amount is split again between the rows that are left */
  const removeRow = (index) => {
    const left = installments.filter((_, i) => i !== index);
    const rows = advanceRules(left) ? layoutAdvance(left) : splitRows(left);
    setInstallments(rows);
    setForm((previous) => ({ ...previous, installment_count: String(rows.length) }));
  };

  /* new row = one month after the last due date, amount split again between all rows */
  const addRow = () => {
    const last = installments.length
      ? installments[installments.length - 1].due_date
      : "";

    const withNew = [
      ...installments,
      {
        id: undefined,
        amount: "",
        due_date: last ? addMonths(last, 1) : addMonths(regDate, 1),
        paid: false
      }
    ];

    /* a single row starts again as 60% / 40% when a row is added */
    if (advanceRules(withNew) && installments.length === 1) {
      poolCents.current = null;
    }

    const rows = advanceRules(withNew) ? layoutAdvance(withNew) : splitRows(withNew);

    setInstallments(rows);
    setForm((previous) => ({ ...previous, installment_count: String(rows.length) }));
  };

  /* the 2 default due dates are created automatically (no Generate button) */
  useEffect(() => {
    if (form.payment_plan === "full" || installments.length > 0) {
      return;
    }

    /* an edited installment bill with only one installment has no rows below */
    if (isEdit && form.payment_plan === "installment") {
      return;
    }

    if (finalFeeCents <= 0 || installmentTargetCents <= 0) {
      return;
    }

    generateSchedule();

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [form.payment_plan, installments.length, finalFeeCents, regDate]);

  /*
   * the final fee changed (discount / course fees edited): the plan is made again
   * from the new final fee (advance 5000, first installment 60%, fresh due date rows)
   */
  const lastFinalFeeCents = useRef(finalFeeCents);

  useEffect(() => {
    if (lastFinalFeeCents.current === finalFeeCents) {
      return;
    }

    lastFinalFeeCents.current = finalFeeCents;

    if (isEdit || form.payment_plan === "full") {
      return;
    }

    advanceTouched.current = false;
    setInstallments([]);
    setForm((previous) => ({
      ...previous,
      advance_amount:
        previous.payment_plan === "installment" ? firstInstallmentShare() : "5000"
    }));

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [finalFeeCents]);

  /* first installment = 60% of the final fee (until the amount is typed by hand) */
  useEffect(() => {
    if (
      isEdit ||
      form.payment_plan !== "installment" ||
      advanceTouched.current ||
      finalFeeCents <= 0
    ) {
      return;
    }

    setForm((previous) => ({ ...previous, advance_amount: firstInstallmentShare() }));

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [form.payment_plan, finalFeeCents, form.registration]);

  /* advance / first installment amount typed -> the balance is split again between the rows (new bills) */
  useEffect(() => {
    if (isEdit || form.payment_plan === "full") {
      return;
    }

    setInstallments((previous) =>
      form.payment_plan === "advance"
        ? adjustFirstRow(previous)
        : splitRows(previous)
    );

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [advanceCents]);

  /* =====================================================
     STEP COMPLETE (green tick on the step bar)
  ===================================================== */

  const step1Complete = Boolean(form.registration) && isFilled(form.billing_date);

  const step2Complete = finalFeeCents > 0;

  const planReady = () => {
    if (form.payment_plan !== "full") {
      return (
        advanceCents > 0 &&
        Boolean(form.balance_due_date) &&
        installments.length > 0 &&
        installmentSumCents === installmentTargetCents
      );
    }
    return true;
  };

  const step3Complete = step2Complete && planReady();

  const step4Complete = isEdit || isFilled(form.initial_payment);

  /*
   * PAYMENT SLIDE (new bills): "Payment Now" comes from the plan
   *   full        -> the full fee
   *   advance     -> the advance amount
   *   installment -> the first installment amount (60% of the final fee)
   */
  useEffect(() => {
    if (activeStep !== 4 || isEdit) {
      return;
    }

    let amount = "";

    if (form.payment_plan === "full") {
      amount = finalFee;
    } else {
      amount = form.advance_amount;
    }

    if (amount !== "") {
      setForm((previous) => ({ ...previous, initial_payment: String(amount) }));
    }

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeStep]);

  const stepList = [
    { id: 1, label: "Student Details", complete: step1Complete },
    { id: 2, label: "Fee Details", complete: step2Complete },
    { id: 3, label: "Payment Plan", complete: step3Complete },
    { id: 4, label: "Payment", complete: step4Complete }
  ];

  const tickIcon = (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="3"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <polyline points="20 6 9 17 4 12" />
    </svg>
  );

  const popupIcons = {
    error: "bx-error-circle",
    warning: "bx-error",
    success: "bx-check-circle"
  };

  /* =====================================================
     VALIDATION (only Next / Save validate - tabs are free)
  ===================================================== */

  const validateStep = (step) => {
    if (step >= 1) {
      if (!form.registration) {
        showAlert("Please select a registration.", "Required Field", "warning");
        setActiveStep(1);
        return false;
      }

      if (!isFilled(form.billing_date)) {
        showAlert("Please select the billing date.", "Required Field", "warning");
        setActiveStep(1);
        return false;
      }

      if (form.billing_date > getToday()) {
        showAlert("Billing date cannot be a future date.");
        setActiveStep(1);
        return false;
      }
    }

    if (step >= 2) {
      if (!(num(form.course_fees) > 0)) {
        showAlert("Please enter the course fees.", "Required Field", "warning");
        setActiveStep(2);
        return false;
      }

      if (finalFeeCents <= 0) {
        showAlert("Final fee must be more than 0.");
        setActiveStep(2);
        return false;
      }

      if (
        isFilled(form.registration_fee) &&
        !/^\d+(\.\d{1,2})?$/.test(String(form.registration_fee))
      ) {
        showAlert("Registration fee accepts numbers only (maximum 2 decimal places).");
        setActiveStep(2);
        return false;
      }
    }

    if (step >= 3) {
      if (form.payment_plan !== "full") {
        if (!(advanceCents > 0) || advanceCents >= finalFeeCents) {
          showAlert(
            `${
              form.payment_plan === "installment"
                ? "First installment amount"
                : "Advance amount"
            } must be more than 0 and less than the final fee.`,
            "Payment Plan"
          );
          setActiveStep(3);
          return false;
        }

        if (!form.balance_due_date) {
          showAlert(
            "Please select the date the balance is due.",
            "Required Field",
            "warning"
          );
          setActiveStep(3);
          return false;
        }

        if (form.balance_due_date < regDate) {
          showAlert("Date cannot be before the registration date.");
          setActiveStep(3);
          return false;
        }
      }

      if (form.payment_plan !== "full" && installments.length < 1) {
        showAlert(
          "Generate the due date schedule for the balance amount.",
          "Payment Plan",
          "warning"
        );
        setActiveStep(3);
        return false;
      }

      /* advance + installment : the schedule rows are checked the same way */
      if (form.payment_plan !== "full") {
        if (installments.length < 1) {
          showAlert(
            "Generate the installment schedule (at least 2 installments).",
            "Payment Plan",
            "warning"
          );
          setActiveStep(3);
          return false;
        }

        for (let i = 0; i < installments.length; i += 1) {
          const row = installments[i];

          if (!(num(row.amount) > 0)) {
            showAlert(`Enter the amount of installment ${i + 1}.`);
            setActiveStep(3);
            return false;
          }

          if (!row.due_date) {
            showAlert(`Select the due date of installment ${i + 1}.`);
            setActiveStep(3);
            return false;
          }
        }

        if (installmentSumCents !== installmentTargetCents) {
          showAlert(
            `Installments add up to ${money(
              installmentSumCents / 100
            )} but they must add up to ${money(
              installmentTargetCents / 100
            )} (final fee minus advance).`,
            "Payment Plan"
          );
          setActiveStep(3);
          return false;
        }
      }
    }

    if (step >= 4 && !isEdit) {
      const paying = toCents(form.initial_payment);

      if (paying < 0 || paying > finalFeeCents) {
        showAlert("Payment now cannot be more than the final fee.");
        return false;
      }

      if (paying > 0 && !isFilled(form.payment_method)) {
        showAlert("Please select the payment method.", "Required Field", "warning");
        return false;
      }

      if (paying > 0 && !isFilled(form.payment_date)) {
        showAlert("Please select the payment date.", "Required Field", "warning");
        return false;
      }
    }

    return true;
  };

  /*
   * TOP TABS CAN ALWAYS BE CLICKED.
   * Validation is performed only by handleNextStep() and the save button.
   */
  const goToStep = (step) => {
    if (step === activeStep) {
      return;
    }

    setActiveStep(step);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleNextStep = () => {
    if (!validateStep(activeStep)) {
      return;
    }

    setActiveStep((previous) => Math.min(previous + 1, 4));
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handlePreviousStep = () => {
    setActiveStep((previous) => Math.max(previous - 1, 1));
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  /* =====================================================
     SUBMIT
  ===================================================== */

  /* empty values of these keys are never sent */
  const SKIP_IF_EMPTY = [
    "discount_validity",
    "advance_amount",
    "balance_due_date",
    "initial_payment",
    "payment_date",
    "email"
  ];

  const buildPayload = () => {
    const plan = form.payment_plan;

    const payload = {
      registration: form.registration,
      billing_date: form.billing_date,
      student_name: form.student_name,
      mobile_number: form.mobile_number,
      email: form.email,
      course: form.course,
      course_fees: form.course_fees,
      /* the discount that is really applied (0 when the offer is over) */
      discount_percentage: appliedDiscount === 0 ? "0" : form.discount_percentage,
      discount_validity: form.discount_validity,
      final_fee: finalFee,
      /* an empty box means 0 (no registration note in the invoice) */
      registration_fee: isFilled(form.registration_fee) ? form.registration_fee : "0",
      payment_plan: PLAN_VALUE[plan],
      /* advance plan: advance + balance date; installment plan: first
         installment amount + first due date (both are needed by the server) */
      advance_amount: plan !== "full" ? form.advance_amount : "",
      balance_due_date: plan !== "full" ? form.balance_due_date : "",
      remarks: form.remarks
    };

    /* the first payment is only taken while creating (later ones: Billing list -> Paid/Pending button) */
    if (!isEdit) {
      payload.initial_payment = form.initial_payment;
      payload.payment_method = form.payment_method;
      payload.payment_date = form.payment_date;
    }

    return payload;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    /* the form is saved only from the last slide */
    if (activeStep !== 4) {
      return;
    }

    setError("");
    setMessage("");

    if (!validateStep(4)) {
      return;
    }

    try {
      setSaving(true);

      const payload = buildPayload();
      const data = new FormData();

      Object.keys(payload).forEach((key) => {
        const value = payload[key];

        /* empty boxes are not sent for the optional fields */
        if (!isFilled(value) && SKIP_IF_EMPTY.includes(key)) {
          return;
        }

        data.append(key, value ?? "");
      });

      /* the full installment list in one JSON text (same way as education_details in registration) */
      const cleanRows =
        form.payment_plan !== "full"
          ? [
              /* installment plan: the first installment (top boxes) is the 1st row */
              ...(form.payment_plan === "installment"
                ? [
                    {
                      ...(firstRowMeta.current.id !== undefined && isEdit
                        ? { id: firstRowMeta.current.id }
                        : {}),
                      installment_no: 1,
                      amount: num(form.advance_amount).toFixed(2),
                      due_date: form.balance_due_date,
                      is_paid: Boolean(firstRowMeta.current.paid)
                    }
                  ]
                : []),
              ...installments.map((row, index) => ({
              ...(row.id !== undefined && isEdit ? { id: row.id } : {}),
              installment_no: index + (form.payment_plan === "installment" ? 2 : 1),
              amount: num(row.amount).toFixed(2),
              due_date: row.due_date,
              is_paid: Boolean(row.paid)
            }))
            ]
          : [];

      data.append("installments", JSON.stringify(cleanRows));

      /*
       * Both calls come from AuthContext.insert (same flow as Addregistration.js).
       * insert() throws the Django error (err.responseData) so it can be
       * shown in the popup below.
       */
      const body = await formDataToPayload(data);

      if (isEdit) {
        body.billing_id = billingId;

        const response = await insert(body, "update_billing_detail");

        if (response && response.success === false) {
          const failure = new Error("Update failed");
          failure.responseData = response;
          throw failure;
        }
      } else {
        const created = await insert(body, "billing_create");

        /* ---- invoice number comes from Django (INVOICE001, INVOICE002 ...) ----
           create response = { message, data: { ..., invoice_number } } */
        const readInvoiceNo = (r) =>
          r &&
          (r.invoice_number ||
            (r.data && r.data.invoice_number) ||
            (r.data && r.data.data && r.data.data.invoice_number) ||
            (r.billing && r.billing.invoice_number));

        let invoiceNo = readInvoiceNo(created);

        /* safety: if it is not in the response, read it back from the list */
        if (!invoiceNo) {
          try {
            const list = await getBillings();
            const mine = (Array.isArray(list) ? list : [])
              .filter((b) => billingRegistrationKey(b) === String(form.registration))
              .sort(
                (a, b) =>
                  Number(b.billing_id ?? b.id ?? 0) - Number(a.billing_id ?? a.id ?? 0)
              );
            invoiceNo = mine.length ? mine[0].invoice_number : "";
          } catch (lookupError) {
            invoiceNo = "";
          }
        }

        const regRecord = registrations.find(
          (r) =>
            String(r.id) === String(form.registration) ||
            String(r.registration_id) === String(form.registration)
        );
        const paidNow = num(form.initial_payment);

        setInvoiceData({
          invoiceNo: invoiceNo || "",
          date: invoiceDate(form.billing_date),
          regId: getDisplayRegistrationId(regRecord, buildPersonRegIds(registrations)),
          name: form.student_name,
          course: form.course,
          phone: form.mobile_number,
          email: form.email,
          courseFee: num(form.course_fees),
          discount: appliedDiscount === 0 ? 0 : num(form.discount_percentage),
          totalFee: num(finalFee),
          registrationFee: num(form.registration_fee),
          paymentMethod: form.payment_method,
          finalTotal: num(finalFee),
          paidToday: paidNow,
          balance: Math.max(num(finalFee) - paidNow, 0),
          /* dues still to come = the installment rows the money paid does not cover */
          future: (() => {
            let credit =
              form.payment_plan === "advance"
                ? Math.max(paidNow - num(form.advance_amount), 0)
                : paidNow;
            const dues =
              form.payment_plan === "full"
                ? []
                : [
                    ...(form.payment_plan === "installment"
                      ? [{ amount: num(form.advance_amount), due_date: form.balance_due_date }]
                      : []),
                    ...installments.map((r) => ({ amount: num(r.amount), due_date: r.due_date }))
                  ];
            const out = [];
            dues.forEach((r) => {
              const part = Math.min(credit, r.amount);
              credit -= part;
              if (r.amount - part > 0) {
                out.push({ date: String(r.due_date || "").slice(0, 10), amount: r.amount - part });
              }
            });
            return out;
          })()
        });
      }

      setMessage(
        isEdit
          ? "Billing updated successfully."
          : "Billing saved successfully."
      );

      /* edit: back to the list as before.
         add : the list opens when the invoice popup is closed */
      if (isEdit && onSaved) {
        setTimeout(() => {
          onSaved();
        }, 1000);
      }
    } catch (err) {
      console.error("Billing save error:", err);

      /* AuthContext puts the Django error in err.responseData */
      const errorMessage = getErrorMessage(
        err.responseData,
        isEdit ? "Unable to update billing." : "Unable to save billing."
      );

      setError(errorMessage);
      showAlert(errorMessage, "Unable to Save");
    } finally {
      setSaving(false);
    }
  };

  /* =====================================================
     FILTER REGISTRATIONS (popup list)
  ===================================================== */

  const billedKeys = new Set(billings.map(billingRegistrationKey).filter(Boolean));

  const unbilledRegistrations = registrations.filter(
    (item) =>
      !billedKeys.has(String(item.id)) &&
      !billedKeys.has(String(item.registration_id))
  );

  const personRegIds = buildPersonRegIds(registrations);

  const filteredRegistrations = unbilledRegistrations.filter((item) => {
    const nameMatch =
      !searchName.trim() || startsWithText(item.student_name, searchName);
    const phoneMatch =
      !searchPhone.trim() || startsWithText(item.mobile_number, searchPhone);
    const courseMatch =
      !searchCourse.trim() || startsWithText(item.course, searchCourse);
    const dateMatch =
      !searchDate || String(item.registration_date || "").includes(searchDate);

    return nameMatch && phoneMatch && courseMatch && dateMatch;
  });

  /* =====================================================
     PAGE
  ===================================================== */

  const balanceAfter = Math.max(
    finalFeeCents / 100 - (isEdit ? alreadyPaid : num(form.initial_payment)),
    0
  );

  return (
    <div className="container-xxl flex-grow-1 container-p-y billing-page-custom">
      {/* =================================================
          HEADER
      ================================================= */}

      <div className="page-header">
        <h4 className="page-title">
          {isEdit ? "Edit Billing" : "Add Billing"}
        </h4>

        <button
          type="button"
          className="back-button"
          onClick={() => {
            if (onBack) {
              onBack();
            }
          }}
        >
          <i className="bx bx-arrow-back me-1"></i>
          Back
        </button>
      </div>

      <form onSubmit={handleSubmit}>
        {/* =================================================
            ONE CARD : STEP BAR + FORM + BUTTONS
        ================================================= */}

        <div className="reg-main-card">
          {/* STEP BAR
              - green tick : all details of that slide are filled
              - number     : the slide you are on (not finished yet) */}
          <div className="billing-step-tabs">
            {stepList.map((step) => {
              const isActive = activeStep === step.id;

              let circleClass = "pending";

              if (step.complete) {
                circleClass = "done";
              } else if (isActive) {
                circleClass = "current";
              }

              return (
                <button
                  key={step.id}
                  type="button"
                  className={`billing-step-tab ${isActive ? "active" : ""}`}
                  onClick={() => goToStep(step.id)}
                >
                  <span className={`step-circle ${circleClass}`}>
                    {circleClass === "current" ? step.id : tickIcon}
                  </span>
                  {step.label}
                </button>
              );
            })}
          </div>

          {/* =================================================
              STEP 1 : STUDENT DETAILS
          ================================================= */}

          {activeStep === 1 && (
            <div className="step-content">
              <div className="custom-card">
                <div className="section-header">
                  <h5 className="section-title">Student Details</h5>
                </div>

                <div className="section-body">
                  <div className="row g-4">
                    {/* REGISTRATION */}
                    <div className="col-md-6">
                      <label className="form-label">REGISTRATION *</label>

                      <div
                        className={`reg-select-box ${isEdit ? "locked" : ""}`}
                        onClick={isEdit ? undefined : openRegistrationPopup}
                        tabIndex="0"
                      >
                        {selectedRegistration
                          ? `${registrationNo || "-"} - ${form.student_name}`
                          : "Click to select registration"}
                      </div>
                    </div>

                    {/* BILLING DATE */}
                    <div className="col-md-6">
                      <label className="form-label">BILLING DATE *</label>

                      <input
                        type="date"
                        className="form-control"
                        name="billing_date"
                        value={form.billing_date}
                        onChange={handleChange}
                        max={getToday()}
                      />
                    </div>

                    {/* STUDENT NAME */}
                    <div className="col-md-6">
                      <label className="form-label">STUDENT NAME</label>

                      <input
                        type="text"
                        className="form-control"
                        value={form.student_name}
                        readOnly
                        placeholder="Fetched from registration"
                        style={{ background: "#f5f5f9" }}
                      />
                    </div>

                    {/* MOBILE */}
                    <div className="col-md-6">
                      <label className="form-label">MOBILE NUMBER</label>

                      <input
                        type="text"
                        className="form-control"
                        value={form.mobile_number}
                        readOnly
                        placeholder="Fetched from registration"
                        style={{ background: "#f5f5f9" }}
                      />
                    </div>

                    {/* EMAIL */}
                    <div className="col-md-6">
                      <label className="form-label">EMAIL</label>

                      <input
                        type="text"
                        className="form-control"
                        value={form.email}
                        readOnly
                        placeholder="Fetched from registration"
                        style={{ background: "#f5f5f9" }}
                      />
                    </div>

                    {/* COURSE */}
                    <div className="col-md-6">
                      <label className="form-label">COURSE</label>

                      <input
                        type="text"
                        className="form-control"
                        value={form.course}
                        readOnly
                        placeholder="Fetched from registration"
                        style={{ background: "#f5f5f9" }}
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* =================================================
              STEP 2 : FEE DETAILS
          ================================================= */}

          {activeStep === 2 && (
            <div className="step-content">
              <div className="custom-card">
                <div className="section-header">
                  <h5 className="section-title">Fee Details</h5>
                </div>

                <div className="section-body">
                  <div className="row g-4">
                    {/* COURSE FEES */}
                    <div className="col-md-6">
                      <label className="form-label">COURSE FEES *</label>

                      <input
                        type="text"
                        className="form-control"
                        name="course_fees"
                        value={form.course_fees}
                        onChange={handleMoneyChange}
                        inputMode="decimal"
                        placeholder="Course fees"
                      />
                    </div>

                    {/* DISCOUNT */}
                    <div className="col-md-6">
                      <label className="form-label">DISCOUNT (%)</label>

                      <input
                        type="text"
                        className="form-control"
                        name="discount_percentage"
                        value={validityCrossed ? "0" : form.discount_percentage}
                        onChange={handleDiscountChange}
                        inputMode="decimal"
                        placeholder="0"
                        disabled={validityCrossed}
                      />

                      {/* DISCOUNT OFFER MESSAGE
                          green : offer is still available
                          red   : offer is over (discount 0, message shows the ended discount) */}
                      {form.discount_validity && (
                        <div
                          className={`discount-offer-msg ${
                            validityCrossed ? "ended" : "available"
                          }`}
                          style={{ minHeight: 0, marginTop: 8 }}
                        >
                          {validityCrossed
                            ? endedDiscount
                              ? `Discount offer is off – ${endedDiscount}% discount ended on ${formatDisplayDate(
                                  form.discount_validity
                                )}.`
                              : `Discount offer is off – validity ended on ${formatDisplayDate(
                                  form.discount_validity
                                )}.`
                            : `Discount offer is available till ${formatDisplayDate(
                                form.discount_validity
                              )}.`}
                        </div>
                      )}
                    </div>

                    {/* REGISTRATION FEE (printed in the invoice notes only) */}
                    <div className="col-md-6">
                      <label className="form-label">REGISTRATION FEE (₹)</label>

                      <input
                        type="text"
                        className="form-control"
                        name="registration_fee"
                        value={form.registration_fee}
                        onChange={handleMoneyChange}
                        inputMode="decimal"
                        placeholder="200"
                      />

                      <small className="d-block mt-2 text-muted">
                        Shown in the invoice notes. It is not added to the final fee.
                        Enter 0 to leave the note out.
                      </small>
                    </div>


                    {/* FINAL FEE (course fees - discount) */}
                    <div className="col-md-6">
                      <label className="form-label">FINAL FEE</label>

                      <input
                        type="text"
                        className="form-control final-fee-box"
                        value={finalFee}
                        readOnly
                        tabIndex={-1}
                        placeholder="Calculated automatically"
                      />

                      {finalFee !== "" && (
                        <small className="d-block mt-2 text-muted">
                          Course fees − discount ({appliedDiscount || 0}%)
                        </small>
                      )}
                    </div>

                  </div>
                </div>
              </div>
            </div>
          )}

          {/* =================================================
              STEP 3 : PAYMENT PLAN
          ================================================= */}

          {activeStep === 3 && (
            <div className="step-content">
              <div className="custom-card">
                <div className="section-header">
                  <h5 className="section-title">Payment Plan</h5>
                </div>

                <div className="section-body">
                  {/* PLAN CARDS */}
                  <div className="plan-cards">
                    {Object.keys(PLAN_LABEL).map((key) => (
                      <button
                        key={key}
                        type="button"
                        className={`plan-card ${
                          form.payment_plan === key ? "active" : ""
                        }`}
                        onClick={() => handlePlanChange(key)}
                      >
                        <strong>{PLAN_LABEL[key]}</strong>
                        <span>
                          {key === "full" && "Whole fee in one payment"}
                          {key === "advance" && "Advance now, balance on a date"}
                          {key === "installment" && "Split into monthly installments"}
                        </span>
                      </button>
                    ))}
                  </div>

                  <div className="row g-4 mt-1">
                    {/* ADVANCE AMOUNT / FIRST INSTALLMENT AMOUNT (advance + installment) */}
                    {form.payment_plan !== "full" && (
                      <div className="col-md-6">
                        <label className="form-label">
                          {form.payment_plan === "installment"
                            ? "FIRST INSTALLMENT AMOUNT *"
                            : "ADVANCE AMOUNT *"}
                        </label>

                        <input
                          type="text"
                          className="form-control"
                          name="advance_amount"
                          value={form.advance_amount}
                          onChange={(e) => {
                            advanceTouched.current = true;
                            handleMoneyChange(e);
                          }}
                          disabled={
                            form.payment_plan === "installment" &&
                            Boolean(firstRowMeta.current.paid)
                          }
                          inputMode="decimal"
                          placeholder={
                            form.payment_plan === "installment"
                              ? "First installment amount"
                              : "Advance amount"
                          }
                        />
                      </div>
                    )}

                    {/* DATE (advance + installment) */}
                    {form.payment_plan !== "full" && (
                      <div className="col-md-6">
                        <label className="form-label">DATE *</label>

                        <input
                          type="date"
                          className="form-control"
                          name="balance_due_date"
                          value={form.balance_due_date}
                          onChange={handleChange}
                          disabled={
                            form.payment_plan === "installment" &&
                            Boolean(firstRowMeta.current.paid)
                          }
                          min={regDate}
                        />

                        {advanceCents > 0 && advanceCents < finalFeeCents && (
                          <small className="d-block mt-2 text-muted">
                            Balance to pay: {money((finalFeeCents - advanceCents) / 100)}
                          </small>
                        )}
                      </div>
                    )}
                  </div>

                  {/* INSTALLMENT TABLE */}
                  {form.payment_plan !== "full" && installments.length > 0 && (
                    <div className="inst-table-wrap mt-4">
                      <table className="inst-table">
                        <thead>
                          <tr>
                            <th>#</th>
                            <th>DUE DATE</th>
                            <th>AMOUNT</th>
                            <th>STATUS</th>
                            <th></th>
                          </tr>
                        </thead>

                        <tbody>
                          {installments.map((row, index) => (
                            <tr key={index}>
                              <td>{index + (form.payment_plan === "installment" ? 2 : 1)}</td>

                              <td>
                                <input
                                  type="date"
                                  className="form-control"
                                  value={row.due_date}
                                  disabled={row.paid}
                                  onChange={(e) =>
                                    updateRow(index, "due_date", e.target.value)
                                  }
                                />
                              </td>

                              <td>
                                <input
                                  type="text"
                                  className="form-control"
                                  value={row.amount}
                                  disabled={row.paid}
                                  inputMode="decimal"
                                  onChange={(e) =>
                                    updateRow(
                                      index,
                                      "amount",
                                      e.target.value
                                        .replace(/[^\d.]/g, "")
                                        .replace(/(\..*)\./g, "$1")
                                    )
                                  }
                                />
                              </td>

                              <td>
                                <span
                                  className={`badge ${
                                    row.paid ? "bg-label-success" : "bg-label-danger"
                                  }`}
                                >
                                  {row.paid ? "Paid" : "Pending"}
                                </span>
                              </td>

                              <td>
                                <button
                                  type="button"
                                  className="inst-add"
                                  title="Add installment"
                                  onClick={addRow}
                                >
                                  +
                                </button>

                                {!row.paid && (
                                  <button
                                    type="button"
                                    className="inst-remove ms-2"
                                    title="Remove"
                                    onClick={() => removeRow(index)}
                                  >
                                    &minus;
                                  </button>
                                )}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>

                      <div className="inst-footer">
                        <span
                          className={
                            installmentSumCents === installmentTargetCents
                              ? "inst-total ok"
                              : "inst-total bad"
                          }
                        >
                          Total {money(installmentSumCents / 100)} of{" "}
                          {money(installmentTargetCents / 100)}
                        </span>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* =================================================
              STEP 4 : PAYMENT
          ================================================= */}

          {activeStep === 4 && (
            <div className="step-content">
              <div className="custom-card">
                <div className="section-header">
                  <h5 className="section-title">Payment</h5>
                </div>

                <div className="section-body">
                  {/* SUMMARY */}
                  <div className="fee-summary">
                    <div>
                      <small>Final Fee</small>
                      <strong>{money(finalFeeCents / 100)}</strong>
                    </div>

                    <div>
                      <small>{isEdit ? "Paid So Far" : "Paying Now"}</small>
                      <strong className="text-success">
                        {money(isEdit ? alreadyPaid : num(form.initial_payment))}
                      </strong>
                    </div>

                    <div>
                      <small>Balance</small>
                      <strong className={balanceAfter > 0 ? "text-danger" : "text-success"}>
                        {money(balanceAfter)}
                      </strong>
                    </div>

                    <div>
                      <small>Plan</small>
                      <strong>{PLAN_LABEL[form.payment_plan]}</strong>
                    </div>
                  </div>

                  <div className="row g-4 mt-1">
                    {/* FIRST PAYMENT (new bills only) */}
                    {!isEdit && (
                      <>
                        <div className="col-md-6">
                          <label className="form-label">PAYMENT NOW</label>

                          <input
                            type="text"
                            className="form-control"
                            name="initial_payment"
                            value={form.initial_payment}
                            onChange={handleMoneyChange}
                            readOnly
                            inputMode="decimal"
                            placeholder={
                              form.payment_plan === "full"
                                ? `Full fee ${money(finalFeeCents / 100)} or leave empty`
                                : "Amount received today (optional)"
                            }
                          />
                        </div>

                        <div className="col-md-6">
                          <label className="form-label">PAYMENT METHOD</label>

                          <select
                            className="form-select"
                            name="payment_method"
                            value={form.payment_method}
                            onChange={handleChange}
                          >
                            {PAYMENT_METHODS.map((method) => (
                              <option key={method} value={method}>
                                {method}
                              </option>
                            ))}
                          </select>
                        </div>
                      </>
                    )}

                    {isEdit && (
                      <div className="col-12">
                        <div className="alert alert-info mb-0">
                          Payments are recorded from the Billing list
                          (Paid / Pending button), so they are not changed here.
                        </div>
                      </div>
                    )}

                  </div>
                </div>
              </div>
            </div>
          )}

          {/* =================================================
              MESSAGES
          ================================================= */}

          {message && <div className="alert alert-success mt-3">{message}</div>}

          {error && <div className="alert alert-danger mt-3">{error}</div>}

          {/* =================================================
              STEP NAVIGATION
          ================================================= */}

          <div className="step-navigation">
            <button
              type="button"
              className="btn btn-outline-secondary"
              onClick={() => {
                if (activeStep === 1) {
                  if (onBack) {
                    onBack();
                  }
                } else {
                  handlePreviousStep();
                }
              }}
            >
              <i className="bx bx-arrow-back me-1"></i>
              {activeStep === 1 ? "Cancel" : "Back"}
            </button>

            {activeStep < 4 ? (
              <button
                key="next-button"
                type="button"
                className="btn save-button"
                onClick={handleNextStep}
              >
                Next
                <i className="bx bx-right-arrow-alt ms-1"></i>
              </button>
            ) : (
              <button
                key="save-button"
                type="submit"
                className="btn save-button"
                disabled={saving}
              >
                <i className="bx bx-save me-1"></i>
                {saving
                  ? "Saving..."
                  : isEdit
                  ? "Update Billing"
                  : "Save Billing"}
              </button>
            )}
          </div>
        </div>
      </form>

      {/* =================================================
          REGISTRATION POPUP
      ================================================= */}

      {showRegistrationPopup && (
        <div className="billing-popup-overlay">
          <div className="billing-popup">
            {/* HEADER */}
            <div className="billing-popup-header">
              <div>
                <h3>Select Registration</h3>
                <p>Registrations that do not have a bill yet</p>
              </div>

              <button
                type="button"
                className="btn-close"
                aria-label="Close"
                onClick={() => setShowRegistrationPopup(false)}
              />
            </div>

            {/* SEARCH */}
            <div className="billing-popup-search">
              <div>
                <label>SEARCH BY NAME</label>
                <div className="input-group">
                  <span className="input-group-text">
                    <i className="bx bx-search"></i>
                  </span>
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Student name"
                    value={searchName}
                    maxLength="151"
                    onChange={(e) =>
                      setSearchName(e.target.value.replace(/[^A-Za-z\s.'-]/g, ""))
                    }
                  />
                </div>
              </div>

              <div>
                <label>SEARCH BY PHONE</label>
                <div className="input-group">
                  <span className="input-group-text">
                    <i className="bx bx-phone"></i>
                  </span>
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Phone number"
                    value={searchPhone}
                    inputMode="numeric"
                    maxLength="10"
                    onChange={(e) =>
                      setSearchPhone(e.target.value.replace(/\D/g, ""))
                    }
                  />
                </div>
              </div>

              <div>
                <label>SEARCH BY COURSE</label>
                <div className="input-group">
                  <span className="input-group-text">
                    <i className="bx bx-book"></i>
                  </span>
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Course"
                    value={searchCourse}
                    maxLength="151"
                    onChange={(e) => setSearchCourse(e.target.value)}
                  />
                </div>
              </div>

              <div>
                <label>REGISTRATION DATE</label>
                <input
                  type="date"
                  className="form-control"
                  value={searchDate}
                  min="2000-01-01"
                  max="2100-12-31"
                  onChange={(e) => setSearchDate(e.target.value)}
                />
              </div>
            </div>

            {/* TABLE */}
            <div className="billing-popup-table-container">
              <table className="billing-popup-table">
                <thead>
                  <tr>
                    <th>S.NO</th>
                    <th>REG ID</th>
                    <th>NAME</th>
                    <th>PHONE</th>
                    <th>COURSE</th>
                    <th>COURSE FEES</th>
                    <th>REGISTRATION DATE</th>
                  </tr>
                </thead>

                <tbody>
                  {filteredRegistrations.length === 0 ? (
                    <tr>
                      <td colSpan="7" className="billing-empty">
                        No registrations found
                      </td>
                    </tr>
                  ) : (
                    filteredRegistrations.map((item, index) => (
                      <tr
                        key={item.id || item.registration_id}
                        className="billing-select-row"
                        onClick={() => handleSelectRegistration(item)}
                      >
                        <td>{index + 1}</td>
                        <td>{getDisplayRegistrationId(item, personRegIds)}</td>
                        <td>{item.student_name || "-"}</td>
                        <td>{item.mobile_number || "-"}</td>
                        <td>{item.course || "-"}</td>
                        <td>{item.course_fees ? money(item.course_fees) : "-"}</td>
                        <td>{item.registration_date || "-"}</td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>

            {/* FOOTER */}
            <div className="billing-popup-footer">
              <span>
                Showing {filteredRegistrations.length} of{" "}
                {unbilledRegistrations.length}
              </span>

              <button
                type="button"
                className="btn btn-outline-secondary"
                onClick={() => setShowRegistrationPopup(false)}
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* =================================================
          VALIDATION POPUP
      ================================================= */}

      {popup && (
        <div className="bill-alert-overlay" onClick={closePopup}>
          <div
            className={`bill-alert-box ${popup.type}`}
            role="alertdialog"
            aria-modal="true"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              type="button"
              className="bill-alert-close"
              aria-label="Close"
              onClick={closePopup}
            >
              &times;
            </button>

            <div className="bill-alert-icon">
              <i className={`bx ${popupIcons[popup.type] || popupIcons.error}`}></i>
            </div>

            <h4 className="bill-alert-title">{popup.title}</h4>

            <p className="bill-alert-text">{popup.text}</p>

            <button
              type="button"
              className="bill-alert-btn"
              onClick={closePopup}
              autoFocus
            >
              Got it
            </button>
          </div>
        </div>
      )}

      {/* INVOICE POPUP (after Save Billing): saved to the computer automatically,
          then Download / Print / WhatsApp / Email buttons */}
      {invoiceData && (
        <Invoice
          data={invoiceData}
          autoDownload
          onClose={() => {
            setInvoiceData(null);
            if (onSaved) {
              onSaved();
            }
          }}
        />
      )}
    </div>
  );
}

export default Addbilling;