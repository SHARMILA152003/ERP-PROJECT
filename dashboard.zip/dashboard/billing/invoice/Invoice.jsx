import React, { useContext, useEffect, useLayoutEffect, useRef, useState } from "react";
import { toPng } from "html-to-image";            // npm i html-to-image
import AuthContext from "../../../services/AuthContext";
import igtLogo from "./igt-logo.png";
import "./invoice.css";

/*
 * <Invoice data={...} autoDownload onClose={...} />
 *
 * data = {
 *   invoiceNo, date ("13/5/2026"), regId, name, course, phone, email,
 *   courseFee, discount (percent), totalFee, paymentMethod,
 *   finalTotal, paidToday, balance
 * }
 *
 * Buttons : Download PNG | Print | WhatsApp | Email | Close
 * autoDownload = true  -> the PNG is saved to the computer as soon as the popup opens
 *
 * Email : AuthContext.insert(payload, "send_invoice_email") sends the PNG from Django.
 *         insert() can only send JSON, so the PNG goes as base64
 *         { name, type, data } and Django turns it back into a file.
 *         If insert is missing, the mail app opens and the PNG is saved to attach.
 */

const COMPANY = {
  name1: "INFOGRO",
  name2: "TECHNOLOGY",
  tagline: "Here to grow your skills",
  line1: "#161 1st Floor, Alapakkam Main Road",
  line2: "Maduravoyal Erikari, Chennai-95",
  phone: "+91 75500 20901"
};

/* used when the invoice data does not carry a registration fee */
export const DEFAULT_REGISTRATION_FEE = 200;

/*
 * Additional notes. The registration fee in note 2 is NOT fixed: it comes
 * from the invoice data (data.registrationFee). A fee of 0 removes the note.
 */
const buildNotes = (registrationFee) => {
  const fee = parseFloat(registrationFee);
  const amount = Number.isFinite(fee) && fee >= 0 ? fee : DEFAULT_REGISTRATION_FEE;

  return [
    "Student need to follow proper formal dress code",
    amount > 0
      ? `Additional ₹${Number.isInteger(amount) ? amount : amount.toFixed(2)} will be collected for the registration`
      : "",
    "Student prohibited to transfer the course to other student and the amount will not be refunded"
  ].filter(Boolean);
};

/* ---------- helpers ---------- */

const toNum = (v) => {
  const n = parseFloat(v);
  return Number.isFinite(n) ? n : 0;
};

/* 50000 -> "₹50000", 2500.5 -> "₹2500.50" */
export const rupee = (v) => {
  const n = toNum(v);
  return `₹${Number.isInteger(n) ? n : n.toFixed(2)}`;
};

/* 2026-05-13 -> 13/5/2026 */
export const invoiceDate = (value) => {
  const m = String(value || "").match(/^(\d{4})-(\d{2})-(\d{2})/);
  return m ? `${Number(m[3])}/${Number(m[2])}/${m[1]}` : value || "-";
};

const ONES = ["", "ONE", "TWO", "THREE", "FOUR", "FIVE", "SIX", "SEVEN", "EIGHT", "NINE", "TEN", "ELEVEN", "TWELVE", "THIRTEEN", "FOURTEEN", "FIFTEEN", "SIXTEEN", "SEVENTEEN", "EIGHTEEN", "NINETEEN"];
const TENS = ["", "", "TWENTY", "THIRTY", "FORTY", "FIFTY", "SIXTY", "SEVENTY", "EIGHTY", "NINETY"];

const below100 = (n) => (n < 20 ? ONES[n] : `${TENS[Math.floor(n / 10)]}${n % 10 ? " " + ONES[n % 10] : ""}`);
const below1000 = (n) =>
  `${n >= 100 ? ONES[Math.floor(n / 100)] + " HUNDRED" + (n % 100 ? " " : "") : ""}${below100(n % 100)}`;

/* Indian system: 150000 -> "ONE LAKH FIFTY THOUSAND ONLY" */
export const amountInWords = (value) => {
  let n = Math.round(toNum(value));
  if (n <= 0) return "ZERO ONLY";
  const parts = [];
  const crore = Math.floor(n / 10000000); n %= 10000000;
  const lakh = Math.floor(n / 100000); n %= 100000;
  const thousand = Math.floor(n / 1000); n %= 1000;
  if (crore) parts.push(`${below1000(crore)} CRORE`);
  if (lakh) parts.push(`${below100(lakh)} LAKH`);
  if (thousand) parts.push(`${below100(thousand)} THOUSAND`);
  if (n) parts.push(below1000(n));
  return `${parts.join(" ")} ONLY`;
};

const fileNameOf = (d) =>
  `${String(d.invoiceNo || "INVOICE").toUpperCase()}_${String(d.name || "student").trim().replace(/[^a-z0-9]+/gi, "_")}.png`;

/* "9876543210" -> "919876543210" (adds 91 for 10 digit Indian numbers) */
const waNumber = (phone) => {
  const digits = String(phone || "").replace(/\D/g, "");
  if (digits.length === 10) return `91${digits}`;
  return digits.replace(/^0+/, "");
};

/* pending installments -> [{ date: "2026-09-24", amount }] (advance / installment plans only) */
export const futureFromInstallments = (list) =>
  (Array.isArray(list) ? list : [])
    .filter((i) => !i.paid)
    .map((i) => ({
      date: String(i.date || i.due_date || "").slice(0, 10),
      amount: Math.max(toNum(i.amount) - toNum(i.paidAmount), 0)
    }))
    .filter((i) => i.amount > 0);

/* ---------- build the invoice data from a billing row of the Billing list ---------- */
export const buildInvoiceFromBill = (bill, regId) => {
  const raw = (bill && bill.raw) || {};
  const payments = Array.isArray(raw.payments) ? raw.payments : [];
  const lastPayment = payments.length ? payments[payments.length - 1] : {};
  return {
    invoiceNo: raw.invoice_number || bill.invoice_number || "",
    date: invoiceDate(bill.billingDate),
    regId: regId || "-",
    name: bill.name,
    course: bill.course,
    phone: bill.phone,
    email: bill.email,
    courseFee: bill.courseFee,
    discount: bill.discount,
    totalFee: bill.finalFee,
    paymentMethod: raw.payment_method || lastPayment.method || lastPayment.payment_method || "-",
    finalTotal: bill.finalFee,
    paidToday: bill.paid,
    balance: bill.balance,
    /* registration fee shown in the notes (falls back to the default) */
    registrationFee:
      raw.registration_fee !== undefined && raw.registration_fee !== null && raw.registration_fee !== ""
        ? raw.registration_fee
        : bill.registrationFee,
    /* dues still to come (Future Payment Date / Amount table) */
    future: futureFromInstallments(bill && bill.installments)
  };
};

/* ---------- the popup ---------- */
export default function Invoice({ data, onClose, autoDownload = false }) {
  const d = data || {};
  const { insert } = useContext(AuthContext) || {};

  const sheetRef = useRef(null);
  const autoDone = useRef(false);
  const [scale, setScale] = useState(1);
  const [sheetHeight, setSheetHeight] = useState(1600);
  const [busy, setBusy] = useState("");
  const [note, setNote] = useState("");

  const invoiceNo = String(d.invoiceNo || "").toUpperCase() || "INVOICE---";
  /* a payment was received for this invoice -> PAID (never shown as Pending) */
  const paid = toNum(d.paidToday) > 0 || toNum(d.balance) <= 0;
  const future = Array.isArray(d.future) ? d.future : [];

  /* fit the 1700px sheet to the screen (the PNG is always taken at full size) */
  useLayoutEffect(() => {
    const fit = () => {
      const available = Math.min(window.innerWidth - 32, 820);
      setScale(Math.min(1, available / 1700));
      if (sheetRef.current) setSheetHeight(sheetRef.current.offsetHeight);
    };
    fit();
    window.addEventListener("resize", fit);

    /* the sheet grows after the fonts / logo load -> measure again, otherwise the bottom is cut */
    let observer;
    if (typeof ResizeObserver !== "undefined" && sheetRef.current) {
      observer = new ResizeObserver(fit);
      observer.observe(sheetRef.current);
    }
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(fit);
    const timer = setTimeout(fit, 400);

    return () => {
      window.removeEventListener("resize", fit);
      if (observer) observer.disconnect();
      clearTimeout(timer);
    };
  }, []);

  const makePng = async () => {
    if (document.fonts && document.fonts.ready) await document.fonts.ready;
    return toPng(sheetRef.current, {
      pixelRatio: 2,
      cacheBust: true,
      backgroundColor: "#ffffff",
      style: { transform: "none", margin: "0" }
    });
  };

  const dataUrlToBlob = async (url) => (await fetch(url)).blob();

  const saveToComputer = (url) => {
    const a = document.createElement("a");
    a.href = url;
    a.download = fileNameOf(d);
    document.body.appendChild(a);
    a.click();
    a.remove();
  };

  const run = async (label, job) => {
    try {
      setBusy(label);
      setNote("");
      await job();
    } catch (err) {
      console.error("Invoice error:", err);
      const reason = err && err.responseData && err.responseData.message;
      setNote(reason ? `Failed: ${reason}` : "Something went wrong. Please try again.");
    } finally {
      setBusy("");
    }
  };

  /* DOWNLOAD */
  const handleDownload = () =>
    run("download", async () => {
      saveToComputer(await makePng());
      setNote(`Saved: ${fileNameOf(d)}`);
    });

  /* saved to the computer automatically when the popup opens (new billing only) */
  useEffect(() => {
    if (!autoDownload || autoDone.current) return;
    autoDone.current = true;
    const t = setTimeout(handleDownload, 600);
    return () => clearTimeout(t);
    // eslint-disable-next-line
  }, []);

  /* PRINT (prints only the invoice image, fits one page) */
  const handlePrint = () =>
    run("print", async () => {
      const url = await makePng();
      const frame = document.createElement("iframe");
      frame.style.cssText = "position:fixed;right:0;bottom:0;width:0;height:0;border:0";
      document.body.appendChild(frame);
      const doc = frame.contentWindow.document;
      doc.open();
      doc.write(
        `<html><head><title>${invoiceNo}</title><style>@page{margin:0}body{margin:0}img{width:100%;display:block}</style></head><body><img id="i" src="${url}"/></body></html>`
      );
      doc.close();
      const img = doc.getElementById("i");
      const go = () => {
        frame.contentWindow.focus();
        frame.contentWindow.print();
        setTimeout(() => frame.remove(), 2000);
      };
      if (img.complete) go();
      else img.onload = go;
    });

  /* WHATSAPP */
  const handleWhatsApp = () =>
    run("whatsapp", async () => {
      const url = await makePng();
      const blob = await dataUrlToBlob(url);
      const file = new File([blob], fileNameOf(d), { type: "image/png" });
      const text =
        `Hello ${d.name}, thank you for joining INFOGRO TECHNOLOGY.\n` +
        `Your invoice ${invoiceNo} for ${d.course} is attached.\n` +
        `Paid: ${rupee(d.paidToday)} | Balance: ${rupee(d.balance)}`;

      /* phones (and some browsers): share sheet with the image attached -> choose WhatsApp */
      if (navigator.canShare && navigator.canShare({ files: [file] })) {
        try {
          await navigator.share({ files: [file], text });
          return;
        } catch (e) {
          if (e && e.name === "AbortError") return;
        }
      }

      /* computer: save the image, open the chat with the message ready, then attach the image */
      saveToComputer(url);
      window.open(
        `https://wa.me/${waNumber(d.phone)}?text=${encodeURIComponent(text)}`,
        "_blank",
        "noopener"
      );
      setNote("Invoice image saved. In WhatsApp click the attach (+) button and choose the saved image.");
    });

  /* EMAIL */
  const handleEmail = () =>
    run("email", async () => {
      const url = await makePng();
      const subject = `Invoice ${invoiceNo} - INFOGRO TECHNOLOGY`;
      const message =
        `Hello ${d.name},\n\nThank you for joining INFOGRO TECHNOLOGY.\n` +
        `Please find your invoice ${invoiceNo} for ${d.course} attached.\n\n` +
        `Paid: ${rupee(d.paidToday)}\nBalance: ${rupee(d.balance)}\n\nRegards,\nINFOGRO TECHNOLOGY\n${COMPANY.phone}`;

      /* real send (invoice attached) through Django */
      if (typeof insert === "function" && d.email) {
        const response = await insert(
          {
            to: d.email,
            subject,
            message,
            filename: fileNameOf(d),
            image: {
              name: fileNameOf(d),
              type: "image/png",
              data: String(url).split(",")[1] || ""
            }
          },
          "send_invoice_email"
        );

        if (response && response.success === false) {
          const failure = new Error("Email failed");
          failure.responseData = response;
          throw failure;
        }

        setNote(`Invoice emailed to ${d.email}`);
        return;
      }

      /* fallback: mail app opens, the image is saved so it can be attached */
      saveToComputer(url);
      window.location.href = `mailto:${d.email || ""}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(message)}`;
      setNote("Invoice image saved. Attach it in the mail window that opened.");
    });

  return (
    <div className="igt-inv-overlay">
      <div className="igt-inv-bar">
        <button type="button" className="igt-inv-btn dl" onClick={handleDownload} disabled={Boolean(busy)}>
          ⬇ Download
        </button>
        <button type="button" className="igt-inv-btn pr" onClick={handlePrint} disabled={Boolean(busy)}>
          🖨 Print
        </button>
        <button type="button" className="igt-inv-btn wa" onClick={handleWhatsApp} disabled={Boolean(busy)}>
          💬 WhatsApp
        </button>
        <button type="button" className="igt-inv-btn em" onClick={handleEmail} disabled={Boolean(busy)}>
          ✉ Email
        </button>
        <button type="button" className="igt-inv-btn cl" onClick={onClose}>
          ✕ Close
        </button>
      </div>

      <div className="igt-inv-note">{busy ? "Please wait..." : note}</div>

      <div className="igt-inv-stage" style={{ width: 1700 * scale, height: sheetHeight * scale }}>
        <div className="igt-inv-scale" style={{ transform: `scale(${scale})`, width: 1700 }}>
          <div className="igt-sheet" ref={sheetRef}>
            <div className="igt-hero">
              <div className="igt-clip">
                <div className="igt-c1" />
                <div className="igt-c2" />
                <div className="igt-c3" />
              </div>

              <div className="igt-brand">
                <div className="igt-badge">
                  <img src={igtLogo} alt="IGT" />
                </div>
                <div className="igt-name">
                  <small>★ IGT ★</small>
                  <h1>
                    {COMPANY.name1} <span>{COMPANY.name2}</span>
                  </h1>
                  <div className="igt-tag">{COMPANY.tagline}</div>
                </div>
              </div>

              <div className="igt-contact">
                <b>CHENNAI</b>
                {COMPANY.line1}
                <br />
                {COMPANY.line2}
                <br />
                {COMPANY.phone}
              </div>

              <div className="igt-ribbon">INVOICE</div>
            </div>
            <div className="igt-stripe" />

            <div className="igt-main">
              <div className="igt-meta">
                <div className="igt-m"><i>Invoice No</i><b>{invoiceNo}</b></div>
                <div className="igt-m"><i>Date</i><b>{d.date}</b></div>
                <div className="igt-m"><i>Reg ID</i><b>{d.regId}</b></div>
              </div>

              <table className="igt-table">
                <thead>
                  <tr>
                    <th>Name</th>
                    <th>Course Name</th>
                    <th>Course Fee</th>
                    <th>Discount</th>
                    <th>Total Fee</th>
                    <th>Payment Method</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>{d.name}</td>
                    <td>{d.course}</td>
                    <td>{rupee(d.courseFee)}</td>
                    <td>{toNum(d.discount)}%</td>
                    <td>{rupee(d.totalFee)}</td>
                    <td>{d.paymentMethod}</td>
                  </tr>
                </tbody>
              </table>

              <div className="igt-row">
                {future.length > 0 && (
                  <div className="igt-future">
                    <div className="igt-fh">
                      <span>Future Payment Date</span>
                      <span>Amount</span>
                    </div>
                    {future.map((f, i) => (
                      <div className="igt-fr" key={i}>
                        <span>{f.date}</span>
                        <span>{rupee(f.amount)}</span>
                      </div>
                    ))}
                    <div className="igt-seal small">
                      <div className={`igt-stamp${paid ? "" : " pending"}`}>{paid ? "PAID" : "PENDING"}</div>
                    </div>
                  </div>
                )}
                <div className="igt-tot">
                  <div className="igt-l final"><span>Final Total</span><b>{rupee(d.finalTotal)}</b></div>
                  <div className="igt-l paid"><span>Paid Today</span><b>{rupee(d.paidToday)}</b></div>
                  <div className="igt-l bal"><span>Total Balance</span><b>{rupee(d.balance)}</b></div>
                  <div className="igt-l words"><span>IN WORDS</span><span>{amountInWords(d.paidToday)}</span></div>
                </div>
                {future.length === 0 && (
                  <div className="igt-seal">
                    <div className={`igt-stamp${paid ? "" : " pending"}`}>{paid ? "PAID" : "PENDING"}</div>
                  </div>
                )}
              </div>
            </div>

            <div className="igt-notes">
              <h3>ADDITIONAL NOTES</h3>
              {buildNotes(d.registrationFee).map((text, i) => (
                <p key={i}>{i + 1}. {text}</p>
              ))}
            </div>

            <div className="igt-foot">
              Thank you for choosing <b>INFOGRO TECHNOLOGY</b> · {COMPANY.phone}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
