import React, { useContext, useEffect, useState } from "react";
import AuthContext from "../../services/AuthContext";
import "./Billing.css";

import Addbilling, {
  num,
  money,
  getToday,
  formatDisplayDate,
  addMonths,
  normalizeBilling,
  buildPersonRegIds,
  getDisplayRegistrationId,
  PLAN_LABEL,
  PAYMENT_METHODS
} from "./addbilling/Addbilling";
import Updatebilling from "./updatebilling/Updatebilling";
import Invoice, { buildInvoiceFromBill, invoiceDate } from "./invoice/Invoice";

/*
 * Server calls come from AuthContext (same flow as Registration.jsx):
 *
 *   getData("fetch_billing_detail")        -> all billings (array)
 *   getData("fetch_registration_datail")   -> all registrations (array, student details + photo)
 *   insert({ billing_id, amount, method, payment_date }, "pay_billing_detail")
 *                                          -> record one payment (backend puts it into the due dates in order)
 *   insert({ billing_id }, "delete_billing_detail")  -> delete
 *
 * AuthContext is shared by every module, so it is used as it is.
 * insert() is used for pay / delete because it is the AuthContext
 * helper that throws the Django error (error.responseData), so the
 * message can be shown in the popup.
 *
 * Add / edit are inside addbilling/Addbilling.js
 * (insert -> "billing_create" / "update_billing_detail").
 *
 * NOTE: the import path of AuthContext above is for
 *   src/<folder>/billing/Billing.jsx
 * If your file is in a different folder, change "../../services/AuthContext".
 */


/*
 * Django sends every saved file as a full url (http://host/media/...),
 * so no server address is needed here.
 */
const apiUrl = "";


/* ============================================================
   FILE URL HELPERS
   API_HOST is the server address (apiUrl above)
   ============================================================ */

const buildFileCandidates = (value, API_HOST = "") => {

  if (!value) {
    return [];
  }

  const text = String(value).trim();

  const list = [];

  const add = (url) => {
    if (url && !list.includes(url)) {
      list.push(url);
    }
  };

  if (/^https?:\/\//i.test(text)) {
    add(text);

    try {
      const path = new URL(text).pathname;

      add(`${API_HOST}${path}`);

      if (!path.startsWith("/media/")) {
        add(`${API_HOST}/media${path}`);
      }
    } catch (err) {
      /* keep the original url only */
    }

    return list;
  }

  const safe = text.includes("%") ? text : encodeURI(text);

  if (safe.startsWith("/")) {
    add(`${API_HOST}${safe}`);

    if (!safe.startsWith("/media/")) {
      add(`${API_HOST}/media${safe}`);
    }
  } else {
    /* plain file name saved in the database -> normally served from /media/ */
    add(
      safe.startsWith("media/")
        ? `${API_HOST}/${safe}`
        : `${API_HOST}/media/${safe}`
    );
    add(`${API_HOST}/${safe}`);
  }

  return list;
};

/* shows the first url that loads, otherwise the fallback */
const FallbackImage = ({ candidates, alt, className, fallback }) => {
  const [index, setIndex] = useState(0);

  const signature = candidates.join("|");

  useEffect(() => {
    setIndex(0);
  }, [signature]);

  if (!candidates.length || index >= candidates.length) {
    return fallback || null;
  }

  return (
    <img
      src={candidates[index]}
      alt={alt}
      className={className}
      onError={() => setIndex((previous) => previous + 1)}
    />
  );
};

/* a file field may be a text, or an object like { url: "..." } */
const pickFileString = (value) => {

  if (!value) {
    return "";
  }

  if (typeof value === "string") {
    const text = value.trim();

    if (!text || ["null", "none", "undefined"].includes(text.toLowerCase())) {
      return "";
    }

    return text;
  }

  if (typeof value === "object") {
    return pickFileString(value.url || value.path || value.file || value.name);
  }

  return "";
};

const getStudentPhotoValue = (item) => {
  if (!item) {
    return "";
  }

  for (const key of [
    "student_photo",
    "student_image",
    "studentPhoto",
    "photo",
    "photo_url",
    "image"
  ]) {
    const value = pickFileString(item[key]);

    if (value) {
      return value;
    }
  }

  return "";
};

/* one person (enquiry no) = one photo: the newest saved photo of that person */
const buildPersonPhotos = (list) => {
  const map = {};

  [...list]
    .sort((a, b) => Number(a.id) - Number(b.id))
    .forEach((record) => {
      const key = String(record.enquiry_no || "");
      const photo = getStudentPhotoValue(record);

      if (key && photo) {
        map[key] = photo;
      }
    });

  return map;
};


/* ============================================================
   ICONS
   ============================================================ */

const ICON_PATHS = {

  phone: (
    <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z" />
  ),

  email: (
    <>
      <rect x="3" y="5" width="18" height="14" rx="2" />
      <polyline points="3,7 12,13 21,7" />
    </>
  ),

  enquiry: (
    <>
      <rect x="4" y="3" width="16" height="18" rx="2" />
      <path d="M8 7h8" />
      <path d="M8 11h8" />
      <path d="M8 15h5" />
    </>
  ),

  course: (
    <>
      <path d="M4 5.5A2.5 2.5 0 0 1 6.5 3H20v16H6.5A2.5 2.5 0 0 0 4 21.5z" />
      <path d="M4 5.5v16" />
      <path d="M8 7h8" />
    </>
  ),

  fees: (
    <>
      <rect x="3" y="6" width="18" height="13" rx="2" />
      <path d="M7 6V4h10v2" />
      <circle cx="12" cy="12.5" r="2.5" />
    </>
  ),

  discount: (
    <>
      <path d="M20.59 13.41L11 23l-9-9 9.59-9.59L20.59 13.41z" />
      <circle cx="7.5" cy="7.5" r="1.5" />
    </>
  ),

  validity: (
    <>
      <circle cx="12" cy="12" r="9" />
      <polyline points="12,7 12,12 15,14" />
    </>
  ),

  plan: (
    <>
      <rect x="3" y="5" width="18" height="16" rx="2" />
      <path d="M16 3v4" />
      <path d="M8 3v4" />
      <path d="M3 10h18" />
      <path d="M8 15h3" />
    </>
  ),

  status: (
    <>
      <circle cx="12" cy="12" r="9" />
      <path d="M8 12l2.5 2.5L16 9" />
    </>
  ),

  remarks: (
    <>
      <path d="M4 4h16v13H7l-3 3V4z" />
      <path d="M8 9h8" />
      <path d="M8 13h5" />
    </>
  ),

  edit: (
    <>
      <path d="M12 20h9" />
      <path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4 12.5-12.5z" />
    </>
  ),

  delete: (
    <>
      <polyline points="3 6 5 6 21 6" />
      <path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6" />
      <path d="M10 11v6" />
      <path d="M14 11v6" />
      <path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2" />
    </>
  ),

  location: (
    <>
      <path d="M12 21s-7-6.2-7-11.5A7 7 0 0 1 19 9.5C19 14.8 12 21 12 21z" />
      <circle cx="12" cy="9.5" r="2.5" />
    </>
  ),

  tick: (
    <polyline points="20 6 9 17 4 12" />
  ),

  /* exclamation mark (!) */
  alert: (
    <>
      <line x1="12" y1="5" x2="12" y2="14" />
      <line x1="12" y1="19" x2="12" y2="19.01" />
    </>
  )

};

const DetailIcon = ({ type, size = 20, strokeWidth = 2 }) => {

  if (!ICON_PATHS[type]) {
    return null;
  }

  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      {ICON_PATHS[type]}
    </svg>
  );
};


/* ============================================================
   EXPANDED DETAILS STRUCTURE
   Student -> Fee -> Payment -> Other
   (value(bill) works on the normalized bill)
   ============================================================ */

const formatDateTime = (value) => {

  if (!value) {
    return "";
  }

  const date = new Date(value);

  if (Number.isNaN(date.getTime())) {
    return String(value);
  }

  return date.toLocaleString("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit"
  });
};


/* ============================================================
   PAYMENT SCHEDULE (expanded row) : Advance / Month 1 / Month 2 ...
   Each row shows method, due date, amount, status and the invoice no
   of the payment that cleared it (click the invoice no to open it).
   ============================================================ */

const asList = (value) => {
  if (Array.isArray(value)) return value;
  if (typeof value === "string" && value.trim().startsWith("[")) {
    try {
      const parsed = JSON.parse(value);
      return Array.isArray(parsed) ? parsed : [];
    } catch (err) {
      return [];
    }
  }
  return [];
};

const firstOf = (obj, keys) => {
  for (const key of keys) {
    const v = obj ? obj[key] : undefined;
    if (v !== undefined && v !== null && v !== "") return v;
  }
  return "";
};

const payInvoiceNo = (p) => firstOf(p, ["invoice_number", "invoice_no", "invoice"]);
const payMethodOf = (p) => firstOf(p, ["method", "payment_method"]);
const payDateOf = (p) => firstOf(p, ["payment_date", "date", "created_at"]);

const buildSchedule = (bill) => {
  const raw = bill.raw || {};
  const payments = asList(raw.payments);
  const rawInst = asList(raw.installments);
  const fallbackMethod = firstOf(raw, ["payment_method"]);
  const fallbackInvoice = firstOf(raw, ["invoice_number"]);

  const rows = [];
  let cursor = 0; /* next payment that is not yet linked to a row */

  const takePayment = () => (cursor < payments.length ? payments[cursor++] : null);

  const makeRow = (label, payment, extra) => ({
    label,
    method: (payment && payMethodOf(payment)) || fallbackMethod || "-",
    invoiceNo: (payment && payInvoiceNo(payment)) || "",
    payDate: payment ? String(payDateOf(payment)).slice(0, 10) : "",
    ...extra
  });

  /* full payment : one row */
  if (bill.plan === "full") {
    const p = takePayment();
    rows.push(
      makeRow("Full Payment", p, {
        due: bill.billingDate,
        amount: bill.finalFee,
        paid: bill.isPaid,
        invoiceNo: (p && payInvoiceNo(p)) || fallbackInvoice
      })
    );
    return rows;
  }

  /* advance row */
  if (bill.advance > 0) {
    const p = takePayment();
    rows.push(
      makeRow("Advance Paid", p, {
        due: bill.billingDate,
        amount: bill.advance,
        paid: true,
        invoiceNo: (p && payInvoiceNo(p)) || fallbackInvoice
      })
    );
  }

  /*
   * installments
   * the first installment that was paid as the advance is the "Advance Paid" row
   * already -> it is not shown again as "Month 1" (only the advance + the next
   * due dates are listed, the months are numbered from 1)
   */
  let monthNo = 0;
  let advanceCovered = false;

  bill.installments.forEach((i, index) => {
    if (
      !advanceCovered &&
      index === 0 &&
      bill.plan !== "full" &&
      bill.advance > 0 &&
      i.paid &&
      Math.round(num(i.amount) * 100) === Math.round(num(bill.advance) * 100)
    ) {
      advanceCovered = true;
      return;
    }

    monthNo += 1;
    const source = rawInst[index] || {};
    const linked = payments.find((p) => {
      const ref = firstOf(p, ["installment", "installment_id", "installment_no"]);
      if (ref !== "" && (String(ref) === String(i.id) || String(ref) === String(i.no))) return true;
      /* one payment can clear several rows -> it lists them in "allocations" */
      return asList(p.allocations).some((a) => String(a.installment_id) === String(i.id));
    });
    const p = linked || (i.paid || i.paidAmount > 0 ? takePayment() : null);
    const partial = !i.paid && i.paidAmount > 0;

    rows.push(
      makeRow(`Month ${monthNo}`, p, {
        due: i.date,
        amount: i.amount,
        paid: Boolean(i.paid),
        left: instLeft(i),
        partial,
        invoiceNo: firstOf(source, ["invoice_number", "invoice_no"]) || (p && payInvoiceNo(p)) || ""
      })
    );
  });

  return rows;
};

const REG_DATE_KEYS = ["registration_date", "reg_date", "date_of_registration", "created_at"];

const getInfoFields = (bill) => {
  const reg = bill.registration || {};
  const regDate = firstOf(reg, REG_DATE_KEYS);

  return [
    { label: "Reg Date", icon: "plan", color: "#696cff", value: regDate ? formatDisplayDate(String(regDate).slice(0, 10)) : "" },
    { label: "Enquiry No", icon: "enquiry", color: "#ffab00", value: bill.enquiryNo },
    { label: "Phone", icon: "phone", color: "#71dd37", value: bill.phone },
    { label: "Email", icon: "email", color: "#03c3ec", value: bill.email },
    { label: "Address", icon: "location", color: "#ff3e1d", value: firstOf(reg, ["address", "student_address"]) },
    { label: "Billing Date", icon: "plan", color: "#03c3ec", value: bill.billingDate ? formatDisplayDate(bill.billingDate) : "" },
    {
      label: "Discount Validity",
      icon: "validity",
      color: "#71dd37",
      value: bill.discountValidity ? formatDisplayDate(bill.discountValidity) : ""
    },
    {
      label: "Balance Due Date",
      icon: "validity",
      color: "#ffab00",
      value: bill.balanceDueDate ? formatDisplayDate(bill.balanceDueDate) : ""
    },
    { label: "Remarks", icon: "remarks", color: "#696cff", value: bill.remarks }
  ];
};


/* ============================================================
   PAYMENT MODAL  (Paid / Pending button -> "Installments")
   ============================================================ */

/* money still to be paid on one installment */
const instLeft = (i) => Math.max(num(i.amount) - num(i.paidAmount), 0);

/*
 * Same rule as the backend (services.py -> _allocate).
 * A payment goes into the due dates in order:
 *   - more than the first pending due date needs -> it is paid in full
 *     and the rest goes to the next due date
 *   - less than it needs -> that due date becomes the amount paid and the
 *     shortfall moves on:
 *       next due date exists -> added to it (15000 + 15000, pay 10000
 *                               -> 10000 + 20000)
 *       it was the last one  -> a NEW due date (next month) is created
 *                               (10000 paid + 25000, pay 5000
 *                               -> 10000 + 5000 paid + 20000 new)
 * Works in paise so there is no decimal error.
 * Returns {
 *   amounts : { [installment id]: the amount that due date will show },
 *   paidIds : [ids the payment will cover (not shown as Paid until saved)],
 *   extra   : the new due date row that will be created (or null)
 * }
 */
const previewAmounts = (installments, rupees) => {
  const total = Math.round(num(rupees) * 100);
  const pending = installments.filter((i) => instLeft(i) > 0);
  const amounts = {};
  const paidIds = [];
  let extra = null;

  let rest = total;

  for (let index = 0; index < pending.length && rest > 0; index += 1) {
    const row = pending[index];
    const left = Math.round(instLeft(row) * 100);

    if (rest >= left) {
      rest -= left;
      paidIds.push(row.id);
    } else {
      const next = pending[index + 1];
      const paidBefore = Math.round(num(row.paidAmount) * 100);

      amounts[row.id] = (paidBefore + rest) / 100;
      paidIds.push(row.id);

      if (next) {
        amounts[next.id] =
          (Math.round(num(next.amount) * 100) + (left - rest)) / 100;
      } else {
        extra = {
          no: Math.max(...installments.map((i) => num(i.no))) + 1,
          date: row.date ? addMonths(row.date, 1) : "",
          amount: (left - rest) / 100
        };
      }

      rest = 0;
    }
  }

  return { amounts, paidIds, extra };
};

const PaymentModal = ({ bill, onClose, onPay, saving }) => {

  /* default = the amount of the first due date that is not paid yet */
  const firstPending = bill.installments.find((i) => instLeft(i) > 0);

  const [amount, setAmount] = useState(
    firstPending
      ? String(instLeft(firstPending))
      : bill.balance > 0
        ? String(bill.balance)
        : ""
  );
  const [method, setMethod] = useState(PAYMENT_METHODS[0]);

  /* due date amounts as they will be after the typed payment (live) */
  const { amounts: shares, extra } = previewAmounts(
    bill.installments,
    amount
  );

  return (
    <div className="bill-pay-overlay" onClick={onClose}>
      <div
        className="bill-pay-box"
        role="dialog"
        aria-modal="true"
        onClick={(e) => e.stopPropagation()}
      >

        <div className="bill-pay-header">
          <div>
            <h3>Payments</h3>
            <p>{bill.name}{bill.course ? ` • ${bill.course}` : ""}</p>
          </div>

          <button
            type="button"
            className="bill-pay-close"
            aria-label="Close"
            onClick={onClose}
          >
            &times;
          </button>
        </div>

        <div className="bill-pay-summary">
          <div>
            <small>Final Fee</small>
            <strong>{money(bill.finalFee)}</strong>
          </div>

          <div>
            <small>Paid</small>
            <strong className="text-success">{money(bill.paid)}</strong>
          </div>

          <div>
            <small>Balance</small>
            <strong className={bill.balance > 0 ? "text-danger" : "text-success"}>
              {money(bill.balance)}
            </strong>
          </div>
        </div>

        {/* installment list (status comes from the saved data) */}
        {bill.installments.length > 0 && (
          <div className="bill-pay-table-wrap">
            <table className="bill-pay-table">
              <thead>
                <tr>
                  <th>#</th>
                  <th>DUE DATE</th>
                  <th>AMOUNT</th>
                  <th>STATUS</th>
                </tr>
              </thead>

              <tbody>
                {bill.installments.map((i) => (
                  <tr key={i.id}>
                    <td>{i.no}</td>
                    <td>{formatDisplayDate(i.date)}</td>
                    <td>
                      {/* typed amount -> what this due date will become */}
                      {shares[i.id] !== undefined
                        ? money(shares[i.id])
                        : money(i.amount)}
                    </td>
                    <td>
                      <span
                        className={`badge ${
                          i.paid ? "bg-label-success" : "bg-label-danger"
                        }`}
                      >
                        {i.paid ? "Paid" : "Pending"}
                      </span>
                    </td>
                  </tr>
                ))}

                {/* new due date that this payment will create */}
                {extra && (
                  <tr>
                    <td>{extra.no}</td>
                    <td>{formatDisplayDate(extra.date)}</td>
                    <td>{money(extra.amount)}</td>
                    <td>
                      <span className="badge bg-label-danger">Pending</span>
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        )}

        {/* custom payment */}
        {bill.balance > 0 && (
          <div className="bill-pay-custom">
            <h6>Enter amount (default = next due date)</h6>

            <div className="bill-pay-row">
              <div>
                <label>AMOUNT</label>
                <input
                  type="number"
                  className="form-control"
                  min="1"
                  max={bill.balance}
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                />
              </div>

              <div>
                <label>METHOD</label>
                <select
                  className="form-select"
                  value={method}
                  onChange={(e) => setMethod(e.target.value)}
                >
                  {PAYMENT_METHODS.map((m) => (
                    <option key={m}>{m}</option>
                  ))}
                </select>
              </div>

              <div>
                <button
                  type="button"
                  className="btn btn-primary w-100"
                  disabled={saving || num(amount) <= 0 || num(amount) > bill.balance}
                  onClick={() =>
                    onPay({ amount: num(amount), method, payment_date: getToday() })
                  }
                >
                  {saving ? "Saving..." : "Make Payment"}
                </button>
              </div>
            </div>
          </div>
        )}

        {bill.balance <= 0 && (
          <div className="alert alert-success mb-0">
            Fees fully paid.
          </div>
        )}

      </div>
    </div>
  );
};


/* ============================================================
   BILLING COMPONENT
   ============================================================ */

function Billing() {

  /* ALL API calls come from AuthContext */
  const { getData, insert } = useContext(AuthContext);

  /* a list from AuthContext -> getData(endpoint) (nothing back = failed) */
  const loadList = async (endpoint) => {

    const list = await getData(endpoint);

    if (!Array.isArray(list)) {
      throw new Error("Unable to load data from server.");
    }

    return list;

  };

  const [pageMode, setPageMode] = useState("list");

  const [editingRecord, setEditingRecord] = useState(null);

  const [billings, setBillings] = useState([]);
  const [registrations, setRegistrations] = useState([]);

  const [searchName, setSearchName] = useState("");
  const [searchPhone, setSearchPhone] = useState("");
  const [searchCourse, setSearchCourse] = useState("");
  const [searchDate, setSearchDate] = useState("");

  const [statusFilter, setStatusFilter] = useState("all"); /* all | paid | pending */

  const [expandedId, setExpandedId] = useState(null);

  const [loading, setLoading] = useState(false);

  const [paymentBill, setPaymentBill] = useState(null);

  /* invoice popup opened from the list */
  const [invoiceData, setInvoiceData] = useState(null);
  const [paymentSaving, setPaymentSaving] = useState(false);


  /* ============================================================
     POPUP ALERT (same popup as Registration.jsx)
     type: "error" | "warning" | "success"
     onConfirm: when given, the popup shows Cancel + confirm buttons
     ============================================================ */

  const [popup, setPopup] = useState(null);

  const showAlert = (
    text,
    title = "Validation Error",
    type = "error",
    onConfirm = null,
    confirmLabel = "Yes"
  ) => {
    setPopup({ text, title, type, onConfirm, confirmLabel });
  };

  const closePopup = () => setPopup(null);

  const confirmPopup = () => {

    const action = popup && popup.onConfirm;

    setPopup(null);

    if (action) {
      action();
    }
  };

  /* Esc key closes the popup / payment box */
  useEffect(() => {

    if (!popup && !paymentBill) {
      return undefined;
    }

    const onKey = (e) => {
      if (e.key === "Escape") {
        setPopup(null);
        setPaymentBill(null);
      }
    };

    window.addEventListener("keydown", onKey);

    return () => window.removeEventListener("keydown", onKey);

  }, [popup, paymentBill]);


  /* ============================================================
     GET BILLINGS  (AuthContext -> getData "fetch_billing_detail")
     + registrations (student name, phone, course, photo)
     ============================================================ */

  const fetchBillings = async () => {

    try {

      setLoading(true);

      const [billingList, registrationList] = await Promise.all([
        loadList("fetch_billing_detail"),
        /* a failed registration call must not hide the bills */
        loadList("fetch_registration_datail").catch((error) => {
          console.error("Error fetching registrations:", error);
          return [];
        })
      ]);

      setBillings(billingList);
      setRegistrations(registrationList);

    }

    catch (error) {

      console.error("Error fetching billings:", error);

      console.error("Response:", error.responseData);

      setBillings([]);

    }

    finally {

      setLoading(false);

    }

  };


  useEffect(() => {

    fetchBillings();

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);


  /* ============================================================
     SEARCH BOX VALIDATION (wrong typing shows the popup alert)
     ============================================================ */

  /* student name: letters only (space . ' - allowed) */
  const handleSearchName = (e) => {

    const value = e.target.value;

    if (/^\s/.test(value)) {
      showAlert("Student name cannot start with a space.");
      return;
    }

    if (/\s{2,}/.test(value)) {
      showAlert("Only one space is allowed between words.");
      return;
    }

    if (!/^[A-Za-z\s.'-]*$/.test(value)) {
      showAlert("Please type letters only for student name.");
      return;
    }

    if (value.length > 150) {
      showAlert("Student name cannot be more than 150 characters.");
      return;
    }

    setSearchName(value);
  };

  /* phone: numbers only, maximum 10 digits */
  const handleSearchPhone = (e) => {

    const value = e.target.value;

    if (!/^\d*$/.test(value)) {
      showAlert("Please type numbers only for phone number.");
      return;
    }

    if (value.length > 10) {
      showAlert("Phone number cannot be more than 10 digits.");
      return;
    }

    setSearchPhone(value);
  };

  const handleSearchCourse = (e) => {

    const value = e.target.value;

    if (/^\s/.test(value)) {
      showAlert("Course cannot start with a space.");
      return;
    }

    if (value.length > 150) {
      showAlert("Course cannot be more than 150 characters.");
      return;
    }

    setSearchCourse(value);
  };

  const handleSearchDate = (e) => {

    const value = e.target.value;

    if (value) {

      const match = value.match(/^(\d{4,6})-(\d{2})-(\d{2})$/);

      const year = match ? Number(match[1]) : 0;

      if (!match || year < 2000 || year > 2100) {
        showAlert("Please select a valid date (year between 2000 and 2100).");
        return;
      }
    }

    setSearchDate(value);
  };


  /* ============================================================
     SEARCH
     ============================================================ */

  const bills = billings.map((record) =>
    normalizeBilling(record, registrations)
  );

  const filteredBills = bills.filter((bill) => {

    /* search matches from the FIRST letter / number only (not the middle) */
    const startsWith = (value, query) =>
      String(value || "")
        .trim()
        .toLowerCase()
        .startsWith(String(query).trim().toLowerCase());

    const nameMatch = !searchName.trim() || startsWith(bill.name, searchName);
    const phoneMatch = !searchPhone.trim() || startsWith(bill.phone, searchPhone);
    const courseMatch = !searchCourse.trim() || startsWith(bill.course, searchCourse);
    const dateMatch =
      !searchDate || String(bill.billingDate || "").includes(searchDate);

    const statusMatch =
      statusFilter === "all" ||
      (statusFilter === "paid" && bill.isPaid) ||
      (statusFilter === "pending" && !bill.isPaid);

    return nameMatch && phoneMatch && courseMatch && dateMatch && statusMatch;
  });

  const personRegIds = buildPersonRegIds(registrations);
  const personPhotos = buildPersonPhotos(registrations);

  const stats = {
    students: bills.length,
    fees: bills.reduce((sum, bill) => sum + bill.finalFee, 0),
    paid: bills.reduce((sum, bill) => sum + bill.paid, 0),
    balance: bills.reduce((sum, bill) => sum + Math.max(bill.balance, 0), 0)
  };

  const clearSearch = () => {
    setSearchName("");
    setSearchPhone("");
    setSearchCourse("");
    setSearchDate("");
    setStatusFilter("all");
  };

  /* open the invoice popup. row = one line of the payment schedule (optional):
     the invoice then shows that payment only (its no, date, method, amount) */
  const openInvoice = (bill, schedule = null, row = null) => {
    const base = buildInvoiceFromBill(
      bill,
      getDisplayRegistrationId(bill.registration, personRegIds)
    );

    /* dues still to come: every unpaid row after this payment (all unpaid rows when no row) */
    const startAt = row && schedule ? schedule.indexOf(row) + 1 : 0;
    const list = schedule || buildSchedule(bill);
    const future = list
      .slice(Math.max(startAt, 0))
      .filter((r) => !r.paid && r.label !== "Full Payment")
      .map((r) => ({
        date: String(r.due || "").slice(0, 10),
        amount: r.left !== undefined ? r.left : num(r.amount)
      }))
      .filter((r) => r.amount > 0);

    if (!row) {
      setInvoiceData({ ...base, future });
      return;
    }

    /* money paid up to and including this row = balance left after it */
    let cumulative = 0;
    for (const r of schedule) {
      if (r.paid) cumulative += num(r.amount);
      if (r === row) break;
    }

    setInvoiceData({
      ...base,
      invoiceNo: row.invoiceNo || base.invoiceNo,
      date: invoiceDate(row.payDate || bill.billingDate),
      paymentMethod: row.method || base.paymentMethod,
      paidToday: row.amount,
      future,
      balance: Math.max(num(bill.finalFee) - cumulative, 0)
    });
  };

  const toggleExpand = (id) => {
    setExpandedId(expandedId === id ? null : id);
  };


  /* ============================================================
     AFTER ADD / EDIT BILLING
     ============================================================ */

  const handleBillingSaved = () => {

    setEditingRecord(null);

    setPageMode("list");

    fetchBillings();

  };


  /* ============================================================
     DELETE BILLING  (AuthContext -> insert "delete_billing_detail")
     ============================================================ */

  const handleDelete = async (bill) => {

    const id = bill.id;

    if (!id) {

      showAlert("Billing ID not found.", "Not Found");

      return;

    }

    /* confirmation popup instead of the browser confirm box */

    showAlert(
      `Are you sure you want to delete the billing of ${
        bill.name || "this student"
      }${bill.course ? ` (${bill.course})` : ""}?`,
      "Delete Billing",
      "warning",
      async () => {

        try {

          const response = await insert(
            { billing_id: id },
            "delete_billing_detail"
          );

          /* a delete with no body (204) is also a success */
          if (response && response.success === false) {
            const failure = new Error("Delete failed");
            failure.responseData = response;
            throw failure;
          }

          showAlert(
            "Billing deleted successfully.",
            "Deleted",
            "success"
          );

          fetchBillings();

        }

        catch (error) {

          console.error("Delete billing error:", error);

          const backendMessage =
            error.responseData?.message ||
            error.responseData?.error ||
            error.responseData?.detail;

          showAlert(backendMessage || "Unable to delete billing.", "Unable to Delete");

        }

      },
      "Delete"
    );

  };


  /* ============================================================
     MAKE PAYMENT  (AuthContext -> insert "pay_billing_detail")
     ============================================================ */

  const handlePay = async (payload) => {

    if (!paymentBill) {
      return;
    }

    try {

      setPaymentSaving(true);

      const response = await insert(
        { billing_id: paymentBill.id, ...payload },
        "pay_billing_detail"
      );

      if (response && response.success === false) {
        const failure = new Error("Payment failed");
        failure.responseData = response;
        throw failure;
      }

      const name = paymentBill.name;

      setPaymentBill(null);

      await fetchBillings();

      showAlert(
        `Payment of ${money(payload.amount)} recorded for ${name}.`,
        "Payment Saved",
        "success"
      );

    }

    catch (error) {

      console.error("Payment error:", error);

      const backendMessage =
        error.responseData?.message ||
        error.responseData?.error ||
        error.responseData?.detail;

      showAlert(
        backendMessage ||
          (error.status
            ? `Payment failed (${error.status}).`
            : "Unable to record the payment."),
        "Unable to Pay"
      );

    }

    finally {

      setPaymentSaving(false);

    }

  };


  /* ============================================================
     EDIT BILLING
     OPENS THE ADD BILLING FORM WITH THE RECORD FILLED IN
     ============================================================ */

  const handleEdit = (bill) => {

    if (!bill.id) {

      showAlert("Billing ID not found.", "Not Found");

      return;

    }

    setEditingRecord(bill);

    setPageMode("edit");

  };


  /* ============================================================
     ADD / EDIT PAGES
     ============================================================ */

  if (pageMode === "add") {

    return (

      <Addbilling
        onBack={() => setPageMode("list")}
        onSaved={handleBillingSaved}
      />

    );

  }


  if (pageMode === "edit" && editingRecord) {

    return (

      <Updatebilling
        key={editingRecord.id}
        billing={editingRecord}
        onClose={() => {
          setEditingRecord(null);
          setPageMode("list");
        }}
        onSuccess={handleBillingSaved}
      />

    );

  }


  /* ============================================================
     LIST PAGE
     ============================================================ */

  const STAT_CARDS = [
    { label: "Students", value: stats.students, tone: "#696cff", raw: true },
    { label: "Total Fees", value: stats.fees, tone: "#03c3ec" },
    { label: "Collected", value: stats.paid, tone: "#71dd37" },
    { label: "Pending", value: stats.balance, tone: "#ff3e1d" }
  ];

  const FILTERS = [
    { key: "all", label: "All" },
    { key: "paid", label: "Fully Paid" },
    { key: "pending", label: "Pending" }
  ];

  return (

    <div className="billing-page">

      {/* ========================================================
          HEADER
          ======================================================== */}

      <div className="billing-header">

        <div>

          <h2>Billing Management</h2>

        </div>

        <button
          type="button"
          className="billing-add-btn btn btn-primary"
          onClick={() => setPageMode("add")}
        >

          <span>+</span>

          Add Billing

        </button>

      </div>


      {/* ========================================================
          STAT CARDS
          ======================================================== */}

      <div className="billing-stats">

        {STAT_CARDS.map((card) => (

          <div className="billing-stat" key={card.label}>

            <span
              className="billing-stat-bar"
              style={{ background: card.tone }}
            ></span>

            <small>{card.label}</small>

            <strong>{card.raw ? card.value : money(card.value)}</strong>

          </div>

        ))}

      </div>


      {/* ========================================================
          SEARCH SECTION
          ======================================================== */}

      <div className="billing-search-card">

        <div className="billing-search-grid">

          {/* NAME */}
          <div className="billing-search-field">
            <div className="billing-input-wrapper">
              <span>⌕</span>
              <input
                type="text"
                placeholder="Student name"
                value={searchName}
                maxLength="151"
                onChange={handleSearchName}
              />
            </div>
          </div>

          {/* PHONE */}
          <div className="billing-search-field">
            <div className="billing-input-wrapper">
              <span>⌕</span>
              <input
                type="text"
                placeholder="Phone number"
                value={searchPhone}
                inputMode="numeric"
                onChange={handleSearchPhone}
              />
            </div>
          </div>

          {/* COURSE */}
          <div className="billing-search-field">
            <div className="billing-input-wrapper">
              <span>⌕</span>
              <input
                type="text"
                placeholder="Course"
                value={searchCourse}
                maxLength="151"
                onChange={handleSearchCourse}
              />
            </div>
          </div>

          {/* DATE */}
          <div className="billing-search-field">
            <input
              type="date"
              value={searchDate}
              min="2000-01-01"
              max="2100-12-31"
              onChange={handleSearchDate}
            />
          </div>

        </div>

        {/* SEARCH BOTTOM */}
        <div className="billing-search-bottom">

          <span>
            Showing {filteredBills.length} billings
          </span>

          <div>

            {FILTERS.map((filter) => (

              <button
                key={filter.key}
                type="button"
                className={`billing-filter-btn ${
                  statusFilter === filter.key ? "active" : ""
                }`}
                onClick={() => setStatusFilter(filter.key)}
              >
                {filter.label}
              </button>

            ))}

            <button
              type="button"
              className="billing-clear-btn"
              onClick={clearSearch}
            >
              Clear
            </button>

            <button
              type="button"
              className="billing-refresh-btn btn btn-primary"
              onClick={fetchBillings}
            >
              Refresh
            </button>

          </div>

        </div>

      </div>


      {/* ========================================================
          BILLING TABLE
          ======================================================== */}

      <div className="billing-list-card">

        <div className="billing-table-container">

          <table className="billing-table">

            <thead>

              <tr>
                <th></th>
                <th>S.NO</th>
                <th>REG ID</th>
                <th>NAME</th>
                <th>PHONE</th>
                <th>COURSE</th>
                <th>PLAN</th>
                <th>FINAL FEE</th>
                <th>PAID</th>
                <th>BALANCE</th>
                <th>STATUS</th>
              </tr>

            </thead>

            <tbody>

              {loading ? (

                <tr>
                  <td colSpan="11" className="billing-empty">
                    Loading...
                  </td>
                </tr>

              ) : filteredBills.length === 0 ? (

                <tr>
                  <td colSpan="11" className="billing-empty">
                    No billings found
                  </td>
                </tr>

              ) : (

                filteredBills.map((bill, index) => {

                  const rowId = bill.id ?? index;

                  /* own photo first, otherwise the photo of the same person (same enquiry no) */
                  const photoCandidates = buildFileCandidates(
                    getStudentPhotoValue(bill.registration) ||
                      personPhotos[String(bill.enquiryNo || "")] ||
                      "",
                    apiUrl
                  );

                  return (

                    <React.Fragment key={rowId}>

                      {/* MAIN ROW */}
                      <tr>

                        {/* EXPAND */}
                        <td>
                          <button
                            type="button"
                            className="billing-expand-btn"
                            onClick={() => toggleExpand(rowId)}
                          >
                            {expandedId === rowId ? "−" : "+"}
                          </button>
                        </td>

                        {/* SERIAL NUMBER 1,2,3... */}
                        <td>{index + 1}</td>

                        {/* REGISTRATION ID */}
                        <td
                          className="billing-id"
                          style={{ whiteSpace: "nowrap" }}
                        >
                          {getDisplayRegistrationId(bill.registration, personRegIds)}
                        </td>

                        {/* NAME + PHOTO */}
                        <td>

                          <div className="billing-student-cell">

                            <div className="billing-student-photo">

                              <FallbackImage
                                candidates={photoCandidates}
                                alt={bill.name || "Student"}
                                fallback={
                                  <div
                                    className="billing-student-photo-placeholder"
                                    style={{ display: "flex" }}
                                  >
                                    <svg
                                      width="22"
                                      height="22"
                                      viewBox="0 0 24 24"
                                      fill="none"
                                      stroke="currentColor"
                                      strokeWidth="1.8"
                                      strokeLinecap="round"
                                      strokeLinejoin="round"
                                    >
                                      <path d="M20 21a8 8 0 0 0-16 0" />
                                      <circle cx="12" cy="7" r="4" />
                                    </svg>
                                  </div>
                                }
                              />

                            </div>

                            <span>{bill.name || "-"}</span>

                          </div>

                        </td>

                        <td style={{ whiteSpace: "nowrap" }}>
                          {bill.phone || "-"}
                        </td>

                        <td>{bill.course || "-"}</td>

                        <td>
                          <span className="billing-plan-badge">
                            {PLAN_LABEL[bill.plan]}
                          </span>
                        </td>

                        <td style={{ whiteSpace: "nowrap" }}>
                          {money(bill.finalFee)}
                        </td>

                        <td
                          className="billing-paid"
                          style={{ whiteSpace: "nowrap" }}
                        >
                          {money(bill.paid)}
                        </td>

                        <td
                          className={
                            bill.balance > 0 ? "billing-due" : "billing-paid"
                          }
                          style={{ whiteSpace: "nowrap" }}
                        >
                          {money(Math.max(bill.balance, 0))}
                        </td>

                        {/* STATUS - opens the payments box */}
                        <td>

                          <button
                            type="button"
                            className={`billing-status-btn status-${
                              bill.isPaid ? "paid" : "pending"
                            }`}
                            onClick={() => setPaymentBill(bill)}
                            title={
                              bill.isPaid
                                ? "View payments"
                                : "Click to make a payment"
                            }
                          >
                            <span className="billing-status-dot"></span>
                            {bill.isPaid ? "Paid" : "Pending"}
                          </button>

                        </td>

                      </tr>


                      {/* EXPANDED DETAILS (student info + payment schedule) */}
                      {expandedId === rowId && (() => {

                        const schedule = buildSchedule(bill);

                        return (

                          <tr>

                            <td
                              colSpan="11"
                              style={{
                                padding: "0",
                                background: "#f5f5f9",
                                borderTop: "1px solid #e7e7eb"
                              }}
                            >

                              <div className="billing-details-wrap">

                                {/* STUDENT INFO */}
                                <div className="bsn-card">

                                  <div className="bsn-info">
                                    {getInfoFields(bill).map((f) => (
                                      <div className="bsn-info-item" key={f.label}>
                                        <div
                                          className="bsn-info-icon"
                                        >
                                          <DetailIcon type={f.icon} size={20} />
                                        </div>
                                        <div className="bsn-info-text">
                                          <span className="bsn-info-label">
                                            {f.label}
                                          </span>
                                          <span className="bsn-info-value">
                                            {f.value === "" || f.value === null || f.value === undefined
                                              ? "-"
                                              : f.value}
                                          </span>
                                        </div>
                                      </div>
                                    ))}
                                  </div>

                                </div>

                                {/* PAYMENT SCHEDULE */}
                                <div className="bsn-card bsn-sched-card">

                                  <div className="bsn-sched-scroll">

                                    <table className="bsn-sched">

                                      <thead>
                                        <tr>
                                          <th>SCHEDULE</th>
                                          <th>PAYMENT METHOD</th>
                                          <th>DUE DATE</th>
                                          <th>AMOUNT</th>
                                          <th>STATUS</th>
                                          <th>INVOICE NO</th>
                                        </tr>
                                      </thead>

                                      <tbody>
                                        {schedule.length === 0 && (
                                          <tr>
                                            <td colSpan="6" className="bsn-sched-empty">
                                              No payment schedule
                                            </td>
                                          </tr>
                                        )}

                                        {schedule.map((row, i) => (
                                          <tr key={`${row.label}-${i}`} className={row.paid ? "is-paid" : "is-open"}>
                                            <td className="bsn-sched-name"><span className={`bsn-dot ${row.paid ? "paid" : row.partial ? "partial" : "pending"}`} />{row.label}</td>
                                            <td>{row.method && row.method !== "-" ? <span className={`bsn-method m-${String(row.method).toLowerCase().replace(/[^a-z]/g, "")}`}>{row.method}</span> : "-"}</td>
                                            <td>{row.due ? formatDisplayDate(row.due) : "-"}</td>
                                            <td className="bsn-amount">{money(row.amount)}</td>
                                            <td>
                                              <span
                                                className={`bsn-status ${
                                                  row.paid
                                                    ? "paid"
                                                    : row.partial
                                                      ? "partial"
                                                      : "pending"
                                                }`}
                                              >
                                                {row.paid ? "Paid" : row.partial ? "Partial" : "Pending"}
                                              </span>
                                            </td>
                                            <td>
                                              {row.invoiceNo ? (
                                                <div className="bsn-invoice-cell">
                                                  <button
                                                    type="button"
                                                    className="bsn-invoice-link"
                                                    onClick={() => openInvoice(bill, schedule, row)}
                                                    title="Open invoice"
                                                  >
                                                    <i className="bx bx-receipt"></i> {String(row.invoiceNo).toUpperCase()}
                                                  </button>

                                                  <button
                                                    type="button"
                                                    className="bsn-row-btn edit"
                                                    onClick={() => handleEdit(bill)}
                                                    title="Edit billing"
                                                    aria-label="Edit billing"
                                                  >
                                                    <DetailIcon type="edit" size={16} />
                                                  </button>

                                                  <button
                                                    type="button"
                                                    className="bsn-row-btn delete"
                                                    onClick={() => handleDelete(bill)}
                                                    title="Delete billing"
                                                    aria-label="Delete billing"
                                                  >
                                                    <DetailIcon type="delete" size={16} />
                                                  </button>
                                                </div>
                                              ) : i === 0 && !schedule.some((r) => r.invoiceNo) ? (
                                                <div className="bsn-invoice-cell">
                                                  <button
                                                    type="button"
                                                    className="bsn-row-btn edit"
                                                    onClick={() => handleEdit(bill)}
                                                    title="Edit billing"
                                                    aria-label="Edit billing"
                                                  >
                                                    <DetailIcon type="edit" size={16} />
                                                  </button>

                                                  <button
                                                    type="button"
                                                    className="bsn-row-btn delete"
                                                    onClick={() => handleDelete(bill)}
                                                    title="Delete billing"
                                                    aria-label="Delete billing"
                                                  >
                                                    <DetailIcon type="delete" size={16} />
                                                  </button>
                                                </div>
                                              ) : (
                                                "-"
                                              )}
                                            </td>
                                          </tr>
                                        ))}
                                      </tbody>

                                    </table>

                                  </div>

                                </div>

                              </div>

                            </td>

                          </tr>

                        );

                      })()}

                    </React.Fragment>

                  );

                })

              )}

            </tbody>

          </table>

        </div>

        {/* COUNT */}
        <div className="billing-pagination">
          Showing 1-{filteredBills.length} of {billings.length}
        </div>

      </div>


      {/* ========================================================
          PAYMENTS BOX
          ======================================================== */}

      {paymentBill && (

        <PaymentModal
          bill={paymentBill}
          saving={paymentSaving}
          onClose={() => setPaymentBill(null)}
          onPay={handlePay}
        />

      )}


      {/* ========================================================
          VALIDATION / MESSAGE POPUP
          ======================================================== */}

      {popup && (

        <div className="bill-alert-overlay" onClick={closePopup}>

          <div
            className={`bill-alert-box ${popup.type}`}
            role="alertdialog"
            aria-modal="true"
            onClick={(e) => e.stopPropagation()}
          >

            <button
              type="button"
              className="bill-alert-close"
              aria-label="Close"
              onClick={closePopup}
            >
              &times;
            </button>

            <div className="bill-alert-icon">
              <DetailIcon
                type={popup.type === "success" ? "tick" : "alert"}
                size={38}
                strokeWidth={2.6}
              />
            </div>

            <h4 className="bill-alert-title">{popup.title}</h4>

            <p className="bill-alert-text">{popup.text}</p>

            <div className="bill-alert-actions">

              {popup.onConfirm && (
                <button
                  type="button"
                  className="bill-alert-btn cancel"
                  onClick={closePopup}
                >
                  Cancel
                </button>
              )}

              <button
                type="button"
                className={`bill-alert-btn${popup.onConfirm ? " danger" : ""}`}
                onClick={popup.onConfirm ? confirmPopup : closePopup}
                autoFocus
              >
                {popup.onConfirm ? popup.confirmLabel : "Got it"}
              </button>

            </div>

          </div>

        </div>

      )}

      {/* INVOICE POPUP (from the Invoice button or an invoice no in the schedule) */}
      {invoiceData && (
        <Invoice
          key={invoiceData.invoiceNo + invoiceData.date}
          data={invoiceData}
          onClose={() => setInvoiceData(null)}
        />
      )}

    </div>

  );

}

export default Billing;
