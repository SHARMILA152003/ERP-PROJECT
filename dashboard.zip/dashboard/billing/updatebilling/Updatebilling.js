import React from "react";

import Addbilling from "../addbilling/Addbilling";

/*
 * EDIT BILLING
 *
 * Shows the exact Addbilling form (same steps, same fields,
 * same validations) filled with the selected billing.
 * Every field can be changed manually and saved.
 *
 * Props
 *   billing   : the billing record to edit (already passed through normalizeBilling)
 *   onClose   : called when the user cancels / goes back
 *   onSuccess : called after the billing is updated
 */

function Updatebilling({ billing, onClose, onSuccess }) {
  return (
    <Addbilling
      billing={billing}
      onBack={onClose}
      onSaved={onSuccess}
    />
  );
}

export default Updatebilling;
