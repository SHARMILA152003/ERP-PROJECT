import React, { useContext, useState } from "react";
import AuthContext from "../../../services/AuthContext";

const Updatedepartment = (props) => {

    const { update } = useContext(AuthContext);

    const [error, setError] = useState("");

    const handleSubmit = async (e) => {

        e.preventDefault();

        setError("");

        if (
            !/^[A-Za-z]+(?: [A-Za-z]+)*$/.test(
                e.target.Department_standard.value.trim()
            )
        ) {

            setError(
                "Department standard must contain only alphabets (no numbers or symbols)."
            );

            return;
        }

        const departmentData = {
            Department_id: e.target.Department_id.value,
            Department_standard: e.target.Department_standard.value,
            Department_Status: e.target.Department_Status.value
        };

        console.log(departmentData);

        try {

            await update(
                departmentData,
                "update_department_datail",
                "/department"
            );

            props.toggle();

        } catch (error) {

            console.error(
                "Update operation failed:",
                error
            );

            const responseData =
                error.responseData;

            const message =
                responseData &&
                (
                    (Array.isArray(responseData.Department_standard)
                        ? responseData.Department_standard[0]
                        : responseData.Department_standard) ||
                    responseData.message ||
                    responseData.detail
                );

            setError(
                message ||
                "Department could not be updated. Please try again."
            );

        }
    };

    return (
        <div
            className="modal fade show"
            tabIndex="-1"
            role="dialog"
            style={{
                display: "block",
                backgroundColor: "rgba(0,0,0,0.5)"
            }}
        >

            <div
                className="modal-dialog modal-dialog-centered"
                role="document"
            >

                <div className="modal-content">

                    {/* =========================
                        HEADER
                    ========================== */}

                    <div className="modal-header">

                        <h5 className="modal-title">
                            Update Department
                        </h5>

                        <button
                            type="button"
                            className="btn-close"
                            onClick={props.toggle}
                            aria-label="Close"
                        ></button>

                    </div>


                    {/* =========================
                        BODY
                    ========================== */}

                    <div className="modal-body">

                        {error && (
                            <div
                                className="alert alert-danger"
                                role="alert"
                            >
                                <strong>Error!</strong>{" "}
                                {error}
                            </div>
                        )}

                        <form onSubmit={handleSubmit}>

                            {/* Hidden Department ID */}

                            <input
                                type="hidden"
                                name="Department_id"
                                defaultValue={props.data.Department_id}
                            />


                            {/* DEPARTMENT STANDARD */}

                            <div className="mb-3">

                                <label
                                    htmlFor="Department_standard"
                                    className="form-label"
                                >
                                    Department Standard
                                </label>

                                <input
                                    type="text"
                                    defaultValue={props.data.Department_standard}
                                    className="form-control"
                                    name="Department_standard"
                                    id="Department_standard"
                                    onInput={(e) => {
                                        e.target.value = e.target.value.replace(/[^A-Za-z ]/g, "");
                                    }}
                                    placeholder="Enter Department Standard"
                                    required
                                />

                            </div>

                            {/* DEPARTMENT STATUS */}

                            <div className="mb-3">

                                <label
                                    htmlFor="Department_Status"
                                    className="form-label"
                                >
                                    Status
                                </label>

                                <select
                                    id="Department_Status"
                                    name="Department_Status"
                                    className="form-select"
                                    defaultValue={props.data.Department_Status || "Active"}
                                    required
                                >

                                    <option value="Active">
                                        Active
                                    </option>

                                    <option value="Deactive">
                                        Deactive
                                    </option>

                                </select>

                            </div>





                            {/* =========================
                                FOOTER
                            ========================== */}

                            <div className="modal-footer px-0 pb-0">

                                <button
                                    type="button"
                                    className="btn btn-outline-secondary"
                                    onClick={props.toggle}
                                >
                                    Cancel
                                </button>

                                <button
                                    type="submit"
                                    className="btn btn-success"
                                >
                                    Update Department
                                </button>

                            </div>

                        </form>

                    </div>

                </div>

            </div>

        </div>
    );
};

export default Updatedepartment;