import React, { useContext, useState } from "react";
import AuthContext from "../../../services/AuthContext";

const Deletedepartment = (props) => {

    const { Delete, getData } = useContext(AuthContext);

    const [error, setError] = useState("");

    const handleSubmit = async () => {

        setError("");

        try {

            if (props.data) {

                // ---- Check first: is this department used by designations? ----
                // (done here with the list API, so the reason always shows,
                //  and nothing is sent to delete when it is in use)
                try {

                    const designations = await getData(
                        "fetch_designation_datail"
                    );

                    const used = Array.isArray(designations)
                        ? designations.filter(
                              (d) =>
                                  String(d.Department_id) ===
                                  String(props.data)
                          )
                        : [];

                    if (used.length > 0) {

                        const names = used
                            .slice(0, 5)
                            .map((d) => d.Designation_name)
                            .join(", ");

                        setError(
                            "This department cannot be deleted because it is used in " +
                            used.length +
                            " designation(s): " +
                            names +
                            (used.length > 5 ? " ..." : "") +
                            ". Delete or change those designations first."
                        );

                        return;
                    }

                } catch (checkError) {

                    // could not check here - the server still checks and
                    // refuses to delete a department that is in use
                    console.error(
                        "Designation check failed:",
                        checkError
                    );

                }

                const departmentData = {
                    Department_id: props.data,
                };

                await Delete(
                    departmentData,
                    "delete_department_datail",
                    "/department"
                );

                props.toggle();

            } else {

                throw new Error(
                    "Missing or invalid data for deletion"
                );

            }

        } catch (error) {

            console.error(
                "Delete operation failed:",
                error
            );

            const responseData =
                error.responseData;

            const message =
                responseData &&
                (
                    responseData.message ||
                    (Array.isArray(responseData.Department_standard)
                        ? responseData.Department_standard[0]
                        : responseData.Department_standard) ||
                    responseData.detail
                );

            setError(
                message ||
                "Department could not be deleted. It may be in use."
            );

        }
    };


    return (

        <div
            className="modal fade show"
            tabIndex="-1"
            role="dialog"
            style={{
                display: "block",
                backgroundColor: "rgba(0,0,0,0.5)"
            }}
        >

            <div
                className="modal-dialog modal-dialog-centered"
                role="document"
            >

                <div className="modal-content">

                    {/* =========================
                        HEADER
                    ========================== */}

                    <div className="modal-header">

                        <h5 className="modal-title">
                            Warning Message
                        </h5>

                        <button
                            type="button"
                            className="btn-close"
                            onClick={props.toggle}
                            aria-label="Close"
                        ></button>

                    </div>


                    {/* =========================
                        BODY
                    ========================== */}

                    <div className="modal-body text-center">

                        <div className="mb-3">

                            <div
                                className="text-danger mb-3"
                                style={{ fontSize: "40px" }}
                            >
                                ⚠
                            </div>

                            <h5>
                                Are you sure you want to delete?
                            </h5>

                            <p className="text-muted mb-0">
                                This action cannot be undone.
                            </p>

                            {error && (
                                <div
                                    className="alert alert-danger mt-3 mb-0"
                                    role="alert"
                                >
                                    <strong>Error!</strong>{" "}
                                    {error}
                                </div>
                            )}

                        </div>

                    </div>


                    {/* =========================
                        FOOTER
                    ========================== */}

                    <div className="modal-footer">

                        <button
                            type="button"
                            className="btn btn-outline-secondary"
                            onClick={props.toggle}
                        >
                            Cancel
                        </button>

                        <button
                            type="button"
                            onClick={handleSubmit}
                            className="btn btn-danger"
                        >
                            Delete
                        </button>

                    </div>

                </div>

            </div>

        </div>
    );
};

export default Deletedepartment;





