import React, { useContext, useState } from "react";
import AuthContext from "../../../services/AuthContext";
// import "./adddepartment.css";

const Adddepartment = (props) => {

    const { insert } = useContext(AuthContext);

    const [validated, setValidated] = useState(false);
    const [error, setError] = useState("");
    const [success, setSuccess] = useState("");
    const [loading, setLoading] = useState(false);


    const handleSubmit = async (e) => {

        e.preventDefault();

        const form = e.currentTarget;

        setError("");
        setSuccess("");


        // =========================
        // FORM VALIDATION
        // =========================

        if (!form.checkValidity()) {

            e.stopPropagation();

            setValidated(true);

            return;
        }


        // =========================
        // GET FORM DATA
        // =========================

        const departmentStandard =
            form.Department_standard.value.trim();


        // =========================
        // DEPARTMENT STANDARD VALIDATION
        // =========================

        if (!/^[A-Za-z]+(?: [A-Za-z]+)*$/.test(departmentStandard)) {

            setError(
                "Department standard must contain only alphabets (no numbers or symbols)."
            );

            setValidated(true);

            return;
        }


        if (departmentStandard.length < 2) {

            setError(
                "Department standard must contain at least 2 characters."
            );

            setValidated(true);

            return;
        }


        // =========================
        // DEPARTMENT DATA
        // =========================

        const departmentData = {

            Department_standard: departmentStandard,

        };


        console.log(
            "Sending Department:",
            departmentData
        );


        try {

            setLoading(true);


            // =========================
            // INSERT
            // =========================

            const response = await insert(
                departmentData,
                "department_create"
            );


            console.log(
                "Department created:",
                response
            );


            // =========================
            // SUCCESS
            // =========================

            setSuccess(
    "Department created successfully!"
);


// Clear form
form.reset();

setValidated(false);


// Refresh parent department list
if (props.onSuccess) {

    await props.onSuccess();

}


        } catch (error) {

            console.error(
                "Department creation error:",
                error
            );


            // =========================
            // DJANGO ERROR
            // =========================

            const responseData =
                error.responseData;


            console.log(
                "Django Error:",
                responseData
            );


            // Department standard duplicate
            if (
                responseData &&
                responseData.Department_standard
            ) {

                const message =
                    Array.isArray(
                        responseData.Department_standard
                    )
                        ? responseData.Department_standard[0]
                        : responseData.Department_standard;


                setError(message);

            }

            // Message error
            else if (
                responseData &&
                responseData.message
            ) {

                setError(
                    responseData.message
                );

            }

            // Detail error
            else if (
                responseData &&
                responseData.detail
            ) {

                setError(
                    responseData.detail
                );

            }

            // Other server error
            else {

                setError(
                    "Department could not be created. Please try again."
                );
            }

        } finally {

            setLoading(false);

        }

    };


return (
    <div
        className="modal fade show"
        tabIndex="-1"
        role="dialog"
        style={{ display: "block", backgroundColor: "rgba(0,0,0,0.5)" }}
    >
        <div
            className="modal-dialog modal-dialog-centered"
            role="document"
        >
            <div className="modal-content">

                {/* HEADER */}
                <div className="modal-header">

                    <h5 className="modal-title">
                        Add Department
                    </h5>

                    <button
                        type="button"
                        className="btn-close"
                        onClick={props.toggle}
                        aria-label="Close"
                    ></button>

                </div>

                {/* BODY */}
                <div className="modal-body">

                    {/* SUCCESS */}
                    {success && (
                        <div
                            className="alert alert-success"
                            role="alert"
                        >
                            <strong>Success!</strong>{" "}
                            {success}
                        </div>
                    )}

                    {/* ERROR */}
                    {error && (
                        <div
                            className="alert alert-danger"
                            role="alert"
                        >
                            <strong>Error!</strong>{" "}
                            {error}
                        </div>
                    )}

                    <form
                        onSubmit={handleSubmit}
                        noValidate
                        className={
                            validated ? "was-validated" : ""
                        }
                    >



                        {/* DEPARTMENT STANDARD */}
                        <div className="mb-3">

                            <label
                                htmlFor="Department_standard"
                                className="form-label"
                            >
                                Department Standard
                            </label>

                            <input
                                type="text"
                                name="Department_standard"
                                id="Department_standard"
                                onInput={(e) => {
                                    e.target.value = e.target.value.replace(/[^A-Za-z ]/g, "");
                                }}
                                className="form-control"
                                placeholder="Enter Department Standard"
                                autoComplete="off"
                                required
                                maxLength="255"
                            />

                            <div className="invalid-feedback">
                                Please enter a valid department standard.
                            </div>

                        </div>


                        {/* FOOTER BUTTONS */}
                        <div className="modal-footer px-0 pb-0">

                            <button
                                type="button"
                                className="btn btn-outline-secondary"
                                onClick={props.toggle}
                                disabled={loading}
                            >
                                Cancel
                            </button>

                            <button
                                type="submit"
                                className="btn btn-primary"
                                disabled={loading}
                            >

                                {loading ? (
                                    <>
                                        <span
                                            className="spinner-border spinner-border-sm me-2"
                                            role="status"
                                            aria-hidden="true"
                                        ></span>

                                        Saving...
                                    </>
                                ) : (
                                    "Save Department"
                                )}

                            </button>

                        </div>

                    </form>

                </div>

            </div>
        </div>
    </div>
);
};


export default Adddepartment;