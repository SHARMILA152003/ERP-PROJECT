import React, {
    useState,
    useContext,
    useEffect,
    useCallback
} from "react";

import "./Department.css";

import Adddepartment from "./adddepartment/Adddepartment";
import Updatedepartment from "./updatedepartment/Updatedepartment";
import Deletedepartment from "./deletedepartment/Deletedepartment";

import AuthContext from "../../services/AuthContext";


function Department() {

    const [addPopupVisible, setAddPopupVisible] = useState(false);
    const [updatePopupVisible, setUpdatePopupVisible] = useState(false);
    const [deletePopupVisible, setDeletePopupVisible] = useState(false);

    const [currentPage, setCurrentPage] = useState(1);

    const { getData, update } = useContext(AuthContext);

    const [departments, setDepartments] = useState([]);

    const [value, setValue] = useState(null);


    // =====================================================
    // FETCH DEPARTMENTS
    // =====================================================

    const fetchDepartments = useCallback(async () => {

        try {

            const data = await getData(
                "fetch_department_datail"
            );

            console.log(
                "Departments fetched:",
                data
            );

            if (Array.isArray(data)) {

                setDepartments(data);

            } else {

                setDepartments([]);

            }

        } catch (err) {

            console.error(
                "Failed to fetch departments:",
                err
            );

        }

    }, [getData]);


    // =====================================================
    // INITIAL LOAD
    // =====================================================

    useEffect(() => {

        fetchDepartments();

    }, [fetchDepartments]);


    // =====================================================
    // ADD POPUP
    // =====================================================

    const toggleAddPopup = () => {

        setAddPopupVisible(
            !addPopupVisible
        );

    };


    // =====================================================
    // UPDATE POPUP
    // =====================================================

    const toggleUpdatePopup = () => {

        setUpdatePopupVisible(
            !updatePopupVisible
        );

    };


    // =====================================================
    // DELETE POPUP
    // =====================================================

    const toggleDeletePopup = () => {

        setDeletePopupVisible(
            !deletePopupVisible
        );

    };


    // =====================================================
    // AFTER DEPARTMENT CREATED
    // =====================================================

    const handleDepartmentCreated = async () => {

        console.log(
            "New department created. Refreshing list..."
        );

        // Fetch latest data from Django
        await fetchDepartments();

        // Close popup
        setAddPopupVisible(false);

        // Go back to first page
        setCurrentPage(1);

    };


    // =====================================================
    // PAGINATION
    // =====================================================

    // =====================================================
    // SEARCH  (department name: any word starting with the typed text)
    // =====================================================

    const [searchText, setSearchText] = useState("");

    const searchWord = searchText.trim().toLowerCase();

    const filteredDepartments = departments.filter((d) =>
        (d.Department_standard || "")
            .toLowerCase()
            .split(/\s+/)
            .some((word) => word.startsWith(searchWord))
    );

    const handleSearch = (e) => {

        setSearchText(e.target.value);

        // always start from the first page of the results
        setCurrentPage(1);

    };


    const itemsPerPage = 4;

    const indexOfLastItem =
        currentPage * itemsPerPage;

    const indexOfFirstItem =
        indexOfLastItem - itemsPerPage;

    const currentDepartments =
        filteredDepartments.slice(
            indexOfFirstItem,
            indexOfLastItem
        );


    const nextPage = () => {

        if (
            indexOfLastItem <
            filteredDepartments.length
        ) {

            setCurrentPage(
                currentPage + 1
            );

        }

    };


    const prevPage = () => {

        if (currentPage > 1) {

            setCurrentPage(
                currentPage - 1
            );

        }

    };


    // =====================================================
    // UPDATE
    // =====================================================

    const handleUpdate = (department) => {

        setValue(department);

        toggleUpdatePopup();

    };


    // =====================================================
    // DELETE
    // =====================================================

    const handleDelete = (id) => {

        setValue(id);

        toggleDeletePopup();

    };


    // =====================================================
    // TOGGLE STATUS (Active <-> Deactive)
    // =====================================================

    const handleToggleStatus = async (department) => {

        const newStatus =
            department.Department_Status === "Active"
                ? "Deactive"
                : "Active";

        try {

            await update(
                {
                    Department_id: department.Department_id,
                    Department_standard: department.Department_standard,
                    Department_Status: newStatus
                },
                "update_department_datail",
                "/department"
            );

            // Show the change immediately, then reload from DB
            setDepartments((prev) =>
                prev.map((d) =>
                    d.Department_id === department.Department_id
                        ? { ...d, Department_Status: newStatus }
                        : d
                )
            );

            await fetchDepartments();

        } catch (err) {

            console.error(
                "Status update failed:",
                err
            );

        }

    };


    return (

        <div className="department-page container-xxl flex-grow-1 container-p-y">


            {/* ================================================= */}
            {/* HEADER */}
            {/* ================================================= */}

            <div className="page-header">

                <div>

                    <h3 className="page-title">
                        Department Management
                    </h3>

                    <p className="page-subtitle">
                        Manage all available departments
                    </p>

                </div>


                <button
                    className="btn btn-primary add-btn"
                    onClick={toggleAddPopup}
                >

                    <i className="bx bx-plus me-2"></i>

                    Add Department

                </button>

            </div>


            {/* ================================================= */}
            {/* ADD DEPARTMENT POPUP */}
            {/* ================================================= */}

            {addPopupVisible && (

                <Adddepartment
                    toggle={toggleAddPopup}
                    onSuccess={handleDepartmentCreated}
                />

            )}


            {/* ================================================= */}
            {/* DEPARTMENT TABLE */}
            {/* ================================================= */}

            <div className="card department-card">

                {/* ============================================= */}
                {/* SEARCH (above the table, left side)            */}
                {/* ============================================= */}

                <div className="d-flex justify-content-start p-3">

                    <div
                        className="input-group"
                        style={{ maxWidth: "320px" }}
                    >

                        <span className="input-group-text">
                            <i className="bx bx-search"></i>
                        </span>

                        <input
                            type="text"
                            className="form-control"
                            placeholder="Search department..."
                            value={searchText}
                            onChange={handleSearch}
                        />

                        {searchText && (

                            <button
                                type="button"
                                className="btn btn-outline-secondary"
                                onClick={() => {
                                    setSearchText("");
                                    setCurrentPage(1);
                                }}
                            >
                                &times;
                            </button>

                        )}

                    </div>

                </div>


                <div className="table-responsive">

                    <table className="table modern-table">

                        <thead>

                            <tr>

                                <th>ID</th>

                                <th>
                                    Department Standard
                                </th>

                                <th>
                                    Status
                                </th>

                                <th width="180">
                                    Action
                                </th>

                            </tr>

                        </thead>


                        <tbody>

                            {currentDepartments.length > 0 ? (

                                currentDepartments.map(
                                    (department) => (

                                        <tr
                                            key={
                                                department.Department_id
                                            }
                                        >

                                            <td>
                                                #{department.Department_id}
                                            </td>


                                            <td>
                                                {
                                                    department.Department_standard
                                                }
                                            </td>


                                            <td>

                                                <span
                                                    className={
                                                        department.Department_Status ===
                                                        "Active"
                                                            ? "status active"
                                                            : "status inactive"
                                                    }
                                                    style={{ cursor: "pointer" }}
                                                    title="Click to change status"
                                                    onClick={() =>
                                                        handleToggleStatus(
                                                            department
                                                        )
                                                    }
                                                >

                                                    {
                                                        department.Department_Status
                                                    }

                                                </span>

                                            </td>


                                            <td>

                                                <div className="action-buttons">

                                                    <button
                                                        className="btn btn-edit"
                                                        onClick={() =>
                                                            handleUpdate(
                                                                department
                                                            )
                                                        }
                                                    >
                                                        Edit
                                                    </button>


                                                    <button
                                                        className="btn btn-delete"
                                                        onClick={() =>
                                                            handleDelete(
                                                                department.Department_id
                                                            )
                                                        }
                                                    >
                                                        Delete
                                                    </button>

                                                </div>

                                            </td>

                                        </tr>

                                    )
                                )

                            ) : (

                                <tr>

                                    <td
                                        colSpan="4"
                                        className="text-center py-4"
                                    >

                                        {searchText
                                            ? "No matching departments found."
                                            : "No departments found."}

                                    </td>

                                </tr>

                            )}

                        </tbody>

                    </table>

                </div>


                {/* ================================================= */}
                {/* UPDATE */}
                {/* ================================================= */}

                {updatePopupVisible && (

                    <Updatedepartment
                        toggle={toggleUpdatePopup}
                        data={value}
                    />

                )}


                {/* ================================================= */}
                {/* DELETE */}
                {/* ================================================= */}

                {deletePopupVisible && (

                    <Deletedepartment
                        toggle={toggleDeletePopup}
                        data={value}
                    />

                )}


                {/* ================================================= */}
                {/* PAGINATION */}
                {/* ================================================= */}

                <div className="card-footer bg-white border-0">

                    <div className="d-flex justify-content-end">

                        <button
                            className="btn btn-light me-2"
                            onClick={prevPage}
                            disabled={
                                currentPage === 1
                            }
                        >

                            <i className="bx bx-chevron-left"></i>

                            Previous

                        </button>


                        <button
                            className="btn btn-primary"
                            onClick={nextPage}
                            disabled={
                                indexOfLastItem >=
                                filteredDepartments.length
                            }
                        >

                            Next

                            <i className="bx bx-chevron-right ms-1"></i>

                        </button>

                    </div>

                </div>

            </div>

        </div>

    );

}


export default Department;