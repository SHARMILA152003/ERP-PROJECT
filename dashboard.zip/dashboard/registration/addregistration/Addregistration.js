import React, { useContext, useEffect, useRef, useState } from "react";
import AuthContext from "../../../services/AuthContext";
import "./addregistration.css";

/*
 * ALL server calls come from AuthContext (same flow as Addcoursefee.js).
 * There is no axios / fetch call inside this file.
 *
 *   getData(...)              -> lists  : "fetch_registration_enquiry_datail",
 *                                         "fetch_registration_datail"
 *   Fetch(...)                -> one registration : "get_registration_datail"
 *   insert(payload, ...)      -> create : "registration_create"
 *                                update : "update_registration_datail"
 *
 * AuthContext is shared by every module, so it is used as it is. It can
 * only send JSON, so the form (with its files) is converted by
 * formDataToPayload() below: a file is sent as base64 and Django turns
 * it back into a normal uploaded file. insert() is used for update too,
 * because it is the helper that throws the Django error
 * (err.responseData) so the message can be shown in the popup.
 */

/*
 * Django sends every saved file as a full url (http://host/media/...),
 * so no server address is needed here.
 */
const apiUrl = "";

/* downloads a saved file (plain GET of a /media/ file) and returns a Blob */
const downloadFile = async (url) => {
  const response = await fetch(url);

  if (!response.ok) {
    throw new Error("Failed to download file");
  }

  return response.blob();
};

/* File -> base64 text (without the "data:...;base64," start) */
const readFileAsBase64 = (file) =>
  new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.onload = () => resolve(String(reader.result).split(",")[1] || "");
    reader.onerror = () => reject(reader.error);

    reader.readAsDataURL(file);
  });

/*
 * FormData -> plain object for AuthContext.insert (JSON).
 * Text boxes stay text; a chosen file becomes
 *   { name, type, data: "<base64>" }
 */
const formDataToPayload = async (formData) => {
  const payload = {};

  for (const [key, value] of formData.entries()) {
    if (typeof value === "object" && value !== null && "size" in value) {
      payload[key] = {
        name: value.name,
        type: value.type,
        data: await readFileAsBase64(value)
      };
    } else {
      payload[key] = value;
    }
  }

  return payload;
};

/* =====================================================
   HELPERS (used for EDIT mode)
===================================================== */

/* API_HOST is the server address given by AuthContext (apiUrl) */
const buildFileCandidates = (value, API_HOST = "") => {
  if (!value) {
    return [];
  }

  const text = String(value).trim();

  const list = [];

  const add = (url) => {
    if (url && !list.includes(url)) {
      list.push(url);
    }
  };

  if (/^https?:\/\//i.test(text)) {
    add(text);

    try {
      const path = new URL(text).pathname;

      add(`${API_HOST}${path}`);

      if (!path.startsWith("/media/")) {
        add(`${API_HOST}/media${path}`);
      }
    } catch (err) {
      /* keep the original url only */
    }

    return list;
  }

  const safe = text.includes("%") ? text : encodeURI(text);

  if (safe.startsWith("/")) {
    add(`${API_HOST}${safe}`);

    if (!safe.startsWith("/media/")) {
      add(`${API_HOST}/media${safe}`);
    }
  } else {
    /* plain file name saved in the database -> normally served from /media/ */
    add(
      safe.startsWith("media/")
        ? `${API_HOST}/${safe}`
        : `${API_HOST}/media/${safe}`
    );
    add(`${API_HOST}/${safe}`);
  }

  return list;
};

/* shows the first url that loads, otherwise the fallback */
const FallbackImage = ({ candidates, alt, className, fallback }) => {
  const [index, setIndex] = useState(0);

  const signature = candidates.join("|");

  useEffect(() => {
    setIndex(0);
  }, [signature]);

  if (!candidates.length || index >= candidates.length) {
    return fallback || null;
  }

  return (
    <img
      src={candidates[index]}
      alt={alt}
      className={className}
      onError={() => setIndex((previous) => previous + 1)}
    />
  );
};

const buildFileUrl = (value, host) => buildFileCandidates(value, host)[0] || "";

/* a file field may be a text, or an object like { url: "..." } */
const pickFileString = (value) => {
  if (!value) {
    return "";
  }

  if (typeof value === "string") {
    const text = value.trim();

    if (
      !text ||
      ["null", "none", "undefined"].includes(text.toLowerCase())
    ) {
      return "";
    }

    return text;
  }

  if (typeof value === "object") {
    return pickFileString(
      value.url || value.path || value.file || value.name
    );
  }

  return "";
};

/* file fields may come with different names from the backend */
const findFileValue = (item, knownKeys, pattern) => {
  if (!item) {
    return "";
  }

  for (const key of knownKeys) {
    const value = pickFileString(item[key]);

    if (value) {
      return value;
    }
  }

  const foundKey = Object.keys(item).find(
    (key) => pattern.test(key) && pickFileString(item[key])
  );

  return foundKey ? pickFileString(item[foundKey]) : "";
};

const getPhotoValue = (item) =>
  findFileValue(
    item,
    ["student_photo", "student_image", "studentPhoto", "photo", "photo_url", "image"],
    /photo|image|picture|avatar/i
  );

const getResumeValue = (item) =>
  findFileValue(item, ["resume_cv", "resume"], /resume|cv/i);

const getAadharValue = (item) =>
  findFileValue(item, ["aadhar_card", "aadhaar_card"], /aadh?a+r/i);

const getFileName = (value) => {
  if (!value) {
    return "";
  }

  const last = String(value).split("?")[0].split("/").pop();

  try {
    return decodeURIComponent(last);
  } catch (err) {
    return last;
  }
};

const toDateInput = (value) => {
  if (!value) {
    return "";
  }

  return String(value).slice(0, 10);
};

/* discount validity is a date - ignore old text values like "30 Days" */
const toValidityDate = (value) =>
  /^\d{4}-\d{2}-\d{2}/.test(String(value || ""))
    ? String(value).slice(0, 10)
    : "";

/*
 * DISCOUNT VALIDITY END DATE (the "to" date shown in the enquiry list).
 * If your enquiry API uses another field name for the "to" date,
 * add that name to this list.
 */
const VALIDITY_END_KEYS = [
  "discount_validity_to",
  "discount_valid_to",
  "discount_validity_end",
  "discount_validity_end_date",
  "discount_end_date",
  "discount_to",
  "validity_end",
  "validity_end_date",
  "validity_to",
  "valid_till",
  "valid_to",
  "to_date"
];

const getValidityEnd = (item) => {
  if (!item) {
    return "";
  }

  /* 1. known "to date" field names */
  for (const key of VALIDITY_END_KEYS) {
    const value = toValidityDate(item[key]);

    if (value) {
      return value;
    }
  }

  /* 2. any other field that looks like a discount / validity "to" date */
  const foundKey = Object.keys(item).find(
    (key) =>
      /(valid|discount)[a-z_]*(_to|_end|till|upto)/i.test(key) &&
      toValidityDate(item[key])
  );

  if (foundKey) {
    return toValidityDate(item[foundKey]);
  }

  /* 3. the validity field itself ("2026-10-11" or "2026-10-11 to 2027-12-18") */
  const dates = String(item.discount_validity || "").match(/\d{4}-\d{2}-\d{2}/g);

  return dates && dates.length ? dates[dates.length - 1] : "";
};

/* 2026-10-27 -> 27-10-2026 */
const formatDisplayDate = (value) => {
  const m = String(value || "").match(/^(\d{4})-(\d{2})-(\d{2})/);
  return m ? `${m[3]}-${m[2]}-${m[1]}` : String(value || "");
};

/*
 * FINAL FEE = course fees - (course fees x discount % / 100)
 * Returns "" when the course fees is empty / not a number.
 * An empty or wrong discount counts as 0, and the discount is kept
 * between 0 and 100.
 */
const calcFinalFee = (fees, discount) => {
  const amount = parseFloat(fees);

  if (!Number.isFinite(amount)) {
    return "";
  }

  let percent = parseFloat(discount);

  if (!Number.isFinite(percent) || percent < 0) {
    percent = 0;
  }

  if (percent > 100) {
    percent = 100;
  }

  return (amount - (amount * percent) / 100).toFixed(2);
};

/* newest record has the biggest id */
const getRecordOrder = (r) => {
  const n = Number(r.id);
  return Number.isFinite(n) ? n : 0;
};

/* educational boxes saved in the existing backend fields for each qualification */
const QUALIFICATION_FIELDS = {
  "10th": ["school_name", "tenth_marks"],
  /* 12th also shows the 10th details (school + 10th marks) */
  "12th": ["school_name", "tenth_marks", "twelfth_marks"],
  Diploma: [
    "school_name",
    "tenth_marks",
    "twelfth_marks",
    "diploma_course",
    "gpa",
    "college_name",
    "specialization",
    "year_of_passing"
  ],
  Degree: [
    "school_name",
    "tenth_marks",
    "twelfth_marks",
    "degree_course",
    "gpa",
    "college_name",
    "specialization",
    "year_of_passing"
  ]
};

const EDU_FIELDS = [
  "school_name",
  "tenth_marks",
  "twelfth_marks",
  "college_name",
  "diploma_course",
  "degree_course",
  "gpa",
  "specialization",
  "year_of_passing"
];

/* these fields are sent only when they are filled (so an unfinished form can be saved) */
const SKIP_IF_EMPTY = [
  "school_name",
  "tenth_marks",
  "twelfth_marks",
  "gpa",
  "year_of_passing",
  "course_fees",
  "discount_percentage",
  "discount_validity"
];

/* =====================================================
   EDUCATIONAL QUALIFICATIONS TABLE
   S.No | Qualification | School/Institute Name | Board/University |
   Percentage | YOP | Degree | Department | Actions (+ / -)
===================================================== */

/*
 * The Qualification box is a text box with a drop-down button.
 * A name can be picked from the list, or any text can be typed
 * (for example "6th Std" or "9th Std").
 */
const EDU_QUALIFICATION_OPTIONS = [
  "10th",
  "12th",
  "UG",
  "PG",
  "Diploma",
  "PhD"
];

const emptyEduRow = (qualification = "") => ({
  qualification,
  institute: "",
  board: "",
  percentage: "",
  yop: "",
  degree: "",
  department: ""
});

/* rows shown when the enquiry has no education details */
const defaultEducationRows = () => [
  emptyEduRow("10th"),
  emptyEduRow("12th"),
  emptyEduRow("UG")
];

/* first filled value among several possible field names of a record */
const pickFirst = (src, keys) => {
  if (!src) {
    return "";
  }

  for (const key of keys) {
    const value = src[key];

    if (value !== null && value !== undefined && String(value).trim() !== "") {
      return String(value).trim();
    }
  }

  return "";
};

const rowHasData = (row) =>
  [
    row.institute,
    row.board,
    row.percentage,
    row.yop,
    row.degree,
    row.department
  ].some((v) => String(v || "").trim() !== "");

/*
 * SCHOOL LEVEL = 12th or anything below it (12th, 11th, 10th, 9th ... 1st,
 * "6th Std", "Class 7", "SSLC", "HSC", "XII", "Plus 2", "LKG" ...).
 * For these qualifications there is no Degree and no Department,
 * so those two boxes are locked (not editable) and kept empty.
 * This also works when the qualification is typed by hand
 * (for example typing "12" locks the boxes at once).
 * UG, PG, Diploma, PhD and other higher qualifications are NOT school level
 * (their boxes stay editable).
 */
const SCHOOL_WORDS = [
  "sslc",
  "lkg",
  "ukg",
  "primary",
  "middle",
  "first",
  "second",
  "third",
  "fourth",
  "fifth",
  "sixth",
  "seventh",
  "eighth",
  "ninth",
  "tenth",
  "eleventh",
  "twelfth",
  "hsc",
  "xii",
  "puc",
  "plus2",
  "plustwo"
];

const isSchoolLevel = (value) => {
  const text = String(value || "")
    .trim()
    .toLowerCase()
    .replace(/[\s.\-_/]/g, "");

  if (!text) {
    return false;
  }

  /* 12th, 10th, 6th, 4, 7th std, 9thstandard, 8thclass, 5th grade ... */
  let match = text.match(/^(\d{1,2})(st|nd|rd|th)?(std|standard|class|grade)?$/);

  /* std6, standard 7, class 8, grade 9 */
  if (!match) {
    match = text.match(/^(std|standard|class|grade)(\d{1,2})(st|nd|rd|th)?$/);

    if (match) {
      return Number(match[2]) >= 1 && Number(match[2]) <= 12;
    }
  } else {
    return Number(match[1]) >= 1 && Number(match[1]) <= 12;
  }

  return SCHOOL_WORDS.some(
    (word) =>
      text === word ||
      text === `${word}std` ||
      text === `${word}standard` ||
      text === `${word}class`
  );
};

/*
 * Qualification text of a fetched row.
 * Known names are written in one standard way (12th, 10th, Diploma ...),
 * any other text (for example "6th Std") is kept as it is.
 */
const canonicalQualification = (value) => {
  const raw = String(value || "").trim();

  const text = raw.toLowerCase().replace(/[\s.]/g, "");

  if (!text) {
    return "";
  }

  if (/^(12|12th|xii|hsc|twelfth|plus2|puc)$/.test(text)) {
    return "12th";
  }

  if (/^(10|10th|x|sslc|tenth)$/.test(text)) {
    return "10th";
  }

  if (text === "diploma") {
    return "Diploma";
  }

  if (/^(phd|doctorate)$/.test(text)) {
    return "PhD";
  }

  if (text === "degree") {
    return "Degree";
  }

  if (/^(pg|postgraduate)$/.test(text)) {
    return "PG";
  }

  if (/^(ug|undergraduate)$/.test(text)) {
    return "UG";
  }

  return raw;
};

/*
 * What kind of qualification a typed text is (used only to copy the table
 * into the old single fields of the backend). "" = not recognised
 * (for example "6th Std") - such a row is kept in the table only.
 */
const legacyKind = (value) => {
  const text = String(value || "")
    .trim()
    .toLowerCase()
    .replace(/[\s.]/g, "");

  if (!text) {
    return "";
  }

  if (/^(12|xii|hsc|twelfth|plus2|puc)/.test(text)) {
    return "12th";
  }

  if (/^(10|sslc|tenth)/.test(text) || text === "x") {
    return "10th";
  }

  if (text.startsWith("diploma")) {
    return "Diploma";
  }

  if (/^(phd|doctor)/.test(text)) {
    return "PhD";
  }

  if (text === "degree") {
    return "Degree";
  }

  if (
    /^(pg|postgraduate|master|mtech|mca|mba|msc|mcom)/.test(text) ||
    /^(ma|me)$/.test(text)
  ) {
    return "PG";
  }

  if (
    /^(ug|undergraduate|bachelor)/.test(text) ||
    /^b(e|tech|sc|ca|com|ba|a|arch|ed|pharm)$/.test(text)
  ) {
    return "UG";
  }

  return "";
};

/* qualifications that have a college / degree / department */
const HIGHER_KINDS = ["UG", "PG", "Degree", "PhD", "Diploma"];

/* a Degree and a Department are expected for these qualifications */
const needsDegree = (qualification) =>
  HIGHER_KINDS.includes(legacyKind(qualification));

/* one row of an education list coming from the enquiry / saved registration */
const rowFromRecord = (item) => ({
  qualification: canonicalQualification(
    pickFirst(item, ["qualification", "level", "type", "name"])
  ),
  institute: pickFirst(item, [
    "institute",
    "institute_name",
    "school_name",
    "college_name",
    "institution",
    "school"
  ]),
  board: pickFirst(item, ["board", "board_name", "university"]),
  percentage: pickFirst(item, ["percentage", "marks", "percent", "cgpa", "gpa"]),
  yop: pickFirst(item, ["yop", "year_of_passing", "passing_year", "year"]),
  degree: pickFirst(item, [
    "degree",
    "degree_course",
    "diploma_course",
    "course"
  ]),
  department: pickFirst(item, [
    "department",
    "specialization",
    "branch",
    "stream"
  ])
});

/*
 * fields like ug_institute, pg_percentage, diploma_yop ...
 * For the "degree" and "diploma" prefixes the old single fields
 * degree_course / diploma_course are NOT read here (they belong to the
 * old single-field format and are handled separately below).
 */
const prefixedRow = (src, prefix, qualification) => ({
  ...emptyEduRow(qualification),
  institute: pickFirst(src, [
    `${prefix}_institute`,
    `${prefix}_college_name`,
    `${prefix}_college`,
    `${prefix}_school_name`
  ]),
  board: pickFirst(src, [`${prefix}_board`, `${prefix}_university`]),
  percentage: pickFirst(src, [
    `${prefix}_percentage`,
    `${prefix}_marks`,
    `${prefix}_cgpa`
  ]),
  yop: pickFirst(src, [
    `${prefix}_yop`,
    `${prefix}_year_of_passing`,
    `${prefix}_year`
  ]),
  degree: pickFirst(
    src,
    prefix === "degree" || prefix === "diploma"
      ? [`${prefix}_degree`]
      : [`${prefix}_degree`, `${prefix}_course`]
  ),
  department: pickFirst(src, [
    `${prefix}_department`,
    `${prefix}_specialization`
  ])
});

/* names an education list can have inside an enquiry / registration */
const EDU_LIST_KEYS = [
  "education_details",
  "educational_qualifications",
  "educational_details",
  "qualifications",
  "education"
];

/* rows built from the single fields of an enquiry / registration (school_name, tenth_marks ...) */
const buildRowsFromFields = (src) => {
  const rows = [
    {
      ...emptyEduRow("10th"),
      institute: pickFirst(src, [
        "tenth_school_name",
        "tenth_school",
        "tenth_institute",
        "school_name"
      ]),
      board: pickFirst(src, ["tenth_board", "tenth_board_name", "board_10th"]),
      percentage: pickFirst(src, [
        "tenth_marks",
        "tenth_percentage",
        "tenth_percent"
      ]),
      yop: pickFirst(src, ["tenth_yop", "tenth_year_of_passing", "tenth_year"])
    },
    {
      ...emptyEduRow("12th"),
      institute: pickFirst(src, [
        "twelfth_school_name",
        "twelfth_school",
        "twelfth_institute"
      ]),
      board: pickFirst(src, [
        "twelfth_board",
        "twelfth_board_name",
        "board_12th"
      ]),
      percentage: pickFirst(src, [
        "twelfth_marks",
        "twelfth_percentage",
        "twelfth_percent"
      ]),
      yop: pickFirst(src, [
        "twelfth_yop",
        "twelfth_year_of_passing",
        "twelfth_year"
      ])
    }
  ];

  const higher = [
    prefixedRow(src, "ug", "UG"),
    prefixedRow(src, "pg", "PG"),
    prefixedRow(src, "degree", "Degree"),
    prefixedRow(src, "diploma", "Diploma"),
    prefixedRow(src, "phd", "PhD")
  ].filter(rowHasData);

  /*
   * older records: ONE higher qualification saved in the single fields
   * (qualification, college_name, degree_course / diploma_course,
   *  specialization, year_of_passing)
   */
  if (!higher.length) {
    const legacyInstitute = pickFirst(src, ["college_name"]);
    const legacyDegreeCourse = pickFirst(src, ["degree_course"]);
    const legacyDiplomaCourse = pickFirst(src, ["diploma_course"]);
    const legacyDepartment = pickFirst(src, ["specialization"]);
    const legacyYop = pickFirst(src, ["year_of_passing"]);

    if (
      legacyInstitute ||
      legacyDegreeCourse ||
      legacyDiplomaCourse ||
      legacyDepartment ||
      legacyYop
    ) {
      const savedQualification = canonicalQualification(src.qualification);

      const isDiploma = Boolean(legacyDiplomaCourse) && !legacyDegreeCourse;

      /* keep the saved text (for example "B.Sc") when it is a higher qualification */
      const rowQualification = HIGHER_KINDS.includes(
        legacyKind(savedQualification)
      )
        ? savedQualification
        : isDiploma
        ? "Diploma"
        : "Degree";

      higher.push({
        ...emptyEduRow(rowQualification),
        institute: legacyInstitute,
        degree: legacyDegreeCourse || legacyDiplomaCourse,
        department: legacyDepartment,
        yop: legacyYop
      });
    }
  }

  if (!higher.length) {
    higher.push(emptyEduRow("Degree"));
  }

  return [...rows, ...higher];
};

/*
 * Build the table rows from an enquiry / registration record.
 * 1. an education list inside the record (education_details ...) is used as it is
 * 2. otherwise the rows are built from the single fields of the record
 * Everything fetched can still be changed by hand, and the boxes the
 * enquiry does not have stay empty for manual entry.
 * (Degree / Department of a school level row - 12th or below - are always empty.)
 */
const clearSchoolLevelRows = (rows) =>
  rows.map((row) =>
    isSchoolLevel(row.qualification)
      ? { ...row, degree: "", department: "" }
      : row
  );

const buildEducationRows = (src) => {
  if (!src) {
    return defaultEducationRows();
  }

  for (const key of EDU_LIST_KEYS) {
    let value = src[key];

    if (typeof value === "string" && value.trim()) {
      try {
        value = JSON.parse(value);
      } catch (err) {
        value = null;
      }
    }

    if (
      Array.isArray(value) &&
      value.length &&
      value[0] &&
      typeof value[0] === "object"
    ) {
      return clearSchoolLevelRows(value.map(rowFromRecord));
    }
  }

  return clearSchoolLevelRows(buildRowsFromFields(src));
};

/*
 * The list that is saved in education_details.
 * It has EXACTLY the same structure as the enquiry table:
 * [{"qualification","institute","board","percentage","yop","degree","department"}]
 * Rows without any detail are left out.
 * Degree / Department of a school level row (12th or below) are sent empty.
 */
const cleanEducationRows = (rows) =>
  rows
    .map((row) => {
      const schoolLevel = isSchoolLevel(row.qualification);

      return {
        qualification: String(row.qualification || "").trim(),
        institute: String(row.institute || "").trim(),
        board: String(row.board || "").trim(),
        percentage: String(row.percentage || "").trim(),
        yop: String(row.yop || "").trim(),
        degree: schoolLevel ? "" : String(row.degree || "").trim(),
        department: schoolLevel ? "" : String(row.department || "").trim()
      };
    })
    .filter((row) => Object.values(row).some((v) => v !== ""));

/*
 * The backend has single fields (qualification, school_name, tenth_marks ...).
 * The table is also copied into those fields so the list page keeps working.
 * (The backend model does the same copy again when it saves.)
 */
const rowsToLegacyFields = (rows) => {
  const r10 = rows.find((r) => legacyKind(r.qualification) === "10th");
  const r12 = rows.find((r) => legacyKind(r.qualification) === "12th");

  const higher = rows.filter((r) =>
    ["UG", "PG", "Degree", "PhD"].includes(legacyKind(r.qualification))
  );

  /* the highest qualification filled is saved in the single fields */
  const top =
    higher.find((r) => legacyKind(r.qualification) === "PhD") ||
    higher.find((r) => legacyKind(r.qualification) === "PG") ||
    higher[0] ||
    null;

  const hasData = (row) =>
    Boolean(row) &&
    [row.institute, row.degree, row.department, row.yop].some(
      (v) => String(v || "").trim() !== ""
    );

  const hasHigher = hasData(top);

  /* Diploma row (used when no UG / PG row is filled) */
  const diploma = rows.find((r) => legacyKind(r.qualification) === "Diploma");

  const hasDiploma = !hasHigher && hasData(diploma);

  const picked = hasHigher ? top : hasDiploma ? diploma : null;

  return {
    qualification: hasHigher
      ? "Degree"
      : hasDiploma
      ? "Diploma"
      : r12
      ? "12th"
      : r10
      ? "10th"
      : "",
    school_name: (r10 && r10.institute) || (r12 && r12.institute) || "",
    tenth_marks: r10 ? r10.percentage : "",
    twelfth_marks: r12 ? r12.percentage : "",
    college_name: picked ? picked.institute : "",
    degree_course: hasHigher ? top.degree : "",
    diploma_course: hasDiploma ? diploma.degree : "",
    specialization: picked ? picked.department : "",
    year_of_passing: picked ? picked.yop : "",
    gpa: ""
  };
};

/* IGT0001 style registration number */
const formatRegNo = (n) => `IGT${String(n).padStart(4, "0")}`;

const getRegNumber = (value) => {
  const m = String(value || "").match(/(\d+)$/);
  return m ? parseInt(m[1], 10) : 0;
};

/* people in the order of their first registration (oldest first) */
const getPersonKeys = (list) => {
  const sorted = [...list].sort(
    (a, b) => getRecordOrder(a) - getRecordOrder(b)
  );

  const keys = [];

  sorted.forEach((r) => {
    const key = String(r.enquiry_no || r.mobile_number || r.id);

    if (!keys.includes(key)) {
      keys.push(key);
    }
  });

  return keys;
};

/* one person = one registration number, so next new person = persons + 1 */
const getNextRegNo = (list) => formatRegNo(getPersonKeys(list).length + 1);

/*
 * Download an existing server file so it can be re-sent with a new registration.
 * The download itself is done by downloadFile() from AuthContext (returns a Blob).
 */
const urlToFile = async (url, fallbackName, downloadFile) => {
  const blob = await downloadFile(url);

  return new File([blob], getFileName(url) || fallbackName, {
    type: blob.type
  });
};

/* try every possible url of a saved file until one can be downloaded */
const fetchFirstFile = async (value, fallbackName, host, downloadFile) => {
  const candidates = buildFileCandidates(value, host);

  for (const url of candidates) {
    try {
      return await urlToFile(url, fallbackName, downloadFile);
    } catch (err) {
      /* try the next url */
    }
  }

  console.warn("Could not copy the saved file from:", candidates);

  throw new Error("File could not be downloaded");
};

/*
 * YEAR PICKER (Year of Passing)
 * A small popup with a grid of 12 years. The arrows move to the
 * earlier / later 12 years, so there is no long list to scroll.
 * Years run from 6 years ahead (students still studying) back to 1970.
 */
const YEAR_MIN = 1970;
const YEAR_PAGE = 12;

const YearPicker = ({ value, onChange }) => {
  const buttonRef = useRef(null);
  const popupRef = useRef(null);

  const [open, setOpen] = useState(false);
  const [pageStart, setPageStart] = useState(0);
  const [pos, setPos] = useState({ top: 0, left: 0 });

  const thisYear = new Date().getFullYear();
  const yearMax = thisYear + 6;

  const selectedYear = /^\d{4}$/.test(String(value || "")) ? Number(value) : 0;

  /* first year of the 12-year block that contains the given year */
  const blockStart = (year) => Math.floor(year / YEAR_PAGE) * YEAR_PAGE;

  const openPicker = () => {
    if (open) {
      setOpen(false);
      return;
    }

    const rect = buttonRef.current.getBoundingClientRect();

    const width = 244;
    const height = 292;

    const left = Math.max(
      8,
      Math.min(rect.left + rect.width / 2 - width / 2, window.innerWidth - width - 8)
    );

    /* open below the box, or above it when there is no space below */
    const below = rect.bottom + 6;
    const top =
      below + height > window.innerHeight && rect.top - height - 6 > 8
        ? rect.top - height - 6
        : below;

    setPos({ top, left });
    setPageStart(blockStart(selectedYear || thisYear));
    setOpen(true);
  };

  /* close on outside click, Esc, scroll or resize */
  useEffect(() => {
    if (!open) {
      return undefined;
    }

    const onDown = (e) => {
      if (
        popupRef.current &&
        !popupRef.current.contains(e.target) &&
        buttonRef.current &&
        !buttonRef.current.contains(e.target)
      ) {
        setOpen(false);
      }
    };

    const onKey = (e) => {
      if (e.key === "Escape") {
        setOpen(false);
      }
    };

    const onMove = (e) => {
      if (popupRef.current && popupRef.current.contains(e.target)) {
        return;
      }
      setOpen(false);
    };

    document.addEventListener("mousedown", onDown);
    document.addEventListener("keydown", onKey);
    window.addEventListener("scroll", onMove, true);
    window.addEventListener("resize", onMove);

    return () => {
      document.removeEventListener("mousedown", onDown);
      document.removeEventListener("keydown", onKey);
      window.removeEventListener("scroll", onMove, true);
      window.removeEventListener("resize", onMove);
    };
  }, [open]);

  const choose = (year) => {
    onChange(String(year));
    setOpen(false);
  };

  const years = [];

  for (let i = 0; i < YEAR_PAGE; i += 1) {
    years.push(pageStart + i);
  }

  const canGoBack = pageStart > blockStart(YEAR_MIN);
  const canGoForward = pageStart + YEAR_PAGE <= yearMax;

  return (
    <div className="year-picker">
      <button
        type="button"
        ref={buttonRef}
        className={`year-picker-btn${value ? " has-value" : ""}${
          open ? " is-open" : ""
        }`}
        onClick={openPicker}
      >
        <span>{value || "Year"}</span>
        <i className="bx bx-calendar year-picker-icon" />
      </button>

      {open && (
        <div
          ref={popupRef}
          className="year-picker-popup"
          style={{ top: pos.top, left: pos.left }}
        >
          <div className="year-picker-head">
            <button
              type="button"
              className="year-nav-btn"
              disabled={!canGoBack}
              onClick={() => setPageStart((p) => p - YEAR_PAGE)}
              aria-label="Earlier years"
            >
              &#8249;
            </button>

            <span className="year-picker-range">
              {pageStart} – {pageStart + YEAR_PAGE - 1}
            </span>

            <button
              type="button"
              className="year-nav-btn"
              disabled={!canGoForward}
              onClick={() => setPageStart((p) => p + YEAR_PAGE)}
              aria-label="Later years"
            >
              &#8250;
            </button>
          </div>

          <div className="year-picker-grid">
            {years.map((year) => {
              const allowed =
                (year >= YEAR_MIN && year <= yearMax) || year === selectedYear;

              return (
                <button
                  type="button"
                  key={year}
                  disabled={!allowed}
                  className={`year-cell${
                    year === selectedYear ? " selected" : ""
                  }${year === thisYear ? " current" : ""}`}
                  onClick={() => choose(year)}
                >
                  {year}
                </button>
              );
            })}
          </div>

          <div className="year-picker-foot">
            <button
              type="button"
              className="year-link"
              onClick={() => {
                onChange("");
                setOpen(false);
              }}
            >
              Clear
            </button>

            <button
              type="button"
              className="year-link"
              onClick={() => choose(thisYear)}
            >
              This year
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

/*
 * QUALIFICATION BOX
 * A text box (type anything) with a drop-down button that lists
 * 10th, 12th, UG, PG, Diploma, PhD. The list opens as a small popup,
 * so the table does not grow or scroll.
 */
const QualificationBox = ({ value, onType, onPick }) => {
  const inputRef = useRef(null);
  const menuRef = useRef(null);

  const [open, setOpen] = useState(false);
  const [pos, setPos] = useState({ top: 0, left: 0, width: 170 });

  const openMenu = () => {
    if (open) {
      setOpen(false);
      return;
    }

    const rect = inputRef.current.getBoundingClientRect();

    const height = EDU_QUALIFICATION_OPTIONS.length * 38 + 12;

    /* open below the box, or above it when there is no space below */
    const below = rect.bottom + 4;
    const top =
      below + height > window.innerHeight && rect.top - height - 4 > 8
        ? rect.top - height - 4
        : below;

    setPos({ top, left: rect.left, width: Math.max(rect.width, 150) });
    setOpen(true);
  };

  /* close on outside click, Esc, scroll or resize */
  useEffect(() => {
    if (!open) {
      return undefined;
    }

    const onDown = (e) => {
      if (
        menuRef.current &&
        !menuRef.current.contains(e.target) &&
        inputRef.current &&
        !inputRef.current.parentNode.contains(e.target)
      ) {
        setOpen(false);
      }
    };

    const onKey = (e) => {
      if (e.key === "Escape") {
        setOpen(false);
      }
    };

    const onMove = (e) => {
      if (menuRef.current && menuRef.current.contains(e.target)) {
        return;
      }
      setOpen(false);
    };

    document.addEventListener("mousedown", onDown);
    document.addEventListener("keydown", onKey);
    window.addEventListener("scroll", onMove, true);
    window.addEventListener("resize", onMove);

    return () => {
      document.removeEventListener("mousedown", onDown);
      document.removeEventListener("keydown", onKey);
      window.removeEventListener("scroll", onMove, true);
      window.removeEventListener("resize", onMove);
    };
  }, [open]);

  return (
    <div className="qual-box">
      <input
        ref={inputRef}
        type="text"
        className="form-control"
        placeholder="Qualification"
        value={value}
        onChange={(e) => onType(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === "ArrowDown" && !open) {
            e.preventDefault();
            openMenu();
          }
        }}
      />

      <button
        type="button"
        className={`qual-toggle${open ? " is-open" : ""}`}
        aria-label="Choose qualification"
        title="Choose qualification"
        onClick={openMenu}
      >
        <svg
          width="14"
          height="14"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="3"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <polyline points="6 9 12 15 18 9" />
        </svg>
      </button>

      {open && (
        <div
          ref={menuRef}
          className="qual-menu"
          style={{ top: pos.top, left: pos.left, width: pos.width }}
        >
          {EDU_QUALIFICATION_OPTIONS.map((name) => (
            <button
              type="button"
              key={name}
              className={`qual-option${name === value ? " selected" : ""}`}
              onClick={() => {
                onPick(name);
                setOpen(false);
              }}
            >
              {name}
            </button>
          ))}
        </div>
      )}
    </div>
  );
};

/* search matches from the FIRST letter / number only (not from the middle) */
const startsWithText = (value, query) =>
  String(value || "")
    .trim()
    .toLowerCase()
    .startsWith(String(query || "").trim().toLowerCase());

/*
 * EDUCATION TABLE - typing rules of the text boxes.
 * A wrong key shows the popup alert and is not typed.
 */
const EDU_TEXT_RULES = {
  qualification: {
    label: "Qualification",
    pattern: /^[A-Za-z0-9\s.\-/()]*$/,
    allowed: "letters, numbers and . - / ( )",
    max: 30
  },
  institute: {
    label: "School / Institute name",
    pattern: /^[A-Za-z0-9\s.,&'\-/()]*$/,
    allowed: "letters, numbers and . , & ' - / ( )",
    max: 150
  },
  board: {
    label: "Board / University",
    pattern: /^[A-Za-z0-9\s.,&'\-/()]*$/,
    allowed: "letters, numbers and . , & ' - / ( )",
    max: 100
  },
  degree: {
    label: "Degree",
    pattern: /^[A-Za-z0-9\s.&\-/()]*$/,
    allowed: "letters, numbers and . & - / ( )",
    max: 100
  },
  department: {
    label: "Department",
    pattern: /^[A-Za-z\s.,&\-/()]*$/,
    allowed: "letters and . , & - / ( )",
    max: 100
  }
};

/* a value counts as filled when it is not empty */
const isFilled = (value) =>
  value !== null && value !== undefined && String(value).trim() !== "";

/* today as YYYY-MM-DD */
const getToday = () => {
  const date = new Date();

  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");

  return `${year}-${month}-${day}`;
};

/* the discount offer is over when the registration date is after the validity end date */
const isValidityCrossed = (registrationDate, validity) =>
  Boolean(validity) && (registrationDate || getToday()) > validity;

/* a discount number above 0 (used to remember the offer discount) - "" otherwise */
const positiveDiscount = (value) => {
  const n = parseFloat(value);

  return Number.isFinite(n) && n > 0 ? String(n) : "";
};

/*
 * Backend error text. When the backend sends the failed fields
 * (for example { message: "...", errors: { address: ["..."] } })
 * the field names are shown too, so it is clear what the server rejected.
 */
const getErrorMessage = (data, fallback) => {
  if (!data) {
    return fallback;
  }

  if (typeof data === "string") {
    return data.length < 300 ? data : fallback;
  }

  const parts = [];

  const base = data.message || data.error || data.detail;

  if (base) {
    parts.push(String(base));
  }

  const fieldErrors =
    data.errors && typeof data.errors === "object"
      ? data.errors
      : !base
      ? data
      : null;

  if (fieldErrors) {
    Object.entries(fieldErrors).forEach(([key, value]) => {
      const text = Array.isArray(value) ? value[0] : value;

      if (text && typeof text !== "object") {
        parts.push(`${key.replace(/_/g, " ")}: ${text}`);
      }
    });
  }

  return parts.length ? parts.join(" – ") : fallback;
};

/* statuses a registration can have (default is Active) */
const REGISTRATION_STATUSES = ["Active", "Inactive", "Completed", "Cancelled"];

/*
 * Add mode  : <Addregistration onBack={...} onSaved={...} />
 * Edit mode : <Addregistration registration={record} onBack={...} onSaved={...} />
 */
function Addregistration({ onBack, onSaved, registration }) {
  /* server address + ALL API calls come from AuthContext */
  const { getData, Fetch, insert } = useContext(AuthContext);

  const isEdit = Boolean(registration);
  const initial = registration || {};
  const registrationId = isEdit
    ? registration.id || registration.registration_id
    : null;

  /* full record used for the saved files (list data may not contain them) */
  const [savedRecord, setSavedRecord] = useState(initial);

  /* Files that already exist on the server (edit mode only) */

  const existingPhoto = isEdit
    ? buildFileUrl(getPhotoValue(savedRecord), apiUrl)
    : "";

  const existingResume = isEdit
    ? buildFileUrl(getResumeValue(savedRecord), apiUrl)
    : "";

  const existingAadhar = isEdit
    ? buildFileUrl(getAadharValue(savedRecord), apiUrl)
    : "";

  /* =====================================================
     VALIDATION POPUP (replaces the browser alert box)
  ===================================================== */

  const [popup, setPopup] = useState(null);

  const showAlert = (text, title = "Validation Error", type = "error") => {
    setPopup({ text, title, type });
  };

  const closePopup = () => setPopup(null);

  /* Esc key closes the popup */
  useEffect(() => {
    if (!popup) {
      return undefined;
    }

    const onKey = (e) => {
      if (e.key === "Escape") {
        setPopup(null);
      }
    };

    window.addEventListener("keydown", onKey);

    return () => window.removeEventListener("keydown", onKey);
  }, [popup]);

  /* =====================================================
     ENQUIRY POPUP
  ===================================================== */

  const [showEnquiryPopup, setShowEnquiryPopup] = useState(false);
  const [enquiries, setEnquiries] = useState([]);

  const [searchName, setSearchName] = useState("");
  const [searchPhone, setSearchPhone] = useState("");
  const [searchCourse, setSearchCourse] = useState("");
  const [searchDate, setSearchDate] = useState("");

  const [selectedEnquiry, setSelectedEnquiry] = useState(
    isEdit ? registration : null
  );
  const [activeStep, setActiveStep] = useState(1);

  const [popupMode, setPopupMode] = useState("new"); /* "new" | "registered" */
  const [registrations, setRegistrations] = useState([]);
  const [registrationNo, setRegistrationNo] = useState(
    isEdit
      ? formatRegNo(getRegNumber(initial.registration_id || initial.id))
      : ""
  );

  /*
   * The discount the enquiry offered (for example "10").
   * When the validity is over the discount box becomes 0, but this value is
   * kept so the red message can still show the discount that has ended
   * (and so it can come back if the registration date is changed back).
   */
  const [offerDiscount, setOfferDiscount] = useState(
    positiveDiscount(initial.discount_percentage)
  );

  /* =====================================================
     COURSES FROM THE COURSE FEES TABLE
     Only courses with an ACTIVE fee are offered. The fee table stores
     only Course_id, so the NAME is looked up in the Course master.
  ===================================================== */
  const [feeCourses, setFeeCourses] = useState([]);

  useEffect(() => {
    let active = true;

    const toList = (data) =>
      Array.isArray(data)
        ? data
        : Array.isArray(data && data.results)
        ? data.results
        : Array.isArray(data && data.data)
        ? data.data
        : [];

    (async () => {
      try {
        const [feeData, courseData] = await Promise.all([
          getData("fetch_coursefee_datail"),
          getData("fetch_course_datail")
        ]);

        const masterCourses = toList(courseData);

        /* a fee with no saved status counts as Active */
        const activeFees = toList(feeData).filter(
          (f) => !f.Status || f.Status === "Active"
        );

        const list = [];
        const seen = new Set();

        activeFees.forEach((fee) => {
          const course = masterCourses.find(
            (c) => Number(c.Course_id) === Number(fee.Course_id)
          );

          if (!course || !course.Course_name) return;
          if (seen.has(Number(fee.Course_id))) return;
          seen.add(Number(fee.Course_id));

          list.push({
            Course_id: fee.Course_id,
            Course_name: course.Course_name,
            Course_Fees: fee.Course_Fees
          });
        });

        list.sort((x, y) =>
          String(x.Course_name).localeCompare(String(y.Course_name))
        );

        if (active) setFeeCourses(list);
      } catch (err) {
        console.error("Failed to fetch course fees:", err);
      }
    })();

    return () => {
      active = false;
    };
  }, [getData]);

  /* all registrations come from AuthContext -> getData("fetch_registration_datail") */
  const loadRegistrations = async () => {
    try {
      const list = await getData("fetch_registration_datail");

      /* getData() gives nothing back when the request failed */
      if (!Array.isArray(list)) {
        throw new Error("Unable to load registrations.");
      }

      setRegistrations(list);
      return list;
    } catch (err) {
      console.error("Error fetching registrations:", err);
      return [];
    }
  };

  /* =====================================================
     EDUCATIONAL QUALIFICATION ROWS
  ===================================================== */

  const [educationRows, setEducationRows] = useState(
    isEdit ? buildEducationRows(initial) : defaultEducationRows()
  );

  const updateEduRow = (index, patch) => {
    setEducationRows((previous) =>
      previous.map((row, i) => (i === index ? { ...row, ...patch } : row))
    );
  };

  /*
   * Qualification typed or picked.
   * 12th or below (12th, 10th, 6th, 7th, 4th ...): Degree and Department
   * are cleared and the two boxes are locked (see isSchoolLevel).
   */
  const changeQualification = (index, value) => {
    if (isSchoolLevel(value)) {
      updateEduRow(index, { qualification: value, degree: "", department: "" });
    } else {
      updateEduRow(index, { qualification: value });
    }
  };

  /* "+" adds a new empty row right below the clicked row (every row) */
  const addEduRowAfter = (index) => {
    if (educationRows.length >= 15) {
      showAlert(
        "You can add only 15 qualification rows.",
        "Cannot Add",
        "warning"
      );
      return;
    }

    setEducationRows((previous) => {
      const next = [...previous];
      next.splice(index + 1, 0, emptyEduRow(""));
      return next;
    });
  };

  /* "-" removes the clicked row (every row, but at least one row stays) */
  const removeEduRow = (index) => {
    if (educationRows.length <= 1) {
      showAlert(
        "At least one qualification row is required.",
        "Cannot Remove",
        "warning"
      );
      return;
    }

    setEducationRows((previous) => previous.filter((_, i) => i !== index));
  };

  /* qualification / institute / board / degree / department typing check */
  const handleEduText = (index, field, value) => {
    const rule = EDU_TEXT_RULES[field];

    if (/^\s/.test(value)) {
      showAlert(`${rule.label} cannot start with a space.`);
      return;
    }

    if (/\s{2,}/.test(value)) {
      showAlert("Only one space is allowed between words.");
      return;
    }

    if (!rule.pattern.test(value)) {
      showAlert(`${rule.label} can contain only ${rule.allowed}.`);
      return;
    }

    if (value.length > rule.max) {
      showAlert(`${rule.label} cannot be more than ${rule.max} characters.`);
      return;
    }

    if (field === "qualification") {
      changeQualification(index, value);
      return;
    }

    updateEduRow(index, { [field]: value });
  };

  const handleEduPercentage = (index, value) => {
    if (!/^\d*\.?\d{0,2}$/.test(value)) {
      showAlert(
        "Please type numbers only for percentage (maximum 2 decimal places)."
      );
      return;
    }

    if (value !== "" && Number(value) > 100) {
      showAlert("Percentage cannot be more than 100.");
      return;
    }

    updateEduRow(index, { percentage: value });
  };

  const handleEduYear = (index, value) => {
    if (!/^\d*$/.test(value)) {
      showAlert("Please type numbers only for year.");
      return;
    }

    if (value.length > 4) {
      showAlert("Year must contain only 4 digits.");
      return;
    }

    updateEduRow(index, { yop: value });
  };

  /* default registration id (IGT0001...) when the add page opens */
  useEffect(() => {
    if (!isEdit) {
      loadRegistrations().then((list) => setRegistrationNo(getNextRegNo(list)));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /* edit mode: load the full record so the saved photo / documents appear automatically */
  useEffect(() => {
    if (!isEdit || !registrationId) {
      return undefined;
    }

    let cancelled = false;

    const loadSavedFiles = async () => {
      let merged = { ...initial };

      /* 1. full record from the server */
      try {
        const rec = await Fetch(
          { Registration_id: registrationId },
          "get_registration_datail"
        );

        if (rec && typeof rec === "object") {
          Object.keys(rec).forEach((key) => {
            if (rec[key] !== null && rec[key] !== undefined && rec[key] !== "") {
              merged[key] = rec[key];
            }
          });
        }
      } catch (err) {
        console.warn("Could not load the full registration record:", err);
      }

      /* 2. still no photo? use the same person's other registrations */
      if (!getPhotoValue(merged)) {
        const list = await loadRegistrations();

        const samePerson = list
          .filter(
            (r) =>
              String(r.enquiry_no || "") === String(merged.enquiry_no || "") ||
              (merged.mobile_number &&
                String(r.mobile_number) === String(merged.mobile_number))
          )
          .sort((a, b) => getRecordOrder(b) - getRecordOrder(a));

        for (const r of samePerson) {
          const photo = getPhotoValue(r);

          if (photo) {
            merged = { ...merged, student_photo: photo };
            break;
          }
        }
      }

      if (!cancelled) {
        setSavedRecord(merged);

        /* remember the saved discount so the red message can show it */
        const savedDiscount = positiveDiscount(merged.discount_percentage);

        if (savedDiscount) {
          setOfferDiscount(savedDiscount);
        }

        /*
         * the education table of the saved record:
         * education_details (list) when it was saved, otherwise it is
         * built from the single columns (college_name, degree_course ...)
         */
        setEducationRows(buildEducationRows(merged));
      }
    };

    loadSavedFiles();

    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /* =====================================================
     MESSAGES
  ===================================================== */

  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  /* =====================================================
     FORM
  ===================================================== */

  const [form, setForm] = useState({
    enquiry_no: initial.enquiry_no ?? "",
    registration_date: toDateInput(initial.registration_date),
    student_name: initial.student_name ?? "",
    mobile_number: initial.mobile_number ?? "",
    email: initial.email ?? "",
    address: initial.address ?? "",

    qualification: initial.qualification ?? "",
    college_name: initial.college_name ?? "",
    diploma_course: initial.diploma_course ?? "",
    degree_course: initial.degree_course ?? "",
    specialization: initial.specialization ?? "",
    year_of_passing: initial.year_of_passing ?? "",
    school_name: initial.school_name ?? "",
    tenth_marks: initial.tenth_marks ?? "",
    twelfth_marks: initial.twelfth_marks ?? "",
    gpa: initial.gpa ?? "",

    course: initial.course ?? "",
    course_fees: initial.course_fees ?? "",
    discount_percentage: initial.discount_percentage ?? "",
    /* the validity date is not shown as a box - only the message below the discount */
    discount_validity: toValidityDate(initial.discount_validity),

    status: initial.status || "Active",
    remarks: initial.remarks ?? ""
  });

  /* =====================================================
     DOCUMENTS
  ===================================================== */

  const [studentImage, setStudentImage] = useState(null);
  const [resume, setResume] = useState(null);
  const [aadharCard, setAadharCard] = useState(null);

  /* photo saved for an already registered person (shown as preview) */
  const [reusedPhotoValue, setReusedPhotoValue] = useState("");
  const [docsCopying, setDocsCopying] = useState(false);

  /* =====================================================
     OPEN ENQUIRY POPUP
     (new enquiries + already registered people)
  ===================================================== */

  const openEnquiryPopup = async () => {
    setError("");
    setMessage("");

    setSearchName("");
    setSearchPhone("");
    setSearchCourse("");
    setSearchDate("");

    setShowEnquiryPopup(true);
    setPopupMode("new");

    /* registered people (used for "Already Registered" + hiding them from "New Enquiry") */
    loadRegistrations();

    try {
      const list = await getData("fetch_registration_enquiry_datail");

      /* getData() gives nothing back when the request failed */
      if (!Array.isArray(list)) {
        throw new Error("Unable to load enquiries from server.");
      }

      setEnquiries(list);
    } catch (err) {
      console.error("Error fetching enquiries:", err);

      setEnquiries([]);

      setError("Unable to load enquiries from server.");

      showAlert("Unable to load enquiries from server.", "Server Error");
    }
  };

  /* =====================================================
     BUILD THE FORM FROM AN ENQUIRY / REGISTRATION RECORD
     (fills every slide: personal, educational, course)
  ===================================================== */

  const buildFormFromRecord = (src, enquiryNo) => {
    const registrationDate = getToday();
    const validity = getValidityEnd(src);

    /* discount is 0 when the validity already ended (user can change it later) */
    const discount = isValidityCrossed(registrationDate, validity)
      ? "0"
      : src.discount_percentage ?? "";

    return {
      enquiry_no: enquiryNo,
      registration_date: registrationDate,

      student_name: src.student_name || "",
      mobile_number: src.mobile_number || "",
      email: src.email || "",
      address: src.address || "",

      qualification: src.qualification || "",
      college_name: src.college_name || "",
      diploma_course: src.diploma_course || "",
      degree_course: src.degree_course || "",
      specialization: src.specialization || "",
      year_of_passing: src.year_of_passing || "",
      school_name: src.school_name || "",
      tenth_marks: src.tenth_marks ?? "",
      twelfth_marks: src.twelfth_marks ?? "",
      gpa: src.gpa ?? "",

      course: src.course || src.degree_course || src.diploma_course || "",
      /* the amount comes from the enquiry (other common field names are checked too) */
      course_fees: pickFirst(src, [
        "course_fees",
        "course_fee",
        "fees",
        "fee",
        "total_fees",
        "amount"
      ]),
      discount_percentage: discount,
      discount_validity: validity,

      /* a registration always starts as Active - the enquiry statuses
         (Follow Up / Converted ...) are not registration statuses */
      status: REGISTRATION_STATUSES.includes(src.status)
        ? src.status
        : "Active",
      remarks: src.remarks || ""
    };
  };

  /* =====================================================
     SELECT NEW ENQUIRY
     (the enquiry list already contains every enquiry detail,
      so no second server call is needed)
  ===================================================== */

  const selectEnquiry = (item) => {
    const enquiryNo = item.enquiry_id || item.id || "";

    setSelectedEnquiry(item);

    setForm(buildFormFromRecord(item, enquiryNo));
    setEducationRows(buildEducationRows(item));

    /* the discount of the enquiry (shown in the red message when the offer is over) */
    setOfferDiscount(positiveDiscount(item.discount_percentage));

    setRegistrationNo(getNextRegNo(registrations));
    setReusedPhotoValue("");
    setStudentImage(null);
    setResume(null);
    setAadharCard(null);

    setShowEnquiryPopup(false);
    setError("");
    setMessage("");
  };

  /* =====================================================
     SELECT ALREADY REGISTERED PERSON (register another course)
  ===================================================== */

  const selectRegisteredPerson = async (person) => {
    const r = person.latest;

    setSelectedEnquiry(r);

    setForm(buildFormFromRecord(r, r.enquiry_no || ""));
    setEducationRows(buildEducationRows(r));

    setOfferDiscount(positiveDiscount(r.discount_percentage));

    /* already registered: keep the person's own registration id (duplicate allowed) */
    const personIndex = getPersonKeys(registrations).indexOf(person.key);

    setRegistrationNo(
      personIndex >= 0
        ? formatRegNo(personIndex + 1)
        : getNextRegNo(registrations)
    );

    setStudentImage(null);
    setResume(null);
    setAadharCard(null);

    setShowEnquiryPopup(false);
    setError("");
    setMessage("");

    /*
     * reuse the documents already uploaded for this person.
     * All registrations of the person are checked (newest first),
     * so a document is found even if the newest record has none.
     */
    const personRecords = [...(person.records || [r])].sort(
      (a, b) => getRecordOrder(b) - getRecordOrder(a)
    );

    const firstValue = (getter) => {
      for (const record of personRecords) {
        const value = getter(record);

        if (value) {
          return value;
        }
      }

      return "";
    };

    const photoValue = firstValue(getPhotoValue);
    const resumeValue = firstValue(getResumeValue);
    const aadharValue = firstValue(getAadharValue);

    /* the saved photo is shown at once as preview */
    setReusedPhotoValue(photoValue);

    if (!photoValue || !resumeValue || !aadharValue) {
      console.warn(
        "Document field not found in registration record. Available fields:",
        Object.keys(r)
      );
    }

    setDocsCopying(true);

    const [photo, cv, aadhar] = await Promise.allSettled([
      photoValue
        ? fetchFirstFile(photoValue, "student_photo", apiUrl, downloadFile)
        : Promise.reject(),
      resumeValue
        ? fetchFirstFile(resumeValue, "resume", apiUrl, downloadFile)
        : Promise.reject(),
      aadharValue
        ? fetchFirstFile(aadharValue, "aadhar", apiUrl, downloadFile)
        : Promise.reject()
    ]);

    if (photo.status === "fulfilled") setStudentImage(photo.value);
    if (cv.status === "fulfilled") setResume(cv.value);
    if (aadhar.status === "fulfilled") setAadharCard(aadhar.value);

    setDocsCopying(false);
  };

  /* =====================================================
     ENQUIRY POPUP SEARCH VALIDATION
     (a wrong key shows the popup alert and is not typed)
  ===================================================== */

  /* student name: letters only (space . ' - allowed) */
  const handleSearchName = (e) => {
    const value = e.target.value;

    if (/^\s/.test(value)) {
      showAlert("Student name cannot start with a space.");
      return;
    }

    if (/\s{2,}/.test(value)) {
      showAlert("Only one space is allowed between words.");
      return;
    }

    if (!/^[A-Za-z\s.'-]*$/.test(value)) {
      showAlert("Please type letters only for student name.");
      return;
    }

    if (value.length > 150) {
      showAlert("Student name cannot be more than 150 characters.");
      return;
    }

    setSearchName(value);
  };

  /* phone: numbers only, maximum 10 digits */
  const handleSearchPhone = (e) => {
    const value = e.target.value;

    if (!/^\d*$/.test(value)) {
      showAlert("Please type numbers only for phone number.");
      return;
    }

    if (value.length > 10) {
      showAlert("Phone number must contain only 10 digits.");
      return;
    }

    setSearchPhone(value);
  };

  /* course: letters, numbers, space and . + # & - / ( ) */
  const handleSearchCourse = (e) => {
    const value = e.target.value;

    if (/^\s/.test(value)) {
      showAlert("Course cannot start with a space.");
      return;
    }

    if (/\s{2,}/.test(value)) {
      showAlert("Only one space is allowed between words.");
      return;
    }

    if (!/^[A-Za-z0-9\s.+#&\-/()]*$/.test(value)) {
      showAlert(
        "Course can contain only letters, numbers and the symbols . + # & - / ( )"
      );
      return;
    }

    if (value.length > 150) {
      showAlert("Course cannot be more than 150 characters.");
      return;
    }

    setSearchCourse(value);
  };

  /* date: a complete date must have a 4 digit year between 2000 and 2100 */
  const handleSearchDate = (e) => {
    const value = e.target.value;

    if (value) {
      const match = value.match(/^(\d{4,6})-(\d{2})-(\d{2})$/);

      const year = match ? Number(match[1]) : 0;

      if (!match || year < 2000 || year > 2100) {
        showAlert("Please select a valid date (year between 2000 and 2100).");
        return;
      }
    }

    setSearchDate(value);
  };

  /* =====================================================
     NAME VALIDATION
  ===================================================== */

  const handleNameChange = (e) => {
    const value = e.target.value;

    if (!/^[A-Za-z\s.'-]*$/.test(value)) {
      showAlert("Please type letters only for student name.");
      return;
    }

    setForm((previous) => ({
      ...previous,
      student_name: value
    }));
  };

  /* =====================================================
     PHONE VALIDATION
  ===================================================== */

  const handlePhoneChange = (e) => {
    const value = e.target.value;

    if (!/^\d*$/.test(value)) {
      showAlert("Please type numbers only for mobile number.");
      return;
    }

    if (value.length > 10) {
      showAlert("Mobile number must contain only 10 digits.");
      return;
    }

    setForm((previous) => ({
      ...previous,
      mobile_number: value
    }));
  };

  /* =====================================================
     EMAIL VALIDATION
  ===================================================== */

  const handleEmailChange = (e) => {
    const value = e.target.value;

    if (/\s/.test(value)) {
      showAlert("Space is not allowed in email.");
      return;
    }

    if (!/^[A-Za-z0-9@._%+-]*$/.test(value)) {
      showAlert("Please enter a valid email address.");
      return;
    }

    const atCount = (value.match(/@/g) || []).length;

    if (atCount > 1) {
      showAlert("Email can contain only one @ symbol.");
      return;
    }

    setForm((previous) => ({
      ...previous,
      email: value
    }));
  };

  /* =====================================================
     DATE VALIDATION
  ===================================================== */

  const handleDateChange = (e) => {
    const value = e.target.value;

    if (!value) {
      setForm((previous) => ({
        ...previous,
        registration_date: ""
      }));
      return;
    }

    const selectedDate = new Date(`${value}T00:00:00`);

    const today = new Date();

    today.setHours(0, 0, 0, 0);

    if (selectedDate > today) {
      showAlert("Registration date cannot be a future date.");
      return;
    }

    setForm((previous) => {
      const next = {
        ...previous,
        registration_date: value
      };

      const wasCrossed = isValidityCrossed(
        previous.registration_date,
        previous.discount_validity
      );

      const nowCrossed = isValidityCrossed(value, previous.discount_validity);

      if (nowCrossed) {
        /* discount offer ended for the new date -> discount becomes 0 */
        next.discount_percentage = "0";
      } else if (wasCrossed && offerDiscount) {
        /* date moved back inside the validity -> the offer discount comes back */
        next.discount_percentage = offerDiscount;
      }

      return next;
    });
  };

  /* =====================================================
     NORMAL INPUT
  ===================================================== */

  const handleChange = (e) => {
    const { name, value } = e.target;

    setForm((previous) => {
      const next = { ...previous, [name]: value };

      /* changing the course fills in its fees from the Course Fees table */
      if (name === "course") {
        const match = feeCourses.find((c) => c.Course_name === value);
        if (match) next.course_fees = String(match.Course_Fees ?? "");
      }

      return next;
    });
  };

  /* =====================================================
     FILE VALIDATION
  ===================================================== */

  const validateFile = (file, type) => {
    if (!file) {
      return false;
    }

    const maxSize = 6 * 1024 * 1024;

    if (file.size > maxSize) {
      showAlert(`${type} size should not exceed 6 MB.`, "File Too Large");
      return false;
    }

    return true;
  };

  /* =====================================================
     STUDENT IMAGE
  ===================================================== */

  const handleImage = (e) => {
    const file = e.target.files[0];

    if (!file) {
      return;
    }

    if (!file.type.startsWith("image/")) {
      showAlert("Please upload a valid image file.", "Invalid File");

      e.target.value = "";
      return;
    }

    if (validateFile(file, "Student image")) {
      setStudentImage(file);
    } else {
      e.target.value = "";
    }
  };

  /* =====================================================
     RESUME
  ===================================================== */

  const handleResume = (e) => {
    const file = e.target.files[0];

    if (!file) {
      return;
    }

    const allowedTypes = [
      "application/pdf",
      "application/msword",
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    ];

    if (!allowedTypes.includes(file.type)) {
      showAlert("Please upload PDF, DOC or DOCX file.", "Invalid File");

      e.target.value = "";
      return;
    }

    if (validateFile(file, "Resume / CV")) {
      setResume(file);
    } else {
      e.target.value = "";
    }
  };

  /* =====================================================
     AADHAAR
  ===================================================== */

  const handleAadhar = (e) => {
    const file = e.target.files[0];

    if (!file) {
      return;
    }

    const allowedTypes = [
      "application/pdf",
      "image/jpeg",
      "image/png"
    ];

    if (!allowedTypes.includes(file.type)) {
      showAlert("Please upload PDF, JPG, JPEG or PNG file.", "Invalid File");

      e.target.value = "";
      return;
    }

    if (validateFile(file, "Aadhaar card")) {
      setAadharCard(file);
    } else {
      e.target.value = "";
    }
  };

  /* =====================================================
     STEP VALIDATION / NAVIGATION
     The Next button validates ONLY the Personal Details slide
     (the student photo is NOT required).
     The other slides can be passed without any checking.
     Saving does not need them (only the enquiry is needed).
  ===================================================== */

  const validateStep = (step) => {
    if (step === 1) {
      if (!isEdit && (!selectedEnquiry || !form.enquiry_no)) {
        showAlert(
          "Please select an enquiry before continuing.",
          "Required Field",
          "warning"
        );
        return false;
      }

      if (!form.registration_date) {
        showAlert("Please enter registration date.", "Required Field", "warning");
        return false;
      }

      if (!form.student_name.trim()) {
        showAlert("Please enter student name.", "Required Field", "warning");
        return false;
      }

      if (!/^\d{10}$/.test(form.mobile_number)) {
        showAlert("Please enter a valid 10 digit mobile number.");
        return false;
      }

      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) {
        showAlert("Please enter a valid email address.");
        return false;
      }

      if (!form.address.trim()) {
        showAlert("Please enter address.", "Required Field", "warning");
        return false;
      }

      /* student photo is not validated - the user can continue without it */
    }

    /* Educational Details and Course Details slides: no validation */

    return true;
  };

  /*
   * TOP TABS CAN ALWAYS BE CLICKED.
   * Validation is performed only by handleNextStep().
   */

  const goToStep = (step) => {
    if (step === activeStep) {
      return;
    }

    setActiveStep(step);

    window.scrollTo({
      top: 0,
      behavior: "smooth"
    });
  };

  const handleNextStep = () => {
    if (!validateStep(activeStep)) {
      return;
    }

    setActiveStep((previous) => Math.min(previous + 1, 4));

    window.scrollTo({
      top: 0,
      behavior: "smooth"
    });
  };

  const handlePreviousStep = () => {
    setActiveStep((previous) => Math.max(previous - 1, 1));

    window.scrollTo({
      top: 0,
      behavior: "smooth"
    });
  };

  /* =====================================================
     SUBMIT
  ===================================================== */

  const handleSubmit = async (e) => {
    e.preventDefault();

    /* the form is saved only from the Upload Documents slide */
    if (activeStep !== 4) {
      return;
    }

    setError("");
    setMessage("");

    if (!selectedEnquiry) {
      showAlert("Please select an enquiry.", "Required Field", "warning");
      return;
    }

    /* empty boxes are allowed - filled boxes must be correct */

    if (form.student_name && !/^[A-Za-z\s.'-]+$/.test(form.student_name)) {
      showAlert("Please enter only letters in student name.");
      return;
    }

    if (form.mobile_number && !/^\d{10}$/.test(form.mobile_number)) {
      showAlert("Please enter a valid 10 digit mobile number.");
      return;
    }

    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (form.email && !emailPattern.test(form.email)) {
      showAlert("Please enter a valid email address.");
      return;
    }

    if (!isEdit && form.course.trim()) {
      const duplicate = registrations.some(
        (r) =>
          String(r.enquiry_no) === String(form.enquiry_no) &&
          String(r.course || "").trim().toLowerCase() ===
            form.course.trim().toLowerCase()
      );

      if (duplicate) {
        showAlert(
          "This student is already registered for this course. Please choose a different course.",
          "Already Registered"
        );
        return;
      }
    }

    /* education table: every row that has any detail needs a qualification */
    for (let i = 0; i < educationRows.length; i += 1) {
      const row = educationRows[i];

      if (rowHasData(row) && !isFilled(row.qualification)) {
        showAlert(
          `Please enter the qualification in row ${i + 1} of the education details.`,
          "Required Field",
          "warning"
        );
        return;
      }

      if (isFilled(row.yop) && !/^\d{4}$/.test(String(row.yop))) {
        showAlert(
          `Year of passing in row ${i + 1} must contain 4 digits.`
        );
        return;
      }
    }

    try {
      let created = null;

      const data = new FormData();

      /*
       * the education table (fetched from the enquiry + everything typed
       * by hand) in the SAME list structure as the enquiry table
       */
      const cleanRows = cleanEducationRows(educationRows);

      /* the education table is copied into the existing single fields */
      const merged = { ...form, ...rowsToLegacyFields(cleanRows) };

      const keepFields = QUALIFICATION_FIELDS[merged.qualification] || [];

      Object.keys(merged).forEach((key) => {
        let value = merged[key];

        /* boxes hidden for the chosen qualification are sent empty */
        if (EDU_FIELDS.includes(key) && !keepFields.includes(key)) {
          value = "";
        }

        /* registration date falls back to today */
        if (key === "registration_date" && !isFilled(value)) {
          value = getToday();
        }

        /*
         * empty boxes are not sent, so a new registration can be saved
         * with only the details fetched from the enquiry
         */
        if (!isFilled(value) && (!isEdit || SKIP_IF_EMPTY.includes(key))) {
          return;
        }

        data.append(key, value);
      });

      /* the full education table (every row) - same structure as the enquiry */
      data.append("education_details", JSON.stringify(cleanRows));

      /*
       * IMPORTANT:
       * Backend serializer uses student_photo, resume_cv, aadhar_card.
       * In edit mode a file is sent only when a new one is chosen.
       */

      if (studentImage) {
        data.append("student_photo", studentImage);
      }

      if (resume) {
        data.append("resume_cv", resume);
      }

      if (aadharCard) {
        data.append("aadhar_card", aadharCard);
      }

      /*
       * Both calls come from AuthContext.insert (same flow as Addcoursefee.js).
       * insert() throws the Django error (err.responseData) so it can be
       * shown in the popup below.
       */
      const payload = await formDataToPayload(data);

      if (isEdit) {
        payload.Registration_id = registrationId;

        const response = await insert(
          payload,
          "update_registration_datail"
        );

        if (response && response.success === false) {
          const failure = new Error("Update failed");
          failure.responseData = response;
          throw failure;
        }
      } else {
        created = await insert(payload, "registration_create");
      }

      setMessage(
        isEdit
          ? "Registration updated successfully."
          : "Registration saved successfully."
      );

      /*
       * A NEW registration is handed to the parent page so it can open the
       * billing plan page for this student. The saved record is read from
       * the create response; if the response has no id, the newest record
       * of this enquiry + course is read back from the registration list.
       */
      let savedRecord = null;

      if (!isEdit) {
        const readCreated = (r) => {
          const candidates = [
            r,
            r && r.data,
            r && r.data && r.data.data,
            r && r.registration
          ];

          return candidates.find(
            (x) =>
              x &&
              typeof x === "object" &&
              !Array.isArray(x) &&
              (x.id !== undefined || x.registration_id !== undefined)
          );
        };

        savedRecord = readCreated(created) || null;

        if (!savedRecord) {
          const list = await loadRegistrations();

          savedRecord =
            list
              .filter(
                (r) =>
                  String(r.enquiry_no) === String(form.enquiry_no) &&
                  String(r.course || "").trim().toLowerCase() ===
                    String(form.course || "").trim().toLowerCase()
              )
              .sort((a, b) => getRecordOrder(b) - getRecordOrder(a))[0] ||
            null;
        }
      }

      if (onSaved) {
        setTimeout(() => {
          onSaved(savedRecord);
        }, 1000);
      }
    } catch (err) {
      console.error("Registration save error:", err);

      /* AuthContext puts the Django error in err.responseData */
      const backendError = err.responseData;

      const errorMessage = getErrorMessage(
        backendError,
        isEdit
          ? "Unable to update registration."
          : "Unable to save registration."
      );

      setError(errorMessage);
      showAlert(errorMessage, "Unable to Save");
    }
  };

  /* =====================================================
     FILTER ENQUIRIES
  ===================================================== */

  /* New Enquiry list: people who are NOT registered yet */
  const registeredEnquiryNos = new Set(
    registrations.map((r) => String(r.enquiry_no || "")).filter(Boolean)
  );

  const newEnquiries = enquiries.filter(
    (item) =>
      !registeredEnquiryNos.has(String(item.enquiry_id || item.id || ""))
  );

  const filteredEnquiries = newEnquiries.filter((item) => {
    const nameMatch =
      !searchName.trim() || startsWithText(item.student_name, searchName);

    const phoneMatch =
      !searchPhone.trim() || startsWithText(item.mobile_number, searchPhone);

    const courseMatch =
      !searchCourse.trim() || startsWithText(item.course, searchCourse);

    const dateMatch =
      !searchDate ||
      String(item.enquiry_date || "").includes(searchDate);

    return nameMatch && phoneMatch && courseMatch && dateMatch;
  });

  /* Already Registered list: one row per person, with all their courses */
  const registeredPeople = Object.values(
    registrations.reduce((acc, r) => {
      const key = String(r.enquiry_no || r.mobile_number || r.id);

      if (!acc[key]) {
        acc[key] = { key, latest: r, first: r, courses: [], records: [] };
      } else if (getRecordOrder(r) >= getRecordOrder(acc[key].latest)) {
        acc[key].latest = r;
      }

      /* first registration of the person = the person's own registration id */
      if (getRecordOrder(r) < getRecordOrder(acc[key].first)) {
        acc[key].first = r;
      }

      /* every registration of the person (used to find the saved documents) */
      acc[key].records.push(r);

      if (r.course) {
        acc[key].courses.push(r.course);
      }

      return acc;
    }, {})
  );

  const filteredRegistered = registeredPeople.filter(({ latest, courses }) => {
    const nameMatch =
      !searchName.trim() || startsWithText(latest.student_name, searchName);

    const phoneMatch =
      !searchPhone.trim() || startsWithText(latest.mobile_number, searchPhone);

    const courseMatch =
      !searchCourse.trim() ||
      courses.some((c) => startsWithText(c, searchCourse));

    const dateMatch =
      !searchDate ||
      String(latest.registration_date || "").includes(searchDate);

    return nameMatch && phoneMatch && courseMatch && dateMatch;
  });

  /* =====================================================
     INLINE DESIGN
  ===================================================== */

  const styles = `
    .registration-page-custom {
      background: #f5f5f9;
      min-height: 100vh;
      padding-bottom: 35px;
    }

    .registration-page-custom .page-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 24px;
    }

    .registration-page-custom .page-title {
      margin: 0;
      color: #566a7f;
      font-weight: 700;
      font-size: 26px;
    }

    .registration-page-custom .back-button {
      border: 1px solid #d9dee3;
      background: #fff;
      color: #697a8d;
      border-radius: 7px;
      padding: 10px 18px;
      font-weight: 600;
      transition: all .2s ease;
    }

    .registration-page-custom .back-button:hover {
      background: #f5f5f9;
      color: #566a7f;
    }

    /* ---------- ONE CARD: step bar + form + buttons ---------- */

    .registration-page-custom .reg-main-card {
      background: #fff;
      border-radius: 16px;
      box-shadow: 0 .125rem .25rem rgba(161,172,184,.15);
      overflow: hidden;
      margin-bottom: 22px;
    }

    .registration-page-custom .reg-main-card .custom-card {
      box-shadow: none;
      border-radius: 0;
      margin-bottom: 0;
      background: transparent;
      overflow: visible;
    }

    .registration-page-custom .reg-main-card .section-header {
      display: none;
    }

    .registration-page-custom .reg-main-card .section-body {
      padding: 26px 24px 24px;
    }

    .registration-page-custom .reg-main-card .alert {
      margin: 0 24px 16px;
    }

    /* ---------- STEP BAR (card style with numbered circles) ---------- */

    .registration-page-custom .registration-step-tabs {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 12px;
      padding: 20px 24px;
      border-bottom: 1px solid #ebeef0;
    }

    .registration-page-custom .registration-step-tab {
      display: flex;
      align-items: center;
      gap: 12px;
      border: 0;
      background: #f3f4f9;
      color: #1f2a44;
      padding: 14px 18px;
      font-size: 15px;
      font-weight: 600;
      border-radius: 12px;
      white-space: nowrap;
      cursor: pointer;
      text-align: left;
      transition: all .2s ease;
    }

    .registration-page-custom .registration-step-tab:hover {
      background: #eceefa;
    }

    .registration-page-custom .registration-step-tab.active {
      background: #eef0ff;
      color: #4338ca;
    }

    .registration-page-custom .step-circle {
      width: 34px;
      height: 34px;
      min-width: 34px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 14px;
      font-weight: 700;
      background: #e3e6ee;
      color: #7b8499;
      transition: all .2s ease;
    }

    .registration-page-custom .step-circle svg {
      width: 16px;
      height: 16px;
    }

    /* current slide (not finished) */
    .registration-page-custom .step-circle.current {
      background: #4338ca;
      color: #fff;
    }

    /* nothing filled / not finished - grey tick */
    .registration-page-custom .step-circle.pending {
      background: #e3e6ee;
      color: #9aa3b5;
    }

    /* all details filled - green tick */
    .registration-page-custom .step-circle.done {
      background: #22c55e;
      color: #fff;
    }

    .registration-page-custom .step-navigation {
      display: flex;
      justify-content: space-between;
      align-items: center;
      gap: 10px;
      margin-top: 0;
      padding: 18px 24px;
      border-top: 1px solid #ebeef0;
    }

    .registration-page-custom .step-content {
      width: 100%;
    }

    .registration-page-custom .custom-card {
      background: #fff;
      border: 0;
      border-radius: 10px;
      box-shadow: 0 .125rem .25rem rgba(161,172,184,.15);
      margin-bottom: 22px;
      overflow: hidden;
    }

    .registration-page-custom .section-header {
      padding: 20px 24px 8px;
      border-bottom: 0;
    }

    .registration-page-custom .section-title {
      color: #566a7f;
      font-size: 20px;
      font-weight: 600;
      margin: 0;
    }

    .registration-page-custom .section-body {
      padding: 16px 24px 24px;
    }

    .registration-page-custom .sub-title {
      color: #566a7f;
      font-size: 17px;
      font-weight: 600;
      margin-bottom: 18px;
    }

    .registration-page-custom .form-label {
      color: #566a7f;
      font-size: 13px;
      font-weight: 600;
      margin-bottom: 7px;
      text-transform: uppercase;
    }

    .registration-page-custom .form-control,
    .registration-page-custom .form-select {
      min-height: 46px;
      border-color: #d9dee3;
      border-radius: 7px;
      color: #566a7f;
      box-shadow: none;
    }

    .registration-page-custom .form-control:focus,
    .registration-page-custom .form-select:focus {
      border-color: #696cff;
      box-shadow: 0 0 0 .15rem rgba(105,108,255,.12);
    }

    /* FINAL FEE box (read only, calculated) */
    .registration-page-custom .final-fee-box,
    .registration-page-custom .final-fee-box:focus {
      background-color: #f5f5f9;
      color: #566a7f;
      font-weight: 700;
      cursor: default;
      border-color: #d9dee3;
      box-shadow: none;
    }

    /* DISCOUNT OFFER MESSAGE (replaces the old discount validity box) */
    .registration-page-custom .discount-offer-msg {
      display: flex;
      align-items: center;
      min-height: 46px;
      font-size: 14px;
      font-weight: 600;
      line-height: 1.4;
    }

    .registration-page-custom .discount-offer-msg.available {
      color: #71dd37;
    }

    .registration-page-custom .discount-offer-msg.ended {
      color: #ff3e1d;
    }

    /* ---------- EDUCATIONAL QUALIFICATIONS TABLE ---------- */

    .registration-page-custom .edu-table-wrap {
      width: 100%;
      overflow-x: auto;
    }

    .registration-page-custom .edu-table {
      width: 100%;
      min-width: 980px;
      border-collapse: collapse;
      border: 1px solid #e3e6ea;
    }

    .registration-page-custom .edu-table th {
      padding: 16px 10px;
      border: 1px solid #e3e6ea;
      color: #697a8d;
      font-size: 15px;
      font-weight: 700;
      text-align: center;
      white-space: nowrap;
      background: #fff;
    }

    .registration-page-custom .edu-table td {
      padding: 10px;
      border: 1px solid #e3e6ea;
      text-align: center;
      vertical-align: middle;
      color: #697a8d;
    }

    .registration-page-custom .edu-table .edu-sno {
      width: 70px;
      font-size: 16px;
    }

    .registration-page-custom .edu-table .form-control,
    .registration-page-custom .edu-table .form-select {
      width: 100%;
      min-height: 46px;
      padding: 8px 12px;
      font-size: 15px;
      border: 1px solid #d9dee3;
      border-radius: 10px;
      color: #566a7f;
      background-color: #fff;
    }

    /* locked boxes (Degree / Department of 12th or below) */
    .registration-page-custom .edu-table .edu-readonly,
    .registration-page-custom .edu-table .edu-readonly:disabled {
      background-color: #e9ecef;
      color: #566a7f;
      cursor: not-allowed;
    }

    .registration-page-custom .edu-col-qualification { width: 170px; }
    .registration-page-custom .edu-col-institute { min-width: 230px; }
    .registration-page-custom .edu-col-board { width: 130px; }
    .registration-page-custom .edu-col-percentage { width: 130px; }
    .registration-page-custom .edu-col-yop { width: 120px; }

    /*
     * BOARD / UNIVERSITY box: normal size at rest. It grows wider while the
     * cursor is on it or while it is being typed in, and goes back to the
     * original size when the cursor is moved away (and the box is not in use).
     * The wide box floats over the next columns, so the table does not move.
     */
    .registration-page-custom .edu-board-wrap {
      position: relative;
      height: 46px;
    }

    .registration-page-custom .edu-table .edu-board-input {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      z-index: 1;
      text-overflow: ellipsis;
      transition: width .2s ease, box-shadow .2s ease, border-color .2s ease;
    }

    .registration-page-custom .edu-table .edu-board-wrap:hover .edu-board-input,
    .registration-page-custom .edu-table .edu-board-input:focus {
      width: 340px;
      z-index: 20;
      border-color: #696cff;
      box-shadow: 0 6px 18px rgba(34,48,80,.18);
      text-overflow: clip;
    }

    /* qualification box (text + drop-down button) */
    .registration-page-custom .qual-box { position: relative; }

    .registration-page-custom .qual-box .form-control {
      padding-right: 38px;
    }

    .registration-page-custom .qual-toggle {
      position: absolute;
      top: 50%;
      right: 8px;
      transform: translateY(-50%);
      width: 26px;
      height: 26px;
      border: 0;
      border-radius: 6px;
      background: transparent;
      color: #8592a3;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      transition: all .15s ease;
    }

    .registration-page-custom .qual-toggle:hover,
    .registration-page-custom .qual-toggle.is-open {
      background: #eceefa;
      color: #4338ca;
    }

    .registration-page-custom .qual-menu {
      position: fixed;
      z-index: 2000;
      background: #fff;
      border: 1px solid #e4e6ee;
      border-radius: 12px;
      box-shadow: 0 10px 30px rgba(34,48,80,.18);
      padding: 6px;
    }

    .registration-page-custom .qual-option {
      display: block;
      width: 100%;
      height: 38px;
      padding: 0 12px;
      border: 0;
      border-radius: 8px;
      background: transparent;
      color: #566a7f;
      font-size: 15px;
      font-weight: 600;
      text-align: left;
      cursor: pointer;
      transition: all .15s ease;
    }

    .registration-page-custom .qual-option:hover {
      background: #e6e8ff;
      color: #4338ca;
    }

    .registration-page-custom .qual-option.selected {
      background: #696cff;
      color: #fff;
    }

    /* year picker */
    .registration-page-custom .year-picker { position: relative; }

    .registration-page-custom .year-picker-btn {
      width: 100%;
      height: 100%;
      min-height: 40px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 6px;
      padding: 8px 10px;
      background: #fff;
      border: 1px solid #d9dee3;
      border-radius: 8px;
      color: #a1acb8;
      font-size: 14px;
      cursor: pointer;
      transition: border-color .15s ease, box-shadow .15s ease;
    }

    .registration-page-custom .year-picker-btn.has-value { color: #566a7f; }

    .registration-page-custom .year-picker-btn:hover,
    .registration-page-custom .year-picker-btn.is-open {
      border-color: #696cff;
      box-shadow: 0 0 0 3px rgba(105,108,255,.15);
    }

    .registration-page-custom .year-picker-icon {
      font-size: 16px;
      color: #8592a3;
    }

    .registration-page-custom .year-picker-popup {
      position: fixed;
      z-index: 2000;
      width: 244px;
      background: #fff;
      border: 1px solid #e4e6ee;
      border-radius: 12px;
      box-shadow: 0 10px 30px rgba(34,48,80,.18);
      padding: 12px;
    }

    .registration-page-custom .year-picker-head {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 10px;
    }

    .registration-page-custom .year-picker-range {
      font-weight: 700;
      font-size: 14px;
      color: #566a7f;
    }

    .registration-page-custom .year-nav-btn {
      width: 30px;
      height: 30px;
      border: 0;
      border-radius: 8px;
      background: #f3f4f9;
      color: #566a7f;
      font-size: 20px;
      line-height: 1;
      cursor: pointer;
    }

    .registration-page-custom .year-nav-btn:hover:not(:disabled) {
      background: #e6e8ff;
      color: #4338ca;
    }

    .registration-page-custom .year-nav-btn:disabled {
      opacity: .35;
      cursor: not-allowed;
    }

    .registration-page-custom .year-picker-grid {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 6px;
    }

    .registration-page-custom .year-cell {
      height: 38px;
      border: 1px solid transparent;
      border-radius: 8px;
      background: #f7f8fb;
      color: #566a7f;
      font-size: 14px;
      font-weight: 600;
      cursor: pointer;
      transition: all .15s ease;
    }

    .registration-page-custom .year-cell:hover:not(:disabled) {
      background: #e6e8ff;
      color: #4338ca;
    }

    .registration-page-custom .year-cell.current {
      border-color: #696cff;
    }

    .registration-page-custom .year-cell.selected {
      background: #696cff;
      color: #fff;
    }

    .registration-page-custom .year-cell:disabled {
      opacity: .3;
      cursor: not-allowed;
    }

    .registration-page-custom .year-picker-foot {
      display: flex;
      justify-content: space-between;
      margin-top: 10px;
      padding-top: 8px;
      border-top: 1px solid #ebeef0;
    }

    .registration-page-custom .year-link {
      border: 0;
      background: transparent;
      color: #696cff;
      font-size: 13px;
      font-weight: 600;
      cursor: pointer;
    }

    .registration-page-custom .year-link:hover { text-decoration: underline; }

    .registration-page-custom .edu-col-degree { width: 120px; }
    .registration-page-custom .edu-col-department { width: 140px; }
    .registration-page-custom .edu-col-actions { width: 120px; }

    /* + (green) and - (red) buttons in the Actions column */

    .registration-page-custom .edu-actions {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 12px;
    }

    .registration-page-custom .edu-add-btn,
    .registration-page-custom .edu-remove-btn {
      width: 38px;
      height: 38px;
      padding: 0;
      border-radius: 10px;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      transition: all .2s ease;
    }

    .registration-page-custom .edu-add-btn {
      border: 1px solid #c6efcf;
      background: #f1fbf3;
      color: #22b24c;
    }

    .registration-page-custom .edu-add-btn:hover {
      background: #22b24c;
      border-color: #22b24c;
      color: #fff;
    }

    .registration-page-custom .edu-remove-btn {
      border: 1px solid #f5c6c6;
      background: #fdf0f0;
      color: #e53935;
    }

    .registration-page-custom .edu-remove-btn:hover {
      background: #e53935;
      border-color: #e53935;
      color: #fff;
    }

    /* locked buttons (10th and 12th rows): visible but not clickable */
    .registration-page-custom .edu-add-btn:disabled,
    .registration-page-custom .edu-remove-btn:disabled {
      opacity: .45;
      cursor: not-allowed;
      pointer-events: none;
    }

    .registration-page-custom .edu-add-btn:disabled:hover {
      background: #f1fbf3;
      border-color: #c6efcf;
      color: #22b24c;
    }

    .registration-page-custom .edu-remove-btn:disabled:hover {
      background: #fdf0f0;
      border-color: #f5c6c6;
      color: #e53935;
    }

    .registration-page-custom .edu-add-btn svg,
    .registration-page-custom .edu-remove-btn svg {
      width: 18px;
      height: 18px;
    }

    .registration-page-custom .enquiry-box {
      min-height: 46px;
      border: 1px solid #d9dee3;
      border-radius: 7px;
      display: flex;
      align-items: center;
      padding: 0 13px;
      color: #697a8d;
      cursor: pointer;
      background: #fff;
      transition: .2s;
    }

    .registration-page-custom .enquiry-box:hover {
      border-color: #696cff;
      background: #f8f8ff;
    }

    .registration-page-custom .enquiry-box.locked,
    .registration-page-custom .enquiry-box.locked:hover {
      cursor: default;
      background: #f5f5f9;
      border-color: #d9dee3;
    }

    .registration-page-custom .student-image-area {
      display: flex;
      justify-content: flex-end;
      align-items: flex-start;
      height: auto;
    }

    .registration-page-custom .student-image-box {
      width: 150px;
      height: 170px;
      border: 2px dashed #d9dee3;
      border-radius: 12px;
      background: #f8f8fa;
      display: flex;
      align-items: center;
      justify-content: center;
      overflow: hidden;
      position: relative;
      cursor: pointer;
      transition: .2s ease;
    }

    .registration-page-custom .student-image-box:hover {
      border-color: #696cff;
      background: #f8f8ff;
    }

    .registration-page-custom .student-image-preview {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }

    .registration-page-custom .image-placeholder {
      text-align: center;
      color: #8592a3;
      padding: 10px;
    }

    .registration-page-custom .image-placeholder i {
      font-size: 34px;
      color: #696cff;
      display: block;
      margin-bottom: 7px;
    }

    .registration-page-custom .image-placeholder span {
      font-size: 12px;
      font-weight: 600;
    }

    .registration-page-custom .hidden-file {
      display: none;
    }

    .registration-page-custom .upload-zone {
      border: 2px dashed #d9dee3;
      border-radius: 10px;
      background: #fff;
      min-height: 175px;
      display: flex;
      align-items: center;
      justify-content: center;
      text-align: center;
      cursor: pointer;
      transition: all .2s ease;
      padding: 25px;
    }

    .registration-page-custom .upload-zone:hover {
      border-color: #696cff;
      background: #f9f9ff;
    }

    .registration-page-custom .upload-icon {
      width: 48px;
      height: 48px;
      border-radius: 8px;
      background: #f0f0ff;
      color: #696cff;
      display: flex;
      align-items: center;
      justify-content: center;
      margin: 0 auto 12px;
      font-size: 25px;
    }

    .registration-page-custom .upload-title {
      color: #435971;
      font-size: 17px;
      font-weight: 600;
      margin-bottom: 5px;
    }

    .registration-page-custom .upload-subtitle {
      color: #8592a3;
      font-size: 13px;
      margin-bottom: 0;
    }

    .registration-page-custom .selected-file {
      margin-top: 10px;
      color: #71dd37;
      font-size: 13px;
      font-weight: 600;
      word-break: break-word;
    }

    .registration-page-custom .document-card {
      height: 100%;
    }

    .registration-page-custom .save-buttons {
      display: flex;
      justify-content: flex-end;
      gap: 10px;
      margin-top: 5px;
    }

    .registration-page-custom .save-button {
      background: #696cff;
      border-color: #696cff;
      color: #fff;
      border-radius: 7px;
      font-weight: 600;
      padding: 10px 20px;
    }

    .registration-page-custom .save-button:hover {
      background: #5f61e6;
      border-color: #5f61e6;
      color: #fff;
    }

    .registration-page-custom .alert {
      border-radius: 7px;
    }

    .enquiry-popup-overlay {
      position: fixed;
      inset: 0;
      background: rgba(67,89,113,.55);
      z-index: 9999;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 20px;
    }

    .enquiry-popup {
      width: min(1400px, 96vw);
      max-height: 92vh;
      background: #fff;
      border-radius: 10px;
      box-shadow: 0 10px 40px rgba(0,0,0,.2);
      overflow: hidden;
      display: flex;
      flex-direction: column;
    }

    .enquiry-popup-header {
      padding: 20px 24px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      border-bottom: 1px solid #ebeef0;
    }

    .enquiry-popup-header h3 {
      color: #566a7f;
      margin: 0 0 4px;
      font-size: 20px;
    }

    .enquiry-popup-header p {
      color: #8592a3;
      margin: 0;
      font-size: 13px;
    }

    .enquiry-popup-modes {
      padding: 16px 24px 0;
      display: flex;
      gap: 28px;
      border-bottom: 0;
    }

    .enquiry-popup-modes .form-check-label {
      color: #566a7f;
      font-weight: 600;
      cursor: pointer;
    }

    .enquiry-popup-search {
      padding: 18px 24px;
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 14px;
      border-bottom: 1px solid #ebeef0;
    }

    .enquiry-popup-search label {
      display: block;
      color: #566a7f;
      font-size: 12px;
      font-weight: 600;
      margin-bottom: 6px;
    }

    .enquiry-popup-table-container {
      flex: 1;
      overflow: auto;
      padding: 0 24px;
    }

    .enquiry-popup-table-container th {
      color: #566a7f;
      font-size: 12px;
      font-weight: 600;
      white-space: nowrap;
    }

    .enquiry-popup-table-container td {
      color: #566a7f;
      vertical-align: middle;
      white-space: nowrap;
    }

    .enquiry-popup-table-container .enquiry-select-row {
      cursor: pointer;
    }

    .enquiry-popup-table-container .enquiry-select-row:hover {
      background: #f7f7ff;
    }

    .enquiry-popup-footer {
      padding: 15px 24px;
      border-top: 1px solid #ebeef0;
      display: flex;
      align-items: center;
      justify-content: space-between;
      color: #8592a3;
      font-size: 13px;
    }

    /* ---------- VALIDATION POPUP ---------- */

    .reg-alert-overlay {
      position: fixed;
      inset: 0;
      background: rgba(34,48,62,.55);
      backdrop-filter: blur(2px);
      z-index: 10050;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 20px;
      animation: regAlertFade .18s ease;
    }

    .reg-alert-box {
      --accent: #ff3e1d;
      --soft: #ffe5e0;
      --ring: #fff1ee;
      position: relative;
      width: min(400px, 100%);
      background: #fff;
      border-radius: 16px;
      padding: 38px 30px 28px;
      text-align: center;
      box-shadow: 0 18px 50px rgba(67,89,113,.35);
      overflow: hidden;
      animation: regAlertPop .3s cubic-bezier(.2,.9,.3,1.3);
    }

    .reg-alert-box.warning {
      --accent: #ffab00;
      --soft: #fff2d6;
      --ring: #fff9ea;
    }

    .reg-alert-box.success {
      --accent: #71dd37;
      --soft: #e8fadf;
      --ring: #f3fcee;
    }

    .reg-alert-box::before {
      content: "";
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      height: 5px;
      background: var(--accent);
    }

    .reg-alert-close {
      position: absolute;
      top: 12px;
      right: 14px;
      width: 30px;
      height: 30px;
      border: 0;
      border-radius: 50%;
      background: transparent;
      color: #a1acb8;
      font-size: 22px;
      line-height: 1;
      cursor: pointer;
      transition: all .2s ease;
    }

    .reg-alert-close:hover {
      background: #f5f5f9;
      color: #566a7f;
    }

    .reg-alert-icon {
      width: 76px;
      height: 76px;
      margin: 0 auto 18px;
      border-radius: 50%;
      background: var(--soft);
      color: var(--accent);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 40px;
      box-shadow: 0 0 0 9px var(--ring);
      animation: regAlertIcon .45s ease .1s both;
    }

    .reg-alert-title {
      margin: 0 0 8px;
      color: #566a7f;
      font-size: 21px;
      font-weight: 700;
    }

    .reg-alert-text {
      margin: 0 0 24px;
      color: #697a8d;
      font-size: 15px;
      line-height: 1.55;
    }

    .reg-alert-btn {
      border: 0;
      background: #696cff;
      color: #fff;
      border-radius: 8px;
      padding: 10px 34px;
      font-size: 15px;
      font-weight: 600;
      cursor: pointer;
      box-shadow: 0 .125rem .25rem rgba(105,108,255,.4);
      transition: all .2s ease;
    }

    .reg-alert-btn:hover {
      background: #5f61e6;
      transform: translateY(-1px);
    }

    .reg-alert-btn:focus-visible {
      outline: 3px solid rgba(105,108,255,.35);
      outline-offset: 2px;
    }

    @keyframes regAlertFade {
      from { opacity: 0; }
      to { opacity: 1; }
    }

    @keyframes regAlertPop {
      from { opacity: 0; transform: scale(.85) translateY(10px); }
      to { opacity: 1; transform: scale(1) translateY(0); }
    }

    @keyframes regAlertIcon {
      0% { transform: scale(.4); }
      60% { transform: scale(1.12); }
      100% { transform: scale(1); }
    }

    @media (max-width: 991px) {
      .registration-page-custom .student-image-area {
        justify-content: flex-start;
        margin-top: 15px;
      }

      .registration-page-custom .registration-step-tabs {
        grid-template-columns: repeat(2, 1fr);
      }

      .enquiry-popup-search {
        grid-template-columns: repeat(2, 1fr);
      }
    }

    @media (max-width: 575px) {
      .enquiry-popup-search {
        grid-template-columns: 1fr;
      }

      .registration-page-custom .registration-step-tabs {
        grid-template-columns: 1fr;
      }

      .registration-page-custom .page-header {
        align-items: flex-start;
        gap: 15px;
      }

      .registration-page-custom .page-title {
        font-size: 22px;
      }
    }
  `;

  /* discount offer is over when the registration date is after the validity end date */
  const validityCrossed = isValidityCrossed(
    form.registration_date,
    form.discount_validity
  );

  /* the discount that has ended (shown in the red message), e.g. "10" */
  const endedDiscount = positiveDiscount(offerDiscount);

  /* FINAL FEE = course fees - discount (shown below the discount validity) */
  const finalFee = calcFinalFee(form.course_fees, form.discount_percentage);

  /* student photo preview: saved photo of the record / registered person */
  const photoCandidates = buildFileCandidates(
    isEdit ? getPhotoValue(savedRecord) : reusedPhotoValue,
    apiUrl
  );

  const photoPlaceholder = (
    <div className="image-placeholder">

      <i className="bx bx-camera"></i>

      <span>Upload Photo</span>

    </div>
  );

  const statusOptions = REGISTRATION_STATUSES;

  /* =====================================================
     STEP COMPLETION (green tick only when ALL details of the slide are filled)
  ===================================================== */

  const hasPhoto = Boolean(
    studentImage || existingPhoto || reusedPhotoValue
  );

  const step1Complete =
    (isEdit || Boolean(selectedEnquiry && form.enquiry_no)) &&
    isFilled(form.registration_date) &&
    isFilled(form.student_name) &&
    /^\d{10}$/.test(form.mobile_number) &&
    /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email) &&
    isFilled(form.address) &&
    hasPhoto;

  /* Degree and Department are not needed for 12th or below (they are locked) */
  const step2Complete =
    educationRows.length > 0 &&
    educationRows.every(
      (row) =>
        isFilled(row.qualification) &&
        isFilled(row.institute) &&
        isFilled(row.board) &&
        isFilled(row.percentage) &&
        isFilled(row.yop) &&
        (isSchoolLevel(row.qualification) ||
          !needsDegree(row.qualification) ||
          (isFilled(row.degree) && isFilled(row.department)))
    );

  const step3Complete =
    isFilled(form.course) &&
    isFilled(form.course_fees) &&
    isFilled(form.discount_percentage) &&
    isFilled(form.discount_validity);

  const step4Complete =
    Boolean(resume || existingResume) &&
    Boolean(aadharCard || existingAadhar);

  const stepList = [
    { id: 1, label: "Personal Details", complete: step1Complete },
    { id: 2, label: "Educational Details", complete: step2Complete },
    { id: 3, label: "Course Details", complete: step3Complete },
    { id: 4, label: "Upload Documents", complete: step4Complete }
  ];

  const tickIcon = (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="3"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <polyline points="20 6 9 17 4 12" />
    </svg>
  );

  const plusIcon = (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="3"
      strokeLinecap="round"
    >
      <line x1="12" y1="5" x2="12" y2="19" />
      <line x1="5" y1="12" x2="19" y2="12" />
    </svg>
  );

  const minusIcon = (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="3"
      strokeLinecap="round"
    >
      <line x1="5" y1="12" x2="19" y2="12" />
    </svg>
  );

  const popupIcons = {
    error: "bx-error-circle",
    warning: "bx-error",
    success: "bx-check-circle"
  };

  return (
    <>
      <style>{styles}</style>

      <div className="container-xxl flex-grow-1 container-p-y registration-page-custom">

        {/* =================================================
            HEADER
        ================================================= */}

        <div className="page-header">

          <h4 className="page-title">
            {isEdit ? "Edit Registration" : "Add Registration"}
          </h4>

          <button
            type="button"
            className="back-button"
            onClick={() => {
              if (onBack) {
                onBack();
              }
            }}
          >
            <i className="bx bx-arrow-back me-1"></i>
            Back
          </button>

        </div>

        <form onSubmit={handleSubmit}>

          {/* =================================================
              ONE CARD : STEP BAR + FORM + BUTTONS
          ================================================= */}

          <div className="reg-main-card">

            {/* =================================================
                STEP BAR
                - green tick  : all details of that slide are filled
                - grey tick   : nothing / not fully filled
                - number      : the slide you are on (not finished yet)
            ================================================= */}

            <div className="registration-step-tabs">

              {stepList.map((step) => {
                const isActive = activeStep === step.id;

                let circleClass = "pending";

                if (step.complete) {
                  circleClass = "done";
                } else if (isActive) {
                  circleClass = "current";
                }

                return (
                  <button
                    key={step.id}
                    type="button"
                    className={`registration-step-tab ${
                      isActive ? "active" : ""
                    }`}
                    onClick={() => goToStep(step.id)}
                  >

                    <span className={`step-circle ${circleClass}`}>
                      {circleClass === "current" ? step.id : tickIcon}
                    </span>

                    {step.label}

                  </button>
                );
              })}

            </div>

            {/* =================================================
                PERSONAL DETAILS
            ================================================= */}

            {activeStep === 1 && (
              <div className="step-content">

                <div className="custom-card">

                  <div className="section-header">
                    <h5 className="section-title">Personal Details</h5>
                  </div>

                  <div className="section-body">

                    <div className="row g-4">

                      <div className="col-lg-9">

                        <div className="row g-4">

                          {/* ENQUIRY */}

                          <div className="col-md-6">

                            <label className="form-label">
                              ENQUIRY NO *
                            </label>

                            <div
                              className={`enquiry-box ${
                                isEdit ? "locked" : ""
                              }`}
                              onClick={
                                isEdit ? undefined : openEnquiryPopup
                              }
                              tabIndex="0"
                            >
                              {selectedEnquiry
                                ? `${form.enquiry_no} - ${form.student_name}`
                                : "Click to select enquiry"}
                            </div>

                          </div>

                          {/* REGISTRATION ID */}

                          <div className="col-md-6">

                            <label className="form-label">
                              REGISTRATION ID
                            </label>

                            <input
                              type="text"
                              className="form-control"
                              value={registrationNo}
                              readOnly
                              placeholder="Auto generated"
                              style={{ background: "#f5f5f9" }}
                            />

                          </div>

                          {/* REGISTRATION DATE */}

                          <div className="col-md-6">

                            <label className="form-label">
                              REGISTRATION DATE *
                            </label>

                            <input
                              type="date"
                              className="form-control"
                              name="registration_date"
                              value={form.registration_date}
                              onChange={handleDateChange}
                              max={getToday()}
                            />

                          </div>

                          {/* STUDENT NAME */}

                          <div className="col-md-6">

                            <label className="form-label">
                              STUDENT NAME *
                            </label>

                            <input
                              type="text"
                              className="form-control"
                              name="student_name"
                              value={form.student_name}
                              onChange={handleNameChange}
                              placeholder="Enter student name"
                            />

                          </div>

                          {/* MOBILE */}

                          <div className="col-md-6">

                            <label className="form-label">
                              MOBILE NUMBER *
                            </label>

                            <input
                              type="text"
                              className="form-control"
                              name="mobile_number"
                              value={form.mobile_number}
                              onChange={handlePhoneChange}
                              maxLength="10"
                              placeholder="10 digit mobile number"
                            />

                          </div>

                          {/* EMAIL */}

                          <div className="col-md-6">

                            <label className="form-label">
                              EMAIL *
                            </label>

                            <input
                              type="email"
                              className="form-control"
                              name="email"
                              value={form.email}
                              onChange={handleEmailChange}
                              placeholder="example@gmail.com"
                            />

                          </div>

                          {/* ADDRESS */}

                          <div className="col-md-6">

                            <label className="form-label">
                              ADDRESS *
                            </label>

                            <input
                              type="text"
                              className="form-control"
                              name="address"
                              value={form.address}
                              onChange={handleChange}
                              placeholder="Enter address"
                            />

                          </div>

                        </div>

                      </div>

                      {/* STUDENT IMAGE TOP RIGHT */}

                      <div className="col-lg-3">

                        <label className="form-label">
                          STUDENT IMAGE *
                        </label>

                        <div className="student-image-area">

                          <label
                            htmlFor="studentImageInput"
                            className="student-image-box"
                          >

                            {studentImage ? (
                              <img
                                src={URL.createObjectURL(studentImage)}
                                alt="Student"
                                className="student-image-preview"
                              />
                            ) : photoCandidates.length > 0 ? (
                              <FallbackImage
                                candidates={photoCandidates}
                                alt="Student"
                                className="student-image-preview"
                                fallback={photoPlaceholder}
                              />
                            ) : (
                              photoPlaceholder
                            )}

                          </label>

                          <input
                            id="studentImageInput"
                            type="file"
                            className="hidden-file"
                            accept="image/*"
                            onChange={handleImage}
                          />

                        </div>

                        {!isEdit &&
                          !studentImage &&
                          reusedPhotoValue &&
                          !docsCopying && (
                            <div
                              className="selected-file"
                              style={{ color: "#ffab00" }}
                            >

                              Saved photo could not be attached automatically —
                              click the image to upload it again

                            </div>
                          )}

                      </div>

                    </div>

                  </div>

                </div>

              </div>
            )}

            {/* =================================================
                EDUCATIONAL DETAILS (table)
            ================================================= */}

            {activeStep === 2 && (
              <div className="step-content">

                <div className="custom-card">

                  <div className="section-header">
                    <h5 className="section-title">Educational Details</h5>
                  </div>

                  <div className="section-body">

                    {!isEdit && selectedEnquiry && (
                      <p
                        style={{
                          margin: "0 0 14px",
                          color: "#8592a3",
                          fontSize: "13px"
                        }}
                      >
                        Details available in the enquiry are filled
                        automatically. Fill the remaining boxes manually.
                      </p>
                    )}

                    <div className="edu-table-wrap">

                      <table className="edu-table">

                        <thead>

                          <tr>
                            <th>S.No</th>
                            <th>Qualification</th>
                            <th>School/Institute Name</th>
                            <th>Board/University</th>
                            <th>Percentage</th>
                            <th>YOP</th>
                            <th>Degree</th>
                            <th>Department</th>
                            <th>Actions</th>
                          </tr>

                        </thead>

                        <tbody>

                          {educationRows.map((row, index) => {
                            /* 12th or below: Degree and Department are locked */
                            const schoolLevel = isSchoolLevel(row.qualification);

                            return (
                            <tr key={index}>

                              {/* S.NO */}

                              <td className="edu-sno">{index + 1}</td>

                              {/* QUALIFICATION (type any text, or pick a suggestion) */}

                              <td className="edu-col-qualification">

                                <QualificationBox
                                  value={row.qualification}
                                  onType={(text) =>
                                    handleEduText(index, "qualification", text)
                                  }
                                  onPick={(name) =>
                                    changeQualification(index, name)
                                  }
                                />

                              </td>

                              {/* SCHOOL / INSTITUTE */}

                              <td className="edu-col-institute">

                                <input
                                  type="text"
                                  className="form-control"
                                  value={row.institute}
                                  onChange={(e) =>
                                    handleEduText(
                                      index,
                                      "institute",
                                      e.target.value
                                    )
                                  }
                                />

                              </td>

                              {/* BOARD / UNIVERSITY (grows while the cursor is on it / typing) */}

                              <td className="edu-col-board">

                                <div className="edu-board-wrap">

                                  <input
                                    type="text"
                                    className="form-control edu-board-input"
                                    placeholder="Board / University"
                                    title={row.board}
                                    value={row.board}
                                    onChange={(e) =>
                                      handleEduText(index, "board", e.target.value)
                                    }
                                  />

                                </div>

                              </td>

                              {/* PERCENTAGE */}

                              <td className="edu-col-percentage">

                                <input
                                  type="text"
                                  inputMode="decimal"
                                  className="form-control"
                                  value={row.percentage}
                                  onChange={(e) =>
                                    handleEduPercentage(index, e.target.value)
                                  }
                                />

                              </td>

                              {/* YOP */}

                              <td className="edu-col-yop">

                                <YearPicker
                                  value={row.yop}
                                  onChange={(year) =>
                                    handleEduYear(index, year)
                                  }
                                />

                              </td>

                              {/* DEGREE (locked for 12th or below) */}

                              <td className="edu-col-degree">

                                <input
                                  type="text"
                                  className={`form-control${
                                    schoolLevel ? " edu-readonly" : ""
                                  }`}
                                  value={schoolLevel ? "" : row.degree}
                                  disabled={schoolLevel}
                                  readOnly={schoolLevel}
                                  title={
                                    schoolLevel
                                      ? "Not needed for 12th or below"
                                      : ""
                                  }
                                  onChange={(e) =>
                                    handleEduText(index, "degree", e.target.value)
                                  }
                                />

                              </td>

                              {/* DEPARTMENT (locked for 12th or below) */}

                              <td className="edu-col-department">

                                <input
                                  type="text"
                                  className={`form-control${
                                    schoolLevel ? " edu-readonly" : ""
                                  }`}
                                  value={schoolLevel ? "" : row.department}
                                  disabled={schoolLevel}
                                  readOnly={schoolLevel}
                                  title={
                                    schoolLevel
                                      ? "Not needed for 12th or below"
                                      : ""
                                  }
                                  onChange={(e) =>
                                    handleEduText(
                                      index,
                                      "department",
                                      e.target.value
                                    )
                                  }
                                />

                              </td>

                              {/* ACTIONS : + (green)  - (red) - every row */}

                              <td className="edu-col-actions">

                                <div className="edu-actions">

                                  <button
                                    type="button"
                                    className="edu-add-btn"
                                    title="Add qualification"
                                    aria-label="Add qualification"
                                    onClick={() => addEduRowAfter(index)}
                                  >
                                    {plusIcon}
                                  </button>

                                  <button
                                    type="button"
                                    className="edu-remove-btn"
                                    title="Remove qualification"
                                    aria-label="Remove qualification"
                                    onClick={() => removeEduRow(index)}
                                  >
                                    {minusIcon}
                                  </button>

                                </div>

                              </td>

                            </tr>
                            );
                          })}

                        </tbody>

                      </table>

                    </div>

                  </div>

                </div>

              </div>
            )}

            {/* =================================================
                COURSE DETAILS
            ================================================= */}

            {activeStep === 3 && (
              <div className="step-content">

                <div className="custom-card">

                  <div className="section-header">
                    <h5 className="section-title">Course Details</h5>
                  </div>

                  <div className="section-body">

                    <div className="row g-4">

                      {/* COURSE */}

                      <div className="col-md-6">

                        <label className="form-label">
                          COURSE *
                        </label>

                        <select
                          className="form-select"
                          name="course"
                          value={form.course}
                          onChange={handleChange}
                        >
                          <option value="">Select course</option>

                          {/* the enquiry's course stays selectable even when it
                              no longer has an Active fee */}
                          {form.course &&
                            !feeCourses.some(
                              (c) => c.Course_name === form.course
                            ) && (
                              <option value={form.course}>{form.course}</option>
                            )}

                          {feeCourses.map((c) => (
                            <option key={c.Course_id} value={c.Course_name}>
                              {c.Course_name}
                            </option>
                          ))}
                        </select>

                      </div>

                      {/* FEES */}

                      <div className="col-md-6">

                        <label className="form-label">
                          COURSE FEES
                        </label>

                        <input
                          type="number"
                          className="form-control"
                          name="course_fees"
                          value={form.course_fees}
                          onChange={handleChange}
                          placeholder="Enter course fees"
                        />

                      </div>

                      {/* DISCOUNT */}

                      <div className="col-md-6">

                        <label className="form-label">
                          DISCOUNT PERCENTAGE
                        </label>

                        <input
                          type="number"
                          className="form-control"
                          name="discount_percentage"
                          value={form.discount_percentage}
                          onChange={handleChange}
                          min="0"
                          max="100"
                          placeholder="0 - 100"
                        />

                      </div>

                      {/*
                        DISCOUNT OFFER MESSAGE
                        (no validity box - only the message)
                        - green : offer is still available
                        - red   : offer is over (the discount box is 0, and the
                                  message shows the discount that has ended)
                      */}

                      <div className="col-md-6">

                        {form.discount_validity && (
                          <>
                            {/* invisible label keeps the message in line with the discount box */}
                            <label
                              className="form-label"
                              style={{ visibility: "hidden" }}
                              aria-hidden="true"
                            >
                              &nbsp;
                            </label>

                            <div
                              className={`discount-offer-msg ${
                                validityCrossed ? "ended" : "available"
                              }`}
                            >
                              {validityCrossed
                                ? endedDiscount
                                  ? `Discount offer is off – ${endedDiscount}% discount ended on ${formatDisplayDate(
                                      form.discount_validity
                                    )}.`
                                  : `Discount offer is off – validity ended on ${formatDisplayDate(
                                      form.discount_validity
                                    )}.`
                                : `Discount offer is available till ${formatDisplayDate(
                                    form.discount_validity
                                  )}.`}
                            </div>
                          </>
                        )}

                      </div>

                      {/* STATUS */}

                      <div className="col-md-6">

                        <label className="form-label">
                          STATUS
                        </label>

                        <select
                          className="form-select"
                          name="status"
                          value={form.status}
                          onChange={handleChange}
                        >

                          {statusOptions.map((option) => (
                            <option key={option} value={option}>
                              {option}
                            </option>
                          ))}

                          {!statusOptions.includes(form.status) && (
                            <option value={form.status}>
                              {form.status}
                            </option>
                          )}

                        </select>

                      </div>

                      {/* FINAL FEE (course fees - discount) */}

                      <div className="col-md-6">

                        <label className="form-label">
                          FINAL FEE
                        </label>

                        <input
                          type="text"
                          className="form-control final-fee-box"
                          value={finalFee}
                          readOnly
                          tabIndex={-1}
                          placeholder="Calculated automatically"
                        />

                        {finalFee !== "" && (
                          <small
                            className="d-block mt-2"
                            style={{ color: "#8592a3" }}
                          >
                            Course fees − {Number(form.discount_percentage) > 0
                              ? Number(form.discount_percentage)
                              : 0}
                            % discount
                          </small>
                        )}

                      </div>

                      {/* REMARKS */}

                      <div className="col-12">

                        <label className="form-label">
                          REMARKS
                        </label>

                        <textarea
                          className="form-control"
                          name="remarks"
                          value={form.remarks}
                          onChange={handleChange}
                          placeholder="Enter remarks"
                          rows="3"
                        />

                      </div>

                    </div>

                  </div>

                </div>

              </div>
            )}

            {/* =================================================
                UPLOAD DOCUMENTS
            ================================================= */}

            {activeStep === 4 && (
              <div className="step-content">

                <div className="custom-card">

                  <div className="section-header">
                    <h5 className="section-title">Upload Documents</h5>
                  </div>

                  <div className="section-body">

                    <div className="row g-4">

                      {/* RESUME */}

                      <div className="col-md-6">

                        <div className="document-card">

                          <label className="form-label">
                            RESUME / CV
                          </label>

                          <label
                            htmlFor="resumeInput"
                            className="upload-zone"
                          >

                            <div>

                              <div className="upload-icon">
                                <i className="bx bx-upload"></i>
                              </div>

                              <div className="upload-title">
                                Drop files here or click to upload
                              </div>

                              <p className="upload-subtitle">
                                PDF, DOC or DOCX — Maximum 6 MB
                              </p>

                              {resume && (
                                <div className="selected-file">

                                  <i className="bx bx-check-circle me-1"></i>

                                  {resume.name}

                                </div>
                              )}

                              {!resume && existingResume && (
                                <div className="selected-file">

                                  <i className="bx bx-check-circle me-1"></i>

                                  Current file: {getFileName(existingResume)}

                                </div>
                              )}

                            </div>

                          </label>

                          <input
                            id="resumeInput"
                            type="file"
                            className="hidden-file"
                            accept=".pdf,.doc,.docx"
                            onChange={handleResume}
                          />

                        </div>

                      </div>

                      {/* AADHAAR */}

                      <div className="col-md-6">

                        <div className="document-card">

                          <label className="form-label">
                            AADHAAR CARD
                          </label>

                          <label
                            htmlFor="aadharInput"
                            className="upload-zone"
                          >

                            <div>

                              <div className="upload-icon">
                                <i className="bx bx-id-card"></i>
                              </div>

                              <div className="upload-title">
                                Drop files here or click to upload
                              </div>

                              <p className="upload-subtitle">
                                PDF, JPG, JPEG or PNG — Maximum 6 MB
                              </p>

                              {aadharCard && (
                                <div className="selected-file">

                                  <i className="bx bx-check-circle me-1"></i>

                                  {aadharCard.name}

                                </div>
                              )}

                              {!aadharCard && existingAadhar && (
                                <div className="selected-file">

                                  <i className="bx bx-check-circle me-1"></i>

                                  Current file: {getFileName(existingAadhar)}

                                </div>
                              )}

                            </div>

                          </label>

                          <input
                            id="aadharInput"
                            type="file"
                            className="hidden-file"
                            accept=".pdf,.jpg,.jpeg,.png"
                            onChange={handleAadhar}
                          />

                        </div>

                      </div>

                    </div>

                  </div>

                </div>

              </div>
            )}

            {/* =================================================
                MESSAGES
            ================================================= */}

            {message && (
              <div
                className="alert alert-success mb-4"
                role="alert"
              >

                <i className="bx bx-check-circle me-2"></i>

                {message}

              </div>
            )}

            {error && (
              <div
                className="alert alert-danger mb-4"
                role="alert"
              >

                <i className="bx bx-error-circle me-2"></i>

                {error}

              </div>
            )}

            {/* =================================================
                STEP NAVIGATION
            ================================================= */}

            <div className="step-navigation">

              <button
                type="button"
                className="btn btn-outline-secondary"
                onClick={() => {
                  if (activeStep === 1) {
                    if (onBack) {
                      onBack();
                    }
                  } else {
                    handlePreviousStep();
                  }
                }}
              >

                <i className="bx bx-arrow-back me-1"></i>

                {activeStep === 1 ? "Cancel" : "Back"}

              </button>

              {activeStep < 4 ? (

                <button
                  key="next-button"
                  type="button"
                  className="btn save-button"
                  onClick={handleNextStep}
                >

                  Next

                  <i className="bx bx-right-arrow-alt ms-1"></i>

                </button>

              ) : (

                <button
                  key="save-button"
                  type="submit"
                  className="btn save-button"
                >

                  <i className="bx bx-save me-1"></i>

                  {isEdit ? "Update Registration" : "Save Registration"}

                </button>

              )}

            </div>

          </div>

        </form>

        {/* =================================================
            ENQUIRY POPUP
        ================================================= */}

        {showEnquiryPopup && (

          <div className="enquiry-popup-overlay">

            <div className="enquiry-popup">

              {/* HEADER */}

              <div className="enquiry-popup-header">

                <div>

                  <h3>Select Enquiry</h3>

                  <p>Search and select a student enquiry</p>

                </div>

                <button
                  type="button"
                  className="btn-close"
                  aria-label="Close"
                  onClick={() => setShowEnquiryPopup(false)}
                />

              </div>

              {/* MODE RADIO BUTTONS */}

              <div className="enquiry-popup-modes">

                <div className="form-check">
                  <input
                    className="form-check-input"
                    type="radio"
                    name="enquiryPopupMode"
                    id="modeNew"
                    checked={popupMode === "new"}
                    onChange={() => setPopupMode("new")}
                  />
                  <label className="form-check-label" htmlFor="modeNew">
                    New Enquiry
                  </label>
                </div>

                <div className="form-check">
                  <input
                    className="form-check-input"
                    type="radio"
                    name="enquiryPopupMode"
                    id="modeRegistered"
                    checked={popupMode === "registered"}
                    onChange={() => setPopupMode("registered")}
                  />
                  <label className="form-check-label" htmlFor="modeRegistered">
                    Already Registered
                  </label>
                </div>

              </div>

              {/* SEARCH */}

              <div className="enquiry-popup-search">

                {/* NAME */}

                <div>

                  <label>SEARCH BY NAME</label>

                  <div className="input-group">

                    <span className="input-group-text">
                      <i className="bx bx-search"></i>
                    </span>

                    <input
                      type="text"
                      className="form-control"
                      placeholder="Student name"
                      value={searchName}
                      maxLength="151"
                      onChange={handleSearchName}
                    />

                  </div>

                </div>

                {/* PHONE */}

                <div>

                  <label>SEARCH BY PHONE</label>

                  <div className="input-group">

                    <span className="input-group-text">
                      <i className="bx bx-phone"></i>
                    </span>

                    <input
                      type="text"
                      className="form-control"
                      placeholder="Phone number"
                      value={searchPhone}
                      inputMode="numeric"
                      onChange={handleSearchPhone}
                    />

                  </div>

                </div>

                {/* COURSE */}

                <div>

                  <label>SEARCH BY COURSE</label>

                  <div className="input-group">

                    <span className="input-group-text">
                      <i className="bx bx-book"></i>
                    </span>

                    <input
                      type="text"
                      className="form-control"
                      placeholder="Course"
                      value={searchCourse}
                      maxLength="151"
                      onChange={handleSearchCourse}
                    />

                  </div>

                </div>

                {/* DATE */}

                <div>

                  <label>SEARCH BY DATE</label>

                  <div className="input-group">

                    <span className="input-group-text">
                      <i className="bx bx-calendar"></i>
                    </span>

                    <input
                      type="date"
                      className="form-control"
                      value={searchDate}
                      min="2000-01-01"
                      max="2100-12-31"
                      onChange={handleSearchDate}
                    />

                  </div>

                </div>

              </div>

              {/* ERROR */}

              {error && (
                <div className="alert alert-danger m-3">
                  {error}
                </div>
              )}

              {/* TABLE */}

              <div className="enquiry-popup-table-container">

                <div className="table-responsive">

                  <table className="table table-hover">

                    <thead>

                      <tr>
                        <th>ENQ ID</th>
                        <th>STUDENT NAME</th>
                        <th>MOBILE</th>
                        <th>EMAIL</th>
                        <th>ADDRESS</th>
                        <th>QUALIFICATION</th>
                        <th>
                          {popupMode === "new"
                            ? "COURSE / DEGREE"
                            : "REGISTERED COURSES"}
                        </th>
                      </tr>

                    </thead>

                    <tbody>

                      {popupMode === "new" ? (

                        filteredEnquiries.length === 0 ? (

                          <tr>
                            <td colSpan="7" className="text-center py-4">
                              No new enquiries found
                            </td>
                          </tr>

                        ) : (

                          filteredEnquiries.map((item) => (

                            <tr
                              key={item.id || item.enquiry_id}
                              onClick={() => selectEnquiry(item)}
                              className="enquiry-select-row"
                            >
                              <td>{item.enquiry_id || item.id || "-"}</td>
                              <td>{item.student_name || "-"}</td>
                              <td>{item.mobile_number || "-"}</td>
                              <td>{item.email || "-"}</td>
                              <td>{item.address || "-"}</td>
                              <td>{item.qualification || "-"}</td>
                              <td>
                                {item.course ||
                                  item.degree_course ||
                                  item.diploma_course ||
                                  "-"}
                              </td>
                            </tr>

                          ))

                        )

                      ) : filteredRegistered.length === 0 ? (

                        <tr>
                          <td colSpan="7" className="text-center py-4">
                            No registered students found
                          </td>
                        </tr>

                      ) : (

                        filteredRegistered.map((person) => (

                          <tr
                            key={person.key}
                            onClick={() => selectRegisteredPerson(person)}
                            className="enquiry-select-row"
                          >
                            <td>{person.latest.enquiry_no || "-"}</td>
                            <td>{person.latest.student_name || "-"}</td>
                            <td>{person.latest.mobile_number || "-"}</td>
                            <td>{person.latest.email || "-"}</td>
                            <td>{person.latest.address || "-"}</td>
                            <td>{person.latest.qualification || "-"}</td>
                            <td>{person.courses.join(", ") || "-"}</td>
                          </tr>

                        ))

                      )}

                    </tbody>

                  </table>

                </div>

              </div>

              {/* FOOTER */}

              <div className="enquiry-popup-footer">

                <span>
                  {popupMode === "new"
                    ? `${filteredEnquiries.length} enquiries found`
                    : `${filteredRegistered.length} registered students found`}
                </span>

                <button
                  type="button"
                  className="btn btn-outline-secondary"
                  onClick={() => setShowEnquiryPopup(false)}
                >
                  Close
                </button>

              </div>

            </div>

          </div>

        )}

        {/* =================================================
            VALIDATION POPUP
        ================================================= */}

        {popup && (

          <div className="reg-alert-overlay" onClick={closePopup}>

            <div
              className={`reg-alert-box ${popup.type}`}
              role="alertdialog"
              aria-modal="true"
              onClick={(e) => e.stopPropagation()}
            >

              <button
                type="button"
                className="reg-alert-close"
                aria-label="Close"
                onClick={closePopup}
              >
                &times;
              </button>

              <div className="reg-alert-icon">
                <i className={`bx ${popupIcons[popup.type] || popupIcons.error}`}></i>
              </div>

              <h4 className="reg-alert-title">{popup.title}</h4>

              <p className="reg-alert-text">{popup.text}</p>

              <button
                type="button"
                className="reg-alert-btn"
                onClick={closePopup}
                autoFocus
              >
                Got it
              </button>

            </div>

          </div>

        )}

      </div>

    </>
  );
}

export default Addregistration;