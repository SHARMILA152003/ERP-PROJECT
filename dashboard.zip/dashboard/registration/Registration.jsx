import React, { useContext, useEffect, useState } from "react";
import AuthContext from "../../services/AuthContext";
import "./Registration.css";

import Addregistration from "./addregistration/Addregistration";
import Updateregistration from "./updateregistration/Updateregistration";
import Addbilling from "../billing/addbilling/Addbilling";

/*
 * Server calls come from AuthContext (same flow as CourseFee.jsx):
 *
 *   getData("fetch_registration_datail")    -> all registrations (array)
 *   insert({ Registration_id, ... }, "update_registration_datail")  -> update
 *   insert({ Registration_id }, "delete_registration_datail")       -> delete
 *
 * AuthContext is shared by every module, so it is used as it is.
 * insert() is used for update / delete because it is the AuthContext
 * helper that throws the Django error (error.responseData), so the
 * message can be shown in the popup.
 *
 * NOTE: the import path of AuthContext above is for
 *   src/<folder>/registration/Registration.jsx
 * If your file is in a different folder, change "../../services/AuthContext".
 */


/*
 * Django sends every saved file as a full url (http://host/media/...),
 * so no server address is needed here.
 */
const apiUrl = "";


/* ============================================================
   FILE URL HELPERS
   API_HOST is the server address given by AuthContext (apiUrl)
   ============================================================ */

const buildFileCandidates = (value, API_HOST = "") => {
  if (!value) {
    return [];
  }

  const text = String(value).trim();

  const list = [];

  const add = (url) => {
    if (url && !list.includes(url)) {
      list.push(url);
    }
  };

  if (/^https?:\/\//i.test(text)) {
    add(text);

    try {
      const path = new URL(text).pathname;

      add(`${API_HOST}${path}`);

      if (!path.startsWith("/media/")) {
        add(`${API_HOST}/media${path}`);
      }
    } catch (err) {
      /* keep the original url only */
    }

    return list;
  }

  const safe = text.includes("%") ? text : encodeURI(text);

  if (safe.startsWith("/")) {
    add(`${API_HOST}${safe}`);

    if (!safe.startsWith("/media/")) {
      add(`${API_HOST}/media${safe}`);
    }
  } else {
    /* plain file name saved in the database -> normally served from /media/ */
    add(
      safe.startsWith("media/")
        ? `${API_HOST}/${safe}`
        : `${API_HOST}/media/${safe}`
    );
    add(`${API_HOST}/${safe}`);
  }

  return list;
};

/* shows the first url that loads, otherwise the fallback */
const FallbackImage = ({ candidates, alt, className, fallback }) => {
  const [index, setIndex] = useState(0);

  const signature = candidates.join("|");

  useEffect(() => {
    setIndex(0);
  }, [signature]);

  if (!candidates.length || index >= candidates.length) {
    return fallback || null;
  }

  return (
    <img
      src={candidates[index]}
      alt={alt}
      className={className}
      onError={() => setIndex((previous) => previous + 1)}
    />
  );
};



/* ============================================================
   ICONS
   ============================================================ */

const ICON_PATHS = {

  phone: (
    <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z" />
  ),

  email: (
    <>
      <rect x="3" y="5" width="18" height="14" rx="2" />
      <polyline points="3,7 12,13 21,7" />
    </>
  ),

  address: (
    <>
      <path d="M20 10c0 5-8 11-8 11S4 15 4 10a8 8 0 1 1 16 0z" />
      <circle cx="12" cy="10" r="2.5" />
    </>
  ),

  qualification: (
    <>
      <path d="M3 7l9-4 9 4-9 4-9-4z" />
      <path d="M7 10v6c2.8 2 7.2 2 10 0v-6" />
      <path d="M21 7v6" />
    </>
  ),

  college: (
    <>
      <rect x="4" y="3" width="16" height="18" rx="2" />
      <path d="M8 7h8" />
      <path d="M8 11h8" />
      <path d="M8 15h5" />
    </>
  ),

  course: (
    <>
      <path d="M4 5.5A2.5 2.5 0 0 1 6.5 3H20v16H6.5A2.5 2.5 0 0 0 4 21.5z" />
      <path d="M4 5.5v16" />
      <path d="M8 7h8" />
    </>
  ),

  diploma: (
    <>
      <circle cx="12" cy="12" r="8" />
      <path d="M8.5 12l2.3 2.3 4.7-4.7" />
    </>
  ),

  degree: (
    <>
      <path d="M3 9l9-5 9 5-9 5-9-5z" />
      <path d="M7 11v5c3 2 7 2 10 0v-5" />
      <path d="M21 9v7" />
    </>
  ),

  specialization: (
    <>
      <circle cx="12" cy="8" r="5" />
      <path d="M8.5 12.5L7 21l5-3 5 3-1.5-8.5" />
    </>
  ),

  year: (
    <>
      <rect x="3" y="5" width="18" height="16" rx="2" />
      <path d="M16 3v4" />
      <path d="M8 3v4" />
      <path d="M3 10h18" />
      <path d="M8 15h3" />
    </>
  ),

  enquiry: (
    <>
      <rect x="4" y="3" width="16" height="18" rx="2" />
      <path d="M8 7h8" />
      <path d="M8 11h8" />
      <path d="M8 15h5" />
    </>
  ),

  fees: (
    <>
      <rect x="3" y="6" width="18" height="13" rx="2" />
      <path d="M7 6V4h10v2" />
      <circle cx="12" cy="12.5" r="2.5" />
    </>
  ),

  discount: (
    <>
      <path d="M20.59 13.41L11 23l-9-9 9.59-9.59L20.59 13.41z" />
      <circle cx="7.5" cy="7.5" r="1.5" />
    </>
  ),

  validity: (
    <>
      <circle cx="12" cy="12" r="9" />
      <polyline points="12,7 12,12 15,14" />
    </>
  ),

  source: (
    <>
      <circle cx="6" cy="12" r="2" />
      <circle cx="18" cy="6" r="2" />
      <circle cx="18" cy="18" r="2" />
      <path d="M8 11l8-4" />
      <path d="M8 13l8 4" />
    </>
  ),

  status: (
    <>
      <circle cx="12" cy="12" r="9" />
      <path d="M8 12l2.5 2.5L16 9" />
    </>
  ),

  remarks: (
    <>
      <path d="M4 4h16v13H7l-3 3V4z" />
      <path d="M8 9h8" />
      <path d="M8 13h5" />
    </>
  ),

  created: (
    <>
      <circle cx="12" cy="12" r="9" />
      <polyline points="12,7 12,12 15,14" />
    </>
  ),

  edit: (
    <>
      <path d="M12 20h9" />
      <path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4 12.5-12.5z" />
    </>
  ),

  delete: (
    <>
      <polyline points="3 6 5 6 21 6" />
      <path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6" />
      <path d="M10 11v6" />
      <path d="M14 11v6" />
      <path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2" />
    </>
  ),

  tick: (
    <polyline points="20 6 9 17 4 12" />
  ),

  /* exclamation mark (!) used for "details not filled" */
  alert: (
    <>
      <line x1="12" y1="5" x2="12" y2="14" />
      <line x1="12" y1="19" x2="12" y2="19.01" />
    </>
  ),

  cross: (
    <>
      <line x1="18" y1="6" x2="6" y2="18" />
      <line x1="6" y1="6" x2="18" y2="18" />
    </>
  )

};

const DetailIcon = ({ type, size = 20, strokeWidth = 2 }) => {

  if (!ICON_PATHS[type]) {
    return null;
  }

  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      {ICON_PATHS[type]}
    </svg>
  );
};


/* ============================================================
   EXPANDED DETAILS STRUCTURE
   Personal -> Educational -> Course -> Other
   ============================================================ */

const DETAIL_SECTIONS = [

  {
    title: "Personal Details",
    fields: [
      { icon: "phone", label: "Mobile Number", key: "mobile_number", color: "#696cff" },
      { icon: "email", label: "Email", key: "email", color: "#03c3ec" },
      { icon: "address", label: "Address", key: "address", color: "#ffab00" }
    ]
  },

  {
    title: "Educational Details",
    /* rendered as a table from the education_details JSON list */
    custom: "education",
    fields: []
  },

  {
    title: "Course Details",
    fields: [
      { icon: "course", label: "Course", key: "course", color: "#696cff" },
      { icon: "fees", label: "Course Fees", key: "course_fees", color: "#ffab00" },
      { icon: "discount", label: "Discount", key: "discount_percentage", color: "#ff3e1d" },
      { icon: "validity", label: "Discount Validity", key: "discount_validity", color: "#71dd37" },
      /* calculated: course fees - discount (not a backend field) */
      { icon: "fees", label: "Final Fee", key: "final_fee", color: "#03c3ec", format: "finalfee" }
    ]
  },

  {
    title: "Documents",
    /* resume / aadhaar links built from resume_cv and aadhar_card */
    custom: "documents",
    fields: []
  },

  {
    title: "Other Details",
    fields: [
      { icon: "enquiry", label: "Enquiry No", key: "enquiry_no", color: "#03c3ec" },
      { icon: "source", label: "Enquiry Source", key: "enquiry_source", color: "#696cff" },
      { icon: "status", label: "Status", key: "status", color: "#71dd37" },
      { icon: "created", label: "Created At", key: "created_at", color: "#03c3ec", format: "datetime" },
      { icon: "remarks", label: "Remarks", key: "remarks", color: "#ff3e1d", wide: true }
    ]
  }

];


/* ============================================================
   HELPERS
   ============================================================ */

/*
 * FINAL FEE = course fees - (course fees x discount % / 100)
 * Returns "" when the course fees is empty / not a number.
 * An empty or wrong discount counts as 0 (kept between 0 and 100).
 */
const calcFinalFee = (fees, discount) => {

  const amount = parseFloat(fees);

  if (!Number.isFinite(amount)) {
    return "";
  }

  let percent = parseFloat(discount);

  if (!Number.isFinite(percent) || percent < 0) {
    percent = 0;
  }

  if (percent > 100) {
    percent = 100;
  }

  return (amount - (amount * percent) / 100).toFixed(2);
};


const formatDateTime = (value) => {

  if (!value) {
    return "";
  }

  const date = new Date(value);

  if (Number.isNaN(date.getTime())) {
    return String(value);
  }

  return date.toLocaleString("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit"
  });
};


/* a file field may be a text, or an object like { url: "..." } */

const pickFileString = (value) => {

  if (!value) {
    return "";
  }

  if (typeof value === "string") {

    const text = value.trim();

    if (
      !text ||
      ["null", "none", "undefined"].includes(text.toLowerCase())
    ) {
      return "";
    }

    return text;

  }

  if (typeof value === "object") {
    return pickFileString(
      value.url || value.path || value.file || value.name
    );
  }

  return "";
};


/* file fields may come with different names from the backend */

const findFileValue = (item, knownKeys, pattern) => {

  if (!item) {
    return "";
  }

  for (const key of knownKeys) {

    const value = pickFileString(item[key]);

    if (value) {
      return value;
    }

  }

  const foundKey = Object.keys(item).find(
    (key) => pattern.test(key) && pickFileString(item[key])
  );

  return foundKey ? pickFileString(item[foundKey]) : "";
};


const getStudentPhotoValue = (item) =>
  findFileValue(
    item,
    [
      "student_photo",
      "student_image",
      "studentPhoto",
      "photo",
      "photo_url",
      "image"
    ],
    /photo|image|picture|avatar/i
  );

const PHOTO_PATTERN = /photo|image|picture|avatar/i;
const RESUME_PATTERN = /resume|cv/i;
const AADHAR_PATTERN = /aadh?a+r/i;

const getResumeValue = (item) =>
  findFileValue(item, ["resume_cv", "resume"], RESUME_PATTERN);

const getAadharValue = (item) =>
  findFileValue(item, ["aadhar_card", "aadhaar_card"], AADHAR_PATTERN);

/* true when the API sends that field at all (even if it is empty) */
const hasFieldLike = (item, pattern) =>
  Object.keys(item || {}).some((key) => pattern.test(key));


/* ============================================================
   FORM COMPLETE / NOT COMPLETE
   red !  = some details of the registration are not filled
   green tick = every detail is filled
   ============================================================ */

const isFilled = (value) =>
  value !== null && value !== undefined && String(value).trim() !== "";

/*
 * education_details comes from the API as JSON text (or already as a list):
 * [{"qualification","institute","board","percentage","yop","degree","department"}]
 * Always returns a list of objects ([] when empty or invalid).
 */
const getEducationRows = (item) => {

  if (!item) {
    return [];
  }

  let rows = item.education_details;

  if (typeof rows === "string") {
    try {
      rows = JSON.parse(rows || "[]");
    } catch (error) {
      return [];
    }
  }

  return Array.isArray(rows)
    ? rows.filter((row) => row && typeof row === "object")
    : [];
};

/* "10th, 12th, B.E" - shown in the Qualification column of the list */
const qualificationText = (item) =>
  getEducationRows(item)
    .map((row) => String(row.qualification || "").trim())
    .filter(Boolean)
    .join(", ") || "-";

/* returns the names of the details that are still empty */
const getMissingDetails = (item, personPhotos = {}) => {

  const missing = [];

  const check = (label, value, key) => {
    /* a detail the API does not send at all cannot be checked */
    if (key && !(key in item)) {
      return;
    }

    if (!isFilled(value)) {
      missing.push(label);
    }
  };

  /* personal details */
  check("Enquiry No", item.enquiry_no, "enquiry_no");
  check("Registration Date", item.registration_date, "registration_date");
  check("Student Name", item.student_name, "student_name");

  if (
    "mobile_number" in item &&
    !/^\d{10}$/.test(String(item.mobile_number || ""))
  ) {
    missing.push("Mobile Number");
  }

  check("Email", item.email, "email");
  check("Address", item.address, "address");

  check(
    "Student Photo",
    getStudentPhotoValue(item) ||
      personPhotos[String(item.enquiry_no || "")] ||
      ""
  );

  /* educational details */
  if ("education_details" in item && getEducationRows(item).length === 0) {
    missing.push("Educational Details");
  }

  /* course details */
  check("Course", item.course, "course");
  check("Course Fees", item.course_fees, "course_fees");
  check("Discount", item.discount_percentage, "discount_percentage");
  check("Discount Validity", item.discount_validity, "discount_validity");

  /* documents (checked only when the API sends these fields) */
  if (hasFieldLike(item, RESUME_PATTERN)) {
    check("Resume / CV", getResumeValue(item));
  }

  if (hasFieldLike(item, AADHAR_PATTERN)) {
    check("Aadhaar Card", getAadharValue(item));
  }

  return missing;
};


/* Full record data sent with PUT when the status is changed */

const buildStatusPayload = (item, status) => {

  const textKeys = [
    "student_name",
    "mobile_number",
    "email",
    "address",
    "course",
    "remarks"
  ];

  const numberKeys = [
    "course_fees",
    "discount_percentage"
  ];

  const payload = { status };

  textKeys.forEach((key) => {
    payload[key] = item[key] ?? "";
  });

  numberKeys.forEach((key) => {
    if (
      item[key] !== null &&
      item[key] !== undefined &&
      item[key] !== ""
    ) {
      payload[key] = item[key];
    }
  });

  if (item.enquiry_no) {
    payload.enquiry_no = item.enquiry_no;
  }

  if (item.registration_date) {
    payload.registration_date = String(item.registration_date).slice(0, 10);
  }

  return payload;
};


/* oldest first: 001, 002, 003 ... then a re-registered 001 comes after them */

const sortRegistrations = (list) => {

  return [...list].sort((a, b) => {

    const idA = Number(a.id);
    const idB = Number(b.id);

    if (
      a.id !== null && a.id !== undefined &&
      b.id !== null && b.id !== undefined &&
      !Number.isNaN(idA) && !Number.isNaN(idB)
    ) {
      return idA - idB;
    }

    const timeA = new Date(a.created_at).getTime();
    const timeB = new Date(b.created_at).getTime();

    if (!Number.isNaN(timeA) && !Number.isNaN(timeB)) {
      return timeA - timeB;
    }

    return 0;

  });

};


/* one person (enquiry no) = one registration id: IGT0001, IGT0002 ... in order of first registration */

const buildPersonRegIds = (list) => {

  const map = {};

  let count = 0;

  sortRegistrations(list).forEach((record) => {

    const key = String(record.enquiry_no || "");

    if (key && !map[key]) {

      count += 1;

      map[key] = `IGT${String(count).padStart(4, "0")}`;

    }

  });

  return map;

};


/* one person (enquiry no) = one photo: the newest saved photo of that person */

const buildPersonPhotos = (list) => {

  const map = {};

  sortRegistrations(list).forEach((record) => {

    const key = String(record.enquiry_no || "");

    const photo = getStudentPhotoValue(record);

    if (key && photo) {

      /* newer registrations come later, so they replace older ones */
      map[key] = photo;

    }

  });

  return map;

};


/* REG0001 -> IGT001 (backend id is not changed) */

const getDisplayRegistrationId = (item, personRegIds = {}) => {

  if (item.enquiry_no && personRegIds[String(item.enquiry_no)]) {
    return personRegIds[String(item.enquiry_no)];
  }

  const rawId =
    item.registration_id ||
    item.id ||
    "";

  const numericPart = String(rawId).match(/(\d+)$/);

  if (numericPart) {
    return `IGT${String(numericPart[1]).padStart(3, "0")}`;
  }

  return rawId || "-";
};


/* ============================================================
   EDUCATION DETAILS TABLE (from education_details)
   ============================================================ */

const EDUCATION_COLUMNS = [
  { key: "qualification", label: "Qualification" },
  { key: "institute", label: "School / College" },
  { key: "board", label: "Board / University" },
  { key: "percentage", label: "Marks / CGPA" },
  { key: "yop", label: "Year" },
  { key: "degree", label: "Degree" },
  { key: "department", label: "Department" }
];

const EducationDetails = ({ item }) => {

  const rows = getEducationRows(item);

  if (rows.length === 0) {
    return (
      <p className="registration-education-empty">
        No education details added.
      </p>
    );
  }

  return (
    <div className="registration-education-wrap">
      <table className="registration-education-table">
        <thead>
          <tr>
            {EDUCATION_COLUMNS.map((column) => (
              <th key={column.key}>{column.label}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row, index) => (
            <tr key={index}>
              {EDUCATION_COLUMNS.map((column) => (
                <td key={column.key}>
                  {String(row[column.key] || "").trim() || "-"}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};


/* ============================================================
   DOCUMENTS (Resume / Aadhaar) - view links
   ============================================================ */

const DOCUMENT_ITEMS = [
  { label: "Resume / CV", get: getResumeValue },
  { label: "Aadhaar Card", get: getAadharValue },
  { label: "Student Photo", get: getStudentPhotoValue }
];

const fileNameOf = (value) => {

  try {
    const clean = decodeURIComponent(String(value).split("?")[0]);
    return clean.substring(clean.lastIndexOf("/") + 1);
  } catch (error) {
    return String(value);
  }
};

const DocumentsDetails = ({ item, apiUrl }) => (

  <div className="registration-documents">

    {DOCUMENT_ITEMS.map((doc) => {

      const value = doc.get(item);

      const url = value ? buildFileCandidates(value, apiUrl)[0] : "";

      return (

        <div key={doc.label} className="registration-document-item">

          <span className="registration-document-label">
            {doc.label}
          </span>

          {url ? (

            <a
              href={url}
              target="_blank"
              rel="noopener noreferrer"
              className="registration-document-link"
              title={fileNameOf(value)}
            >
              View file
            </a>

          ) : (

            <span className="registration-document-missing">
              Not uploaded
            </span>

          )}

        </div>

      );

    })}

  </div>

);


/* ============================================================
   DETAIL ITEM
   ============================================================ */

const DetailItem = ({ field, item }) => {

  let value;

  if (field.format === "datetime") {
    value = formatDateTime(item[field.key]);
  } else if (field.format === "finalfee") {
    /* course fees - discount % (calculated, not saved) */
    value = calcFinalFee(item.course_fees, item.discount_percentage);
  } else {
    value = item[field.key];
  }

  return (

    <div
      className={`registration-detail-item ${
        field.wide ? "wide" : ""
      }`}
    >

      <div
        className="registration-detail-icon"
        style={{
          color: field.color,
          background: `${field.color}29`
        }}
      >
        <DetailIcon type={field.icon} />
      </div>

      <div className="registration-detail-content">

        <label style={{ color: field.color }}>
          {field.label}
        </label>

        <p>
          {value === null || value === undefined || value === ""
            ? "-"
            : value}
        </p>

      </div>

    </div>

  );

};


/* ============================================================
   REGISTRATION COMPONENT
   ============================================================ */

function Registration() {

  /* server address + API calls from AuthContext */
  const { getData, insert } = useContext(AuthContext);

  const [pageMode, setPageMode] = useState("list");

  const [editingRecord, setEditingRecord] = useState(null);

  /* the registration just saved -> opened in the billing plan page */
  const [billingRegistration, setBillingRegistration] = useState(null);

  const [registrations, setRegistrations] = useState([]);

  const [searchName, setSearchName] = useState("");
  const [searchPhone, setSearchPhone] = useState("");
  const [searchCourse, setSearchCourse] = useState("");
  const [searchDate, setSearchDate] = useState("");

  const [expandedId, setExpandedId] = useState(null);

  const [loading, setLoading] = useState(false);

  const [statusUpdatingId, setStatusUpdatingId] = useState(null);


  /* ============================================================
     POPUP ALERT (same popup as Addregistration.jsx)
     type: "error" | "warning" | "success"
     onConfirm: when given, the popup shows Cancel + confirm buttons
     ============================================================ */

  const [popup, setPopup] = useState(null);

  const showAlert = (
    text,
    title = "Validation Error",
    type = "error",
    onConfirm = null,
    confirmLabel = "Yes"
  ) => {
    setPopup({ text, title, type, onConfirm, confirmLabel });
  };

  const closePopup = () => setPopup(null);

  const confirmPopup = () => {
    const action = popup && popup.onConfirm;

    setPopup(null);

    if (action) {
      action();
    }
  };

  /* Esc key closes the popup */
  useEffect(() => {

    if (!popup) {
      return undefined;
    }

    const onKey = (e) => {
      if (e.key === "Escape") {
        setPopup(null);
      }
    };

    window.addEventListener("keydown", onKey);

    return () => window.removeEventListener("keydown", onKey);

  }, [popup]);


  /* ============================================================
     GET REGISTRATIONS  (AuthContext -> getData "fetch_registration_datail")
     ============================================================ */

  const fetchRegistrations = async () => {

    try {

      setLoading(true);

      const records = await getData("fetch_registration_datail");

      /* getData() gives nothing back when the request failed */
      if (!Array.isArray(records)) {
        throw new Error("Unable to load registrations.");
      }

      /* help to find why photos are not shown (open the browser console) */

      if (
        records.length > 0 &&
        !records.some((record) => getStudentPhotoValue(record))
      ) {
        console.warn(
          "No photo field found in the registration API. Fields received:",
          Object.keys(records[0])
        );
      }

      setRegistrations(records);

    }

    catch (error) {

      console.error("Error fetching registrations:", error);

      console.error("Response:", error.responseData);

      setRegistrations([]);

    }

    finally {

      setLoading(false);

    }

  };


  useEffect(() => {

    fetchRegistrations();

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);


  /* ============================================================
     SEARCH BOX VALIDATION (wrong typing shows the popup alert)
     ============================================================ */

  /* student name: letters only (space . ' - allowed) */
  const handleSearchName = (e) => {

    const value = e.target.value;

    if (/^\s/.test(value)) {
      showAlert("Student name cannot start with a space.");
      return;
    }

    if (/\s{2,}/.test(value)) {
      showAlert("Only one space is allowed between words.");
      return;
    }

    if (!/^[A-Za-z\s.'-]*$/.test(value)) {
      showAlert("Please type letters only for student name.");
      return;
    }

    if (value.length > 150) {
      showAlert("Student name cannot be more than 150 characters.");
      return;
    }

    setSearchName(value);

  };


  /* phone: numbers only, maximum 10 digits */
  const handleSearchPhone = (e) => {

    const value = e.target.value;

    if (!/^\d*$/.test(value)) {
      showAlert("Please type numbers only for phone number.");
      return;
    }

    if (value.length > 10) {
      showAlert("Phone number must contain only 10 digits.");
      return;
    }

    setSearchPhone(value);

  };


  /* course: letters, numbers, space and . + # & - / ( ) */
  const handleSearchCourse = (e) => {

    const value = e.target.value;

    if (/^\s/.test(value)) {
      showAlert("Course cannot start with a space.");
      return;
    }

    if (/\s{2,}/.test(value)) {
      showAlert("Only one space is allowed between words.");
      return;
    }

    if (!/^[A-Za-z0-9\s.+#&\-/()]*$/.test(value)) {
      showAlert(
        "Course can contain only letters, numbers and the symbols . + # & - / ( )"
      );
      return;
    }

    if (value.length > 150) {
      showAlert("Course cannot be more than 150 characters.");
      return;
    }

    setSearchCourse(value);

  };


  /* date: a complete date must have a 4 digit year between 2000 and 2100 */
  const handleSearchDate = (e) => {

    const value = e.target.value;

    if (value) {

      const match = value.match(/^(\d{4,6})-(\d{2})-(\d{2})$/);

      const year = match ? Number(match[1]) : 0;

      if (!match || year < 2000 || year > 2100) {
        showAlert("Please select a valid date (year between 2000 and 2100).");
        return;
      }

    }

    setSearchDate(value);

  };


  /* ============================================================
     SEARCH
     ============================================================ */

  const filteredRegistrations = sortRegistrations(registrations).filter((item) => {

    /* search matches from the FIRST letter / number only (not the middle) */
    const startsWith = (value, query) =>
      String(value || "")
        .trim()
        .toLowerCase()
        .startsWith(String(query).trim().toLowerCase());

    const nameMatch =
      !searchName.trim() || startsWith(item.student_name, searchName);

    const phoneMatch =
      !searchPhone.trim() || startsWith(item.mobile_number, searchPhone);

    const courseMatch =
      !searchCourse.trim() || startsWith(item.course, searchCourse);

    const dateMatch =
      !searchDate ||
      String(item.registration_date || "").includes(searchDate);

    return (
      nameMatch &&
      phoneMatch &&
      courseMatch &&
      dateMatch
    );

  });


  const personRegIds = buildPersonRegIds(registrations);

  const personPhotos = buildPersonPhotos(registrations);


  const clearSearch = () => {

    setSearchName("");
    setSearchPhone("");
    setSearchCourse("");
    setSearchDate("");

  };


  const toggleExpand = (id) => {

    setExpandedId(expandedId === id ? null : id);

  };


  /* ============================================================
     AFTER ADD / EDIT REGISTRATION
     ============================================================ */

  const handleRegistrationSaved = (savedRecord) => {

    setEditingRecord(null);

    fetchRegistrations();

    /*
     * A NEW registration goes straight to the billing plan page of this
     * student (Addbilling opens on the Payment Plan step).
     * Without the saved record (or after an edit) the list is shown.
     */
    if (savedRecord && typeof savedRecord === "object") {

      setBillingRegistration(savedRecord);

      setPageMode("billing");

      return;

    }

    setPageMode("list");

  };


  /* ============================================================
     DELETE REGISTRATION  (AuthContext -> Delete "delete_registration_datail")
     ============================================================ */

  const handleDelete = async (item) => {

    const id = item.id || item.registration_id;

    if (!id) {

      showAlert("Registration ID not found.", "Not Found");

      return;

    }

    /* confirmation popup instead of the browser confirm box */

    showAlert(
      `Are you sure you want to delete registration ${
        item.registration_id || id
      }?`,
      "Delete Registration",
      "warning",
      async () => {

        try {

          await insert(
            { Registration_id: id },
            "delete_registration_datail"
          );

          showAlert(
            "Registration deleted successfully.",
            "Deleted",
            "success"
          );

          fetchRegistrations();

        }

        catch (error) {

          console.error("Delete registration error:", error);

          const backendMessage =
            error.responseData?.message ||
            error.responseData?.error ||
            error.responseData?.detail;

          showAlert(
            backendMessage || "Unable to delete registration.",
            "Unable to Delete"
          );

        }

      },
      "Delete"
    );

  };


  /* ============================================================
     TOGGLE STATUS  (AuthContext -> update "update_registration_datail")
     Active -> Inactive, anything else -> Active
     ============================================================ */

  const handleToggleStatus = async (item) => {

    const id = item.id || item.registration_id;

    if (!id || statusUpdatingId === id) {
      return;
    }

    const newStatus =
      String(item.status || "").toLowerCase() === "active"
        ? "Inactive"
        : "Active";

    try {

      setStatusUpdatingId(id);

      /* the full record data is sent (JSON) with the new status */

      const payload = buildStatusPayload(item, newStatus);

      await insert(
        { ...payload, Registration_id: id },
        "update_registration_datail"
      );

      setRegistrations((previous) =>
        previous.map((record) =>
          (record.id || record.registration_id) === id
            ? { ...record, status: newStatus }
            : record
        )
      );

    }

    catch (error) {

      console.error("Status update error:", error);

      const backendMessage =
        error.responseData?.message ||
        error.responseData?.error ||
        error.responseData?.detail ||
        (error.responseData?.status &&
          String(error.responseData.status));

      showAlert(backendMessage || "Unable to update status.", "Unable to Update");

    }

    finally {

      setStatusUpdatingId(null);

    }

  };


  /* ============================================================
     EDIT REGISTRATION
     OPENS THE ADD REGISTRATION FORM WITH THE RECORD FILLED IN
     ============================================================ */

  const handleEdit = (item) => {

    const id = item.id || item.registration_id;

    if (!id) {

      showAlert("Registration ID not found.", "Not Found");

      return;

    }

    setEditingRecord(item);

    setPageMode("edit");

  };


  /* ============================================================
     ADD / EDIT PAGES
     ============================================================ */

  if (pageMode === "add") {

    return (

      <Addregistration
        onBack={() => setPageMode("list")}
        onSaved={handleRegistrationSaved}
      />

    );

  }


  if (pageMode === "billing" && billingRegistration) {

    return (

      <Addbilling
        key={billingRegistration.id || billingRegistration.registration_id}
        registration={billingRegistration}
        onBack={() => {
          setBillingRegistration(null);
          setPageMode("list");
        }}
        onSaved={() => {
          setBillingRegistration(null);
          setPageMode("list");
          fetchRegistrations();
        }}
      />

    );

  }


  if (pageMode === "edit" && editingRecord) {

    return (

      <Updateregistration
        key={editingRecord.id || editingRecord.registration_id}
        registration={editingRecord}
        onClose={() => {
          setEditingRecord(null);
          setPageMode("list");
        }}
        onSuccess={handleRegistrationSaved}
      />

    );

  }


  /* ============================================================
     LIST PAGE
     ============================================================ */

  return (

    <div
      className="registration-page"
      style={{
        paddingTop: "8px",
        paddingBottom: "30px"
      }}
    >

      {/* ========================================================
          HEADER
          ======================================================== */}

      <div
        className="registration-header"
        style={{ marginBottom: "18px" }}
      >

        <div>

          <h2
            style={{
              marginBottom: "0",
              fontWeight: "700"
            }}
          >
            Registration Management
          </h2>

        </div>

        <button
          type="button"
          className="registration-add-btn btn btn-primary"
          onClick={() => setPageMode("add")}
        >

          <span>+</span>

          Add Registration

        </button>

      </div>


      {/* ========================================================
          SEARCH SECTION
          ======================================================== */}

      <div
        className="registration-search-card"
        style={{
          paddingTop: "20px",
          paddingBottom: "18px",
          marginBottom: "20px"
        }}
      >

        <div
          className="registration-search-grid"
          style={{ marginTop: "0" }}
        >

          {/* NAME */}

          <div className="registration-search-field">

            <div className="registration-input-wrapper">

              <span>⌕</span>

              <input
                type="text"
                placeholder="Student name"
                value={searchName}
                maxLength="151"
                onChange={handleSearchName}
              />

            </div>

          </div>


          {/* PHONE */}

          <div className="registration-search-field">

            <div className="registration-input-wrapper">

              <span>⌕</span>

              <input
                type="text"
                placeholder="Phone number"
                value={searchPhone}
                inputMode="numeric"
                onChange={handleSearchPhone}
              />

            </div>

          </div>


          {/* COURSE */}

          <div className="registration-search-field">

            <div className="registration-input-wrapper">

              <span>⌕</span>

              <input
                type="text"
                placeholder="Course"
                value={searchCourse}
                maxLength="151"
                onChange={handleSearchCourse}
              />

            </div>

          </div>


          {/* DATE */}

          <div className="registration-search-field">

            <input
              type="date"
              value={searchDate}
              min="2000-01-01"
              max="2100-12-31"
              onChange={handleSearchDate}
            />

          </div>

        </div>


        {/* SEARCH BOTTOM */}

        <div
          className="registration-search-bottom"
          style={{ marginTop: "16px" }}
        >

          <span>

            Showing {filteredRegistrations.length} registrations

          </span>

          <div>

            <button
              type="button"
              className="registration-clear-btn"
              onClick={clearSearch}
            >
              Clear
            </button>

            <button
              type="button"
              className="registration-refresh-btn btn btn-primary"
              onClick={fetchRegistrations}
            >
              Refresh
            </button>

          </div>

        </div>

      </div>


      {/* ========================================================
          REGISTRATION TABLE
          ======================================================== */}

      <div
        className="registration-list-card"
        style={{ marginTop: "0" }}
      >

        <div className="registration-table-container">

          <table className="registration-table">

            <thead>

              <tr>

                <th></th>
                <th>S.NO</th>
                <th>FORM</th>
                <th>REG ID</th>
                <th>ENQ NO</th>
                <th>NAME</th>
                <th>PHONE</th>
                <th>COURSE</th>
                <th>QUALIFICATION</th>
                <th>REGISTRATION DATE</th>
                <th>STATUS</th>
                <th>ACTION</th>

              </tr>

            </thead>

            <tbody>

              {loading ? (

                <tr>

                  <td
                    colSpan="12"
                    className="registration-empty"
                  >
                    Loading...
                  </td>

                </tr>

              ) : filteredRegistrations.length === 0 ? (

                <tr>

                  <td
                    colSpan="12"
                    className="registration-empty"
                  >
                    No registrations found
                  </td>

                </tr>

              ) : (

                filteredRegistrations.map((item, index) => {

                  const rowId = item.id || item.registration_id;

                  /* own photo first, otherwise the photo of the same person (same enquiry no) */

                  const photoCandidates = buildFileCandidates(
                    getStudentPhotoValue(item) ||
                      personPhotos[String(item.enquiry_no || "")] ||
                      "",
                    apiUrl
                  );

                  /* red ! = some details are not filled, green tick = all details are filled */

                  const missingDetails = getMissingDetails(item, personPhotos);

                  const formComplete = missingDetails.length === 0;

                  return (

                    <React.Fragment key={rowId}>

                      {/* MAIN ROW */}

                      <tr>

                        {/* EXPAND */}

                        <td>

                          <button
                            type="button"
                            className="registration-expand-btn"
                            onClick={() => toggleExpand(rowId)}
                          >
                            {expandedId === rowId ? "−" : "+"}
                          </button>

                        </td>

                        {/* SERIAL NUMBER 1,2,3... */}

                        <td>{index + 1}</td>

                        {/* FORM COMPLETE INDICATOR */}

                        <td>

                          <span
                            className={`registration-form-badge ${
                              formComplete ? "complete" : "incomplete"
                            }`}
                            title={
                              formComplete
                                ? "All details are filled"
                                : `Not filled: ${missingDetails.join(", ")}`
                            }
                          >
                            <DetailIcon
                              type={formComplete ? "tick" : "alert"}
                              size={18}
                              strokeWidth={3}
                            />
                          </span>

                        </td>

                        {/* REGISTRATION ID */}

                        <td
                          className="registration-id"
                          style={{ whiteSpace: "nowrap" }}
                        >
                          {getDisplayRegistrationId(item, personRegIds)}
                        </td>

                        {/* ENQUIRY NO */}

                        <td style={{ whiteSpace: "nowrap" }}>
                          {item.enquiry_no || "-"}
                        </td>

                        {/* NAME + PHOTO */}

                        <td>

                          <div className="registration-student-cell">

                            <div className="registration-student-photo">

                              <FallbackImage
                                candidates={photoCandidates}
                                alt={item.student_name || "Student"}
                                fallback={
                                  <div
                                    className="registration-student-photo-placeholder"
                                    style={{ display: "flex" }}
                                  >

                                    <svg
                                      width="22"
                                      height="22"
                                      viewBox="0 0 24 24"
                                      fill="none"
                                      stroke="currentColor"
                                      strokeWidth="1.8"
                                      strokeLinecap="round"
                                      strokeLinejoin="round"
                                    >
                                      <path d="M20 21a8 8 0 0 0-16 0" />
                                      <circle cx="12" cy="7" r="4" />
                                    </svg>

                                  </div>
                                }
                              />

                            </div>

                            <span>{item.student_name || "-"}</span>

                          </div>

                        </td>

                        <td style={{ whiteSpace: "nowrap" }}>
                          {item.mobile_number || "-"}
                        </td>

                        <td>{item.course || "-"}</td>

                        <td>{qualificationText(item)}</td>

                        <td style={{ whiteSpace: "nowrap" }}>
                          {item.registration_date || "-"}
                        </td>

                        {/* STATUS */}

                        <td>

                          <button
                            type="button"
                            className={`registration-status-btn status-${
                              String(item.status || "New")
                                .toLowerCase()
                                .replace(/\s/g, "-")
                            }`}
                            onClick={() => handleToggleStatus(item)}
                            disabled={statusUpdatingId === rowId}
                            title={
                              String(item.status || "").toLowerCase() === "active"
                                ? "Click to set Inactive"
                                : "Click to set Active"
                            }
                          >
                            <span className="registration-status-dot"></span>
                            {item.status || "New"}
                          </button>

                        </td>

                        {/* ACTION - SNEAT SOFT ICON BUTTONS */}

                        <td>

                          <div className="registration-actions">

                            <button
                              type="button"
                              className="registration-edit-btn"
                              onClick={() => handleEdit(item)}
                              title="Edit"
                              aria-label="Edit registration"
                            >
                              <DetailIcon type="edit" size={17} />
                            </button>

                            <button
                              type="button"
                              className="registration-delete-btn"
                              onClick={() => handleDelete(item)}
                              title="Delete"
                              aria-label="Delete registration"
                            >
                              <DetailIcon type="delete" size={17} />
                            </button>

                          </div>

                        </td>

                      </tr>


                      {/* EXPANDED DETAILS */}

                      {expandedId === rowId && (

                        <tr>

                          <td
                            colSpan="12"
                            style={{
                              padding: "0",
                              background: "#f5f5f9",
                              borderTop: "1px solid #e7e7eb"
                            }}
                          >

                            <div className="registration-details-wrap">

                              <div className="registration-details-panel">

                                {DETAIL_SECTIONS.map((section) => (

                                  <div
                                    key={section.title}
                                    className="registration-detail-section"
                                  >

                                    <h6 className="registration-detail-section-title">
                                      {section.title}
                                    </h6>

                                    {section.custom === "education" ? (

                                      <EducationDetails item={item} />

                                    ) : section.custom === "documents" ? (

                                      <DocumentsDetails
                                        item={item}
                                        apiUrl={apiUrl}
                                      />

                                    ) : (

                                    <div className="registration-detail-grid">

                                      {section.fields
                                        .filter(
                                          (field) =>
                                            !field.hideIfEmpty ||
                                            (item[field.key] !== null &&
                                              item[field.key] !== undefined &&
                                              item[field.key] !== "")
                                        )
                                        .map((field) => (

                                        <DetailItem
                                          key={field.key}
                                          field={field}
                                          item={item}
                                        />

                                      ))}

                                    </div>

                                    )}

                                  </div>

                                ))}

                              </div>

                            </div>

                          </td>

                        </tr>

                      )}

                    </React.Fragment>

                  );

                })

              )}

            </tbody>

          </table>

        </div>


        {/* COUNT */}

        <div className="registration-pagination">

          Showing 1-{filteredRegistrations.length} of {registrations.length}

        </div>

      </div>


      {/* ========================================================
          VALIDATION / MESSAGE POPUP
          ======================================================== */}

      {popup && (

        <div className="reg-alert-overlay" onClick={closePopup}>

          <div
            className={`reg-alert-box ${popup.type}`}
            role="alertdialog"
            aria-modal="true"
            onClick={(e) => e.stopPropagation()}
          >

            <button
              type="button"
              className="reg-alert-close"
              aria-label="Close"
              onClick={closePopup}
            >
              &times;
            </button>

            <div className="reg-alert-icon">
              <DetailIcon
                type={popup.type === "success" ? "tick" : "alert"}
                size={38}
                strokeWidth={2.6}
              />
            </div>

            <h4 className="reg-alert-title">{popup.title}</h4>

            <p className="reg-alert-text">{popup.text}</p>

            <div className="reg-alert-actions">

              {popup.onConfirm && (
                <button
                  type="button"
                  className="reg-alert-btn cancel"
                  onClick={closePopup}
                >
                  Cancel
                </button>
              )}

              <button
                type="button"
                className={`reg-alert-btn${
                  popup.onConfirm ? " danger" : ""
                }`}
                onClick={popup.onConfirm ? confirmPopup : closePopup}
                autoFocus
              >
                {popup.onConfirm ? popup.confirmLabel : "Got it"}
              </button>

            </div>

          </div>

        </div>

      )}


      {/* ========================================================
          DESIGN OVERRIDES (SNEAT STYLE)
          ======================================================== */}

      <style>{`

        .registration-page {
          padding-top: 8px !important;
        }

        .registration-header {
          margin-bottom: 18px !important;
        }

        .registration-header p {
          display: none !important;
        }


        /* ---------- TABLE: NO HORIZONTAL SCROLL, ALL COLUMNS VISIBLE ---------- */

        .registration-table-container {
          overflow-x: visible !important;
          overflow-y: visible !important;
        }

        .registration-table {
          width: 100% !important;
          min-width: 0 !important;
          table-layout: auto !important;
        }

        .registration-table th,
        .registration-table td {
          padding: 12px 8px !important;
          font-size: 13px !important;
          white-space: normal;
          overflow-wrap: break-word;
          vertical-align: middle;
        }

        .registration-table th {
          font-size: 12px !important;
          line-height: 1.3;
        }

        .registration-table .registration-expand-btn {
          width: 26px !important;
          height: 26px !important;
          min-width: 26px !important;
        }


        /* ---------- ADD / REFRESH BUTTONS ---------- */

        .registration-add-btn,
        .registration-refresh-btn {
          background: #696cff !important;
          border: 1px solid #696cff !important;
          color: #ffffff !important;
          border-radius: 6px !important;
          min-height: 38px !important;
          padding: 8px 18px !important;
          font-size: 14px !important;
          font-weight: 600 !important;
          box-shadow: 0 2px 4px rgba(105, 108, 255, 0.2) !important;
          transition: all 0.2s ease !important;
        }

        .registration-add-btn:hover,
        .registration-refresh-btn:hover {
          background: #5f62e8 !important;
          border-color: #5f62e8 !important;
        }

        .registration-add-btn:hover {
          transform: translateY(-1px);
        }


        /* ---------- FORM COMPLETE INDICATOR (red ! / green tick) ---------- */

        .registration-form-badge {
          width: 30px;
          height: 30px;
          border-radius: 50%;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          cursor: help;
          transition: all 0.2s ease;
        }

        .registration-form-badge.complete {
          background: #e8fadf;
          color: #22c55e;
        }

        .registration-form-badge.incomplete {
          background: #ffe0db;
          color: #ff3e1d;
        }


        /* ---------- EDIT / DELETE (SNEAT SOFT ICON BUTTONS) ---------- */

        .registration-actions {
          display: flex !important;
          align-items: center !important;
          gap: 6px !important;
          flex-wrap: nowrap !important;
        }

        .registration-actions .registration-edit-btn,
        .registration-actions .registration-delete-btn {
          width: 32px !important;
          height: 32px !important;
          min-width: 32px !important;
          padding: 0 !important;
          border: 0 !important;
          border-radius: 6px !important;
          display: inline-flex !important;
          align-items: center !important;
          justify-content: center !important;
          box-shadow: none !important;
          cursor: pointer;
          font-size: 0 !important;
          transition: all 0.2s ease !important;
        }

        .registration-actions .registration-edit-btn {
          background: #e7e7ff !important;
          color: #696cff !important;
        }

        .registration-actions .registration-edit-btn:hover {
          background: #696cff !important;
          color: #ffffff !important;
          box-shadow: 0 2px 6px rgba(105, 108, 255, 0.4) !important;
        }

        .registration-actions .registration-delete-btn {
          background: #ffe0db !important;
          color: #ff3e1d !important;
        }

        .registration-actions .registration-delete-btn:hover {
          background: #ff3e1d !important;
          color: #ffffff !important;
          box-shadow: 0 2px 6px rgba(255, 62, 29, 0.4) !important;
        }


        /* ---------- STATUS BUTTON (SNEAT SOFT LABEL) ---------- */

        .registration-status-btn {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          min-width: 80px;
          justify-content: center;
          padding: 6px 10px;
          border: 0;
          border-radius: 6px;
          background: #ffeccc;
          color: #ffab00;
          font-size: 13px;
          font-weight: 600;
          line-height: 1.2;
          cursor: pointer;
          transition: all 0.2s ease;
        }

        .registration-status-btn:disabled {
          opacity: 0.6;
          cursor: wait;
        }

        .registration-status-dot {
          width: 7px;
          height: 7px;
          border-radius: 50%;
          background: currentColor;
        }

        .registration-status-btn.status-active {
          background: #e8fadf;
          color: #71dd37;
        }

        .registration-status-btn.status-active:hover:not(:disabled) {
          background: #71dd37;
          color: #ffffff;
          box-shadow: 0 2px 6px rgba(113, 221, 55, 0.4);
        }

        .registration-status-btn.status-inactive {
          background: #ebeef0;
          color: #8592a3;
        }

        .registration-status-btn.status-inactive:hover:not(:disabled) {
          background: #8592a3;
          color: #ffffff;
          box-shadow: 0 2px 6px rgba(133, 146, 163, 0.4);
        }

        .registration-status-btn.status-new {
          background: #d7f5fc;
          color: #03c3ec;
        }

        .registration-status-btn.status-new:hover:not(:disabled) {
          background: #03c3ec;
          color: #ffffff;
        }

        .registration-status-btn.status-completed {
          background: #e7e7ff;
          color: #696cff;
        }

        .registration-status-btn.status-completed:hover:not(:disabled) {
          background: #696cff;
          color: #ffffff;
        }

        .registration-status-btn.status-cancelled {
          background: #ffe0db;
          color: #ff3e1d;
        }

        .registration-status-btn.status-cancelled:hover:not(:disabled) {
          background: #ff3e1d;
          color: #ffffff;
        }


        /* ---------- SEARCH CARD ---------- */

        .registration-search-card {
          border-radius: 12px !important;
          box-shadow: 0 2px 8px rgba(67, 89, 113, 0.08) !important;
        }

        .registration-search-grid {
          margin-top: 0 !important;
        }


        /* ---------- EXPANDED DETAILS (SNEAT STYLE) ---------- */

        .registration-details-wrap {
          width: 100%;
          box-sizing: border-box;
          padding: 18px 20px 20px 20px;
          background: #f5f5f9;
        }

        .registration-details-panel {
          background: #ffffff;
          border-radius: 8px;
          box-shadow: 0 0.125rem 0.25rem rgba(161, 172, 184, 0.15);
          padding: 6px 24px;
        }

        .registration-detail-section {
          padding: 20px 0;
          border-bottom: 1px solid #ebeef0;
        }

        .registration-detail-section:last-child {
          border-bottom: 0;
        }

        .registration-detail-section-title {
          margin: 0 0 16px 0;
          color: #566a7f;
          font-size: 16px;
          font-weight: 600;
        }

        .registration-detail-grid {
          display: grid;
          grid-template-columns: repeat(4, minmax(0, 1fr));
          gap: 20px 24px;
        }

        .registration-detail-item {
          display: flex;
          align-items: flex-start;
          gap: 12px;
          min-width: 0;
        }

        .registration-detail-item.wide {
          grid-column: 1 / -1;
        }

        .registration-detail-icon {
          width: 38px;
          height: 38px;
          min-width: 38px;
          border-radius: 6px;
          display: flex;
          align-items: center;
          justify-content: center;
          flex-shrink: 0;
        }

        .registration-detail-content {
          min-width: 0;
          flex: 1;
        }

        .registration-detail-content label {
          display: block;
          margin: 0 0 3px 0;
          font-size: 11px;
          line-height: 1.3;
          font-weight: 700;
          letter-spacing: 0.5px;
          text-transform: uppercase;
        }

        .registration-detail-content p {
          margin: 0;
          color: #566a7f;
          font-size: 14.5px;
          font-weight: 500;
          line-height: 1.45;
          word-break: break-word;
        }


        /* ---------- STUDENT PHOTO ---------- */

        .registration-student-cell {
          display: flex;
          align-items: center;
          gap: 8px;
          min-width: 0;
        }

        .registration-student-photo {
          width: 38px;
          height: 38px;
          min-width: 38px;
          border-radius: 10px;
          overflow: hidden;
          border: 1px solid #e5e7eb;
          background: #eeeeff;
          color: #696cff;
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .registration-student-photo img {
          width: 100%;
          height: 100%;
          object-fit: cover;
          display: block;
        }

        .registration-student-photo-placeholder {
          width: 100%;
          height: 100%;
          align-items: center;
          justify-content: center;
        }

        .registration-student-cell > span {
          color: #566a83;
          font-weight: 600;
          min-width: 0;
        }


        /* ---------- REGISTRATION ID ---------- */

        .registration-id {
          color: #5667d9 !important;
          font-weight: 700 !important;
        }


        /* ---------- VALIDATION POPUP (same as Addregistration) ---------- */

        .reg-alert-overlay {
          position: fixed;
          inset: 0;
          background: rgba(34, 48, 62, 0.55);
          backdrop-filter: blur(2px);
          z-index: 10050;
          display: flex;
          align-items: center;
          justify-content: center;
          padding: 20px;
          animation: regAlertFade 0.18s ease;
        }

        .reg-alert-box {
          --accent: #ff3e1d;
          --soft: #ffe5e0;
          --ring: #fff1ee;
          position: relative;
          width: min(400px, 100%);
          background: #fff;
          border-radius: 16px;
          padding: 38px 30px 28px;
          text-align: center;
          box-shadow: 0 18px 50px rgba(67, 89, 113, 0.35);
          overflow: hidden;
          animation: regAlertPop 0.3s cubic-bezier(0.2, 0.9, 0.3, 1.3);
        }

        .reg-alert-box.warning {
          --accent: #ffab00;
          --soft: #fff2d6;
          --ring: #fff9ea;
        }

        .reg-alert-box.success {
          --accent: #71dd37;
          --soft: #e8fadf;
          --ring: #f3fcee;
        }

        .reg-alert-box::before {
          content: "";
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          height: 5px;
          background: var(--accent);
        }

        .reg-alert-close {
          position: absolute;
          top: 12px;
          right: 14px;
          width: 30px;
          height: 30px;
          border: 0;
          border-radius: 50%;
          background: transparent;
          color: #a1acb8;
          font-size: 22px;
          line-height: 1;
          cursor: pointer;
          transition: all 0.2s ease;
        }

        .reg-alert-close:hover {
          background: #f5f5f9;
          color: #566a7f;
        }

        .reg-alert-icon {
          width: 76px;
          height: 76px;
          margin: 0 auto 18px;
          border-radius: 50%;
          background: var(--soft);
          color: var(--accent);
          display: flex;
          align-items: center;
          justify-content: center;
          box-shadow: 0 0 0 9px var(--ring);
          animation: regAlertIcon 0.45s ease 0.1s both;
        }

        .reg-alert-title {
          margin: 0 0 8px;
          color: #566a7f;
          font-size: 21px;
          font-weight: 700;
        }

        .reg-alert-text {
          margin: 0 0 24px;
          color: #697a8d;
          font-size: 15px;
          line-height: 1.55;
        }

        .reg-alert-actions {
          display: flex;
          justify-content: center;
          gap: 10px;
        }

        .reg-alert-btn {
          border: 0;
          background: #696cff;
          color: #fff;
          border-radius: 8px;
          padding: 10px 34px;
          font-size: 15px;
          font-weight: 600;
          cursor: pointer;
          box-shadow: 0 0.125rem 0.25rem rgba(105, 108, 255, 0.4);
          transition: all 0.2s ease;
        }

        .reg-alert-btn:hover {
          background: #5f61e6;
          transform: translateY(-1px);
        }

        .reg-alert-btn.danger {
          background: #ff3e1d;
          box-shadow: 0 0.125rem 0.25rem rgba(255, 62, 29, 0.4);
        }

        .reg-alert-btn.danger:hover {
          background: #e6361a;
        }

        .reg-alert-btn.cancel {
          background: #fff;
          color: #697a8d;
          border: 1px solid #d9dee3;
          box-shadow: none;
        }

        .reg-alert-btn.cancel:hover {
          background: #f5f5f9;
        }

        .reg-alert-btn:focus-visible {
          outline: 3px solid rgba(105, 108, 255, 0.35);
          outline-offset: 2px;
        }

        @keyframes regAlertFade {
          from { opacity: 0; }
          to { opacity: 1; }
        }

        @keyframes regAlertPop {
          from { opacity: 0; transform: scale(0.85) translateY(10px); }
          to { opacity: 1; transform: scale(1) translateY(0); }
        }

        @keyframes regAlertIcon {
          0% { transform: scale(0.4); }
          60% { transform: scale(1.12); }
          100% { transform: scale(1); }
        }


        /* ---------- RESPONSIVE ---------- */

        @media (max-width: 1200px) {
          .registration-detail-grid {
            grid-template-columns: repeat(3, minmax(0, 1fr));
          }
        }

        @media (max-width: 900px) {
          .registration-detail-grid {
            grid-template-columns: repeat(2, minmax(0, 1fr));
          }

          .registration-details-wrap {
            padding: 14px;
          }

          .registration-details-panel {
            padding: 4px 16px;
          }
        }

        @media (max-width: 600px) {
          .registration-detail-grid {
            grid-template-columns: 1fr;
            gap: 16px;
          }

          .registration-student-photo {
            width: 34px;
            height: 34px;
            min-width: 34px;
          }
        }

      `}</style>

    </div>

  );

}


export default Registration;
