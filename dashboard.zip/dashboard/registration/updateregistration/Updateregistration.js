import React from "react";

import Addregistration from "../addregistration/Addregistration";

/*
 * EDIT REGISTRATION
 *
 * Shows the exact Addregistration form (same tabs, same fields,
 * same validations) filled with the selected registration.
 * Every field can be changed manually and saved.
 *
 * Props
 *   registration : the registration record to edit
 *   onClose      : called when the user cancels / goes back
 *   onSuccess    : called after the registration is updated
 */

function Updateregistration({ registration, onClose, onSuccess }) {
  return (
    <Addregistration
      registration={registration}
      onBack={onClose}
      onSaved={onSuccess}
    />
  );
}

export default Updateregistration;
