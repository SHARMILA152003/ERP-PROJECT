import React, { useContext, useState } from "react";
import AuthContext from "../../../services/AuthContext";
import "./deleteregistration.css";

/*
 * Delete uses insert({ Registration_id }, "delete_registration_datail")
 * from AuthContext. insert() is the AuthContext helper that throws the
 * Django error (error.responseData), so the message can be shown.
 * There is no axios call in this file.
 *
 * NOTE: the import path of AuthContext is for
 *   src/<folder>/registration/deleteregistration/Deleteregistration.jsx
 * If your file is in a different folder, change "../../../services/AuthContext".
 */

function Deleteregistration({ registration, onClose, onSuccess }) {
  const { insert } = useContext(AuthContext);

  const [deleting, setDeleting] = useState(false);
  const [error, setError] = useState("");

  const id = registration.id || registration.registration_id;

  const handleDelete = async () => {
    if (!id) {
      setError("Registration ID not found.");
      return;
    }

    setDeleting(true);
    setError("");

    try {
      const response = await insert(
        { Registration_id: id },
        "delete_registration_datail"
      );

      /* a delete with no body (204) is also a success */
      if (response && response.success === false) {
        const failure = new Error("Delete failed");
        failure.responseData = response;
        throw failure;
      }

      if (onSuccess) {
        onSuccess();
      }
    } catch (err) {
      console.error("Delete registration error:", err, err.responseData);

      const data = err.responseData;

      setError(
        (data && (data.message || data.error || data.detail)) ||
          err.message ||
          "Unable to delete registration."
      );
    } finally {
      setDeleting(false);
    }
  };

  return (
    <div className="delete-registration-overlay">
      <div className="delete-registration-modal">
        <div className="delete-icon">🗑</div>

        <h2>Delete Registration?</h2>

        <p>
          Are you sure you want to delete
          <strong> {registration.student_name} </strong>
          registration?
        </p>

        <p className="delete-warning">This action cannot be undone.</p>

        {error && (
          <p className="delete-warning" style={{ color: "#ff3e1d" }}>
            {error}
          </p>
        )}

        <div className="delete-actions">
          <button
            type="button"
            className="delete-cancel"
            onClick={onClose}
            disabled={deleting}
          >
            Cancel
          </button>

          <button
            type="button"
            className="delete-confirm"
            onClick={handleDelete}
            disabled={deleting}
          >
            {deleting ? "Deleting..." : "Delete"}
          </button>
        </div>
      </div>
    </div>
  );
}

export default Deleteregistration;
