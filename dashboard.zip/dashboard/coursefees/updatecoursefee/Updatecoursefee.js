import React, { useContext, useState } from "react";
import AuthContext from "../../../services/AuthContext";
import Validationpopup from "../validationpopup/Validationpopup";

const Updatecoursefee = (props) => {

    const { update } = useContext(AuthContext);

    const [validated, setValidated] = useState(false);
    const [error, setError] = useState("");
    const [loading, setLoading] = useState(false);

    const courses = props.courses || [];
    const courseFees = props.courseFees || [];
    const data = props.data || {};


    const handleSubmit = async (e) => {

        e.preventDefault();

        const form = e.currentTarget;

        setError("");


        // =========================
        // FORM VALIDATION
        // =========================

        if (!form.checkValidity()) {

            e.stopPropagation();

            setValidated(true);

            return;
        }


        // =========================
        // VALIDATION: one Active fee per course
        // Only matters when this fee is Active (e.g. its course is changed
        // to a course that already has another Active fee).
        // =========================

        const isThisActive =
            !form.Status.value || form.Status.value === "Active";

        if (isThisActive) {

            const alreadyActive = courseFees.some(
                (f) =>
                    String(f.CourseFee_id) !== String(form.CourseFee_id.value) &&
                    Number(f.Course_id) === parseInt(form.Course_id.value, 10) &&
                    (!f.Status || f.Status === "Active")
            );

            if (alreadyActive) {

                setError(
                    "This course already has another Active fee. " +
                    "Deactivate that one first."
                );

                return;
            }
        }


        // =========================
        // COURSE FEE DATA
        // =========================

        const courseFeeData = {
            CourseFee_id: form.CourseFee_id.value,
            Course_id: parseInt(form.Course_id.value, 10),
            Course_Fees: parseFloat(form.Course_Fees.value),
            Status: form.Status.value
        };

        console.log("Updating Course Fee:", courseFeeData);


        try {

            setLoading(true);

            await update(
                courseFeeData,
                "update_coursefee_datail",
                "/coursefees"
            );

            // Refresh parent list + go back to the list
            if (props.onSuccess) {

                await props.onSuccess();

            } else {

                props.toggle();

            }

        } catch (err) {

            console.error(
                "Update operation failed:",
                err
            );

            const responseData = err && err.responseData;

            if (responseData && responseData.detail) {

                setError(responseData.detail);

            } else {

                setError(
                    "Course fee plan could not be updated. Please try again."
                );
            }

        } finally {

            setLoading(false);

        }
    };


    return (

        <div className="coursefee-page centered-form-page container-xxl flex-grow-1 container-p-y">

            <div className="centered-form-wrap">


                {/* ================================================= */}
                {/* HEADER */}
                {/* ================================================= */}

                <div className="page-header">

                    <div>

                        <h3 className="page-title">
                            Update Course Fee
                        </h3>

                        <p className="page-subtitle">
                            Edit the fee for this course
                        </p>

                    </div>


                    <button
                        type="button"
                        className="btn btn-outline-secondary add-btn"
                        onClick={props.toggle}
                    >

                        <i className="bx bx-arrow-back me-2"></i>

                        Back to List

                    </button>

                </div>


                {/* ================================================= */}
                {/* FORM CARD */}
                {/* ================================================= */}

                <div className="card coursefee-card add-coursefee-card">

                    <div className="card-body">

                        {/* ERROR POPUP */}
                        {error && (
                            <Validationpopup
                                message={error}
                                toggle={() => setError("")}
                            />
                        )}

                        <form
                            onSubmit={handleSubmit}
                            noValidate
                            className={
                                validated ? "was-validated" : ""
                            }
                        >

                            {/* Hidden Course Fee ID */}
                            <input
                                type="hidden"
                                name="CourseFee_id"
                                defaultValue={data.CourseFee_id}
                            />

                            {/* Hidden Status — kept as-is so editing never changes it */}
                            <input
                                type="hidden"
                                name="Status"
                                defaultValue={data.Status || "Active"}
                            />


                            {/* SELECT COURSE + COURSE FEES */}
                            <div className="row">

                                <div className="col-md-6 mb-3">

                                    <label
                                        htmlFor="Course_id"
                                        className="form-label"
                                    >
                                        Select Course
                                    </label>

                                    <select
                                        id="Course_id"
                                        name="Course_id"
                                        className="form-select"
                                        defaultValue={data.Course_id}
                                        required
                                    >

                                        <option value="" disabled>
                                            Select Course
                                        </option>

                                        {courses.map((course) => (

                                            <option
                                                key={course.Course_id}
                                                value={course.Course_id}
                                            >
                                                {course.Course_name}
                                            </option>

                                        ))}

                                    </select>

                                    <div className="invalid-feedback">
                                        Please select a course.
                                    </div>

                                </div>


                                <div className="col-md-6 mb-3">

                                    <label
                                        htmlFor="Course_Fees"
                                        className="form-label"
                                    >
                                        Course Fees
                                    </label>

                                    <input
                                        type="number"
                                        name="Course_Fees"
                                        id="Course_Fees"
                                        className="form-control"
                                        defaultValue={data.Course_Fees}
                                        placeholder="e.g. 25000"
                                        min="0"
                                        step="0.01"
                                        required
                                    />

                                    <div className="invalid-feedback">
                                        Please enter a valid fee amount.
                                    </div>

                                </div>

                            </div>


                            {/* FOOTER BUTTONS */}
                            <div className="d-flex justify-content-end gap-2 mt-4">

                                <button
                                    type="button"
                                    className="btn btn-outline-secondary"
                                    onClick={props.toggle}
                                    disabled={loading}
                                >
                                    Cancel
                                </button>

                                <button
                                    type="submit"
                                    className="btn btn-success"
                                    disabled={loading}
                                >

                                    {loading ? (
                                        <>
                                            <span
                                                className="spinner-border spinner-border-sm me-2"
                                                role="status"
                                                aria-hidden="true"
                                            ></span>

                                            Updating...
                                        </>
                                    ) : (
                                        "Update Course Fee"
                                    )}

                                </button>

                            </div>

                        </form>

                    </div>

                </div>

            </div>

        </div>

    );
};

export default Updatecoursefee;
