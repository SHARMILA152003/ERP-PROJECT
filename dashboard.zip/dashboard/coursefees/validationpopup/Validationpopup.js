import React from "react";

// Popup message (same look as the Delete popup) used to show
// validation / error messages.
const Validationpopup = (props) => {

    return (

        <div
            className="modal fade show"
            tabIndex="-1"
            role="dialog"
            style={{
                display: "block",
                backgroundColor: "rgba(0,0,0,0.5)"
            }}
        >

            <div
                className="modal-dialog modal-dialog-centered"
                role="document"
            >

                <div className="modal-content">

                    {/* HEADER */}
                    <div className="modal-header">

                        <h5 className="modal-title">
                            Warning Message
                        </h5>

                        <button
                            type="button"
                            className="btn-close"
                            onClick={props.toggle}
                            aria-label="Close"
                        ></button>

                    </div>


                    {/* BODY */}
                    <div className="modal-body text-center">

                        <div className="mb-3">

                            <div
                                className="text-danger mb-3"
                                style={{ fontSize: "40px" }}
                            >
                                ⚠
                            </div>

                            <h5>
                                {props.message}
                            </h5>

                        </div>

                    </div>


                    {/* FOOTER */}
                    <div className="modal-footer justify-content-center">

                        <button
                            type="button"
                            onClick={props.toggle}
                            className="btn btn-danger"
                        >
                            OK
                        </button>

                    </div>

                </div>

            </div>

        </div>
    );
};

export default Validationpopup;
