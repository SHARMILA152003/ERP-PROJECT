import React, { useContext, useState } from "react";
import AuthContext from "../../../services/AuthContext";
import Validationpopup from "../validationpopup/Validationpopup";
// import "./addcoursefee.css";

const Addcoursefee = (props) => {

    const { insert } = useContext(AuthContext);

    const [validated, setValidated] = useState(false);
    const [error, setError] = useState("");
    const [success, setSuccess] = useState("");
    const [loading, setLoading] = useState(false);

    const courseFees = props.courseFees || [];

    // A fee with no saved status counts as Active (same rule as the list page)
    const isFeeActive = (fee) =>
        !fee.Status || fee.Status === "Active";

    // Courses that already have an ACTIVE fee are not offered again.
    // Courses with no fee yet, or whose fee is Deactive, are shown.
    const coursesWithActiveFee = new Set(
        courseFees
            .filter(isFeeActive)
            .map((fee) => Number(fee.Course_id))
    );

    const courses = (props.courses || []).filter(
        (course) => !coursesWithActiveFee.has(Number(course.Course_id))
    );


    const handleSubmit = async (e) => {

        e.preventDefault();

        const form = e.currentTarget;

        setError("");
        setSuccess("");


        // =========================
        // FORM VALIDATION
        // =========================

        if (!form.checkValidity()) {

            e.stopPropagation();

            setValidated(true);

            return;
        }


        // =========================
        // GET FORM DATA
        // =========================

        const courseId =
            form.Course_id.value;

        // NOTE: named feeAmount so it does not shadow the courseFees
        // array (props) used for the Active-fee check below.
        const feeAmount =
            form.Course_Fees.value;

        // Status is not on the form; new fees start as Active
        const status = "Active";


        // =========================
        // VALIDATION: one Active fee per course
        // New fees start as Active, so block if this course
        // already has an Active fee.
        // =========================

        const alreadyActive = courseFees.some(
            (f) =>
                Number(f.Course_id) === parseInt(courseId, 10) &&
                (!f.Status || f.Status === "Active")
        );

        if (alreadyActive) {

            setError(
                "This course already has an Active fee. " +
                "Deactivate the existing fee first, then add a new one."
            );

            return;
        }


        // =========================
        // COURSE FEE DATA
        // =========================

        const courseFeeData = {

            Course_id: parseInt(courseId, 10),

            Course_Fees: parseFloat(feeAmount),

            Status: status,

        };


        console.log(
            "Sending Course Fee:",
            courseFeeData
        );


        try {

            setLoading(true);


            // =========================
            // INSERT
            // =========================

            const response = await insert(
                courseFeeData,
                "coursefee_create"
            );


            console.log(
                "Course Fee created:",
                response
            );


            // =========================
            // SUCCESS
            // =========================

            setSuccess(
    "Course fee plan created successfully!"
);


// Clear form
form.reset();

setValidated(false);


// Refresh parent list
if (props.onSuccess) {

    await props.onSuccess();

}


        } catch (error) {

            console.error(
                "Course fee creation error:",
                error
            );


            // =========================
            // DJANGO ERROR
            // =========================

            const responseData =
                error.responseData;


            console.log(
                "Django Error:",
                responseData
            );


            // Detail error
            if (
                responseData &&
                responseData.detail
            ) {

                setError(
                    responseData.detail
                );

            }

            // Other server error
            else {

                setError(
                    "Course fee plan could not be created. Please try again."
                );
            }

        } finally {

            setLoading(false);

        }

    };


return (

    <div className="coursefee-page centered-form-page container-xxl flex-grow-1 container-p-y">

        <div className="centered-form-wrap">


            {/* ================================================= */}
            {/* HEADER */}
            {/* ================================================= */}

            <div className="page-header">

                <div>

                    <h3 className="page-title">
                        Add Course Fee
                    </h3>

                    <p className="page-subtitle">
                        Create a new fee for a course
                    </p>

                </div>


                <button
                    type="button"
                    className="btn btn-outline-secondary add-btn"
                    onClick={props.toggle}
                >

                    <i className="bx bx-arrow-back me-2"></i>

                    Back to List

                </button>

            </div>


            {/* ================================================= */}
            {/* FORM CARD */}
            {/* ================================================= */}

            <div className="card coursefee-card add-coursefee-card">

                <div className="card-body">

                    {/* SUCCESS */}
                    {success && (
                        <div
                            className="alert alert-success"
                            role="alert"
                        >
                            <strong>Success!</strong>{" "}
                            {success}
                        </div>
                    )}

                    {/* ERROR POPUP */}
                    {error && (
                        <Validationpopup
                            message={error}
                            toggle={() => setError("")}
                        />
                    )}

                    <form
                        onSubmit={handleSubmit}
                        noValidate
                        className={
                            validated ? "was-validated" : ""
                        }
                    >

                        {/* SELECT COURSE + COURSE FEES — one row, two columns */}
                        <div className="row">

                            <div className="col-md-6 mb-3">

                                <label
                                    htmlFor="Course_id"
                                    className="form-label"
                                >
                                    Select Course
                                </label>

                                <select
                                    id="Course_id"
                                    name="Course_id"
                                    className="form-select"
                                    required
                                    defaultValue=""
                                >

                                    <option value="" disabled>
                                        {courses.length > 0
                                            ? "Select Course"
                                            : "No course available"}
                                    </option>

                                    {courses.map((course) => (

                                        <option
                                            key={course.Course_id}
                                            value={course.Course_id}
                                        >
                                            {course.Course_name}
                                        </option>

                                    ))}

                                </select>

                                <div className="invalid-feedback">
                                    Please select a course.
                                </div>

                                {courses.length === 0 && (
                                    <div className="form-text text-muted">
                                        Every course already has an active fee.
                                        Deactive a course fee to add a new one.
                                    </div>
                                )}

                            </div>


                            <div className="col-md-6 mb-3">

                                <label
                                    htmlFor="Course_Fees"
                                    className="form-label"
                                >
                                    Course Fees
                                </label>

                                <input
                                    type="number"
                                    name="Course_Fees"
                                    id="Course_Fees"
                                    className="form-control"
                                    placeholder="e.g. 25000"
                                    required
                                    min="0"
                                    step="0.01"
                                />

                                <div className="invalid-feedback">
                                    Please enter a valid fee amount.
                                </div>

                            </div>

                        </div>


                        {/* FOOTER BUTTONS */}
                        <div className="d-flex justify-content-end gap-2 mt-4">

                            <button
                                type="button"
                                className="btn btn-outline-secondary"
                                onClick={props.toggle}
                                disabled={loading}
                            >
                                Cancel
                            </button>

                            <button
                                type="submit"
                                className="btn btn-primary"
                                disabled={loading}
                            >

                                {loading ? (
                                    <>
                                        <span
                                            className="spinner-border spinner-border-sm me-2"
                                            role="status"
                                            aria-hidden="true"
                                        ></span>

                                        Saving...
                                    </>
                                ) : (
                                    "Save"
                                )}

                            </button>

                        </div>

                    </form>

                </div>

            </div>

        </div>

    </div>

);
};


export default Addcoursefee;
