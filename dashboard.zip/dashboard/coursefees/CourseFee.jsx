import React, {
    useState,
    useContext,
    useEffect,
    useCallback
} from "react";

import "./CourseFee.css";

import Addcoursefee from "./addcoursefee/Addcoursefee";
import Updatecoursefee from "./updatecoursefee/Updatecoursefee";
import Deletecoursefee from "./deletecoursefee/Deletecoursefee";
import Validationpopup from "./validationpopup/Validationpopup";

import AuthContext from "../../services/AuthContext";


function CourseFee() {

    const [addPopupVisible, setAddPopupVisible] = useState(false);
    const [updatePopupVisible, setUpdatePopupVisible] = useState(false);
    const [deletePopupVisible, setDeletePopupVisible] = useState(false);

    const [currentPage, setCurrentPage] = useState(1);

    // Search box text (matches course names that START with it)
    const [searchTerm, setSearchTerm] = useState("");

    const { getData, update } = useContext(AuthContext);

    const [courseFees, setCourseFees] = useState([]);

    const [courses, setCourses] = useState([]);

    const [value, setValue] = useState(null);

    const [statusError, setStatusError] = useState("");


    // =====================================================
    // FETCH COURSE FEES
    // =====================================================

    const fetchCourseFees = useCallback(async () => {

        try {

            const data = await getData(
                "fetch_coursefee_datail"
            );

            console.log(
                "Course Fees fetched:",
                data
            );

            if (Array.isArray(data)) {

                setCourseFees(data);

            } else {

                setCourseFees([]);

            }

        } catch (err) {

            console.error(
                "Failed to fetch course fees:",
                err
            );

        }

    }, [getData]);


    // =====================================================
    // FETCH COURSES (for dropdown + name lookup)
    // =====================================================

    const fetchCourses = useCallback(async () => {

        try {

            const data = await getData(
                "fetch_course_datail"
            );

            if (Array.isArray(data)) {

                setCourses(data);

            } else {

                setCourses([]);

            }

        } catch (err) {

            console.error(
                "Failed to fetch courses:",
                err
            );

        }

    }, [getData]);


    // =====================================================
    // INITIAL LOAD
    // =====================================================

    useEffect(() => {

        fetchCourseFees();

        fetchCourses();

    }, [fetchCourseFees, fetchCourses]);


    // =====================================================
    // ADD PAGE (open / back to list)
    // =====================================================

    const toggleAddPopup = () => {

        setAddPopupVisible(
            !addPopupVisible
        );

    };


    // =====================================================
    // UPDATE POPUP
    // =====================================================

    const toggleUpdatePopup = () => {

        setUpdatePopupVisible(
            !updatePopupVisible
        );

    };


    // =====================================================
    // DELETE POPUP
    // =====================================================

    const toggleDeletePopup = () => {

        setDeletePopupVisible(
            !deletePopupVisible
        );

    };


    // =====================================================
    // AFTER COURSE FEE CREATED
    // =====================================================

    const handleCourseFeeCreated = async () => {

        console.log(
            "New course fee created. Refreshing list..."
        );

        // Fetch latest data from Django
        await fetchCourseFees();

        // Back to the list
        setAddPopupVisible(false);

        // Go back to first page
        setCurrentPage(1);

    };


    // =====================================================
    // AFTER COURSE FEE UPDATED
    // =====================================================

    const handleCourseFeeUpdated = async () => {

        console.log(
            "Course fee updated. Refreshing list..."
        );

        await fetchCourseFees();

        // Back to the list
        setUpdatePopupVisible(false);

    };


    // =====================================================
    // PAGINATION
    // =====================================================

    const itemsPerPage = 4;

    const indexOfLastItem =
        currentPage * itemsPerPage;

    const indexOfFirstItem =
        indexOfLastItem - itemsPerPage;

    // Search by course: only names that START WITH the typed letters
    // match (case-insensitive) — not letters found in the middle.
    const searchText = searchTerm.trim().toLowerCase();

    const filteredCourseFees = courseFees.filter((fee) => {

        if (searchText === "") return true;

        const match = courses.find(
            (c) => c.Course_id === fee.Course_id
        );

        const courseName = String(
            match ? match.Course_name : fee.Course_id
        ).toLowerCase();

        return courseName.startsWith(searchText);
    });

    const currentCourseFees =
        filteredCourseFees.slice(
            indexOfFirstItem,
            indexOfLastItem
        );


    const nextPage = () => {

        if (
            indexOfLastItem <
            filteredCourseFees.length
        ) {

            setCurrentPage(
                currentPage + 1
            );

        }

    };


    const prevPage = () => {

        if (currentPage > 1) {

            setCurrentPage(
                currentPage - 1
            );

        }

    };


    // =====================================================
    // UPDATE
    // =====================================================

    const handleUpdate = (courseFee) => {

        setValue(courseFee);

        toggleUpdatePopup();

    };


    // =====================================================
    // DELETE
    // =====================================================

    const handleDelete = (id) => {

        setValue(id);

        toggleDeletePopup();

    };


    // =====================================================
    // STATUS BUTTON (Active / Deactive — click to switch)
    // The saved value stays "Active" / "Inactive" (same as the
    // Add / Edit forms); the button just shows "Deactive".
    // A plan with no saved status counts as Active.
    // =====================================================

    const isFeeActive = (courseFee) =>
        !courseFee.Status || courseFee.Status === "Active";

    const handleToggleStatus = async (courseFee) => {

        setStatusError("");

        const newStatus = isFeeActive(courseFee) ? "Inactive" : "Active";

        // VALIDATION: only one Active fee is allowed per course.
        // Deactivating is always fine; activating is blocked if another
        // fee of the same course is already Active.
        if (newStatus === "Active") {

            const alreadyActive = courseFees.some(
                (f) =>
                    f.CourseFee_id !== courseFee.CourseFee_id &&
                    Number(f.Course_id) === Number(courseFee.Course_id) &&
                    isFeeActive(f)
            );

            if (alreadyActive) {

                setStatusError(
                    `"${getCourseName(courseFee)}" already has an Active fee. ` +
                    `Deactivate it first before activating another.`
                );

                return;
            }
        }

        const payload = {
            CourseFee_id: courseFee.CourseFee_id,
            Course_id: courseFee.Course_id,
            Course_Fees: courseFee.Course_Fees,
            Status: newStatus,
        };

        try {

            await update(
                payload,
                "update_coursefee_datail",
                "/coursefees"
            );

            await fetchCourseFees();

        } catch (err) {

            console.error(
                "Failed to toggle status:",
                err
            );

        }

    };


    // =====================================================
    // HELPER: RESOLVE COURSE NAME
    // =====================================================

    const getCourseName = (courseFee) => {

        const match = courses.find(
            (c) => c.Course_id === courseFee.Course_id
        );

        return match
            ? match.Course_name
            : courseFee.Course_id;

    };


    // =====================================================
    // ADD PAGE VIEW
    // =====================================================
    // Swap the whole list out for the Addcoursefee page —
    // rendered directly in the page, no modal/backdrop.

    if (addPopupVisible) {

        return (

            <Addcoursefee
                toggle={toggleAddPopup}
                onSuccess={handleCourseFeeCreated}
                courses={courses}
                courseFees={courseFees}
            />

        );

    }


    // =====================================================
    // UPDATE PAGE VIEW
    // =====================================================
    // Edit opens the Updatecoursefee page directly —
    // same as Add, no modal/backdrop.

    if (updatePopupVisible) {

        return (

            <Updatecoursefee
                toggle={toggleUpdatePopup}
                onSuccess={handleCourseFeeUpdated}
                data={value}
                courses={courses}
                courseFees={courseFees}
            />

        );

    }


    return (

        <div className="coursefee-page container-xxl flex-grow-1 container-p-y">


            {/* ================================================= */}
            {/* HEADER */}
            {/* ================================================= */}

            <div className="page-header">

                <div>

                    <h3 className="page-title">
                        Course Fee Management
                    </h3>

                    <p className="page-subtitle">
                        Manage fees for each course
                    </p>

                </div>


                <button
                    className="btn btn-primary add-btn"
                    onClick={toggleAddPopup}
                >

                    <i className="bx bx-plus me-2"></i>

                    Add Course Fee

                </button>

            </div>


            {/* ================================================= */}
            {/* COURSE FEE TABLE */}
            {/* ================================================= */}

            {statusError && (
                <Validationpopup
                    message={statusError}
                    toggle={() => setStatusError("")}
                />
            )}

            <div className="card coursefee-card">

                {/* SEARCH BOX */}
                <div className="coursefee-search">

                    <i className="bx bx-search coursefee-search-icon"></i>

                    <input
                        type="text"
                        className="form-control coursefee-search-input"
                        placeholder="Search by course"
                        value={searchTerm}
                        onChange={(e) => {
                            setSearchTerm(e.target.value);
                            setCurrentPage(1);
                        }}
                    />

                </div>

                <div className="table-responsive">

                    <table className="table modern-table">

                        <thead>

                            <tr>

                                <th>ID</th>

                                <th>
                                    Course
                                </th>

                                <th>
                                    Course Fees
                                </th>

                                <th>
                                    Status
                                </th>

                                <th width="180">
                                    Action
                                </th>

                            </tr>

                        </thead>


                        <tbody>

                            {currentCourseFees.length > 0 ? (

                                currentCourseFees.map(
                                    (courseFee) => (

                                        <tr
                                            key={
                                                courseFee.CourseFee_id
                                            }
                                        >

                                            <td>
                                                #{courseFee.CourseFee_id}
                                            </td>


                                            <td>

                                                <strong>
                                                    {
                                                        getCourseName(courseFee)
                                                    }
                                                </strong>

                                            </td>


                                            <td>

                                                {
                                                    courseFee.Course_Fees
                                                }

                                            </td>


                                            <td>

                                                <button
                                                    type="button"
                                                    className={
                                                        isFeeActive(courseFee)
                                                            ? "coursefee-status-switch active"
                                                            : "coursefee-status-switch inactive"
                                                    }
                                                    onClick={() =>
                                                        handleToggleStatus(courseFee)
                                                    }
                                                    title="Click to switch status"
                                                >

                                                    {
                                                        isFeeActive(courseFee)
                                                            ? "Active"
                                                            : "Deactive"
                                                    }

                                                </button>

                                            </td>


                                            <td>

                                                <div className="action-buttons">

                                                    {/* <button
                                                        className="btn btn-edit"
                                                        onClick={() =>
                                                            handleUpdate(
                                                                courseFee
                                                            )
                                                        }
                                                    >
                                                        Edit
                                                    </button> */}


                                                    <button
                                                        className="btn btn-delete"
                                                        onClick={() =>
                                                            handleDelete(
                                                                courseFee.CourseFee_id
                                                            )
                                                        }
                                                    >
                                                        Delete
                                                    </button>

                                                </div>

                                            </td>

                                        </tr>

                                    )
                                )

                            ) : (

                                <tr>

                                    <td
                                        colSpan="5"
                                        className="text-center py-4"
                                    >

                                        {searchText !== ""
                                            ? "No course found for your search."
                                            : "No course fee plans found."}

                                    </td>

                                </tr>

                            )}

                        </tbody>

                    </table>

                </div>


                {/* ================================================= */}
                {/* DELETE */}
                {/* ================================================= */}

                {deletePopupVisible && (

                    <Deletecoursefee
                        toggle={toggleDeletePopup}
                        data={value}
                    />

                )}


                {/* ================================================= */}
                {/* PAGINATION */}
                {/* ================================================= */}

                <div className="card-footer bg-white border-0">

                    <div className="d-flex justify-content-end">

                        <button
                            className="btn btn-light me-2"
                            onClick={prevPage}
                            disabled={
                                currentPage === 1
                            }
                        >

                            <i className="bx bx-chevron-left"></i>

                            Previous

                        </button>


                        <button
                            className="btn btn-primary"
                            onClick={nextPage}
                            disabled={
                                indexOfLastItem >=
                                filteredCourseFees.length
                            }
                        >

                            Next

                            <i className="bx bx-chevron-right ms-1"></i>

                        </button>

                    </div>

                </div>

            </div>

        </div>

    );

}


export default CourseFee;
