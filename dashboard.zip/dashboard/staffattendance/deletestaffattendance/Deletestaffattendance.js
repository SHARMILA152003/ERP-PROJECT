import React, { useContext, useState } from "react";
import AuthContext from "../../../services/AuthContext";
import "../addstaffattendance/addstaffattendance.css";

const Deletestaffattendance = (props) => {

    const { Delete } = useContext(AuthContext);

    const [error, setError] = useState("");
    const [loading, setLoading] = useState(false);

    // props.data is the attendance record; props.staff is its staff (for the name)
    const record = props.data || {};
    const staff = props.staff || {};


    const handleSubmit = async () => {

        setError("");

        try {

            if (!record.Attendance_id) {

                throw new Error(
                    "Missing or invalid data for deletion"
                );

            }

            setLoading(true);

            await Delete(
                { Attendance_id: record.Attendance_id },
                "delete_staffattendance_datail",
                "/staffattendance"
            );

            // Refresh the list and go back to it
            if (props.onSuccess) {

                await props.onSuccess();

            } else {

                props.toggle();

            }

        } catch (error) {

            console.error(
                "Delete operation failed:",
                error
            );

            setError(
                "Attendance could not be deleted. Please try again."
            );

        } finally {

            setLoading(false);

        }
    };


    return (

        <div className="staffattendance-page centered-form-page container-xxl flex-grow-1 container-p-y">

            <div className="centered-form-wrap">


                {/* ================================================= */}
                {/* HEADER */}
                {/* ================================================= */}

                <div className="page-header">

                    <div>

                        <h3 className="page-title">
                            Delete Attendance
                        </h3>

                        <p className="page-subtitle">
                            Please confirm before deleting
                        </p>

                    </div>


                    <button
                        type="button"
                        className="btn btn-outline-secondary add-btn"
                        onClick={props.toggle}
                        disabled={loading}
                    >

                        <i className="bx bx-arrow-back me-2"></i>

                        Back to List

                    </button>

                </div>


                {/* ================================================= */}
                {/* CONFIRM CARD */}
                {/* ================================================= */}

                <div className="card staffattendance-card">

                    <div className="card-body text-center">

                        {/* ERROR */}
                        {error && (
                            <div
                                className="alert alert-danger text-start"
                                role="alert"
                            >
                                <strong>Error!</strong>{" "}
                                {error}
                            </div>
                        )}

                        <div
                            className="text-danger mb-3"
                            style={{ fontSize: "40px" }}
                        >
                            <i className="bx bx-error"></i>
                        </div>

                        <h5>
                            Are you sure you want to delete the attendance
                            {staff.Staff_name
                                ? ` of "${staff.Staff_name}"`
                                : ""}
                            {record.Attendance_date
                                ? ` on ${String(record.Attendance_date).split("T")[0]}`
                                : ""}
                            ?
                        </h5>

                        <p className="text-muted mb-0">
                            This action cannot be undone.
                        </p>


                        <div className="d-flex justify-content-center gap-2 mt-4">

                            <button
                                type="button"
                                className="btn btn-outline-secondary"
                                onClick={props.toggle}
                                disabled={loading}
                            >
                                <i className="bx bx-x me-1"></i>
                                Cancel
                            </button>

                            <button
                                type="button"
                                onClick={handleSubmit}
                                className="btn btn-danger"
                                disabled={loading}
                            >

                                {loading ? (
                                    <>
                                        <span
                                            className="spinner-border spinner-border-sm me-2"
                                            role="status"
                                            aria-hidden="true"
                                        ></span>

                                        Deleting...
                                    </>
                                ) : (
                                    <>
                                        <i className="bx bx-trash me-1"></i>
                                        Delete
                                    </>
                                )}

                            </button>

                        </div>

                    </div>

                </div>

            </div>

        </div>
    );
};

export default Deletestaffattendance;
