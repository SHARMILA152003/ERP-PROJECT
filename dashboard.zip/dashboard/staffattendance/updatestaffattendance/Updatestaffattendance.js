import React, { useContext } from "react";
import AuthContext from "../../../services/AuthContext";
import {
    AttendanceForm,
    buildAttendancePayload,
    toDateKey
} from "../addstaffattendance/Addstaffattendance";

const Updatestaffattendance = (props) => {

    const { update } = useContext(AuthContext);

    // props.data is the attendance record clicked in the grid.
    const initialValues = {
        ...props.data,
        Attendance_date: toDateKey(props.data.Attendance_date)
    };

    // null -> "" so inputs stay controlled
    Object.keys(initialValues).forEach((k) => {

        if (initialValues[k] === null || initialValues[k] === undefined) {

            initialValues[k] = "";

        }

    });

    const handleSave = async (values) => {

        const payload = buildAttendancePayload(values, {
            Attendance_id: props.data.Attendance_id
        });

        await update(
            payload,
            "update_staffattendance_datail",
            "/staffattendance"
        );

        // Refresh the list and go back to it
        if (props.onSuccess) {

            await props.onSuccess();

        } else {

            props.toggle();

        }

    };

    return (

        <AttendanceForm
            title="Edit Attendance"
            submitLabel="Update Attendance"
            failMessage="Attendance could not be updated. Please try again."
            initialValues={initialValues}
            staffList={props.staffList}
            existingAttendance={props.existingAttendance}
            holidays={props.holidays}
            currentId={props.data.Attendance_id}
            onSubmit={handleSave}
            onBack={props.toggle}
            onDelete={props.onDelete}
        />

    );
};

export default Updatestaffattendance;
