import React, {
    useState,
    useContext,
    useEffect,
    useCallback,
    useMemo
} from "react";

import "./StaffAttendance.css";

import Addstaffattendance, {
    staffCode,
    dateKey,
    todayKey,
    toDateKey
} from "./addstaffattendance/Addstaffattendance";
import Updatestaffattendance from "./updatestaffattendance/Updatestaffattendance";
import Deletestaffattendance from "./deletestaffattendance/Deletestaffattendance";

import AuthContext from "../../services/AuthContext";


// =====================================================
// HELPERS
// =====================================================

const MONTHS = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
];

const WEEKDAYS = ["SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT"];

// same names as the Weekly Off Day dropdown in Staff Schedule (index = Date.getDay())
const WEEKDAY_NAMES = [
    "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"
];

const MIN_YEAR = 2000;
const MAX_YEAR = 2100;

const show = (v) =>
    v === null || v === undefined || String(v).trim() === ""
        ? "-"
        : String(v);

// icon + class for each attendance state
const STATE_ICON = {
    Present: { icon: "bx-check-circle", cls: "att-present", title: "Present" },
    Absent: { icon: "bx-x-circle", cls: "att-absent", title: "Absent" },
    Holiday: { icon: "bx-star", cls: "att-holiday-ic", title: "Holiday" },
    Celebration: { icon: "bx-gift", cls: "att-celebration", title: "Celebration" },
    Leave: { icon: "bx-calendar", cls: "att-leave", title: "Leave" },
    "Week Off": { icon: "bx-home", cls: "att-weekoff", title: "Week Off" },
    Permission: { icon: "bx-time", cls: "att-permission", title: "Permission" }
};


// ---- working time (stored in staff_attendance.Attendance_working_minutes) ----

// "HH:MM" -> minutes from midnight (null when empty)
const timeToMinutes = (t) => {
    if (!t) return null;
    const m = /^(\d{1,2}):(\d{2})/.exec(String(t));
    return m ? Number(m[1]) * 60 + Number(m[2]) : null;
};

// "13:05" -> "01:05 PM"
const to12h = (t) => {
    const mins = timeToMinutes(t);
    if (mins === null) return "-";
    const h = Math.floor(mins / 60);
    const mm = String(mins % 60).padStart(2, "0");
    return `${String(h % 12 || 12).padStart(2, "0")}:${mm} ${h >= 12 ? "PM" : "AM"}`;
};

// saved minutes (calculated by the server inside the staff's schedule); null until check out
const getWorkingMinutes = (record) => {
    if (!record) return null;
    const v = record.Attendance_working_minutes;
    return v === null || v === undefined || v === "" ? null : Number(v);
};

// 510 -> "8h 30m"
const formatWorking = (minutes) =>
    minutes === null || minutes === undefined
        ? ""
        : `${Math.floor(minutes / 60)}h ${String(minutes % 60).padStart(2, "0")}m`;


// =====================================================
// SEARCH BOX VALIDATION (same rules as Staff Register)
// =====================================================

const SEARCH_MAX = 50;

// remove leading space + collapse repeated spaces
const tidySpaces = (v) =>
    v.replace(/^\s+/, "").replace(/\s{2,}/g, " ");

// Name: letters, space and ONE "." only
const sanitizeName = (v) => {

    let text = tidySpaces(v.replace(/[^A-Za-z .]/g, ""))
        .replace(/^\.+/, "");

    let dotSeen = false;

    text = text.replace(/\./g, () => {
        if (dotSeen) return "";
        dotSeen = true;
        return ".";
    });

    return text.slice(0, SEARCH_MAX);

};

const startsWith = (value, term) =>
    String(value || "")
        .toLowerCase()
        .startsWith(term.trim().toLowerCase());


// =====================================================
// STAFF CALENDAR POPUP (opened by the View button)
// Sunday -> Saturday grid. Reuses MONTHS, WEEKDAYS, MIN_YEAR
// and MAX_YEAR defined above.
// =====================================================

const STATE_META = {
    Present:     { icon: "bx-check-circle", color: "#22A55B", bg: "#DCFCE7" },
    Absent:      { icon: "bx-x-circle",     color: "#E8456B", bg: "#FFE4E6" },
    Holiday:     { icon: "bx-star",         color: "#F9733B", bg: "#FFEDD5" },
    Celebration: { icon: "bx-gift",         color: "#D946EF", bg: "#FAE8FF" },
    Leave:       { icon: "bx-calendar",     color: "#19B8E6", bg: "#CFFAFE" },
    "Week Off":  { icon: "bx-home",         color: "#8B5CF6", bg: "#EDE9FE" },
    Permission:  { icon: "bx-time",         color: "#F59E0B", bg: "#FEF3C7" }
};

const STATE_ORDER = ["Present", "Absent", "Holiday", "Week Off"];

// =====================================================
// HOLIDAY KINDS - each kind has its own icon + colour.
// The reason is written after a separator: government-new,
// emergency-flood, celebration-fun ...
// =====================================================
const HOLIDAY_KIND = {
    // Government + Emergency come from Holiday events, Celebration from Working events
    government:  { label: "Government",  icon: "bx-flag",  color: "#2563EB", bg: "#DBEAFE", chip: "#1E40AF" },
    emergency:   { label: "Emergency",   icon: "bx-error", color: "#DC2626", bg: "#FEE2E2", chip: "#B91C1C" },
    celebration: { label: "Celebration", icon: "bx-gift",  color: "#D946EF", bg: "#FAE8FF", chip: "#86198F" }
};

const HOLIDAY_KIND_KEYS = Object.keys(HOLIDAY_KIND);

// event row -> { kind, reason }
// kind   = Holiday_category (Government / Emergency / Celebration)
// reason = the event title typed in the calendar ("new", "flood", "fun" ...)
// "government-new" typed in the category is understood too.
const parseHoliday = (e) => {

    const cat = String(e.Holiday_category || "").trim();
    const lower = cat.toLowerCase();

    let kind = HOLIDAY_KIND_KEYS.find((k) => lower.startsWith(k)) || "";

    if (!kind && lower === "celebrity") kind = "celebration";     // old name
    if (!kind && e.Event_type === "Working") kind = "celebration";

    if (!kind) return { kind: "", reason: "" };

    const inline = cat.slice(kind.length).replace(/^\s*[-:_/|]\s*/, "").trim();

    const reason = inline || String(e.Event_title || "").trim();

    return { kind, reason };

};

// "government-new" (kind + separator + reason)
const holidayTag = (kind, reason) =>
    kind ? (reason ? `${kind}-${reason}` : kind) : (reason || "");

const prettyDate = (key) => {
    const [y, m, d] = key.split("-").map(Number);
    return `${d} ${MONTHS[m - 1]} ${y}`;
};


// =====================================================
// STAFF CALENDAR MODAL
//
// props:
//   staff      : staff row
//   month/year : month shown when it opens (0-11)
//   getDay     : (staffId, "yyyy-mm-dd") =>
//                  { state, record, holidayName } | null
//   onClose    : close the popup
//   onPickDay  : (staff, "yyyy-mm-dd", record|null) -> opens the
//                existing Add / Edit attendance page
// =====================================================

function StaffCalendarModal({
    staff,
    month: initialMonth,
    year: initialYear,
    getDay,
    onClose,
    onPickDay,
    showTimeTip,
    hideTimeTip
}) {

    const [month, setMonth] = useState(initialMonth);
    const [year, setYear] = useState(initialYear);
    const [selected, setSelected] = useState(null);

    const today = todayKey();

    // close with Esc
    useEffect(() => {

        const onKey = (e) => {
            if (e.key === "Escape") onClose();
        };

        window.addEventListener("keydown", onKey);

        return () => window.removeEventListener("keydown", onKey);

    }, [onClose]);


    // ---------------- month navigation ----------------
    const goMonth = (step) => {

        let m = month + step;
        let y = year;

        if (m < 0) { m = 11; y -= 1; }
        if (m > 11) { m = 0; y += 1; }

        if (y < MIN_YEAR || y > MAX_YEAR) return;

        setMonth(m);
        setYear(y);
        setSelected(null);

    };


    // ---------------- cells: blanks first, then every day ----------------
    const cells = useMemo(() => {

        const offset = new Date(year, month, 1).getDay();      // 0 = Sunday
        const total = new Date(year, month + 1, 0).getDate();

        const list = [];

        for (let i = 0; i < offset; i++) list.push(null);

        for (let d = 1; d <= total; d++) {

            const key = dateKey(year, month, d);

            list.push({
                day: d,
                key,
                isSunday: new Date(year, month, d).getDay() === 0,
                info: getDay(staff.Staff_id, key)
            });

        }

        return list;

    }, [year, month, staff, getDay]);


    // ---------------- summary ----------------
    const counts = useMemo(() => {

        const c = {};

        STATE_ORDER.forEach((k) => { c[k] = 0; });
        c.Leave = 0;   // old Leave records still count, but Leave is not shown any more
        c.Permission = 0;   // same for old Permission records

        cells.forEach((cell) => {
            if (cell && cell.info && c[cell.info.state] !== undefined) {
                c[cell.info.state] += 1;
            }
        });

        return c;

    }, [cells]);

    const worked = counts.Present + counts.Absent + counts.Leave + counts.Permission;

    const percent = worked ? Math.round((counts.Present / worked) * 100) : 0;

    const selectedCell = cells.find((c) => c && c.key === selected);

    const selectedInfo = selectedCell ? selectedCell.info : null;

    // can the selected day be edited / added from here?
    const canAct =
        selectedCell &&
        !(selectedInfo && selectedInfo.state === "Holiday") &&
        ((selectedInfo && selectedInfo.record) || selectedCell.key <= today);


    return (

        <div className="att-cal-overlay" onClick={onClose}>

            <div
                className="att-cal-modal"
                role="dialog"
                aria-modal="true"
                aria-label={`${staff.Staff_name} attendance calendar`}
                onClick={(e) => e.stopPropagation()}
            >

                {/* ---------- HEADER ---------- */}
                <div className="att-cal-head">

                    {staff.Staff_photo ? (
                        <img className="staff-avatar" src={staff.Staff_photo} alt={staff.Staff_name} />
                    ) : (
                        <span className="staff-avatar">
                            {String(staff.Staff_name || "?").charAt(0).toUpperCase()}
                        </span>
                    )}

                    <div className="att-cal-who">
                        <strong>{staff.Staff_name}</strong>
                        <span>
                            {staffCode(staff)}
                            {staff.Staff_gender ? ` · ${staff.Staff_gender}` : ""}
                            {staff.Staff_age ? ` · ${staff.Staff_age} yrs` : ""}
                        </span>
                    </div>

                    <button
                        type="button"
                        className="att-cal-close"
                        onClick={onClose}
                        aria-label="Close"
                    >
                        <i className="bx bx-x"></i>
                    </button>

                </div>


                {/* ---------- MONTH NAV + ATTENDANCE % ---------- */}
                <div className="att-cal-nav">

                    <span></span>

                    <div className="att-cal-month">

                        <button type="button" className="att-step-btn" onClick={() => goMonth(-1)} aria-label="Previous month">
                            <i className="bx bx-chevron-left"></i>
                        </button>

                        <span>{MONTHS[month]} {year}</span>

                        <button type="button" className="att-step-btn" onClick={() => goMonth(1)} aria-label="Next month">
                            <i className="bx bx-chevron-right"></i>
                        </button>

                    </div>

                    <span className="att-cal-percent">
                        Attendance {percent}%
                    </span>

                </div>


                {/* ---------- STATUS CHIPS (one row) ---------- */}
                <div className="att-cal-chips">

                    {STATE_ORDER.map((k) => (
                        <span
                            key={k}
                            className="att-cal-chip"
                            style={{ background: STATE_META[k].bg, color: STATE_META[k].color }}
                        >
                            <i className={`bx ${STATE_META[k].icon}`}></i>
                            {k} {counts[k]}
                        </span>
                    ))}

                </div>


                {/* ---------- CALENDAR GRID (Sunday -> Saturday) ---------- */}
                <div className="att-cal-grid">

                    {WEEKDAYS.map((w, i) => (
                        <div key={w} className={"att-cal-dow" + (i === 0 ? " is-sunday" : "")}>
                            {w}
                        </div>
                    ))}

                    {cells.map((cell, i) => {

                        if (!cell) {
                            return <div key={`blank-${i}`} className="att-cal-cell is-blank"></div>;
                        }

                        const baseMeta = cell.info ? STATE_META[cell.info.state] : null;
                        const cellKind = cell.info && cell.info.state === "Holiday"
                            ? HOLIDAY_KIND[cell.info.holidayKind]
                            : null;
                        const meta = cellKind ? { ...baseMeta, ...cellKind } : baseMeta;

                        return (

                            <button
                                type="button"
                                key={cell.key}
                                className={
                                    "att-cal-cell" +
                                    (cell.isSunday ? " is-sunday" : "") +
                                    (cell.key === today ? " is-today" : "") +
                                    (cell.key === selected ? " is-selected" : "")
                                }
                                style={meta ? { background: meta.bg } : undefined}
                                title={
                                    cell.info
                                        ? (holidayTag(cell.info.holidayKind, cell.info.holidayReason) || cell.info.state)
                                        : "No record"
                                }
                                onClick={() => setSelected(cell.key)}
                            >

                                <span className="att-cal-day">{cell.day}</span>

                                {meta && (
                                    <span className="att-cal-foot">

                                        {cell.info && cell.info.state === "Present" && cell.info.record && cell.info.record.Attendance_in_time ? (
                                            <span
                                                className={"att-cal-worktime" + (getWorkingMinutes(cell.info.record) === null ? " is-open" : "")}
                                                onMouseEnter={(e) => showTimeTip(e, cell.info.record, cell.key)}
                                                onMouseLeave={hideTimeTip}
                                            >
                                                {getWorkingMinutes(cell.info.record) !== null
                                                    ? formatWorking(getWorkingMinutes(cell.info.record))
                                                    : "in"}
                                            </span>
                                        ) : <span></span>}

                                        <i className={`bx ${meta.icon}`} style={{ color: meta.color }}></i>

                                    </span>
                                )}

                            </button>

                        );

                    })}

                </div>


                {/* ---------- SELECTED DAY ---------- */}
                <div className="att-cal-detail">

                    {!selectedCell && (
                        <span>Select a date to see its status and remarks.</span>
                    )}

                    {selectedCell && (

                        <>
                            <div className="att-cal-detail-text">

                                <strong>{prettyDate(selectedCell.key)}</strong>

                                <span>
                                    {selectedInfo && STATE_META[selectedInfo.state] && (
                                        <i
                                            className={`bx ${(HOLIDAY_KIND[selectedInfo.holidayKind] || STATE_META[selectedInfo.state]).icon}`}
                                            style={{
                                                color: (HOLIDAY_KIND[selectedInfo.holidayKind] || STATE_META[selectedInfo.state]).color,
                                                fontSize: "16px",
                                                marginRight: "6px",
                                                verticalAlign: "middle"
                                            }}
                                        ></i>
                                    )}

                                    {selectedInfo ? selectedInfo.state : "No record"}

                                    {selectedInfo && selectedInfo.holidayKind
                                        ? ` · ${holidayTag(selectedInfo.holidayKind, selectedInfo.holidayReason)}`
                                        : ""}

                                    {selectedInfo && selectedInfo.holidayName && !selectedInfo.holidayKind
                                        ? ` · Remark: ${selectedInfo.holidayName}`
                                        : ""}

                                    {selectedInfo && selectedInfo.leaveType
                                        ? ` · Leave (${selectedInfo.leaveType}) was applied on this day`
                                        : ""}

                                    {selectedInfo && selectedInfo.record && selectedInfo.record.Attendance_leave_type
                                        ? ` · ${selectedInfo.record.Attendance_leave_type}`
                                        : ""}

                                    {selectedInfo && selectedInfo.record && selectedInfo.record.Attendance_in_time
                                        ? ` · ${selectedInfo.record.Attendance_in_time}${selectedInfo.record.Attendance_out_time ? ` to ${selectedInfo.record.Attendance_out_time}` : ""}`
                                        : ""}

                                    {selectedInfo && selectedInfo.record && getWorkingMinutes(selectedInfo.record) !== null
                                        ? ` · Working ${formatWorking(getWorkingMinutes(selectedInfo.record))}`
                                        : ""}

                                    {selectedInfo && selectedInfo.record && selectedInfo.record.Attendance_day_type
                                        ? ` · ${selectedInfo.record.Attendance_day_type}${
                                            selectedInfo.record.Attendance_pay_days !== null &&
                                            selectedInfo.record.Attendance_pay_days !== undefined
                                                ? ` (pay ${Number(selectedInfo.record.Attendance_pay_days).toFixed(2)} day)`
                                                : ""
                                        }`
                                        : ""}

                                    {selectedInfo && selectedInfo.record && selectedInfo.record.Attendance_remarks
                                        ? ` · ${selectedInfo.record.Attendance_remarks}`
                                        : ""}
                                </span>

                            </div>

                            {canAct && (
                                <button
                                    type="button"
                                    className="att-cal-action"
                                    onClick={() =>
                                        onPickDay(
                                            staff,
                                            selectedCell.key,
                                            selectedInfo ? selectedInfo.record : null
                                        )
                                    }
                                >
                                    <i className={selectedInfo && selectedInfo.record ? "bx bx-edit-alt" : "bx bx-plus"}></i>
                                    {selectedInfo && selectedInfo.record ? "Edit" : "Add"}
                                </button>
                            )}
                        </>

                    )}

                </div>

            </div>

        </div>

    );

}


function StaffAttendance() {

    const now = new Date();

    // ---------------- page switching (same pattern as Staff Register) ----------------
    const [addPageVisible, setAddPageVisible] = useState(false);
    const [updatePageVisible, setUpdatePageVisible] = useState(false);
    const [deletePageVisible, setDeletePageVisible] = useState(false);

    const [value, setValue] = useState(null);       // record being edited / deleted
    const [calendarStaff, setCalendarStaff] = useState(null);   // staff whose calendar popup is open
    const [prefill, setPrefill] = useState(null);   // staff + date clicked in the grid
    const [timeTip, setTimeTip] = useState(null);   // hover tooltip: { x, y, record, date }

    // ---------------- filters ----------------
    const [month, setMonth] = useState(now.getMonth());
    const [year, setYear] = useState(now.getFullYear());

    // which half of the month the grid shows: 0 = days 1-15, 1 = day 16 to month end
    const [half, setHalf] = useState(now.getDate() > 15 ? 1 : 0);

    const [search, setSearch] = useState({ name: "" });

    const [currentPage, setCurrentPage] = useState(1);

    // ---------------- data ----------------
    const { getData } = useContext(AuthContext);

    const [staffList, setStaffList] = useState([]);
    const [attendanceList, setAttendanceList] = useState([]);
    const [calendarEvents, setCalendarEvents] = useState([]);
    const [scheduleList, setScheduleList] = useState([]);   // Staff Schedule (weekly off day)


    // =====================================================
    // FETCH
    // =====================================================

    const asArray = (d) => (Array.isArray(d) ? d : []);

    const fetchAll = useCallback(async () => {

        try {

            // holidays now come only from the Calendar module
            // (the old staff_holiday table / fetch_staffholiday_datail is no longer used)
            const [staff, attendance, calendar, schedules] = await Promise.all([
                getData("fetch_staffregister_datail"),
                getData("fetch_staffattendance_datail"),
                getData("fetch_calendar_datail").catch(() => []),
                getData("fetch_staffschedule_datail").catch(() => [])
            ]);

            console.log("Attendance data fetched:", { staff, attendance, calendar, schedules });

            setScheduleList(asArray(schedules));

            setStaffList(asArray(staff));
            setAttendanceList(asArray(attendance));
            setCalendarEvents(asArray(calendar));

        } catch (err) {

            console.error("Failed to fetch attendance data:", err);

        }

    }, [getData]);

    useEffect(() => {

        fetchAll();

    }, [fetchAll]);


    // =====================================================
    // LOOKUPS (built once per data change)
    // =====================================================

    // "staffId|yyyy-mm-dd" -> attendance record
    const attendanceMap = useMemo(() => {

        const map = {};

        attendanceList.forEach((a) => {
            map[`${a.Staff_id}|${toDateKey(a.Attendance_date)}`] = a;
        });

        return map;

    }, [attendanceList]);

    // Holiday Calendar entries (Event_type = "Holiday") turned into one row per
    // day (a Start date -> End date range covers every day in between), then
    // joined with the old staff-holiday rows. Same shape the rest of the page
    // already uses: { Holiday_date, Holiday_name, ... }
    const holidays = useMemo(() => {

        const list = [];
        const seen = new Set();

        const add = (date, name, extra = {}) => {

            if (!date || seen.has(date)) return;

            seen.add(date);

            list.push({ Holiday_date: date, Holiday_name: name, ...extra });

        };

        calendarEvents
            .filter((e) => e.Event_type === "Holiday")
            .forEach((e) => {

                const start = toDateKey(e.Event_date);
                const end = toDateKey(e.Event_end_date) || start;
                const { kind, reason } = parseHoliday(e);

                if (!start) return;

                // reason shown on the attendance page = calendar title
                // (+ leave type chosen in the calendar, if any)
                const name = [e.Event_title, e.Event_leave ? `(${e.Event_leave})` : ""]
                    .filter(Boolean)
                    .join(" ");

                const [sy, sm, sd] = start.split("-").map(Number);
                const last = new Date(...end.split("-").map((n, i) => (i === 1 ? n - 1 : n)));

                for (
                    let d = new Date(sy, sm - 1, sd);
                    d <= last;
                    d.setDate(d.getDate() + 1)
                ) {
                    add(dateKey(d.getFullYear(), d.getMonth(), d.getDate()), name, {
                        Holiday_category: e.Holiday_category || "",
                        Holiday_kind: kind,
                        Holiday_reason: reason
                    });
                }

            });

        return list;

    }, [calendarEvents]);

    // Working days with a celebration (Event_type = "Working")
    // "yyyy-mm-dd" -> { reason }
    const celebrationMap = useMemo(() => {

        const map = {};

        calendarEvents
            .filter((e) => e.Event_type === "Working")
            .forEach((e) => {

                const key = toDateKey(e.Event_date);

                if (key) map[key] = { reason: parseHoliday(e).reason };

            });

        return map;

    }, [calendarEvents]);

    // staffId -> [{ from, to, offDay }] from the Staff Schedule page
    const weekOffMap = useMemo(() => {

        const map = {};

        scheduleList.forEach((sch) => {

            const offDay = WEEKDAY_NAMES.indexOf(String(sch.Schedule_weekly_off || "").trim());

            if (offDay < 0) return;

            const id = String(sch.Staff_id);

            if (!map[id]) map[id] = [];

            map[id].push({
                from: toDateKey(sch.Schedule_start_date),
                to: toDateKey(sch.Schedule_end_date),
                offDay
            });

        });

        return map;

    }, [scheduleList]);

    // is this date the weekly off day of this staff? (inside a schedule date range)
    const isWeekOff = useCallback((staffId, key) => {

        const ranges = weekOffMap[String(staffId)];

        if (!ranges) return false;

        const [y, m, d] = key.split("-").map(Number);
        const dow = new Date(y, m - 1, d).getDay();

        return ranges.some(
            (r) => r.offDay === dow && key >= r.from && key <= r.to
        );

    }, [weekOffMap]);

    // "yyyy-mm-dd" -> holiday record
    const holidayMap = useMemo(() => {

        const map = {};

        holidays.forEach((h) => {
            map[toDateKey(h.Holiday_date)] = h;
        });

        return map;

    }, [holidays]);

    // only Active staff are listed in the grid
    const activeStaff = useMemo(
        () => staffList.filter((s) => s.Staff_Status !== "Deactive"),
        [staffList]
    );


    const handleSearch = (key, sanitize) => (e) => {

        setSearch((prev) => ({ ...prev, [key]: sanitize(e.target.value) }));

        setCurrentPage(1);

    };

    // =====================================================
    // PAGINATION
    // =====================================================

    // opening a month: current month -> the half that has today, other months -> 1-15
    useEffect(() => {

        const t = new Date();

        setHalf(
            month === t.getMonth() && year === t.getFullYear() && t.getDate() > 15
                ? 1
                : 0
        );

    }, [month, year]);

    // the 15 days shown in the grid (THU 01, FRI 02 ...)
    const monthDays = useMemo(() => {

        const total = new Date(year, month + 1, 0).getDate();
        const today = todayKey();
        const list = [];

        const from = half === 0 ? 1 : 16;
        const to = half === 0 ? Math.min(15, total) : total;

        for (let d = from; d <= to; d++) {

            const key = dateKey(year, month, d);
            const dow = new Date(year, month, d).getDay();

            list.push({
                key,
                dow: WEEKDAYS[dow],
                label: String(d).padStart(2, "0"),
                isSunday: dow === 0,
                isToday: key === today
            });
        }

        return list;

    }, [month, year, half]);

    const itemsPerPage = 10;

    const filteredStaff = activeStaff.filter(
        (s) => startsWith(s.Staff_name, search.name)
    );

    const indexOfLastItem = currentPage * itemsPerPage;

    const indexOfFirstItem = indexOfLastItem - itemsPerPage;

    const currentStaff = filteredStaff.slice(indexOfFirstItem, indexOfLastItem);

    const nextPage = () => {

        if (indexOfLastItem < filteredStaff.length) setCurrentPage(currentPage + 1);

    };

    const prevPage = () => {

        if (currentPage > 1) setCurrentPage(currentPage - 1);

    };


    // reason chips under the grid: government-new, emergency-flood, celebration-fun
    // (only the days currently shown)
    const reasonChips = useMemo(() => {

        const seen = new Set();
        const list = [];

        monthDays.forEach((day) => {

            const h = holidayMap[day.key];
            const c = celebrationMap[day.key];

            const kind = h ? h.Holiday_kind : c ? "celebration" : "";
            const reason = h ? h.Holiday_reason : c ? c.reason : "";

            if (!kind) return;

            const tag = holidayTag(kind, reason);

            if (seen.has(tag)) return;

            seen.add(tag);
            list.push({ tag, kind });

        });

        return list;

    }, [monthDays, holidayMap, celebrationMap]);

    // =====================================================
    // CALENDAR POPUP (View button)
    // =====================================================

    // one day of one staff -> { state, record, holidayName } | null
    // (Holiday wins over a saved record, same as the grid)
    const getDayInfo = useCallback((staffId, key) => {

        const holiday = holidayMap[key];

        if (holiday) {

            const under = attendanceMap[`${staffId}|${key}`];

            return {
                state: "Holiday",
                record: null,
                holidayName: holiday.Holiday_name || "",
                holidayKind: holiday.Holiday_kind || "",
                holidayReason: holiday.Holiday_reason || "",
                leaveType:
                    under && under.Attendance_status === "Leave"
                        ? (under.Attendance_leave_type || "Leave")
                        : ""
            };
        }

        const record = attendanceMap[`${staffId}|${key}`];

        if (record) {
            return { state: record.Attendance_status, record, holidayName: "" };
        }

        // weekly off day from the Staff Schedule page (no attendance saved)
        if (isWeekOff(staffId, key)) {
            return { state: "Week Off", record: null, holidayName: "" };
        }

        // working day with a celebration (no attendance saved yet)
        const cel = celebrationMap[key];

        if (cel) {
            return {
                state: "Celebration",
                record: null,
                holidayName: "",
                holidayKind: "celebration",
                holidayReason: cel.reason
            };
        }

        return null;

    }, [holidayMap, attendanceMap, celebrationMap, isWeekOff]);

    // Add / Edit button inside the popup -> reuse the existing pages
    const handleCalendarPick = (staff, key, record) => {

        setCalendarStaff(null);

        handleCellClick(staff, { key }, record);

    };


    // =====================================================
    // ADD / EDIT / DELETE PAGES
    // =====================================================

    const showAddPage = (data = null) => {

        setPrefill(data);

        setAddPageVisible(true);

    };

    const hideAddPage = () => {

        setAddPageVisible(false);

        setPrefill(null);

    };

    const handleAttendanceSaved = async () => {

        await fetchAll();

        setAddPageVisible(false);

        setUpdatePageVisible(false);

        setPrefill(null);

    };

    const hideUpdatePage = () => setUpdatePageVisible(false);

    const showDeleteFromUpdate = () => {

        setUpdatePageVisible(false);

        setDeletePageVisible(true);

    };

    const hideDeletePage = () => setDeletePageVisible(false);

    const handleAttendanceDeleted = async () => {

        await fetchAll();

        setDeletePageVisible(false);

    };


    // click on a grid cell
    const handleCellClick = (staff, day, record) => {

        if (holidayMap[day.key]) return;

        if (record) {

            setValue(record);

            setUpdatePageVisible(true);

            return;
        }

        // no record yet -> Add page with staff + date filled in
        // (future dates are not allowed, so ignore them)
        if (day.key > todayKey()) return;

        showAddPage({
            Staff_id: staff.Staff_id,
            Attendance_date: day.key
        });

    };


    // =====================================================
    // ADD PAGE VIEW
    // =====================================================

    if (addPageVisible) {

        return (

            <Addstaffattendance
                toggle={hideAddPage}
                onSuccess={handleAttendanceSaved}
                onRefresh={fetchAll}
                prefill={prefill}
                staffList={activeStaff}
                existingAttendance={attendanceList}
                holidays={holidays}
            />

        );

    }


    // =====================================================
    // EDIT PAGE VIEW
    // =====================================================

    if (updatePageVisible && value) {

        return (

            <Updatestaffattendance
                toggle={hideUpdatePage}
                onSuccess={handleAttendanceSaved}
                onDelete={showDeleteFromUpdate}
                data={value}
                staffList={staffList}
                existingAttendance={attendanceList}
                holidays={holidays}
            />

        );

    }


    // =====================================================
    // DELETE PAGE VIEW
    // =====================================================

    if (deletePageVisible && value) {

        return (

            <Deletestaffattendance
                toggle={hideDeletePage}
                onSuccess={handleAttendanceDeleted}
                data={value}
                staff={staffList.find(
                    (s) => String(s.Staff_id) === String(value.Staff_id)
                )}
            />

        );

    }


    const firstShown =
        filteredStaff.length === 0 ? 0 : indexOfFirstItem + 1;

    const lastShown = Math.min(indexOfLastItem, filteredStaff.length);


    // hover tooltip for the working time shown beside the Present tick
    // (used by the grid and by the View calendar popup)
    const showTimeTip = (e, record, dateKey) => {
        const r = e.currentTarget.getBoundingClientRect();
        setTimeTip({
            x: r.left + r.width / 2,
            y: r.top,
            record,
            date: dateKey
        });
    };

    const hideTimeTip = () => setTimeTip(null);

    return (

        <div className="staffattendance-page container-xxl flex-grow-1 container-p-y">


            {/* ================================================= */}
            {/* HEADER */}
            {/* ================================================= */}

            <div className="page-header">

                <div>

                    <h3 className="page-title">
                        Staff View Attendance
                    </h3>

                    <p className="page-subtitle">
                        Manage monthly attendance of all staff
                    </p>

                </div>


                <button
                    type="button"
                    className="btn btn-primary add-btn"
                    onClick={() => showAddPage()}
                >

                    <i className="bx bx-plus me-2"></i>

                    Add Attendance

                </button>

            </div>


            {/* ================================================= */}
            {/* ATTENDANCE CARD */}
            {/* ================================================= */}

            <div className="card staffattendance-card">

                {/* TOOLBAR */}
                <div className="att-toolbar">

                    <div className="filter-field">
                        <i className="bx bx-user"></i>
                        <input
                            type="text"
                            className="form-control"
                            placeholder="Search by name"
                            maxLength={SEARCH_MAX}
                            autoComplete="off"
                            value={search.name}
                            onChange={handleSearch("name", sanitizeName)}
                        />
                    </div>

                    <div className="filter-field">
                        <i className="bx bx-calendar"></i>
                        <select
                            className="form-select"
                            aria-label="Select Month"
                            value={month}
                            onChange={(e) => setMonth(Number(e.target.value))}
                        >
                            {MONTHS.map((m, i) => (
                                <option key={m} value={i}>{m}</option>
                            ))}
                        </select>
                    </div>

                    <div className="filter-field">
                        <i className="bx bx-calendar-alt"></i>
                        <select
                            className="form-select"
                            aria-label="Select Year"
                            value={year}
                            onChange={(e) => setYear(Number(e.target.value))}
                        >
                            {Array.from(
                                { length: MAX_YEAR - MIN_YEAR + 1 },
                                (_, i) => MIN_YEAR + i
                            ).map((y) => (
                                <option key={y} value={y}>{y}</option>
                            ))}
                        </select>
                    </div>

                    {/* 15-DAY SWITCH */}
                    <div className="att-half-toggle" role="group" aria-label="Days shown">
                        <button
                            type="button"
                            className={half === 0 ? "is-active" : ""}
                            onClick={() => setHalf(0)}
                        >
                            1 - 15
                        </button>
                        <button
                            type="button"
                            className={half === 1 ? "is-active" : ""}
                            onClick={() => setHalf(1)}
                        >
                            16 - {new Date(year, month + 1, 0).getDate()}
                        </button>
                    </div>

                </div>


                {/* LEGEND */}
                <div className="att-legend">

                    {[
                        { key: "Present", icon: STATE_ICON.Present.icon, cls: STATE_ICON.Present.cls },
                        { key: "Absent", icon: STATE_ICON.Absent.icon, cls: STATE_ICON.Absent.cls },
                        { key: "Government", icon: HOLIDAY_KIND.government.icon, color: HOLIDAY_KIND.government.color },
                        { key: "Emergency", icon: HOLIDAY_KIND.emergency.icon, color: HOLIDAY_KIND.emergency.color },
                        { key: "Celebration", icon: HOLIDAY_KIND.celebration.icon, color: HOLIDAY_KIND.celebration.color },
                        { key: "Week Off", icon: STATE_ICON["Week Off"].icon, cls: STATE_ICON["Week Off"].cls }
                    ].map((l) => (

                        <span key={l.key}>
                            <i
                                className={`bx ${l.icon} ${l.cls || ""}`}
                                style={l.color ? { color: l.color } : undefined}
                            ></i>
                            {l.key}
                        </span>

                    ))}

                </div>


                {/* ================================================= */}
                {/* ATTENDANCE GRID */}
                {/* ================================================= */}

                <div className="table-responsive">

                    <table className="att-grid">

                        <thead>

                            <tr>

                                <th className="att-col-id"><i className="bx bx-hash"></i>StaffId</th>

                                <th className="att-col-name"><i className="bx bx-user"></i>Staff Name</th>

                                {monthDays.map((day) => (
                                    <th
                                        key={day.key}
                                        className={
                                            "att-day" +
                                            (day.isSunday ? " is-sunday" : "") +
                                            (day.isToday ? " is-today" : "")
                                        }
                                    >
                                        {day.dow}
                                        <br />
                                        {day.label}
                                    </th>
                                ))}

                                <th className="att-col-action">Action</th>

                            </tr>

                        </thead>


                        <tbody>

                            {currentStaff.length > 0 ? (

                                currentStaff.map((staff) => (

                                    <tr key={staff.Staff_id}>

                                        <td className="att-col-id">
                                            {staffCode(staff)}
                                        </td>


                                        <td className="att-col-name">

                                            <div className="staff-name-cell">

                                                {staff.Staff_photo ? (

                                                    <img
                                                        className="staff-avatar"
                                                        src={staff.Staff_photo}
                                                        alt={staff.Staff_name}
                                                    />

                                                ) : (

                                                    <span className="staff-avatar">
                                                        {String(staff.Staff_name || "?")
                                                            .charAt(0)
                                                            .toUpperCase()}
                                                    </span>

                                                )}

                                                <div className="staff-name-text">

                                                    <strong title={staff.Staff_name}>
                                                        {show(staff.Staff_name)}
                                                    </strong>

                                                    <span className="staff-sub">
                                                        {staff.Staff_gender || "-"}
                                                        {staff.Staff_age
                                                            ? ` · ${staff.Staff_age} yrs`
                                                            : ""}
                                                    </span>

                                                </div>

                                            </div>

                                        </td>


                                        {monthDays.map((day) => {

                                            const info = getDayInfo(staff.Staff_id, day.key);
                                            const meta = info ? STATE_ICON[info.state] : null;

                                            if (info && info.state === "Holiday") {
                                                const hk = HOLIDAY_KIND[info.holidayKind];
                                                const tag = holidayTag(info.holidayKind, info.holidayReason);
                                                return (
                                                    <td key={day.key} className="att-cell">
                                                        <span
                                                            className="att-cell-holiday"
                                                            title={
                                                                tag
                                                                    ? tag
                                                                    : info.holidayName ? `Holiday - ${info.holidayName}` : "Holiday"
                                                            }
                                                        >
                                                            {hk ? (
                                                                <i className={`bx ${hk.icon}`} style={{ color: hk.color }}></i>
                                                            ) : (
                                                                <i className={`bx ${STATE_ICON.Holiday.icon} ${STATE_ICON.Holiday.cls}`}></i>
                                                            )}
                                                        </span>
                                                    </td>
                                                );
                                            }

                                            return (
                                                <td key={day.key} className="att-cell">
                                                    <button
                                                        type="button"
                                                        className={"att-cell-btn" + (info ? "" : " is-empty")}
                                                        title={info ? `${holidayTag(info.holidayKind, info.holidayReason) || (meta ? meta.title : info.state)} - ${day.key}` : `Add attendance - ${day.key}`}
                                                        onClick={() => handleCellClick(staff, day, info ? info.record : null)}
                                                    >
                                                        {meta ? (
                                                            <i className={`bx ${meta.icon} ${meta.cls}`}></i>
                                                        ) : (
                                                            <i className="bx bx-plus"></i>
                                                        )}
                                                    </button>

                                                    {info && info.state === "Present" && info.record && info.record.Attendance_in_time && (
                                                        <span
                                                            className={"att-worktime" + (getWorkingMinutes(info.record) === null ? " is-open" : "")}
                                                            onMouseEnter={(e) => showTimeTip(e, info.record, day.key)}
                                                            onMouseLeave={hideTimeTip}
                                                        >
                                                            {getWorkingMinutes(info.record) !== null
                                                                ? formatWorking(getWorkingMinutes(info.record)).replace(" ", "")
                                                                : "in"}
                                                        </span>
                                                    )}
                                                </td>
                                            );

                                        })}


                                        <td className="att-col-action">

                                            <button
                                                type="button"
                                                className="att-view-btn"
                                                title="View monthly calendar"
                                                onClick={() => setCalendarStaff(staff)}
                                            >
                                                <i className="bx bx-calendar-event"></i>
                                                View
                                            </button>

                                        </td>

                                    </tr>

                                ))

                            ) : (

                                <tr>

                                    <td
                                        colSpan={3 + monthDays.length}
                                        className="text-center py-4"
                                    >

                                        No staff found.

                                    </td>

                                </tr>

                            )}

                        </tbody>

                    </table>

                </div>


                {/* REASONS (kind-reason) */}
                {reasonChips.length > 0 && (
                    <div className="att-reasons">
                        {reasonChips.map((r) => (
                            <span
                                key={r.tag}
                                className="att-reason"
                                style={{
                                    background: HOLIDAY_KIND[r.kind].bg,
                                    color: HOLIDAY_KIND[r.kind].chip
                                }}
                            >
                                <i className={`bx ${HOLIDAY_KIND[r.kind].icon}`}></i>
                                {r.tag}
                            </span>
                        ))}
                    </div>
                )}


                {/* ================================================= */}
                {/* PAGINATION */}
                {/* ================================================= */}

                <div className="card-footer bg-white border-0">

                    <div className="d-flex justify-content-between align-items-center flex-wrap gap-2">

                        <span className="table-count">
                            <i className="bx bx-group me-1"></i>
                            Showing{" "}
                            <strong>{firstShown} - {lastShown}</strong>{" "}
                            of <strong>{filteredStaff.length}</strong> staff
                        </span>

                        <div className="d-flex">

                            <button
                                className="btn btn-light me-2"
                                onClick={prevPage}
                                disabled={currentPage === 1}
                            >

                                <i className="bx bx-chevron-left"></i>

                                Previous

                            </button>


                            <button
                                className="btn btn-primary"
                                onClick={nextPage}
                                disabled={indexOfLastItem >= filteredStaff.length}
                            >

                                Next

                                <i className="bx bx-chevron-right ms-1"></i>

                            </button>

                        </div>

                    </div>

                </div>

            </div>


            {/* working time hover tooltip (fixed, so the table scroll never clips it) */}
            {timeTip && (
                <div
                    className="att-time-tip"
                    style={{ left: timeTip.x, top: timeTip.y }}
                >
                    <div className="att-time-tip-date">{timeTip.date}</div>
                    <div className="att-time-tip-row">
                        <span>Check in</span>
                        <strong>{to12h(timeTip.record.Attendance_in_time)}</strong>
                    </div>
                    <div className="att-time-tip-row">
                        <span>Check out</span>
                        <strong>{to12h(timeTip.record.Attendance_out_time)}</strong>
                    </div>
                    <div className="att-time-tip-row is-total">
                        <span>Working time</span>
                        <strong>
                            {getWorkingMinutes(timeTip.record) !== null
                                ? formatWorking(getWorkingMinutes(timeTip.record))
                                : "-"}
                        </strong>
                    </div>
                </div>
            )}

            {/* ================================================= */}
            {/* STAFF CALENDAR POPUP */}
            {/* ================================================= */}

            {calendarStaff && (

                <StaffCalendarModal
                    staff={calendarStaff}
                    month={month}
                    year={year}
                    getDay={getDayInfo}
                    onClose={() => setCalendarStaff(null)}
                    onPickDay={handleCalendarPick}
                    showTimeTip={showTimeTip}
                    hideTimeTip={hideTimeTip}
                />

            )}

        </div>

    );

}


export default StaffAttendance;
