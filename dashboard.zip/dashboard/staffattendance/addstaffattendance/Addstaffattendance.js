import React, { useState, useEffect, useContext, useMemo } from "react";
import AuthContext from "../../../services/AuthContext";
import "./addstaffattendance.css";

// =====================================================
// SHARED HELPERS (also used by the list page)
// =====================================================

// Leave and Permission are no longer offered; old Leave / Permission records
// can still be opened and saved
export const STATUS_OPTIONS = ["Present", "Absent", "Week Off"];

// statuses that have an in / out time
export const TIMED_STATUSES = ["Present", "Permission"];

// same icons + colors as the legend on the attendance list page
export const STATUS_ICONS = {
    Present: { icon: "bxs-check-circle", cls: "att-present" },
    Absent: { icon: "bxs-x-circle", cls: "att-absent" },
    Leave: { icon: "bxs-calendar", cls: "att-leave" },
    "Week Off": { icon: "bxs-home", cls: "att-weekoff" },
    Permission: { icon: "bxs-time", cls: "att-permission" }
};
export const LEAVE_TYPES = ["Casual Leave", "Sick Leave", "Earned Leave", "Other"];

// Staff ID shown in the grid, e.g. "IGT E001".
// Uses Staff_code from Django when it exists, otherwise builds it from Staff_id.
export const staffCode = (staff) =>
    staff && staff.Staff_code
        ? staff.Staff_code
        : `IGT E${String((staff && staff.Staff_id) || 0).padStart(3, "0")}`;

const pad = (n) => String(n).padStart(2, "0");

// yyyy-mm-dd (local time, no timezone shift)
export const dateKey = (y, m, d) => `${y}-${pad(m + 1)}-${pad(d)}`;

export const todayKey = () => {
    const t = new Date();
    return dateKey(t.getFullYear(), t.getMonth(), t.getDate());
};

// Django may send "2026-10-05" or "2026-10-05T00:00:00Z"
export const toDateKey = (d) => (d ? String(d).split("T")[0] : "");

export const emptyAttendance = () => ({
    Staff_id: "",
    Attendance_date: todayKey(),
    Attendance_status: "Present",
    Attendance_in_time: "",
    Attendance_out_time: "",
    Attendance_leave_type: "",
    Attendance_remarks: ""
});

// =====================================================
// VALIDATION (one place: used while typing and on submit)
// ctx = { existingAttendance, holidays, currentId }
// =====================================================

export const validateField = (name, value, all, ctx) => {

    const v = typeof value === "string" ? value.trim() : value;

    switch (name) {

        case "Staff_id":
            return v ? "" : "Staff is required.";

        case "Attendance_date": {

            if (!v) return "Date is required.";

            if (Number.isNaN(new Date(v).getTime())) return "Enter a valid date.";

            if (v > todayKey()) return "Attendance cannot be marked for a future date.";

            const holiday = (ctx.holidays || []).find(
                (h) => toDateKey(h.Holiday_date) === v
            );

            if (holiday) return "This date is a holiday.";

            const duplicate = (ctx.existingAttendance || []).some(
                (a) =>
                    String(a.Staff_id) === String(all.Staff_id) &&
                    toDateKey(a.Attendance_date) === v &&
                    Number(a.Attendance_id) !== Number(ctx.currentId)
            );

            if (all.Staff_id && duplicate)
                return "Attendance is already marked for this staff on this date.";

            return "";
        }

        case "Attendance_status":
            return STATUS_OPTIONS.includes(v) || v === "Leave" || v === "Permission" ? "" : "Status is required.";

        case "Attendance_in_time":
            if (all.Attendance_status === "Present" && !v) return "In time is required.";
            return "";

        case "Attendance_out_time":
            if (TIMED_STATUSES.includes(all.Attendance_status) && v && all.Attendance_in_time &&
                v <= all.Attendance_in_time)
                return "Out time must be after in time.";
            return "";

        case "Attendance_leave_type":
            if (all.Attendance_status === "Leave" && !v) return "Leave type is required.";
            return "";

        case "Attendance_remarks":
            if (v && v.length > 200) return "Remarks can contain 200 characters only.";
            return "";

        default:
            return "";
    }
};

// Plain JSON object for AuthContext insert / update (same style as Staff Register).
export const buildAttendancePayload = (values, extra = {}) => {

    const payload = {};

    Object.keys(values).forEach((key) => {

        const v = values[key];

        if (typeof v === "string") payload[key] = v.trim();
        else if (v !== null && v !== undefined) payload[key] = v;

    });

    // Present / Permission have times, Leave needs a type; clear what does not apply
    if (!TIMED_STATUSES.includes(payload.Attendance_status)) {
        payload.Attendance_in_time = "";
        payload.Attendance_out_time = "";
    }

    if (payload.Attendance_status !== "Leave") payload.Attendance_leave_type = "";

    return { ...payload, ...extra };
};

// =====================================================
// FORM COMPONENT
// props: initialValues, staffList, existingAttendance, holidays,
//        currentId, title, submitLabel, failMessage,
//        onSubmit(values), onBack, onDelete (optional)
// =====================================================

export const AttendanceForm = (props) => {

    const [values, setValues] = useState(() => ({
        ...emptyAttendance(),
        ...(props.initialValues || {})
    }));

    const [errors, setErrors] = useState({});
    const [loading, setLoading] = useState(false);

    // Error popup (same style as the delete popup)
    const [popup, setPopup] = useState("");

    const ctx = {
        existingAttendance: props.existingAttendance,
        holidays: props.holidays,
        currentId: props.currentId
    };

    const staffList = props.staffList || [];

    // Re-check date whenever staff / date changes (duplicate + holiday rule)
    useEffect(() => {

        if (!values.Attendance_date) return;

        setErrors((prev) => ({
            ...prev,
            Attendance_date: validateField("Attendance_date", values.Attendance_date, values, ctx)
        }));

        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [values.Staff_id, values.Attendance_date]);


    const setField = (name, value) => {

        setValues((prev) => {

            const next = { ...prev, [name]: value };

            return next;

        });

        setErrors((prev) => ({
            ...prev,
            [name]: validateField(name, value, { ...values, [name]: value }, ctx)
        }));

    };

    const handleChange = (name) => (e) => setField(name, e.target.value);


    const validateAll = () => {

        const found = {};

        Object.keys(emptyAttendance()).forEach((name) => {

            const msg = validateField(name, values[name], values, ctx);

            if (msg) found[name] = msg;

        });

        return found;
    };


    const handleSubmit = async (e) => {

        e.preventDefault();

        const found = validateAll();

        if (Object.keys(found).length > 0) {

            setErrors(found);

            setPopup(Object.values(found)[0]);

            return;
        }

        try {

            setLoading(true);

            await props.onSubmit(values);

        } catch (err) {

            console.error("Attendance save failed:", err);

            const data = err && err.responseData;

            let message = props.failMessage || "Attendance could not be saved. Please try again.";

            if (data) {

                const firstKey = Object.keys(data).find((k) => k !== "detail");

                if (data.detail) {
                    message = data.detail;
                } else if (firstKey) {
                    message = Array.isArray(data[firstKey]) ? data[firstKey][0] : String(data[firstKey]);
                }

            }

            setPopup(message);

        } finally {

            setLoading(false);

        }

    };


    // ---------------- small field helpers ----------------
    const err = (name) => errors[name];

    const cls = (base, name) => base + (err(name) ? " is-invalid" : "");

    const Label = ({ text, required, htmlFor }) => (
        <label htmlFor={htmlFor} className="att-field-label">
            {text}
            {required && <span className="req">*</span>}
        </label>
    );

    const FieldError = ({ name }) =>
        err(name) ? <div className="invalid-feedback d-block">{err(name)}</div> : null;

    const isPresent = values.Attendance_status === "Present";
    const hasTimes = TIMED_STATUSES.includes(values.Attendance_status);
    const isLeave = values.Attendance_status === "Leave";


    return (

        <div className="staffattendance-page centered-form-page container-xxl flex-grow-1 container-p-y">

            <div className="centered-form-wrap">

                {/* ================= PAGE HEADER ================= */}
                <div className="page-header">

                    <h3 className="page-title">
                        {props.title}
                    </h3>

                    <button
                        type="button"
                        className="att-back-btn"
                        onClick={props.onBack}
                        disabled={loading}
                    >
                        <i className="bx bx-arrow-back me-2"></i>
                        Back to list
                    </button>

                </div>


                <div className="card staffattendance-card">

                    <div className="card-body">

                        <form onSubmit={handleSubmit} noValidate>

                            <div className="row att-form-grid">

                                <div className="col-md-6 mb-3">
                                    <Label text="Staff" required htmlFor="Staff_id" />
                                    <div className="att-input-icon">
<i className="bx bx-user"></i>
<select
                                        id="Staff_id"
                                        className={cls("form-select", "Staff_id")}
                                        value={values.Staff_id}
                                        onChange={handleChange("Staff_id")}
                                    >
                                        <option value="">Select Staff</option>
                                        {staffList.map((s) => (
                                            <option key={s.Staff_id} value={s.Staff_id}>
                                                {staffCode(s)} - {s.Staff_name}
                                            </option>
                                        ))}
                                    </select>
</div>
                                    <FieldError name="Staff_id" />
                                </div>

                                {/* ---------- Row: Attendance Date | Remarks ---------- */}
                                <div className="col-md-6 mb-3">
                                    <Label text="Attendance Date" required htmlFor="Attendance_date" />
                                    <div className="att-input-icon">
                                        <i className="bx bx-calendar"></i>
                                        <input
                                            id="Attendance_date"
                                            type="date"
                                            className={cls("form-control", "Attendance_date")}
                                            max={todayKey()}
                                            value={values.Attendance_date}
                                            onChange={handleChange("Attendance_date")}
                                        />
                                    </div>
                                    <FieldError name="Attendance_date" />
                                </div>

                                <div className="col-md-6 mb-3">
                                    <Label text="Remarks" htmlFor="Attendance_remarks" />
                                    <div className="att-input-icon">
                                        <i className="bx bx-comment-detail"></i>
                                        <input
                                            id="Attendance_remarks"
                                            type="text"
                                            maxLength={200}
                                            autoComplete="off"
                                            placeholder="Enter remarks (optional)"
                                            className={cls("form-control", "Attendance_remarks")}
                                            value={values.Attendance_remarks}
                                            onChange={handleChange("Attendance_remarks")}
                                        />
                                    </div>
                                    <FieldError name="Attendance_remarks" />
                                </div>


                                {/* ---------- Row: Status (radio buttons, all in ONE row) ---------- */}
                                <div className="col-12 mb-3">
                                    <Label text="Status" required />
                                    <div
                                        className={"att-radio-group" + (err("Attendance_status") ? " is-invalid" : "")}
                                        role="radiogroup"
                                        aria-label="Status"
                                    >
                                        {(values.Attendance_status === "Permission"
                                            ? [...STATUS_OPTIONS, "Permission"]   // an old Permission record keeps its option
                                            : STATUS_OPTIONS
                                        ).map((st) => (
                                            <label key={st} className="att-radio">
                                                <input
                                                    type="radio"
                                                    name="Attendance_status"
                                                    value={st}
                                                    checked={values.Attendance_status === st}
                                                    onChange={handleChange("Attendance_status")}
                                                />
                                                <i className={`bx ${STATUS_ICONS[st].icon} ${STATUS_ICONS[st].cls}`}></i>
                                                <span>{st}</span>
                                            </label>
                                        ))}
                                    </div>
                                    <FieldError name="Attendance_status" />
                                </div>


                                {/* ---------- Row: In Time | Out Time ---------- */}
                                {hasTimes && (
                                    <>
                                        <div className="col-md-6 mb-3">
                                            <Label text="In Time" required={isPresent} htmlFor="Attendance_in_time" />
                                            <div className="att-input-icon">
                                                <i className="bx bx-log-in-circle"></i>
                                                <input
                                                    id="Attendance_in_time"
                                                    type="time"
                                                    className={cls("form-control", "Attendance_in_time")}
                                                    value={values.Attendance_in_time}
                                                    onChange={handleChange("Attendance_in_time")}
                                                />
                                            </div>
                                            <FieldError name="Attendance_in_time" />
                                        </div>

                                        <div className="col-md-6 mb-3">
                                            <Label text="Out Time" htmlFor="Attendance_out_time" />
                                            <div className="att-input-icon">
                                                <i className="bx bx-log-out-circle"></i>
                                                <input
                                                    id="Attendance_out_time"
                                                    type="time"
                                                    className={cls("form-control", "Attendance_out_time")}
                                                    value={values.Attendance_out_time}
                                                    onChange={handleChange("Attendance_out_time")}
                                                />
                                            </div>
                                            <FieldError name="Attendance_out_time" />
                                        </div>
                                    </>
                                )}

                                {isLeave && (
                                    <div className="col-md-6 mb-3">
                                        <Label text="Leave Type" required htmlFor="Attendance_leave_type" />
                                        <div className="att-input-icon">
                                            <i className="bx bx-calendar-minus"></i>
                                            <select
                                                id="Attendance_leave_type"
                                                className={cls("form-select", "Attendance_leave_type")}
                                                value={values.Attendance_leave_type}
                                                onChange={handleChange("Attendance_leave_type")}
                                            >
                                                <option value="">Select Leave Type</option>
                                                {LEAVE_TYPES.map((t) => (
                                                    <option key={t} value={t}>{t}</option>
                                                ))}
                                            </select>
                                        </div>
                                        <FieldError name="Attendance_leave_type" />
                                    </div>
                                )}

                            </div>


                            {/* ================= FOOTER ================= */}
                            <div className="att-form-footer">

                                <div>

                                    <button
                                        type="button"
                                        className="btn btn-outline-secondary"
                                        onClick={props.onBack}
                                        disabled={loading}
                                    >
                                        Cancel
                                    </button>

                                    {props.onDelete && (
                                        <button
                                            type="button"
                                            className="btn btn-outline-danger ms-2"
                                            onClick={props.onDelete}
                                            disabled={loading}
                                        >
                                            Delete
                                        </button>
                                    )}

                                </div>

                                <button
                                    type="submit"
                                    className="btn btn-primary"
                                    disabled={loading}
                                >

                                    {loading ? (
                                        <>
                                            <span
                                                className="spinner-border spinner-border-sm me-2"
                                                role="status"
                                                aria-hidden="true"
                                            ></span>
                                            Saving...
                                        </>
                                    ) : (
                                        props.submitLabel
                                    )}

                                </button>

                            </div>

                        </form>

                    </div>

                </div>

            </div>


            {/* ================= ERROR POPUP ================= */}
            {popup && (

                <div
                    className="att-popup-backdrop"
                    onClick={() => setPopup("")}
                >

                    <div
                        className="att-popup"
                        role="alertdialog"
                        aria-modal="true"
                        onClick={(e) => e.stopPropagation()}
                    >

                        <div className="att-popup-icon">⚠</div>

                        <h5>{popup}</h5>

                        <button
                            type="button"
                            className="btn btn-primary mt-3"
                            onClick={() => setPopup("")}
                            autoFocus
                        >
                            OK
                        </button>

                    </div>

                </div>

            )}

        </div>
    );
};


// =====================================================
// BULK ADD FORM (one table, one row per staff)
// props: staffList, existingAttendance, holidays, prefill, onBack, onSaveRow(values)
// =====================================================

const emptyRow = () => ({
    Attendance_status: "",
    Attendance_in_time: "",
    Attendance_out_time: "",
    Attendance_leave_type: ""
});

export const BulkAttendanceForm = (props) => {

    const staffList = props.staffList || [];
    const prefill = props.prefill || {};

    const [date, setDate] = useState(prefill.Attendance_date || todayKey());
    const [search, setSearch] = useState("");
    const [rows, setRows] = useState(() => {
        // staff clicked in the grid starts as Present
        return prefill.Staff_id
            ? { [prefill.Staff_id]: { ...emptyRow(), Attendance_status: "Present" } }
            : {};
    });
    const [rowErrors, setRowErrors] = useState({});
    const [loading, setLoading] = useState(false);
    const [popup, setPopup] = useState("");

    const holiday = (props.holidays || []).find(
        (h) => toDateKey(h.Holiday_date) === date
    );

    const dateError = !date
        ? "Date is required."
        : date > todayKey()
            ? "Attendance cannot be marked for a future date."
            : holiday
                ? "This date is a holiday."
                : "";

    // staff already marked on the chosen date: status is locked, but the
    // check out time can still be entered (it updates that saved record)
    const markedRec = useMemo(() => {
        const map = {};
        (props.existingAttendance || []).forEach((a) => {
            if (toDateKey(a.Attendance_date) === date) map[a.Staff_id] = a;
        });
        return map;
    }, [props.existingAttendance, date]);

    const markedMap = useMemo(() => {
        const map = {};
        Object.keys(markedRec).forEach((id) => {
            map[id] = markedRec[id].Attendance_status;
        });
        return map;
    }, [markedRec]);

    // a saved record with a check in time can get / change its check out time
    const canCheckout = (id) => {
        const rec = markedRec[id];
        return !!rec && TIMED_STATUSES.includes(rec.Attendance_status) && !!rec.Attendance_in_time;
    };

    // check out shown for a saved record: the saved value until the user edits it
    const savedOut = (id) => {
        const row = rows[id];
        if (row && row.__outEdited) return row.Attendance_out_time;
        return (markedRec[id] && markedRec[id].Attendance_out_time) || "";
    };

    // saved records whose check out was entered / changed on this screen
    const outUpdates = () =>
        staffList.filter((s) => {
            const rec = markedRec[s.Staff_id];
            const row = rows[s.Staff_id];
            return (
                canCheckout(s.Staff_id) &&
                row && row.__outEdited &&
                row.Attendance_out_time !== (rec.Attendance_out_time || "")
            );
        });

    const visibleStaff = staffList.filter((s) => {
        const q = search.trim().toLowerCase();
        if (!q) return true;
        return (
            String(s.Staff_name || "").toLowerCase().includes(q) ||
            staffCode(s).toLowerCase().includes(q)
        );
    });

    const rowOf = (id) => rows[id] || emptyRow();

    const updateRow = (id, patch) => {
        setRows((prev) => ({ ...prev, [id]: { ...(prev[id] || emptyRow()), ...patch } }));
        setRowErrors((prev) => {
            if (!prev[id]) return prev;
            const next = { ...prev };
            delete next[id];
            return next;
        });
    };

    const setStatus = (id, status) => {
        const keepTimes = TIMED_STATUSES.includes(status);
        updateRow(id, {
            Attendance_status: status,
            ...(keepTimes ? {} : { Attendance_in_time: "", Attendance_out_time: "" }),
            ...(status === "Leave" ? {} : { Attendance_leave_type: "" })
        });
    };

    // "Set all present / absent" (skips staff that are already marked)
    const setAll = (status) => {
        setRows((prev) => {
            const next = { ...prev };
            staffList.forEach((s) => {
                if (markedMap[s.Staff_id]) return;
                const old = prev[s.Staff_id] || emptyRow();
                next[s.Staff_id] = {
                    ...old,
                    Attendance_status: status,
                    ...(status === "Present" ? {} : { Attendance_in_time: "", Attendance_out_time: "" }),
                    ...(status === "Leave" ? {} : { Attendance_leave_type: "" })
                };
            });
            return next;
        });
        setRowErrors({});
    };

    const allSelected = (status) => {
        const open = staffList.filter((s) => !markedMap[s.Staff_id]);
        return open.length > 0 && open.every((s) => rowOf(s.Staff_id).Attendance_status === status);
    };

    const handleSubmit = async (e) => {

        e.preventDefault();

        if (dateError) {
            setPopup(dateError);
            return;
        }

        // Flow: check-in time entered -> Present. Nothing chosen -> Absent.
        // Present without an In Time is an error (never saved as Absent).
        const resolveRow = (r) => {
            if (r.Attendance_in_time && r.Attendance_status !== "Permission")
                return { ...r, Attendance_status: "Present" };
            if (r.Attendance_status === "Week Off" || r.Attendance_status === "Permission")
                return r;
            // Present chosen but no In Time: keep it as Present so the form
            // asks for the In Time instead of silently saving Absent.
            if (r.Attendance_status === "Present")
                return r;
            return { ...r, Attendance_status: "Absent", Attendance_in_time: "", Attendance_out_time: "" };
        };

        const picked = staffList.filter((s) => !markedMap[s.Staff_id]);
        const outList = outUpdates();

        if (picked.length === 0 && outList.length === 0) {
            setPopup("Attendance is already marked for all staff on this date.");
            return;
        }

        // validate every picked row
        const found = {};

        // check out entered for an already saved record
        outList.forEach((s) => {
            const msg = validateField(
                "Attendance_out_time",
                rows[s.Staff_id].Attendance_out_time,
                markedRec[s.Staff_id],
                {}
            );
            if (msg) found[s.Staff_id] = msg;
        });
        picked.forEach((s) => {
            const r = resolveRow(rowOf(s.Staff_id));
            const all = { ...r, Attendance_date: date, Staff_id: s.Staff_id };
            const msg =
                validateField("Attendance_in_time", r.Attendance_in_time, all, {}) ||
                validateField("Attendance_out_time", r.Attendance_out_time, all, {});
            if (msg) found[s.Staff_id] = msg;
        });

        if (Object.keys(found).length > 0) {
            setRowErrors(found);
            const first = staffList.find((s) => found[s.Staff_id]);
            setPopup(`${first.Staff_name}: ${found[first.Staff_id]}`);
            return;
        }

        setLoading(true);

        const failed = [];

        // update the check out on that particular saved record
        for (const s of outList) {
            try {
                await props.onUpdateRow({
                    Attendance_id: markedRec[s.Staff_id].Attendance_id,
                    Attendance_out_time: rows[s.Staff_id].Attendance_out_time
                });
            } catch (err) {
                console.error("Check out update failed:", err);
                failed.push(s);
            }
        }

        // save one by one (same insert call as before)
        for (const s of picked) {
            const r = resolveRow(rowOf(s.Staff_id));
            try {
                await props.onSaveRow({
                    ...emptyAttendance(),
                    ...r,
                    Staff_id: s.Staff_id,
                    Attendance_date: date
                });
            } catch (err) {
                console.error("Attendance save failed:", err);
                failed.push(s);
            }
        }

        setLoading(false);

        if (failed.length === 0) {
            if (props.onSuccess) await props.onSuccess();
            return;
        }

        // keep only the rows that failed so the user can try again
        const savedIds = [...picked, ...outList]
            .filter((s) => !failed.includes(s))
            .map((s) => s.Staff_id);
        if (savedIds.length > 0 && props.onRefresh) await props.onRefresh();
        setRows((prev) => {
            const next = { ...prev };
            savedIds.forEach((id) => delete next[id]);
            return next;
        });
        setPopup(
            `Attendance could not be saved for: ${failed.map((s) => s.Staff_name).join(", ")}. Please try again.`
        );
    };

    const pickedCount = staffList.filter(
        (s) => !markedMap[s.Staff_id] && rowOf(s.Staff_id).Attendance_in_time
    ).length;

    return (

        <div className="staffattendance-page centered-form-page container-xxl flex-grow-1 container-p-y">

            <div className="centered-form-wrap att-bulk-wrap">

                <div className="page-header">

                    <h3 className="page-title">Add Attendance</h3>

                    <button
                        type="button"
                        className="att-back-btn"
                        onClick={props.onBack}
                        disabled={loading}
                    >
                        <i className="bx bx-arrow-back me-2"></i>
                        Back to list
                    </button>

                </div>

                <div className="card staffattendance-card">

                    <form onSubmit={handleSubmit} noValidate>

                        {/* ---------- date / set all / search bar ---------- */}
                        <div className="att-bulk-bar">

                            <div className="att-bulk-field">
                                <label htmlFor="bulk_date">Date</label>
                                <div className="att-input-icon">
                                    <i className="bx bx-calendar"></i>
                                    <input
                                        id="bulk_date"
                                        type="date"
                                        className={"form-control" + (dateError ? " is-invalid" : "")}
                                        max={todayKey()}
                                        value={date}
                                        onChange={(e) => setDate(e.target.value)}
                                    />
                                </div>
                            </div>

                            <div className="att-bulk-setall">
                                {["Present", "Absent"].map((st) => (
                                    <label key={st} className="att-radio">
                                        <input
                                            type="radio"
                                            name="bulk_set_all"
                                            checked={allSelected(st)}
                                            onChange={() => setAll(st)}
                                            disabled={!!dateError}
                                        />
                                        <span>Set all {st.toLowerCase()}</span>
                                    </label>
                                ))}
                            </div>

                            <div className="att-bulk-field att-bulk-search">
                                <label htmlFor="bulk_search">Search</label>
                                <div className="att-input-icon">
                                    <i className="bx bx-search"></i>
                                    <input
                                        id="bulk_search"
                                        type="text"
                                        autoComplete="off"
                                        placeholder="Search staff"
                                        className="form-control"
                                        value={search}
                                        onChange={(e) => setSearch(e.target.value)}
                                    />
                                </div>
                            </div>

                        </div>

                        {dateError && (
                            <div className="att-bulk-alert">
                                <i className="bx bx-error-circle"></i>
                                {holiday && holiday.Holiday_name
                                    ? `${dateError} (${holiday.Holiday_name})`
                                    : dateError}
                            </div>
                        )}

                        {/* ---------- staff table ---------- */}
                        <div className="att-bulk-scroll">

                            <table className="att-bulk-table">

                                <thead>
                                    <tr>
                                        <th>Staff ID</th>
                                        <th>Staff Name</th>
                                        <th>Status</th>
                                        <th>Check In</th>
                                        <th>Check Out</th>
                                    </tr>
                                </thead>

                                <tbody>

                                    {visibleStaff.length === 0 && (
                                        <tr>
                                            <td colSpan={5} className="att-bulk-empty">
                                                No staff found.
                                            </td>
                                        </tr>
                                    )}

                                    {visibleStaff.map((s) => {

                                        const id = s.Staff_id;
                                        const r = rowOf(id);
                                        const marked = markedMap[id];
                                        const off = !!marked || !!dateError;

                                        return (
                                            <tr key={id} className={rowErrors[id] ? "has-error" : ""}>

                                                <td>{staffCode(s)}</td>
                                                <td>{s.Staff_name}</td>

                                                <td>
                                                    {marked ? (
                                                        <span className="att-bulk-marked">
                                                            <i className={`bx ${(STATUS_ICONS[marked] || {}).icon} ${(STATUS_ICONS[marked] || {}).cls}`}></i>
                                                            Already marked: {marked}
                                                        </span>
                                                    ) : (
                                                        <>
                                                            <div className="att-bulk-status" role="radiogroup">
                                                                {STATUS_OPTIONS.map((st) => (
                                                                    <label key={st} className="att-radio">
                                                                        <input
                                                                            type="radio"
                                                                            name={`status_${id}`}
                                                                            value={st}
                                                                            checked={r.Attendance_status === st}
                                                                            onChange={() => setStatus(id, st)}
                                                                            disabled={off}
                                                                        />
                                                                        <i className={`bx ${STATUS_ICONS[st].icon} ${STATUS_ICONS[st].cls}`}></i>
                                                                        <span>{st}</span>
                                                                    </label>
                                                                ))}
                                                            </div>

                                                            {rowErrors[id] && (
                                                                <div className="att-bulk-error">{rowErrors[id]}</div>
                                                            )}
                                                        </>
                                                    )}
                                                </td>

                                                <td>
                                                    <input
                                                        type="time"
                                                        className="form-control att-bulk-time"
                                                        value={marked ? ((markedRec[id] && markedRec[id].Attendance_in_time) || "") : r.Attendance_in_time}
                                                        disabled={off || r.Attendance_status === "Absent" || r.Attendance_status === "Week Off"}
                                                        onChange={(e) => {
                                                            const t = e.target.value;
                                                            // check-in typed -> Present (Permission keeps its own status)
                                                            const keep = r.Attendance_status === "Permission";
                                                            updateRow(id, {
                                                                Attendance_in_time: t,
                                                                ...(t && !keep ? { Attendance_status: "Present" } : {}),
                                                                ...(!t ? { Attendance_out_time: "" } : {})
                                                            });
                                                        }}
                                                    />
                                                </td>

                                                <td>
                                                    <input
                                                        type="time"
                                                        className="form-control att-bulk-time"
                                                        value={marked ? savedOut(id) : r.Attendance_out_time}
                                                        disabled={
                                                            !!dateError ||
                                                            (marked ? !canCheckout(id) : !r.Attendance_in_time)
                                                        }
                                                        onChange={(e) =>
                                                            updateRow(id, {
                                                                Attendance_out_time: e.target.value,
                                                                ...(marked ? { __outEdited: true } : {})
                                                            })
                                                        }
                                                    />
                                                </td>

                                            </tr>
                                        );
                                    })}

                                </tbody>

                            </table>

                        </div>

                        {/* ---------- footer ---------- */}
                        <div className="att-bulk-footer">

                            <span className="att-bulk-count">
                                {pickedCount} of {staffList.length} staff checked in (others are saved as Absent). Saved staff can still get a check out time.
                            </span>

                            <button
                                type="submit"
                                className="btn btn-primary att-bulk-save"
                                disabled={loading || !!dateError}
                            >
                                {loading ? (
                                    <>
                                        <span
                                            className="spinner-border spinner-border-sm me-2"
                                            role="status"
                                            aria-hidden="true"
                                        ></span>
                                        Saving...
                                    </>
                                ) : (
                                    "Save Attendance"
                                )}
                            </button>

                        </div>

                    </form>

                </div>

            </div>

            {popup && (

                <div className="att-popup-backdrop" onClick={() => setPopup("")}>

                    <div
                        className="att-popup"
                        role="alertdialog"
                        aria-modal="true"
                        onClick={(e) => e.stopPropagation()}
                    >
                        <div className="att-popup-icon">⚠</div>

                        <h5>{popup}</h5>

                        <button
                            type="button"
                            className="btn btn-primary mt-3"
                            onClick={() => setPopup("")}
                            autoFocus
                        >
                            OK
                        </button>
                    </div>

                </div>

            )}

        </div>
    );
};


// =====================================================
// ADD ATTENDANCE PAGE
// props: toggle, onSuccess, staffList, existingAttendance, holidays,
//        prefill (optional: { Staff_id, Attendance_date })
// =====================================================

const Addstaffattendance = (props) => {

    const { insert, update } = useContext(AuthContext);

    // check out time -> update only that saved attendance record
    const handleUpdateRow = async (values) => {

        const response = await update(
            { Attendance_id: values.Attendance_id, Attendance_out_time: values.Attendance_out_time },
            "update_staffattendance_datail",
            "/staffattendance"
        );

        const bad =
            !response ||
            response.error ||
            response.ok === false ||
            (typeof response.status === "number" && response.status >= 400);

        if (bad) {
            const err = new Error("Check out update failed");
            err.responseData = response && (response.data || response);
            throw err;
        }

    };

    // one staff row -> same insert call as the old single form
    const handleSaveRow = async (values) => {

        const payload = buildAttendancePayload(values);

        const response = await insert(
            payload,
            "staffattendance_create"
        );

        // AuthContext.insert may resolve (not throw) on an HTTP error; treat that as a failure
        const bad =
            !response ||
            response.error ||
            response.ok === false ||
            (typeof response.status === "number" && response.status >= 400);

        if (bad) {
            const err = new Error("Attendance save failed");
            err.responseData = response && (response.data || response);
            throw err;
        }

    };

    return (

        <BulkAttendanceForm
            staffList={props.staffList}
            existingAttendance={props.existingAttendance}
            holidays={props.holidays}
            prefill={props.prefill}
            onSaveRow={handleSaveRow}
            onUpdateRow={handleUpdateRow}
            onSuccess={props.onSuccess}
            onRefresh={props.onRefresh}
            onBack={props.toggle}
        />

    );
};

export default Addstaffattendance;