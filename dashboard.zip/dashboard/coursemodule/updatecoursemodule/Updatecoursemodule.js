import React, { useContext, useState } from "react";
import AuthContext from "../../../services/AuthContext";
import "../addcoursemodule/addcoursemodule.css";
import KeywordInput, { CATEGORY_KEYWORDS } from "../KeywordInput";

// Default duration pre-filled for every new syllabus topic row
const DEFAULT_DURATION = "2 Hr";

// Normalizes whatever shape CourseModule_Syllabus currently has into
// the { topic, duration } row format used by the table below.
// Handles: an array of rows already (new format), a plain string
// (old single-textarea format), or nothing yet.
const normalizeTopics = (syllabus) => {

    if (Array.isArray(syllabus) && syllabus.length > 0) {

        return syllabus.map((row) => ({
            topic: row.topic || "",
            duration: row.duration || ""
        }));

    }

    if (typeof syllabus === "string" && syllabus.trim() !== "") {

        return [{ topic: syllabus, duration: "" }];

    }

    return [{ topic: "", duration: DEFAULT_DURATION }];

};


// Normalizes a module name for duplicate checks: ignores case and ALL spaces,
// so "Cascading Style Sheet" and "cascadingstylesheet" are the same name.
const normalizeName = (name) =>
    String(name || "").replace(/\s+/g, "").toLowerCase();

const Updatecoursemodule = (props) => {

    const { update } = useContext(AuthContext);

    const [status, setStatus] = useState(
        props.data.CourseModule_Status || "Active"
    );

    const [topics, setTopics] = useState(
        normalizeTopics(props.data.CourseModule_Syllabus)
    );

    const [description, setDescription] = useState(
        props.data.CourseModule_category || ""
    );

    const [error, setError] = useState("");
    const [nameError, setNameError] = useState("");
    const [categoryError, setCategoryError] = useState("");

    // Validates the module name as the user types (skips this module itself)
    const validateName = (value) => {

        const name = value.trim();

        if (name === "") return "Module name is required.";

        if (name.length < 2)
            return "Module name must contain at least 2 characters.";

        const duplicate = (props.existingModules || []).some(
            (m) =>
                Number(m.CourseModule_id) !== Number(props.data.CourseModule_id) &&
                normalizeName(m.CourseModule_name) === normalizeName(name)
        );

        if (duplicate)
            return `Module name "${name}" already exists. Please use a different name.`;

        return "";
    };
    const [loading, setLoading] = useState(false);


    const addTopicRow = () => {

        setTopics((prev) => [
            ...prev,
            { topic: "", duration: DEFAULT_DURATION }
        ]);

    };


    const insertTopicRowAfter = (index) => {

        setTopics((prev) => {

            const updated = [...prev];

            updated.splice(index + 1, 0, { topic: "", duration: DEFAULT_DURATION });

            return updated;

        });

    };


    const removeTopicRow = (index) => {

        setTopics((prev) =>
            prev.filter((_, i) => i !== index)
        );

    };


    const updateTopicField = (index, field, fieldValue) => {

        setTopics((prev) =>
            prev.map((row, i) =>
                i === index
                    ? { ...row, [field]: fieldValue }
                    : row
            )
        );

    };


    // =====================================================
    // SMART PASTE: pasting multi-line text into a Topic cell
    // instantly splits it into one row per line, starting at
    // the row that was pasted into.
    // =====================================================

    const handleTopicPaste = (e, index) => {

        const pastedText = e.clipboardData.getData("text");

        const lines = pastedText
            .split(/\r?\n/)
            .map((line) => line.trim())
            .filter((line) => line !== "");

        if (lines.length <= 1) {

            return;

        }

        e.preventDefault();

        setTopics((prev) => {

            const updated = [...prev];

            updated[index] = {
                ...updated[index],
                topic: lines[0]
            };

            const newRows = lines.slice(1).map((line) => ({
                topic: line,
                duration: DEFAULT_DURATION
            }));

            updated.splice(index + 1, 0, ...newRows);

            return updated;

        });

    };


    const handleSubmit = async (e) => {

        e.preventDefault();

        setError("");

        const moduleName = e.target.CourseModule_name.value.trim();

        const nameMsg = validateName(moduleName);

        if (nameMsg) {

            setNameError(nameMsg);

            return;
        }

        setNameError("");

        const cleanedTopics = topics
            .map((row) => ({
                topic: row.topic.trim(),
                duration: row.duration.trim()
            }))
            .filter((row) => row.topic !== "");

        const typedDescription =
            description.trim();

        const matchedKeyword = CATEGORY_KEYWORDS.find(
            (k) => k.toLowerCase() === typedDescription.toLowerCase()
        );

        // Must be one of the keywords (an older saved value is still allowed unchanged)
        if (
            !matchedKeyword &&
            typedDescription !== props.data.CourseModule_category
        ) {

            setCategoryError(
                "Please choose a category: Frontend, Database, Backend or Others."
            );

            return;
        }

        setCategoryError("");

        const courseModuleData = {
            CourseModule_id: Number(e.target.CourseModule_id.value),
            CourseModule_name: moduleName,
            CourseModule_category: matchedKeyword || typedDescription,
            CourseModule_Syllabus: cleanedTopics,
            CourseModule_Status: status
        };

        if (cleanedTopics.length === 0) {

            setError("Please add at least one syllabus topic.");

            return;

        }

        try {

            setLoading(true);

            await update(
                courseModuleData,
                "update_coursemodule_datail",
                "/coursemodule"
            );

            // Refresh the list and go back to it
            if (props.onSuccess) {

                await props.onSuccess();

            } else {

                props.toggle();

            }

        } catch (error) {

            console.error(
                "Update operation failed:",
                error
            );

            const responseData = error.responseData;

            if (responseData && responseData.CourseModule_name) {

                setError(
                    Array.isArray(responseData.CourseModule_name)
                        ? responseData.CourseModule_name[0]
                        : responseData.CourseModule_name
                );

            } else if (responseData && responseData.detail) {

                setError(responseData.detail);

            } else {

                setError(
                    "Course Module could not be updated. Please try again."
                );

            }

        } finally {

            setLoading(false);

        }
    };

    return (

        <div className="coursemodule-page centered-form-page container-xxl flex-grow-1 container-p-y">

            <div className="centered-form-wrap">


                {/* ================================================= */}
                {/* HEADER */}
                {/* ================================================= */}

                <div className="page-header">

                    <div>

                        <h3 className="page-title">
                            Edit Course Module
                        </h3>

                        <p className="page-subtitle">
                            Update the course module details
                        </p>

                    </div>


                    <button
                        type="button"
                        className="btn btn-outline-secondary add-btn"
                        onClick={props.toggle}
                    >

                        <i className="bx bx-arrow-back me-2"></i>

                        Back to List

                    </button>

                </div>


                {/* ================================================= */}
                {/* FORM CARD */}
                {/* ================================================= */}

                <div className="card coursemodule-card">

                    <div className="card-body">

                        {/* ERROR */}
                        {error && (
                            <div
                                className="alert alert-danger"
                                role="alert"
                            >
                                <strong>Error!</strong>{" "}
                                {error}
                            </div>
                        )}

                        <form onSubmit={handleSubmit}>

                            {/* Hidden Course Module ID */}

                            <input
                                type="hidden"
                                name="CourseModule_id"
                                defaultValue={props.data.CourseModule_id}
                            />


                            {/* MODULE NAME + DESCRIPTION — one row, two columns */}
                            <div className="row">

                                <div className="col-md-6 mb-3">

                                    <label
                                        htmlFor="CourseModule_name"
                                        className="form-label"
                                    >
                                        Module Name
                                    </label>

                                    <input
                                        type="text"
                                        defaultValue={props.data.CourseModule_name}
                                        className={
                                            "form-control" +
                                            (nameError ? " is-invalid" : "")
                                        }
                                        name="CourseModule_name"
                                        id="CourseModule_name"
                                        placeholder="e.g. HTML"
                                        maxLength="255"
                                        onChange={(e) =>
                                            setNameError(validateName(e.target.value))
                                        }
                                    />

                                    {nameError && (
                                        <div className="invalid-feedback d-block">
                                            {nameError}
                                        </div>
                                    )}

                                </div>


                                <div className="col-md-6 mb-3">

                                    <label
                                        htmlFor="CourseModule_category_text"
                                        className="form-label"
                                    >
                                        Category
                                    </label>

                                    <KeywordInput
                                        value={description}
                                        onChange={(v) => {
                                            setDescription(v);
                                            setCategoryError("");
                                        }}
                                    />

                                    {categoryError && (
                                        <div className="invalid-feedback d-block">
                                            {categoryError}
                                        </div>
                                    )}

                                </div>

                            </div>


                            {/* SYLLABUS / DURATION — dynamic topic rows */}

                            <div className="mb-3">

                                <label className="form-label">
                                    Syllabus
                                </label>

                                <div className="syllabus-table-wrap">

                                    <table className="syllabus-table">

                                        <thead>

                                            <tr>

                                                <th className="syllabus-no-col">
                                                    No
                                                </th>

                                                <th>
                                                    Topic
                                                </th>

                                                <th className="syllabus-duration-col">
                                                    Duration
                                                </th>

                                                <th className="syllabus-action-col"></th>

                                            </tr>

                                        </thead>


                                        <tbody>

                                            {topics.map((row, index) => (

                                                <tr key={index}>

                                                    <td>
                                                        {index + 1}
                                                    </td>

                                                    <td>

                                                        <input
                                                            type="text"
                                                            className="form-control form-control-sm"
                                                            placeholder="e.g. Introduction to HTML"
                                                        maxLength="255"
                                                            value={row.topic}
                                                            onChange={(e) =>
                                                                updateTopicField(
                                                                    index,
                                                                    "topic",
                                                                    e.target.value
                                                                )
                                                            }
                                                            onPaste={(e) =>
                                                                handleTopicPaste(
                                                                    e,
                                                                    index
                                                                )
                                                            }
                                                        />

                                                    </td>

                                                    <td>

                                                        <input
                                                            type="text"
                                                            className="form-control form-control-sm"
                                                            placeholder="e.g. 1 Hr"
                                                        maxLength="50"
                                                            value={row.duration}
                                                            onChange={(e) =>
                                                                updateTopicField(
                                                                    index,
                                                                    "duration",
                                                                    e.target.value
                                                                )
                                                            }
                                                        />

                                                    </td>

                                                    <td>

                                                    <div className="syllabus-actions">

                                                        <button
                                                            type="button"
                                                            className="syllabus-icon-btn syllabus-icon-add"
                                                            onClick={() =>
                                                                insertTopicRowAfter(index)
                                                            }
                                                            title="Add topic below"
                                                        >
                                                            <i className="bx bx-plus"></i>
                                                        </button>

                                                        <button
                                                            type="button"
                                                            className="syllabus-icon-btn syllabus-icon-remove"
                                                            onClick={() =>
                                                                removeTopicRow(index)
                                                            }
                                                            disabled={topics.length === 1}
                                                            title="Remove topic"
                                                        >
                                                            <i className="bx bx-minus"></i>
                                                        </button>

                                                    </div>

                                                </td>

                                                </tr>

                                            ))}

                                        </tbody>

                                    </table>

                                    <button
                                        type="button"
                                        className="syllabus-add-btn"
                                        onClick={addTopicRow}
                                    >
                                        + Add Syllabus Topic
                                    </button>

                                </div>

                            </div>


                            


                            {/* =========================
                                FOOTER
                            ========================== */}

                            <div className="d-flex justify-content-end gap-2 mt-4">

                                <button
                                    type="button"
                                    className="btn btn-outline-secondary"
                                    onClick={props.toggle}
                                    disabled={loading}
                                >
                                    Cancel
                                </button>

                                <button
                                    type="submit"
                                    className="btn btn-success"
                                    disabled={loading}
                                >
                                    {loading ? (
                                        <>
                                            <span
                                                className="spinner-border spinner-border-sm me-2"
                                                role="status"
                                                aria-hidden="true"
                                            ></span>

                                            Updating...
                                        </>
                                    ) : (
                                        "Update Course Module"
                                    )}
                                </button>

                            </div>

                        </form>

                    </div>

                </div>

            </div>

        </div>
    );
};

export default Updatecoursemodule;
