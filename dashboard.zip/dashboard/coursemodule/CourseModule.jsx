import React, {
    useState,
    useContext,
    useEffect,
    useCallback
} from "react";

import "./CourseModule.css";

import Addcoursemodule from "./addcoursemodule/Addcoursemodule";
import Updatecoursemodule from "./updatecoursemodule/Updatecoursemodule";
import Deletecoursemodule from "./deletecoursemodule/Deletecoursemodule";

import AuthContext from "../../services/AuthContext";


// Rows-per-page choices for the footer selector
const ROWS_PER_PAGE_OPTIONS = [1, 2, 3, 4, 5, 10, 25, 50];

// Target (in hours) the duration bar is measured against.
// Change this one number to use a different target.
const TARGET_HOURS = 25;


function CourseModule() {

    const [addPopupVisible, setAddPopupVisible] = useState(false);
    const [updatePageVisible, setUpdatePageVisible] = useState(false);
    const [deletePageVisible, setDeletePageVisible] = useState(false);

    // Module whose syllabus is open in the View modal (null = closed)
    const [syllabusModule, setSyllabusModule] = useState(null);

    const [currentPage, setCurrentPage] = useState(1);

    const [searchTerm, setSearchTerm] = useState("");

    // Status filter tab: "all" | "Active" | "Inactive"
    const [statusFilter, setStatusFilter] = useState("all");

    // Rows per page (picked in the footer)
    const [itemsPerPage, setItemsPerPage] = useState(10);

    // Column sorting: sortKey = "name" | "duration" | null (no sort)
    const [sortKey, setSortKey] = useState(null);
    const [sortDir, setSortDir] = useState("asc");

    // Ids of the rows ticked with the checkboxes
    const [selectedIds, setSelectedIds] = useState([]);

    const { getData, update } = useContext(AuthContext);

    const [courseModules, setCourseModules] = useState([]);

    const [value, setValue] = useState(null);


    // =====================================================
    // FETCH COURSE MODULES
    // =====================================================

    const fetchCourseModules = useCallback(async () => {

        try {

            const data = await getData(
                "fetch_coursemodule_datail"
            );

            console.log(
                "Course Modules fetched:",
                data
            );

            if (Array.isArray(data)) {

                setCourseModules(data);

            } else {

                setCourseModules([]);

            }

        } catch (err) {

            console.error(
                "Failed to fetch course modules:",
                err
            );

        }

    }, [getData]);


    // =====================================================
    // INITIAL LOAD
    // =====================================================

    useEffect(() => {

        fetchCourseModules();

    }, [fetchCourseModules]);


    // =====================================================
    // ADD PAGE (no longer a popup — swaps the table view
    // for the Addcoursemodule page directly, centered)
    // =====================================================

    const showAddPage = () => {

        setAddPopupVisible(true);

    };

    const hideAddPage = () => {

        setAddPopupVisible(false);

    };


    // =====================================================
    // EDIT PAGE (no longer a popup — swaps the list for the
    // Updatecoursemodule page directly, like the Add page)
    // =====================================================

    const hideUpdatePage = () => {

        setUpdatePageVisible(false);

    };


    const handleCourseModuleUpdated = async () => {

        // Fetch latest data from Django, then back to the list
        // (stay on the same pagination page)
        await fetchCourseModules();

        setUpdatePageVisible(false);

    };


    // =====================================================
    // DELETE PAGE (no longer a popup — confirmation page)
    // =====================================================

    const hideDeletePage = () => {

        setDeletePageVisible(false);

    };


    const handleCourseModuleDeleted = async () => {

        await fetchCourseModules();

        setDeletePageVisible(false);

        // The current page may no longer exist after a delete
        setCurrentPage(1);

    };


    // =====================================================
    // AFTER COURSE MODULE CREATED
    // =====================================================

    const handleCourseModuleCreated = async () => {

        console.log(
            "New course module created. Refreshing list..."
        );

        // Fetch latest data from Django
        await fetchCourseModules();

        // Close add page, back to list
        setAddPopupVisible(false);

        // Go back to first page
        setCurrentPage(1);

    };


    // =====================================================
    // PAGINATION
    // =====================================================

    const indexOfLastItem =
        currentPage * itemsPerPage;

    const indexOfFirstItem =
        indexOfLastItem - itemsPerPage;

    // Search by module name (case-insensitive) — matches only from the
    // START of the name, not anywhere inside it
    const filteredCourseModules = courseModules.filter(
        (m) =>
            String(m.CourseModule_name || "")
                .toLowerCase()
                .startsWith(searchTerm.trim().toLowerCase()) &&
            (statusFilter === "all" ||
                (statusFilter === "Active"
                    ? m.CourseModule_Status === "Active"
                    : m.CourseModule_Status !== "Active"))
    );


    const nextPage = () => {

        if (
            indexOfLastItem <
            filteredCourseModules.length
        ) {

            setCurrentPage(
                currentPage + 1
            );

        }

    };


    const prevPage = () => {

        if (currentPage > 1) {

            setCurrentPage(
                currentPage - 1
            );

        }

    };


    // =====================================================
    // UPDATE
    // =====================================================

    const handleUpdate = (courseModule) => {

        setValue(courseModule);

        setUpdatePageVisible(true);

    };


    // =====================================================
    // DELETE
    // =====================================================

    const handleDelete = (courseModule) => {

        setValue(courseModule);

        setDeletePageVisible(true);

    };


    // =====================================================
    // STATUS BUTTON (Active / Deactive — click to switch)
    // =====================================================

    const handleToggleStatus = async (courseModule) => {

        const newStatus =
            courseModule.CourseModule_Status === "Active"
                ? "Deactive"
                : "Active";

        const payload = {
            CourseModule_id: courseModule.CourseModule_id,
            CourseModule_name: courseModule.CourseModule_name,
            CourseModule_category: courseModule.CourseModule_category,
            CourseModule_Syllabus: courseModule.CourseModule_Syllabus,
            CourseModule_Status: newStatus,
        };

        try {

            await update(
                payload,
                "update_coursemodule_datail",
                "/coursemodule"
            );

            await fetchCourseModules();

        } catch (err) {

            console.error(
                "Failed to toggle status:",
                err
            );

        }

    };


    // =====================================================
    // TOTAL DURATION (sum of every syllabus topic's duration)
    // Durations are typed as free text, e.g. "1 Hr", "30 min",
    // "1h 30m", "2.5 hours". A number with no unit is read as
    // hours. Topics whose duration can't be read are skipped.
    // =====================================================

    const getTotalMinutes = (courseModule) => {

        const topics = courseModule.CourseModule_Syllabus;

        if (!Array.isArray(topics)) {

            return 0;

        }

        let totalMinutes = 0;

        topics.forEach((row) => {

            const text = String(row.duration || "").toLowerCase();

            const parts = [
                ...text.matchAll(
                    /(\d+(?:\.\d+)?)\s*(hours?|hrs?|h|minutes?|mins?|m)?/g
                )
            ];

            parts.forEach((match) => {

                const amount = parseFloat(match[1]);

                const unit = match[2] || "h";

                totalMinutes += unit.startsWith("m")
                    ? amount
                    : amount * 60;

            });

        });

        return Math.round(totalMinutes);

    };


    // 150 -> "2 Hrs 30 Mins", 60 -> "1 Hr", 0 -> "-"
    const formatDuration = (totalMinutes) => {

        if (totalMinutes === 0) {

            return "-";

        }

        const hours = Math.floor(totalMinutes / 60);

        const minutes = totalMinutes % 60;

        const hourText = `${hours} ${hours === 1 ? "Hr" : "Hrs"}`;

        const minuteText = `${minutes} ${minutes === 1 ? "Min" : "Mins"}`;

        if (hours > 0 && minutes > 0) {

            return `${hourText} ${minuteText}`;

        }

        return hours > 0 ? hourText : minuteText;

    };


    const getTotalDuration = (courseModule) =>
        formatDuration(getTotalMinutes(courseModule));


    // =====================================================
    // SORTING (Module / Duration column headers)
    // asc -> desc -> back to the original order
    // =====================================================

    const handleSort = (key) => {

        if (sortKey !== key) {

            setSortKey(key);
            setSortDir("asc");

        } else if (sortDir === "asc") {

            setSortDir("desc");

        } else {

            setSortKey(null);
            setSortDir("asc");

        }

        setCurrentPage(1);

    };

    const sortedCourseModules = sortKey
        ? [...filteredCourseModules].sort((a, b) => {

            const result =
                sortKey === "name"
                    ? String(a.CourseModule_name || "").localeCompare(
                        String(b.CourseModule_name || ""),
                        undefined,
                        { sensitivity: "base", numeric: true }
                    )
                    : getTotalMinutes(a) - getTotalMinutes(b);

            return sortDir === "asc" ? result : -result;

        })
        : filteredCourseModules;

    // Only the rows for the current page
    const currentCourseModules = sortedCourseModules.slice(
        indexOfFirstItem,
        indexOfLastItem
    );

    const getSortMark = (key) =>
        sortKey === key ? (sortDir === "asc" ? "↑" : "↓") : "↑↓";


    // A bare number ("1", "2.5") is read as hours everywhere else,
    // so show it that way here too: "1" -> "1 Hr", "2" -> "2 Hrs".
    const formatTopicDuration = (text) => {

        const value = String(text || "").trim();

        if (value === "") {

            return "-";

        }

        if (/^\d+(\.\d+)?$/.test(value)) {

            return `${value} ${parseFloat(value) === 1 ? "Hr" : "Hrs"}`;

        }

        return value;

    };


    // =====================================================
    // SYLLABUS VIEW MODAL
    // =====================================================

    const openSyllabus = (courseModule) => {

        setSyllabusModule(courseModule);

    };


    const closeSyllabus = () => {

        setSyllabusModule(null);

    };


    // Esc closes the modal
    useEffect(() => {

        if (!syllabusModule) {

            return undefined;

        }

        const onKeyDown = (e) => {

            if (e.key === "Escape") {

                setSyllabusModule(null);

            }

        };

        window.addEventListener("keydown", onKeyDown);

        return () => window.removeEventListener("keydown", onKeyDown);

    }, [syllabusModule]);


    // =====================================================
    // SYLLABUS TOPIC COUNT (syllabus is an array of
    // { topic, duration } rows — the table shows how many)
    // =====================================================

    const getSyllabusCount = (courseModule) => {

        const topics = courseModule.CourseModule_Syllabus;

        return Array.isArray(topics) ? topics.length : 0;

    };


    // =====================================================
    // TABLE DISPLAY HELPERS (initials tile, "25 days ago",
    // category colour, duration bar, page numbers)
    // =====================================================

    const hashOf = (text) => {

        let h = 0;

        for (const ch of String(text || "")) {

            h = (h * 31 + ch.charCodeAt(0)) >>> 0;

        }

        return h;

    };

    // "DaTaAnAlytics" -> "Da", "Web Design" -> "WD"
    const getInitials = (name) => {

        const words = String(name || "")
            .trim()
            .split(/\s+/)
            .filter(Boolean);

        if (words.length === 0) {

            return "?";

        }

        if (words.length === 1) {

            return (
                words[0][0].toUpperCase() +
                (words[0][1] || "").toLowerCase()
            );

        }

        return (words[0][0] + words[1][0]).toUpperCase();

    };

    const timeAgo = (value) => {

        if (!value) {

            return "";

        }

        const created = new Date(value);

        if (isNaN(created.getTime())) {

            return "";

        }

        const days = Math.floor(
            (Date.now() - created.getTime()) / 86400000
        );

        if (days <= 0) {

            return "today";

        }

        if (days === 1) {

            return "yesterday";

        }

        if (days < 30) {

            return `${days} days ago`;

        }

        const months = Math.floor(days / 30);

        if (months < 12) {

            return `${months} ${months === 1 ? "month" : "months"} ago`;

        }

        const years = Math.floor(days / 365);

        return `${years} ${years === 1 ? "year" : "years"} ago`;

    };

    const getCategoryClass = (category) => {

        const c = String(category || "").toLowerCase();

        if (c.includes("back")) {

            return "cm-cat-backend";

        }

        if (c.includes("front")) {

            return "cm-cat-frontend";

        }

        if (!c || c.includes("other")) {

            return "cm-cat-others";

        }

        return `cm-cat-${hashOf(c) % 3}`;

    };

    // Duration bar: measured against a fixed target (TARGET_HOURS),
    // so a short module no longer shows a full bar.
    const getDurationPercent = (courseModule) => {

        const minutes = getTotalMinutes(courseModule);

        return minutes > 0
            ? Math.min(
                100,
                Math.max(4, Math.round((minutes / (TARGET_HOURS * 60)) * 100))
            )
            : 0;

    };

    // Page numbers with "…" gaps: 1 … 4 5 6 … 12
    const totalPages = Math.max(
        1,
        Math.ceil(filteredCourseModules.length / itemsPerPage)
    );

    const getPageNumbers = () => {

        const pages = [];

        for (let n = 1; n <= totalPages; n++) {

            if (
                n === 1 ||
                n === totalPages ||
                Math.abs(n - currentPage) <= 1
            ) {

                pages.push(n);

            } else if (pages[pages.length - 1] !== "…") {

                pages.push("…");

            }

        }

        return pages;

    };

    const showingFrom =
        filteredCourseModules.length === 0 ? 0 : indexOfFirstItem + 1;

    const showingTo = Math.min(
        indexOfLastItem,
        filteredCourseModules.length
    );


    // =====================================================
    // STATUS TABS (All / Active / Inactive with counts)
    // =====================================================

    const activeCount = courseModules.filter(
        (m) => m.CourseModule_Status === "Active"
    ).length;

    const statusTabs = [
        { key: "all", label: "All", count: courseModules.length },
        { key: "Active", label: "Active", count: activeCount },
        {
            key: "Inactive",
            label: "Inactive",
            count: courseModules.length - activeCount
        }
    ];


    // =====================================================
    // ROW SELECTION (checkboxes)
    // =====================================================

    const toggleSelect = (id) => {

        setSelectedIds((prev) =>
            prev.includes(id)
                ? prev.filter((x) => x !== id)
                : [...prev, id]
        );

    };

    const pageIds = currentCourseModules.map(
        (m) => m.CourseModule_id
    );

    const allPageSelected =
        pageIds.length > 0 &&
        pageIds.every((id) => selectedIds.includes(id));

    const toggleSelectPage = () => {

        setSelectedIds((prev) =>
            allPageSelected
                ? prev.filter((id) => !pageIds.includes(id))
                : [...new Set([...prev, ...pageIds])]
        );

    };

    const selectedModules = courseModules.filter((m) =>
        selectedIds.includes(m.CourseModule_id)
    );


    // =====================================================
    // EXPORT (CSV — opens in Excel)
    // =====================================================

    const exportCsv = (rows, filename) => {

        const esc = (v) =>
            `"${String(v ?? "").replace(/"/g, '""')}"`;

        const header = [
            "ID",
            "Module Name",
            "Syllabus Topics",
            "Duration",
            "Category",
            "Created Date",
            "Status"
        ];

        const lines = rows.map((m) =>
            [
                m.CourseModule_id,
                m.CourseModule_name,
                getSyllabusCount(m),
                getTotalDuration(m),
                m.CourseModule_category,
                m.Create_date
                    ? new Date(m.Create_date).toLocaleDateString()
                    : "-",
                m.CourseModule_Status
            ]
                .map(esc)
                .join(",")
        );

        const csv =
            "\uFEFF" +
            [header.map(esc).join(","), ...lines].join("\r\n");

        const blob = new Blob([csv], {
            type: "text/csv;charset=utf-8;"
        });

        const url = URL.createObjectURL(blob);

        const link = document.createElement("a");

        link.href = url;
        link.download = filename;

        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);

        URL.revokeObjectURL(url);

    };


    // =====================================================
    // ADD PAGE VIEW
    // =====================================================
    // Swap the whole list out for the Addcoursemodule page —
    // rendered centered within the page, no modal/backdrop.

    if (addPopupVisible) {

        return (

            <Addcoursemodule
                toggle={hideAddPage}
                onSuccess={handleCourseModuleCreated}
                existingModules={courseModules}
            />

        );

    }


    // =====================================================
    // EDIT PAGE VIEW
    // =====================================================

    if (updatePageVisible && value) {

        return (

            <Updatecoursemodule
                toggle={hideUpdatePage}
                onSuccess={handleCourseModuleUpdated}
                data={value}
                existingModules={courseModules}
            />

        );

    }


    // =====================================================
    // DELETE PAGE VIEW
    // =====================================================

    if (deletePageVisible && value) {

        return (

            <Deletecoursemodule
                toggle={hideDeletePage}
                onSuccess={handleCourseModuleDeleted}
                data={value}
            />

        );

    }


    return (

        <div className="coursemodule-page container-xxl flex-grow-1 container-p-y">


            {/* ================================================= */}
            {/* HEADER */}
            {/* ================================================= */}

            <div className="page-header">

                <div>

                    <h3 className="page-title">
                        Course Module Management
                    </h3>

                    <p className="page-subtitle">
                        Manage all available course modules
                    </p>

                </div>


                <button
                    className="btn btn-primary add-btn"
                    onClick={showAddPage}
                >

                    <i className="bx bx-plus me-2"></i>

                    Add Course Module

                </button>

            </div>


            {/* ================================================= */}
            {/* COURSE MODULE TABLE */}
            {/* ================================================= */}

            <div className="card coursemodule-card">

                {/* TOOLBAR: search + status tabs + export */}
                <div className="coursemodule-search-bar">

                    <div className="coursemodule-search-box">

                        <i className="bx bx-search"></i>

                        <input
                            type="text"
                            className="form-control"
                            placeholder="Search by module name"
                            value={searchTerm}
                            onChange={(e) => {
                                setSearchTerm(e.target.value);
                                setCurrentPage(1);
                            }}
                        />

                        {searchTerm && (
                            <button
                                type="button"
                                className="coursemodule-search-clear"
                                onClick={() => {
                                    setSearchTerm("");
                                    setCurrentPage(1);
                                }}
                                aria-label="Clear search"
                            >
                                <i className="bx bx-x"></i>
                            </button>
                        )}

                    </div>

                    <div
                        className="cm-tabs"
                        role="tablist"
                        aria-label="Filter by status"
                    >

                        {statusTabs.map((tab) => (

                            <button
                                key={tab.key}
                                type="button"
                                role="tab"
                                aria-selected={statusFilter === tab.key}
                                className={`cm-tab${
                                    statusFilter === tab.key ? " on" : ""
                                }`}
                                onClick={() => {
                                    setStatusFilter(tab.key);
                                    setCurrentPage(1);
                                }}
                            >

                                {tab.label}

                                <em>{tab.count}</em>

                            </button>

                        ))}

                    </div>

                    <button
                        type="button"
                        className="cm-export-btn"
                        onClick={() =>
                            exportCsv(
                                sortedCourseModules,
                                "course-modules.csv"
                            )
                        }
                        disabled={filteredCourseModules.length === 0}
                    >
                        <i className="bx bx-download"></i>
                        Export
                    </button>

                </div>


                {/* BULK BAR (shows when rows are ticked) */}
                {selectedModules.length > 0 && (

                    <div className="cm-bulk-bar">

                        <span className="cm-bulk-count">
                            {selectedModules.length} selected
                        </span>

                        <div className="cm-bulk-actions">

                            <button
                                type="button"
                                className="cm-bulk-btn"
                                onClick={() =>
                                    exportCsv(
                                        selectedModules,
                                        "course-modules-selected.csv"
                                    )
                                }
                            >
                                Export selected
                            </button>

                            <button
                                type="button"
                                className="cm-bulk-btn ghost"
                                onClick={() => setSelectedIds([])}
                            >
                                Clear
                            </button>

                        </div>

                    </div>

                )}

                <div className="table-responsive">

                    <table className="table modern-table">

                        <thead>

                            <tr>

                                <th className="cm-col-check">
                                    <input
                                        type="checkbox"
                                        className="cm-check"
                                        checked={allPageSelected}
                                        onChange={toggleSelectPage}
                                        disabled={pageIds.length === 0}
                                        aria-label="Select all on this page"
                                    />
                                </th>

                                <th
                                    aria-sort={
                                        sortKey === "name"
                                            ? sortDir === "asc" ? "ascending" : "descending"
                                            : "none"
                                    }
                                >
                                    <button
                                        type="button"
                                        className={`cm-sort${sortKey === "name" ? " on" : ""}`}
                                        onClick={() => handleSort("name")}
                                        title="Sort by module name"
                                    >
                                        Module
                                        <span className="cm-sort-mark">{getSortMark("name")}</span>
                                    </button>
                                </th>

                                <th>Topics</th>

                                <th
                                    aria-sort={
                                        sortKey === "duration"
                                            ? sortDir === "asc" ? "ascending" : "descending"
                                            : "none"
                                    }
                                >
                                    <button
                                        type="button"
                                        className={`cm-sort${sortKey === "duration" ? " on" : ""}`}
                                        onClick={() => handleSort("duration")}
                                        title="Sort by duration"
                                    >
                                        Duration
                                        <span className="cm-sort-mark">{getSortMark("duration")}</span>
                                    </button>
                                </th>

                                <th>Category</th>

                                <th>Status</th>

                                <th className="cm-col-action">Action</th>

                            </tr>

                        </thead>


                        <tbody>

                            {currentCourseModules.length > 0 ? (

                                currentCourseModules.map(
                                    (courseModule) => {

                                        const id = courseModule.CourseModule_id;

                                        const name = courseModule.CourseModule_name;

                                        const topicCount = getSyllabusCount(courseModule);

                                        const durationPercent = getDurationPercent(courseModule);

                                        const age = timeAgo(courseModule.Create_date);

                                        return (

                                            <tr
                                                key={id}
                                                className={
                                                    selectedIds.includes(id)
                                                        ? "is-selected"
                                                        : ""
                                                }
                                            >

                                                <td className="cm-col-check">
                                                    <input
                                                        type="checkbox"
                                                        className="cm-check"
                                                        checked={selectedIds.includes(id)}
                                                        onChange={() => toggleSelect(id)}
                                                        aria-label={`Select ${name}`}
                                                    />
                                                </td>


                                                <td>

                                                    <div className="cm-module-cell">

                                                        <span
                                                            className={`cm-tile cm-tile-${
                                                                hashOf(name) % 5
                                                            }`}
                                                        >
                                                            {getInitials(name)}
                                                        </span>

                                                        <div className="cm-module-text">

                                                            <strong
                                                                className="cm-module-name"
                                                                title={name}
                                                            >
                                                                {name}
                                                            </strong>

                                                            <small
                                                                className="cm-module-sub"
                                                                title={
                                                                    courseModule.Create_date
                                                                        ? new Date(
                                                                              courseModule.Create_date
                                                                          ).toLocaleDateString()
                                                                        : ""
                                                                }
                                                            >
                                                                #{id}
                                                                {age ? ` · ${age}` : ""}
                                                            </small>

                                                        </div>

                                                    </div>

                                                </td>


                                                <td>

                                                    <button
                                                        type="button"
                                                        className="btn-view-syllabus cm-topics-chip"
                                                        onClick={() =>
                                                            openSyllabus(
                                                                courseModule
                                                            )
                                                        }
                                                        title="View syllabus"
                                                    >

                                                        <i className="bx bx-show"></i>

                                                        {topicCount}{" "}
                                                        {topicCount === 1
                                                            ? "topic"
                                                            : "topics"}

                                                    </button>

                                                </td>


                                                <td>

                                                    <div className="cm-duration">

                                                        <span>
                                                            {getTotalDuration(courseModule)}
                                                        </span>

                                                        {durationPercent > 0 && (

                                                            <>
                                                                <div
                                                                    className="cm-bar"
                                                                    role="progressbar"
                                                                    aria-valuemin={0}
                                                                    aria-valuemax={100}
                                                                    aria-valuenow={durationPercent}
                                                                >
                                                                    <i
                                                                        style={{
                                                                            width: `${durationPercent}%`
                                                                        }}
                                                                    ></i>
                                                                </div>

                                                                <small className="cm-target">
                                                                    of {TARGET_HOURS} Hrs target
                                                                </small>
                                                            </>

                                                        )}

                                                    </div>

                                                </td>


                                                <td>

                                                    <span
                                                        className={`cm-cat ${getCategoryClass(
                                                            courseModule.CourseModule_category
                                                        )}`}
                                                    >
                                                        {courseModule.CourseModule_category || "-"}
                                                    </span>

                                                </td>


                                                <td>

                                                    {(() => {

                                                        const isActive =
                                                            courseModule.CourseModule_Status === "Active";

                                                        return (

                                                            <button
                                                                type="button"
                                                                role="switch"
                                                                aria-checked={isActive}
                                                                aria-label={`${name} status`}
                                                                className={`cm-switch ${isActive ? "on" : "off"}`}
                                                                onClick={() =>
                                                                    handleToggleStatus(
                                                                        courseModule
                                                                    )
                                                                }
                                                                title={
                                                                    isActive
                                                                        ? "Click to deactivate"
                                                                        : "Click to activate"
                                                                }
                                                            >

                                                                <span className="cm-switch-track">
                                                                    <span className="cm-switch-knob"></span>
                                                                </span>

                                                                <span className="cm-switch-label">
                                                                    {isActive ? "Active" : "Inactive"}
                                                                </span>

                                                            </button>

                                                        );

                                                    })()}

                                                </td>


                                                <td>

                                                    <div className="cm-actions">

                                                        <button
                                                            type="button"
                                                            className="cm-icon-btn edit"
                                                            onClick={() =>
                                                                handleUpdate(
                                                                    courseModule
                                                                )
                                                            }
                                                            title="Edit"
                                                            aria-label={`Edit ${name}`}
                                                        >
                                                            <i className="bx bx-pencil"></i>
                                                        </button>


                                                        <button
                                                            type="button"
                                                            className="cm-icon-btn delete"
                                                            onClick={() =>
                                                                handleDelete(
                                                                    courseModule
                                                                )
                                                            }
                                                            title="Delete"
                                                            aria-label={`Delete ${name}`}
                                                        >
                                                            <i className="bx bx-trash"></i>
                                                        </button>

                                                    </div>

                                                </td>

                                            </tr>

                                        );

                                    }
                                )

                            ) : (

                                <tr>

                                    <td
                                        colSpan="7"
                                        className="text-center py-4"
                                    >

                                        No course modules found.

                                    </td>

                                </tr>

                            )}

                        </tbody>

                    </table>

                </div>


                {/* ================================================= */}
                {/* PAGINATION */}
                {/* ================================================= */}

                <div className="card-footer bg-white border-0">

                    <div className="cm-footer">

                        <span className="cm-showing">
                            Showing {showingFrom}–{showingTo} of{" "}
                            {filteredCourseModules.length}{" "}
                            {filteredCourseModules.length === 1
                                ? "module"
                                : "modules"}
                        </span>

                        <label className="cm-rows">

                            <span>Rows per page</span>

                            <select
                                className="cm-rows-select"
                                value={itemsPerPage}
                                onChange={(e) => {
                                    setItemsPerPage(Number(e.target.value));
                                    setCurrentPage(1);
                                }}
                            >
                                {ROWS_PER_PAGE_OPTIONS.map((n) => (
                                    <option key={n} value={n}>
                                        {n}
                                    </option>
                                ))}
                            </select>

                        </label>

                        <div className="cm-pager">

                            <button
                                type="button"
                                className="cm-page-btn"
                                onClick={prevPage}
                                disabled={currentPage === 1}
                                aria-label="Previous page"
                            >
                                <i className="bx bx-chevron-left"></i>
                            </button>

                            {getPageNumbers().map((page, index) =>

                                page === "…" ? (

                                    <span
                                        key={`gap-${index}`}
                                        className="cm-page-gap"
                                    >
                                        …
                                    </span>

                                ) : (

                                    <button
                                        key={page}
                                        type="button"
                                        className={`cm-page-btn${
                                            page === currentPage ? " on" : ""
                                        }`}
                                        onClick={() => setCurrentPage(page)}
                                    >
                                        {page}
                                    </button>

                                )

                            )}

                            <button
                                type="button"
                                className="cm-page-btn"
                                onClick={nextPage}
                                disabled={
                                    indexOfLastItem >=
                                    filteredCourseModules.length
                                }
                                aria-label="Next page"
                            >
                                <i className="bx bx-chevron-right"></i>
                            </button>

                        </div>

                    </div>

                </div>

            </div>


            {/* ================================================= */}
            {/* SYLLABUS MODAL */}
            {/* ================================================= */}

            {syllabusModule && (

                <div
                    className="modal fade show syllabus-modal"
                    tabIndex="-1"
                    role="dialog"
                    aria-modal="true"
                    style={{
                        display: "block",
                        backgroundColor: "rgba(67, 89, 113, 0.5)"
                    }}
                    onClick={closeSyllabus}
                >

                    <div
                        className="modal-dialog modal-dialog-centered"
                        role="document"
                        onClick={(e) => e.stopPropagation()}
                    >

                        <div className="modal-content">

                            {/* FLOATING CLOSE (X) BUTTON */}
                            <button
                                type="button"
                                className="syllabus-close-btn"
                                aria-label="Close"
                                onClick={closeSyllabus}
                            >
                                <i className="bx bx-x"></i>
                            </button>


                            {/* TITLE */}
                            <div className="syllabus-title-wrap">

                                <span className="syllabus-title-icon">
                                    <i className="bx bx-book-open"></i>
                                </span>

                                <div>

                                    <h5 className="syllabus-modal-title">
                                        {syllabusModule.CourseModule_name} — Syllabus
                                    </h5>

                                    <p className="syllabus-modal-sub">
                                        Topics covered in this course module
                                    </p>

                                </div>

                            </div>


                            {/* TOPIC TABLE */}
                            <div className="syllabus-modal-body">

                                <table className="syllabus-view-table">

                                    <thead>

                                        <tr>

                                            <th width="80">
                                                <i className="bx bx-hash"></i>
                                                No
                                            </th>

                                            <th>
                                                <i className="bx bx-list-ul"></i>
                                                Topic
                                            </th>

                                            <th width="150">
                                                <i className="bx bx-time-five"></i>
                                                Duration
                                            </th>

                                        </tr>

                                    </thead>

                                    <tbody>

                                        {getSyllabusCount(syllabusModule) > 0 ? (

                                            syllabusModule.CourseModule_Syllabus.map(
                                                (row, index) => (

                                                    <tr
                                                        key={
                                                            row.syllabus_id ||
                                                            index
                                                        }
                                                    >

                                                        <td>

                                                            <span className="syllabus-no-badge">
                                                                {
                                                                    row.sequence_no ||
                                                                    index + 1
                                                                }
                                                            </span>

                                                        </td>

                                                        <td>

                                                            <span className="syllabus-topic">

                                                                <i className="bx bx-bookmark"></i>

                                                                {row.topic}

                                                            </span>

                                                        </td>

                                                        <td>

                                                            <span className="syllabus-duration-pill">

                                                                <i className="bx bx-time-five"></i>

                                                                {
                                                                    formatTopicDuration(
                                                                        row.duration
                                                                    )
                                                                }

                                                            </span>

                                                        </td>

                                                    </tr>

                                                )
                                            )

                                        ) : (

                                            <tr>

                                                <td
                                                    colSpan="3"
                                                    className="syllabus-empty"
                                                >

                                                    <i className="bx bx-folder-open"></i>

                                                    <div>
                                                        No syllabus topics added.
                                                    </div>

                                                </td>

                                            </tr>

                                        )}

                                    </tbody>

                                </table>

                            </div>


                            {/* TOTALS + CLOSE BUTTON */}
                            <div className="syllabus-modal-footer">

                                <div className="syllabus-totals">

                                    <div className="syllabus-stat topics">

                                        <span className="syllabus-stat-icon">
                                            <i className="bx bx-list-check"></i>
                                        </span>

                                        <div>

                                            <span className="syllabus-total-label">
                                                Total Topics
                                            </span>

                                            <span className="syllabus-total-value">
                                                {getSyllabusCount(syllabusModule)}
                                            </span>

                                        </div>

                                    </div>


                                    <div className="syllabus-stat duration">

                                        <span className="syllabus-stat-icon">
                                            <i className="bx bx-timer"></i>
                                        </span>

                                        <div>

                                            <span className="syllabus-total-label">
                                                Total Duration
                                            </span>

                                            <span className="syllabus-total-value">
                                                {getTotalDuration(syllabusModule)}
                                            </span>

                                        </div>

                                    </div>

                                </div>


                                <button
                                    type="button"
                                    className="syllabus-cancel-btn"
                                    onClick={closeSyllabus}
                                >
                                    Close
                                </button>

                            </div>

                        </div>

                    </div>

                </div>

            )}

        </div>

    );

}


export default CourseModule;
