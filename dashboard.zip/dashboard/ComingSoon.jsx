import React from "react";
import { useLocation } from "react-router-dom";
import SidebarData from "../assets/json/sidebar.json";

// Shown for menu pages that are not built yet
function ComingSoon() {
  const { pathname } = useLocation();

  let title = "";

  SidebarData.forEach((item) => {
    if (item.path === pathname) title = item.title;

    (item.subNav || []).forEach((sub) => {
      if (sub.path === pathname) title = sub.title;
    });
  });

  return (
    <div className="content-wrapper">
      <div className="container-xxl flex-grow-1 container-p-y">
        <h4 className="fw-semibold py-3 mb-4">{title || "Page not found"}</h4>

        <div className="card">
          <div className="card-body text-center py-5">
            <i className="bx bx-time-five bx-lg text-primary mb-2"></i>
            <h5 className="mb-1">
              {title ? "This module is coming soon" : "This page does not exist"}
            </h5>
            <p className="text-muted mb-0">
              {title
                ? "It will be available in an upcoming update."
                : "Please choose a page from the menu."}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default ComingSoon;
