import React, {
    useState,
    useContext,
    useEffect,
    useCallback,
    useMemo
} from "react";

import "./Calendar.css";

import { toDateKey } from "./addcalendar/Addcalendar";
import Addholiday from "./addcalendar/Addholiday";
import Updatecalendar from "./updatecalendar/Updatecalendar";
import Deletecalendar from "./deletecalendar/Deletecalendar";

import AuthContext from "../../services/AuthContext";


// =====================================================
// HELPERS
// =====================================================

const MONTHS_SHORT = [
    "Jan", "Feb", "Mar", "Apr", "May", "Jun",
    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
];

const WEEKDAYS = [
    "Sunday", "Monday", "Tuesday", "Wednesday",
    "Thursday", "Friday", "Saturday"
];

const MIN_YEAR = 2000;
const MAX_YEAR = 2100;

// rows per page options (minimum 5)
const PAGE_SIZE_OPTIONS = [5, 10, 20, 50];
const DEFAULT_PAGE_SIZE = 5;

// category buttons next to the year box
// "match" = values saved by Add Holiday ("Celebrity" is the old name, kept so old rows still show)
const CATEGORY_BUTTONS = [
    { label: "All", value: "", match: null },
    { label: "Government", value: "Government", match: ["Government"] },
    { label: "Emergency", value: "Emergency", match: ["Emergency"] },
    { label: "Celebration", value: "Celebration", match: ["Celebration", "Celebrity"] }
];

// icon + class for each category (same icons as the Staff Attendance page)
const CATEGORY_META = {
    Government:  { icon: "bxs-flag-alt", cls: "cat-government" },
    Emergency:   { icon: "bxs-error",    cls: "cat-emergency" },
    Celebration: { icon: "bxs-gift",     cls: "cat-celebration" }
};

// saved value -> category name ("Celebrity" is the old name)
const categoryName = (v) => {
    const t = String(v || "").trim().toLowerCase();
    if (t === "government") return "Government";
    if (t === "emergency") return "Emergency";
    if (t === "celebration" || t === "celebrity") return "Celebration";
    return "";
};

// "2026-01-01" -> "01 Jan 2026"
const formatDate = (key) => {
    const [y, m, d] = key.split("-").map(Number);
    return `${String(d).padStart(2, "0")} ${MONTHS_SHORT[m - 1]} ${y}`;
};

// "2026-01-01" -> "Thursday" (local time, no timezone shift)
const weekdayName = (key) => {
    const [y, m, d] = key.split("-").map(Number);
    return WEEKDAYS[new Date(y, m - 1, d).getDay()];
};


// [1, 2, 3, "...", 10] style list of page buttons
const buildPageList = (current, totalPages) => {

    if (totalPages <= 7) {
        return Array.from({ length: totalPages }, (_, i) => i + 1);
    }

    const pages = new Set([1, totalPages, current - 1, current, current + 1]);

    const list = [...pages]
        .filter((n) => n >= 1 && n <= totalPages)
        .sort((a, b) => a - b);

    const out = [];

    list.forEach((n, i) => {
        if (i > 0 && n - list[i - 1] > 1) out.push("...");
        out.push(n);
    });

    return out;
};


// =====================================================
// HOLIDAY CALENDAR PAGE
// =====================================================

function Calendar() {

    // ---------------- page switching ----------------
    const [addPageVisible, setAddPageVisible] = useState(false);
    const [updatePageVisible, setUpdatePageVisible] = useState(false);
    const [deletePageVisible, setDeletePageVisible] = useState(false);

    const [value, setValue] = useState(null);   // holiday being edited / deleted

    // ---------------- filters / paging ----------------
    const [year, setYear] = useState(new Date().getFullYear());
    const [category, setCategory] = useState("");   // "" = all categories
    const [page, setPage] = useState(1);
    const [pageSize, setPageSize] = useState(DEFAULT_PAGE_SIZE);

    // ---------------- data ----------------
    const { getData } = useContext(AuthContext);

    const [events, setEvents] = useState([]);


    // =====================================================
    // FETCH
    // =====================================================

    const fetchAll = useCallback(async () => {

        try {

            const data = await getData("fetch_calendar_datail");

            setEvents(Array.isArray(data) ? data : []);

        } catch (err) {

            console.error("Failed to fetch calendar data:", err);

        }

    }, [getData]);

    useEffect(() => {

        fetchAll();

    }, [fetchAll]);


    // =====================================================
    // HOLIDAYS OF THE SELECTED YEAR (sorted by date)
    // =====================================================

    const activeCategory =
        CATEGORY_BUTTONS.find((b) => b.value === category) || CATEGORY_BUTTONS[0];

    const holidays = useMemo(() => {

        return events
            .filter((e) =>
                (e.Event_type === "Holiday" || e.Event_type === "Working") &&
                toDateKey(e.Event_date).startsWith(`${year}-`) &&
                (!activeCategory.match || activeCategory.match.includes(e.Holiday_category))
            )
            .sort((a, b) =>
                toDateKey(a.Event_date).localeCompare(toDateKey(b.Event_date))
            );

    }, [events, year, activeCategory]);

    const total = holidays.length;
    const totalPages = Math.max(1, Math.ceil(total / pageSize));

    const start = (page - 1) * pageSize;
    const rows = holidays.slice(start, start + pageSize);

    const from = total === 0 ? 0 : start + 1;
    const to = start + rows.length;

    // keep the page valid when the list shrinks
    useEffect(() => {
        if (page > totalPages) setPage(totalPages);
    }, [page, totalPages]);

    const handleYearSelect = (e) => {
        setYear(Number(e.target.value));
        setPage(1);
    };

    const handlePageSize = (e) => {
        setPageSize(Number(e.target.value));
        setPage(1);
    };

    const handleCategoryClick = (value) => {
        setCategory(value);
        setPage(1);
    };


    // =====================================================
    // ADD / EDIT / DELETE PAGES
    // =====================================================

    const showAddPage = () => setAddPageVisible(true);

    const hideAddPage = () => setAddPageVisible(false);

    const showUpdatePage = (holiday) => {

        setValue(holiday);

        setUpdatePageVisible(true);
    };

    const hideUpdatePage = () => setUpdatePageVisible(false);

    const showDeletePage = (holiday) => {

        setValue(holiday);

        setUpdatePageVisible(false);

        setDeletePageVisible(true);
    };

    const hideDeletePage = () => setDeletePageVisible(false);

    const handleSaved = async () => {

        await fetchAll();

        setAddPageVisible(false);

        setUpdatePageVisible(false);
    };

    const handleDeleted = async () => {

        await fetchAll();

        setDeletePageVisible(false);
    };


    if (updatePageVisible && value) {

        return (
            <Updatecalendar
                toggle={hideUpdatePage}
                onSuccess={handleSaved}
                onDelete={() => showDeletePage(value)}
                data={value}
                existingEvents={events}
            />
        );
    }

    if (deletePageVisible && value) {

        return (
            <Deletecalendar
                toggle={hideDeletePage}
                onSuccess={handleDeleted}
                data={value}
            />
        );
    }


    return (

        <div className="calendar-page container-xxl flex-grow-1 container-p-y">


            {/* ================================================= */}
            {/* HEADER */}
            {/* ================================================= */}

            <div className="page-header">

                <div>

                    <h3 className="page-title">Holiday Calendar</h3>

                    <p className="page-subtitle">
                        Manage holiday dates and reasons
                    </p>

                </div>

                <button
                    type="button"
                    className="btn btn-primary add-btn"
                    onClick={showAddPage}
                >
                    <i className="bx bx-calendar-plus"></i>
                    Add Holiday
                </button>

            </div>


            {/* ================================================= */}
            {/* HOLIDAY CARD */}
            {/* ================================================= */}

            <div className="card calendar-card">

                {/* YEAR FILTER */}
                <div className="cal-toolbar">

                    <div className="filter-field">
                        <i className="bx bx-calendar"></i>
                        <select
                            className="form-select"
                            aria-label="Select Year"
                            value={year}
                            onChange={handleYearSelect}
                        >
                            {Array.from(
                                { length: MAX_YEAR - MIN_YEAR + 1 },
                                (_, i) => MIN_YEAR + i
                            ).map((y) => (
                                <option key={y} value={y}>{y}</option>
                            ))}
                        </select>
                    </div>

                    {/* CATEGORY BUTTONS */}
                    <div className="cat-group" role="group" aria-label="Holiday category">
                        {CATEGORY_BUTTONS.map((b) => (
                            <button
                                key={b.label}
                                type="button"
                                className={"cat-btn" + (category === b.value ? " is-active" : "")}
                                aria-pressed={category === b.value}
                                onClick={() => handleCategoryClick(b.value)}
                            >
                                {CATEGORY_META[b.value] && (
                                    <i className={`bx ${CATEGORY_META[b.value].icon} cat-btn-ic ${CATEGORY_META[b.value].cls}`}></i>
                                )}
                                {b.label}
                            </button>
                        ))}
                    </div>

                </div>


                {/* TABLE */}
                <div className="table-responsive holiday-table-wrap">

                    <table className="table holiday-table">

                        <thead>
                            <tr>
                                <th className="col-sno">S.NO</th>
                                <th>DATE</th>
                                <th>REASON</th>
                                <th>CATEGORY</th>
                                <th className="col-actions">ACTIONS</th>
                            </tr>
                        </thead>

                        <tbody>

                            {rows.length === 0 && (
                                <tr>
                                    <td colSpan={5} className="holiday-empty">
                                        No holidays found for {year}.
                                    </td>
                                </tr>
                            )}

                            {rows.map((h, i) => {

                                const key = toDateKey(h.Event_date);

                                return (

                                    <tr key={h.Event_id}>

                                        <td className="col-sno">{start + i + 1}</td>

                                        <td>
                                            <div className="holiday-date">{formatDate(key)}</div>
                                            <div className="holiday-day">{weekdayName(key)}</div>
                                        </td>

                                        <td>
                                            <span className="holiday-reason">{h.Event_title}</span>
                                        </td>

                                        <td>
                                            {categoryName(h.Holiday_category) ? (
                                                <span className={`holiday-cat ${CATEGORY_META[categoryName(h.Holiday_category)].cls}`}>
                                                    <i className={`bx ${CATEGORY_META[categoryName(h.Holiday_category)].icon}`}></i>
                                                    {categoryName(h.Holiday_category)}
                                                    {h.Event_type === "Working" ? " · Working day" : ""}
                                                </span>
                                            ) : (
                                                "-"
                                            )}
                                        </td>

                                        <td className="col-actions">
                                            <div className="row-actions">
                                                <button
                                                    type="button"
                                                    className="act-btn act-edit"
                                                    title="Edit"
                                                    aria-label={`Edit ${h.Event_title}`}
                                                    onClick={() => showUpdatePage(h)}
                                                >
                                                    <i className="bx bx-edit-alt"></i>
                                                </button>
                                                <button
                                                    type="button"
                                                    className="act-btn act-delete"
                                                    title="Delete"
                                                    aria-label={`Delete ${h.Event_title}`}
                                                    onClick={() => showDeletePage(h)}
                                                >
                                                    <i className="bx bx-trash"></i>
                                                </button>
                                            </div>
                                        </td>

                                    </tr>

                                );
                            })}

                        </tbody>

                    </table>

                </div>


                {/* FOOTER: count + rows per page + paging */}
                <div className="holiday-footer">

                    <div className="footer-left">

                        <span className="table-count">
                            Showing <strong>{from}</strong> - <strong>{to}</strong> of{" "}
                            <strong>{total}</strong> holiday{total === 1 ? "" : "s"}
                        </span>

                        <label className="page-size">
                            Rows per page
                            <select
                                className="form-select"
                                value={pageSize}
                                onChange={handlePageSize}
                            >
                                {PAGE_SIZE_OPTIONS.map((n) => (
                                    <option key={n} value={n}>{n}</option>
                                ))}
                            </select>
                        </label>

                    </div>

                    <div className="holiday-pager">

                        <button
                            type="button"
                            className="pager-btn"
                            disabled={page <= 1}
                            onClick={() => setPage((p) => p - 1)}
                        >
                            Previous
                        </button>

                        {buildPageList(page, totalPages).map((n, i) =>
                            n === "..." ? (
                                <span key={`gap-${i}`} className="pager-gap">…</span>
                            ) : (
                                <button
                                    key={n}
                                    type="button"
                                    className={"pager-num" + (n === page ? " is-active" : "")}
                                    aria-current={n === page ? "page" : undefined}
                                    onClick={() => setPage(n)}
                                >
                                    {n}
                                </button>
                            )
                        )}

                        <button
                            type="button"
                            className="pager-btn is-primary"
                            disabled={page >= totalPages}
                            onClick={() => setPage((p) => p + 1)}
                        >
                            Next
                        </button>

                    </div>

                </div>

            </div>


            


            {/* ================================================= */}
            {/* ADD HOLIDAY POPUP (full-year calendar) */}
            {/* ================================================= */}

            {addPageVisible && (
                <Addholiday
                    toggle={hideAddPage}
                    onSuccess={handleSaved}
                    onRefresh={fetchAll}
                    year={year}
                    existingEvents={events}
                />
            )}

        </div>

    );
}

export default Calendar;
