import React, { useState, useEffect, useContext } from "react";
import AuthContext from "../../../services/AuthContext";
import "./addcalendar.css";

// =====================================================
// SHARED HELPERS (also used by the list / update pages)
// =====================================================

export const EVENT_TYPES = ["Event", "Meeting", "Exam", "Holiday", "Working", "Reminder"];

// icon + colors for every event type (same palette as Staff Attendance)
export const TYPE_META = {
    Event:    { icon: "bxs-calendar-event", color: "#4F46E5", bg: "#E0E7FF", cls: "cal-event" },
    Meeting:  { icon: "bxs-group",          color: "#19B8E6", bg: "#CFFAFE", cls: "cal-meeting" },
    Exam:     { icon: "bxs-book",           color: "#E8456B", bg: "#FFE4E6", cls: "cal-exam" },
    Holiday:  { icon: "bxs-star",           color: "#F9733B", bg: "#FFEDD5", cls: "cal-holiday" },
    Working:  { icon: "bxs-gift",           color: "#D946EF", bg: "#FAE8FF", cls: "cal-working" },
    Reminder: { icon: "bxs-bell",           color: "#F59E0B", bg: "#FEF3C7", cls: "cal-reminder" }
};

const pad = (n) => String(n).padStart(2, "0");

// yyyy-mm-dd (local time, no timezone shift)
export const dateKey = (y, m, d) => `${y}-${pad(m + 1)}-${pad(d)}`;

export const todayKey = () => {
    const t = new Date();
    return dateKey(t.getFullYear(), t.getMonth(), t.getDate());
};

// Django may send "2026-10-05" or "2026-10-05T00:00:00Z"
export const toDateKey = (d) => (d ? String(d).split("T")[0] : "");

// Django may send "09:30:00" -> show "09:30"
export const toTimeShort = (t) => (t ? String(t).slice(0, 5) : "");

export const emptyEvent = () => ({
    Event_title: "",
    Event_type: "Event",
    Event_date: todayKey(),
    Event_end_date: "",
    Event_time: "",
    Event_description: ""
});

// =====================================================
// VALIDATION (one place: used while typing and on submit)
// ctx = { existingEvents, currentId }
// =====================================================

const TITLE_REGEX = /^[A-Za-z0-9][A-Za-z0-9 .,&'()\-/:]*$/;

export const validateField = (name, value, all, ctx = {}) => {

    const v = value === null || value === undefined ? "" : String(value);

    switch (name) {

        case "Event_title": {

            if (!v.trim()) return "Event title is required.";
            if (v.trim().length < 3) return "Event title must be at least 3 characters.";
            if (v.length > 100) return "Event title can be 100 characters at most.";
            if (!TITLE_REGEX.test(v.trim())) {
                return "Use letters, numbers and . , & ' ( ) - / : only.";
            }
            return "";
        }

        case "Event_type":
            return EVENT_TYPES.includes(v) ? "" : "Please select an event type.";

        case "Event_date": {

            if (!v) return "Event date is required.";

            const year = Number(v.split("-")[0]);
            if (year < 2000 || year > 2100) return "Year must be between 2000 and 2100.";

            // same title on the same date is a duplicate
            const title = String(all.Event_title || "").trim().toLowerCase();

            if (title) {
                const dup = (ctx.existingEvents || []).some(
                    (e) =>
                        String(e.Event_id) !== String(ctx.currentId) &&
                        toDateKey(e.Event_date) === v &&
                        String(e.Event_title || "").trim().toLowerCase() === title
                );
                if (dup) return "This event is already added on the selected date.";
            }
            return "";
        }

        case "Event_end_date":

            if (!v) return "";
            if (all.Event_date && v < all.Event_date) {
                return "End date cannot be before the event date.";
            }
            if (Number(v.split("-")[0]) > 2100) return "Year must be 2100 or earlier.";
            return "";

        case "Event_time":
            return "";

        case "Event_description":
            return v.length > 300 ? "Description can be 300 characters at most." : "";

        default:
            return "";
    }
};

// values -> object sent to Django
export const buildEventPayload = (values, extra = {}) => ({
    Event_title: String(values.Event_title || "").trim().replace(/\s+/g, " "),
    Event_type: values.Event_type,
    Event_date: values.Event_date,
    Event_end_date: values.Event_end_date || null,
    Event_time: values.Event_time || null,
    Event_description: String(values.Event_description || "").trim(),
    ...extra
});


// =====================================================
// EVENT FORM (shared by Add and Update)
// props: title, submitLabel, failMessage, initialValues,
//        existingEvents, currentId, onSubmit(values), onBack, onDelete
// =====================================================

export const EventForm = (props) => {

    const [values, setValues] = useState(() => ({
        ...emptyEvent(),
        ...(props.initialValues || {})
    }));

    const [errors, setErrors] = useState({});
    const [loading, setLoading] = useState(false);

    // Error popup (same style as the delete popup)
    const [popup, setPopup] = useState("");

    const ctx = {
        existingEvents: props.existingEvents,
        currentId: props.currentId
    };

    // Re-check date whenever title / date changes (duplicate rule)
    useEffect(() => {

        if (!values.Event_date) return;

        setErrors((prev) => ({
            ...prev,
            Event_date: validateField("Event_date", values.Event_date, values, ctx),
            Event_end_date: validateField("Event_end_date", values.Event_end_date, values, ctx)
        }));

        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [values.Event_title, values.Event_date]);


    const setField = (name, value) => {

        setValues((prev) => ({ ...prev, [name]: value }));

        setErrors((prev) => ({
            ...prev,
            [name]: validateField(name, value, { ...values, [name]: value }, ctx)
        }));
    };

    const handleChange = (name) => (e) => setField(name, e.target.value);

    // title: no leading space, no double spaces
    const handleTitle = (e) => {
        setField("Event_title", e.target.value.replace(/^\s+/, "").replace(/\s{2,}/g, " "));
    };


    const validateAll = () => {

        const found = {};

        Object.keys(emptyEvent()).forEach((name) => {
            const msg = validateField(name, values[name], values, ctx);
            if (msg) found[name] = msg;
        });

        return found;
    };


    const handleSubmit = async (e) => {

        e.preventDefault();

        const found = validateAll();

        if (Object.keys(found).length > 0) {
            setErrors(found);
            setPopup(Object.values(found)[0]);
            return;
        }

        try {

            setLoading(true);

            await props.onSubmit(values);

        } catch (err) {

            console.error("Event save failed:", err);

            const data = err && err.responseData;

            let message = props.failMessage || "Event could not be saved. Please try again.";

            if (data) {

                const firstKey = Object.keys(data).find((k) => k !== "detail");

                if (data.detail) {
                    message = data.detail;
                } else if (firstKey) {
                    message = Array.isArray(data[firstKey]) ? data[firstKey][0] : String(data[firstKey]);
                }
            }

            setPopup(message);

        } finally {

            setLoading(false);
        }
    };


    // ---------------- small field helpers ----------------
    const err = (name) => errors[name];

    const cls = (base, name) => base + (err(name) ? " is-invalid" : "");

    const Label = ({ text, required, htmlFor }) => (
        <label htmlFor={htmlFor} className="cal-field-label">
            {text}
            {required && <span className="req">*</span>}
        </label>
    );

    const FieldError = ({ name }) =>
        err(name) ? <div className="invalid-feedback d-block">{err(name)}</div> : null;


    return (

        <div className="calendar-page centered-form-page container-xxl flex-grow-1 container-p-y">

            <div className="centered-form-wrap">

                {/* ================= PAGE HEADER ================= */}
                <div className="page-header">

                    <h3 className="page-title">
                        {props.title}
                    </h3>

                    <button
                        type="button"
                        className="cal-back-btn"
                        onClick={props.onBack}
                        disabled={loading}
                    >
                        <i className="bx bx-arrow-back me-2"></i>
                        Back to list
                    </button>

                </div>


                <div className="card calendar-card">

                    <div className="card-body">

                        <form onSubmit={handleSubmit} noValidate>

                            <div className="row cal-form-grid">

                                {/* ---------- Title | Date ---------- */}
                                <div className="col-md-6 mb-3">
                                    <Label text="Event Title" required htmlFor="Event_title" />
                                    <div className="cal-input-icon">
                                        <i className="bx bx-text"></i>
                                        <input
                                            id="Event_title"
                                            type="text"
                                            maxLength={100}
                                            autoComplete="off"
                                            placeholder="Enter event title"
                                            className={cls("form-control", "Event_title")}
                                            value={values.Event_title}
                                            onChange={handleTitle}
                                        />
                                    </div>
                                    <FieldError name="Event_title" />
                                </div>

                                <div className="col-md-6 mb-3">
                                    <Label text="Event Date" required htmlFor="Event_date" />
                                    <div className="cal-input-icon">
                                        <i className="bx bx-calendar"></i>
                                        <input
                                            id="Event_date"
                                            type="date"
                                            min="2000-01-01"
                                            max="2100-12-31"
                                            className={cls("form-control", "Event_date")}
                                            value={values.Event_date}
                                            onChange={handleChange("Event_date")}
                                        />
                                    </div>
                                    <FieldError name="Event_date" />
                                </div>


                                {/* ---------- End date | Time ---------- */}
                                <div className="col-md-6 mb-3">
                                    <Label text="End Date (optional)" htmlFor="Event_end_date" />
                                    <div className="cal-input-icon">
                                        <i className="bx bx-calendar-alt"></i>
                                        <input
                                            id="Event_end_date"
                                            type="date"
                                            min={values.Event_date || "2000-01-01"}
                                            max="2100-12-31"
                                            className={cls("form-control", "Event_end_date")}
                                            value={values.Event_end_date}
                                            onChange={handleChange("Event_end_date")}
                                        />
                                    </div>
                                    <FieldError name="Event_end_date" />
                                </div>

                                <div className="col-md-6 mb-3">
                                    <Label text="Time (optional)" htmlFor="Event_time" />
                                    <div className="cal-input-icon">
                                        <i className="bx bx-time-five"></i>
                                        <input
                                            id="Event_time"
                                            type="time"
                                            className={cls("form-control", "Event_time")}
                                            value={values.Event_time}
                                            onChange={handleChange("Event_time")}
                                        />
                                    </div>
                                    <FieldError name="Event_time" />
                                </div>


                                {/* ---------- Type (radio buttons, one row) ---------- */}
                                <div className="col-12 mb-3">
                                    <Label text="Event Type" required />
                                    <div
                                        className={"cal-radio-group" + (err("Event_type") ? " is-invalid" : "")}
                                        role="radiogroup"
                                        aria-label="Event Type"
                                    >
                                        {EVENT_TYPES.map((t) => (
                                            <label key={t} className="cal-radio">
                                                <input
                                                    type="radio"
                                                    name="Event_type"
                                                    value={t}
                                                    checked={values.Event_type === t}
                                                    onChange={handleChange("Event_type")}
                                                />
                                                <i
                                                    className={`bx ${TYPE_META[t].icon}`}
                                                    style={{ color: TYPE_META[t].color }}
                                                ></i>
                                                {t}
                                            </label>
                                        ))}
                                    </div>
                                    <FieldError name="Event_type" />
                                </div>


                                {/* ---------- Description ---------- */}
                                <div className="col-12 mb-3">
                                    <Label text="Description (optional)" htmlFor="Event_description" />
                                    <div className="cal-input-icon is-textarea">
                                        <i className="bx bx-comment-detail"></i>
                                        <textarea
                                            id="Event_description"
                                            rows={3}
                                            maxLength={300}
                                            placeholder="Enter description"
                                            className={cls("form-control", "Event_description")}
                                            value={values.Event_description}
                                            onChange={handleChange("Event_description")}
                                        />
                                    </div>
                                    <FieldError name="Event_description" />
                                </div>

                            </div>


                            {/* ---------- FOOTER ---------- */}
                            <div className="cal-form-footer">

                                <div className="d-flex gap-2">

                                    <button
                                        type="button"
                                        className="btn btn-outline-secondary"
                                        onClick={props.onBack}
                                        disabled={loading}
                                    >
                                        Cancel
                                    </button>

                                    {props.onDelete && (
                                        <button
                                            type="button"
                                            className="btn btn-outline-danger"
                                            onClick={props.onDelete}
                                            disabled={loading}
                                        >
                                            <i className="bx bx-trash me-1"></i>
                                            Delete
                                        </button>
                                    )}

                                </div>

                                <button
                                    type="submit"
                                    className="btn btn-primary"
                                    disabled={loading}
                                >
                                    {loading ? (
                                        <>
                                            <span
                                                className="spinner-border spinner-border-sm me-2"
                                                role="status"
                                                aria-hidden="true"
                                            ></span>
                                            Saving...
                                        </>
                                    ) : (
                                        props.submitLabel
                                    )}
                                </button>

                            </div>

                        </form>

                    </div>

                </div>

            </div>


            {/* ================= ERROR POPUP ================= */}
            {popup && (

                <div className="cal-popup-backdrop" onClick={() => setPopup("")}>

                    <div
                        className="cal-popup"
                        role="alertdialog"
                        aria-modal="true"
                        onClick={(e) => e.stopPropagation()}
                    >

                        <div className="cal-popup-icon">⚠</div>

                        <h5>{popup}</h5>

                        <button
                            type="button"
                            className="btn btn-primary mt-3"
                            onClick={() => setPopup("")}
                            autoFocus
                        >
                            OK
                        </button>

                    </div>

                </div>

            )}

        </div>
    );
};


// =====================================================
// ADD PAGE
// props: toggle, onSuccess, prefill ({ Event_date }), existingEvents
// =====================================================

const Addcalendar = (props) => {

    const { insert } = useContext(AuthContext);

    const initialValues = {
        ...emptyEvent(),
        ...(props.prefill || {})
    };

    const handleSave = async (values) => {

        await insert(
            buildEventPayload(values),
            "calendar_create",
            "/calendar"
        );

        // Refresh the list and go back to it
        if (props.onSuccess) {
            await props.onSuccess();
        } else {
            props.toggle();
        }
    };

    return (

        <EventForm
            title="Add Event"
            submitLabel="Save Event"
            failMessage="Event could not be added. Please try again."
            initialValues={initialValues}
            existingEvents={props.existingEvents}
            onSubmit={handleSave}
            onBack={props.toggle}
        />

    );
};

export default Addcalendar;
