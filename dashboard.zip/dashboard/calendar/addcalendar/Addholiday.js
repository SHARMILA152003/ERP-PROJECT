import React, { useState, useEffect, useContext, useMemo, useRef } from "react";
import AuthContext from "../../../services/AuthContext";
import "./addholiday.css";

import {
    buildEventPayload,
    validateField,
    dateKey,
    todayKey,
    toDateKey
} from "./Addcalendar";

// =====================================================
// ADD HOLIDAY POPUP
// Pick the dates on a full-year calendar, then type the
// reason for each date.
// props: toggle, onSuccess, onRefresh, year, existingEvents
// =====================================================

const MONTHS = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
];

const MONTHS_SHORT = [
    "Jan", "Feb", "Mar", "Apr", "May", "Jun",
    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
];

const DOW = ["S", "M", "T", "W", "T", "F", "S"];

// holiday category (one radio row, applies to every new date)
// Government + Emergency are saved as Holiday, Celebration as a Working day
const HOLIDAY_CATEGORIES = ["Government", "Emergency", "Celebration"];

const CATEGORY_LABEL = {
    Government: "Government",
    Emergency: "Emergency",
    Celebration: "Celebration"
};

const eventTypeFor = (category) => (category === "Celebration" ? "Working" : "Holiday");

// saved value -> category name ("Celebrity" is the old name)
const categoryName = (v) => {
    const t = String(v || "").trim().toLowerCase();
    if (t === "government") return "Government";
    if (t === "emergency") return "Emergency";
    if (t === "celebration" || t === "celebrity") return "Celebration";
    return "";
};

const POP_WIDTH = 230;     // width of the small input box (px)

const MIN_YEAR = 2000;
const MAX_YEAR = 2100;

const isLeap = (y) => (y % 4 === 0 && y % 100 !== 0) || y % 400 === 0;

// letters, numbers and . , & ' ( ) - / : only; no leading / double spaces
const sanitizeReason = (v) =>
    v
        .replace(/[^A-Za-z0-9 .,&'()\-/:]/g, "")
        .replace(/^\s+/, "")
        .replace(/\s{2,}/g, " ");

const prettyDate = (key) => {
    const [y, m, d] = key.split("-").map(Number);
    return `${String(d).padStart(2, "0")} ${MONTHS_SHORT[m - 1]} ${y}`;
};

const Addholiday = (props) => {

    const { insert } = useContext(AuthContext);

    const [year, setYear] = useState(props.year || new Date().getFullYear());

    // { "2026-01-01": { reason: "New Year", category: "Government" } }
    // -> new dates picked by the user. A date keeps the category that was
    // selected when it was clicked, so the radio button can be changed
    // between dates (Government dates first, then Emergency, ...).
    // radio button: pick the category first, then click the dates
    const [category, setCategory] = useState("");

    // popup message: { kind: "alert" | "confirm" | "discard", text }
    const [popup, setPopup] = useState(null);
    const [picked, setPicked] = useState({});

    // small input box next to the clicked date: { key, top, left }
    const [pop, setPop] = useState(null);
    const [draft, setDraft] = useState("");
    const [draftError, setDraftError] = useState("");

    const bodyRef = useRef(null);
    const popRef = useRef(null);
    const [saving, setSaving] = useState(false);
    const [message, setMessage] = useState("");

    const today = todayKey();


    // ---------------- existing holidays (cannot be picked again) ----------------
    const existing = useMemo(() => {

        // date -> category name ("" when the saved record has no category)
        const map = new Map();

        (props.existingEvents || []).forEach((e) => {
            if (e.Event_type === "Holiday" || e.Event_type === "Working") {
                map.set(toDateKey(e.Event_date), categoryName(e.Holiday_category));
            }
        });

        return map;

    }, [props.existingEvents]);


    // ---------------- close with Esc ----------------
    // (the handler always calls the latest closeNow / closePopup)
    const escRef = useRef(null);

    useEffect(() => {

        const onKey = (e) => {
            if (e.key === "Escape" && escRef.current) escRef.current();
        };

        document.addEventListener("keydown", onKey);

        return () => document.removeEventListener("keydown", onKey);
    }, []);


    // ---------------- counts for the chips ----------------
    const stats = useMemo(() => {

        let sundays = 0;

        for (let d = new Date(year, 0, 1); d.getFullYear() === year; d.setDate(d.getDate() + 1)) {
            if (d.getDay() === 0) sundays += 1;
        }

        const fresh = Object.keys(picked).filter((k) => k.startsWith(`${year}-`)).length;

        return { days: isLeap(year) ? 366 : 365, sundays, fresh };

    }, [year, picked]);


    const pickedKeys = Object.keys(picked).sort();


    // ---------------- actions ----------------
    const goYear = (step) => {

        const y = year + step;

        if (y < MIN_YEAR || y > MAX_YEAR) return;

        setYear(y);
    };

    // click a date -> small input box opens next to it
    const openDate = (key, e) => {

        if (existing.has(key) || saving) return;

        // radio button first, then the dates
        if (!category) {
            setPopup({
                kind: "alert",
                text: "Please select a category (Government, Emergency or Celebration) before clicking the dates."
            });
            return;
        }

        setMessage("");

        // place the box under the date (inside the scrolling body)
        const body = bodyRef.current;
        const cell = e.currentTarget.getBoundingClientRect();
        const box = body.getBoundingClientRect();

        const left = Math.max(
            4,
            Math.min(
                cell.left - box.left + cell.width / 2 - POP_WIDTH / 2,
                body.clientWidth - POP_WIDTH - 4
            )
        );

        const top = cell.bottom - box.top + body.scrollTop + 6;

        setDraft(picked[key] ? picked[key].reason : "");
        setDraftError("");
        setPop({
            key,
            top,
            left,
            // an already added date keeps its own category
            category: picked[key] ? picked[key].category : category
        });
    };

    const closePop = () => setPop(null);

    // OK / Enter -> keep this date with its reason
    const commitDate = () => {

        const text = draft.trim();

        const err = validateField("Event_title", text, {}, {});

        if (err) {
            setDraftError(err);
            return;
        }

        setPicked((prev) => ({
            ...prev,
            [pop.key]: { reason: text, category: pop.category }
        }));

        setPop(null);
    };

    // Remove -> take the date out again
    const removeDate = () => {

        setPicked((prev) => {
            const next = { ...prev };
            delete next[pop.key];
            return next;
        });

        setPop(null);
    };

    // when the box opens: focus it and make sure it is visible
    useEffect(() => {

        if (!pop || !popRef.current) return;

        const input = popRef.current.querySelector("input");

        if (input) input.focus();

        popRef.current.scrollIntoView({ block: "nearest" });

    }, [pop]);

    // click outside the box closes it
    useEffect(() => {

        if (!pop) return;

        const onDown = (e) => {

            if (popRef.current && popRef.current.contains(e.target)) return;

            if (e.target.closest && e.target.closest(".hol-day")) return;

            setPop(null);
        };

        document.addEventListener("mousedown", onDown);

        return () => document.removeEventListener("mousedown", onDown);

    }, [pop]);


    // Save button: check everything, then show the confirm popup
    const handleSave = () => {

        if (!category) {
            setPopup({ kind: "alert", text: "Please select a category (Government, Emergency or Celebration)." });
            return;
        }

        if (pickedKeys.length === 0) {
            setPopup({ kind: "alert", text: "Please click at least one date on the calendar." });
            return;
        }

        setPopup({ kind: "confirm" });
    };

    // Cancel / X / Esc: warn if there is anything not saved yet
    const closeNow = () => {

        if (saving) return;

        if (pickedKeys.length > 0 || category) {
            setPopup({ kind: "discard" });
            return;
        }

        props.toggle();
    };

    const closePopup = () => setPopup(null);

    escRef.current = popup ? closePopup : pop ? closePop : closeNow;

    // Confirm popup -> really save
    const doSave = async () => {

        setPopup(null);

        setSaving(true);
        setMessage("");

        const saved = [];

        try {

            for (const key of pickedKeys) {

                await insert(
                    buildEventPayload(
                        {
                            Event_title: picked[key].reason,
                            Event_type: eventTypeFor(picked[key].category),
                            Event_date: key,
                            Event_end_date: "",
                            Event_time: "",
                            Event_description: ""
                        },
                        { Holiday_category: picked[key].category }
                    ),
                    "calendar_create",
                    "/calendarevent"
                );

                saved.push(key);
            }

            if (props.onSuccess) await props.onSuccess();
            else props.toggle();

        } catch (err) {

            console.error("Failed to add holiday:", err);

            // keep only the dates that were not saved
            setPicked((prev) => {
                const next = { ...prev };
                saved.forEach((k) => delete next[k]);
                return next;
            });

            if (saved.length > 0 && props.onRefresh) await props.onRefresh();

            setMessage(
                saved.length > 0
                    ? `${saved.length} saved, the rest could not be added. Please try again.`
                    : "Holidays could not be added. Please try again."
            );

            setSaving(false);
        }
    };


    // ---------------- one month ----------------
    const renderMonth = (m) => {

        const offset = new Date(year, m, 1).getDay();
        const total = new Date(year, m + 1, 0).getDate();

        const cells = [];

        for (let i = 0; i < offset; i++) {
            cells.push(<span key={`b${i}`} className="hol-day is-blank"></span>);
        }

        for (let d = 1; d <= total; d++) {

            const key = dateKey(year, m, d);
            const sunday = new Date(year, m, d).getDay() === 0;

            const isOld = existing.has(key);
            const isNew = key in picked;

            cells.push(
                <button
                    type="button"
                    key={key}
                    disabled={isOld}
                    title={isOld ? "Already a holiday" : isNew ? `${prettyDate(key)} - ${picked[key].reason} (${picked[key].category})` : prettyDate(key)}
                    className={
                        "hol-day" +
                        (sunday ? " is-sunday" : "") +
                        (key === today ? " is-today" : "") +
                        (isOld ? ` is-holiday${existing.get(key) ? ` cat-${existing.get(key).toLowerCase()}` : ""}` : "") +
                        (isNew ? ` is-new cat-${picked[key].category.toLowerCase()}` : "") +
                        (pop && pop.key === key ? " is-active" : "")
                    }
                    onClick={(e) => openDate(key, e)}
                >
                    {d}
                </button>
            );
        }

        return (

            <div className="hol-month" key={m}>

                <div className="hol-month-name">{MONTHS[m]}</div>

                <div className="hol-grid">

                    {DOW.map((w, i) => (
                        <span key={i} className={"hol-dow" + (i === 0 ? " is-sunday" : "")}>
                            {w}
                        </span>
                    ))}

                    {cells}

                </div>

            </div>
        );
    };


    return (

        <div className="hol-overlay" role="dialog" aria-modal="true" aria-label="Add Holiday">

            <div className="hol-modal">

                {/* ---------- HEADER ---------- */}
                <div className="hol-head">

                    <span className="hol-head-icon">
                        <i className="bx bxs-star"></i>
                    </span>

                    <div className="hol-head-text">
                        <h5>Add Holiday</h5>
                        <p>Pick a category, click a date, then type its reason.</p>
                    </div>

                    <button
                        type="button"
                        className="hol-close"
                        aria-label="Close"
                        disabled={saving}
                        onClick={closeNow}
                    >
                        <i className="bx bx-x"></i>
                    </button>

                </div>


                {/* ---------- BODY ---------- */}
                <div className="hol-body" ref={bodyRef}>

                    <div className="hol-year">

                        <button type="button" onClick={() => goYear(-1)} aria-label="Previous year">
                            <i className="bx bx-chevron-left"></i>
                        </button>

                        <strong>{year}</strong>

                        <button type="button" onClick={() => goYear(1)} aria-label="Next year">
                            <i className="bx bx-chevron-right"></i>
                        </button>

                    </div>

                    <div className="hol-chips">

                        <span className="hol-chip is-days">
                            <i className="bx bx-calendar"></i> {stats.days} days
                        </span>

                        <span className="hol-chip is-sundays">
                            <i className="bx bxs-home"></i> Sundays {stats.sundays}
                        </span>

                        <span className="hol-chip is-new">
                            <i className="bx bx-plus"></i> New {stats.fresh}
                        </span>

                        <div className="hol-cats" role="radiogroup" aria-label="Holiday category">

                            {HOLIDAY_CATEGORIES.map((c) => (
                                <label
                                    key={c}
                                    className={"hol-cat cat-" + c.toLowerCase() + (category === c ? " is-active" : "")}
                                >
                                    <input
                                        type="radio"
                                        name="holiday-category"
                                        value={c}
                                        checked={category === c}
                                        disabled={saving}
                                        onChange={() => setCategory(c)}
                                    />
                                    {CATEGORY_LABEL[c]}
                                </label>
                            ))}

                        </div>

                    </div>

                    <div className="hol-months">
                        {MONTHS.map((_, m) => renderMonth(m))}
                    </div>


                    {/* ---------- SMALL INPUT BOX NEXT TO THE CLICKED DATE ---------- */}
                    {pop && (

                        <div
                            className="hol-pop"
                            ref={popRef}
                            style={{ top: pop.top, left: pop.left, width: POP_WIDTH }}
                        >

                            <div className="hol-pop-head">
                                <strong>{prettyDate(pop.key)}</strong>
                                <span className={`hol-pop-cat cat-${pop.category.toLowerCase()}`}>
                                    {pop.category}
                                </span>
                                <button type="button" aria-label="Close" onClick={closePop}>
                                    <i className="bx bx-x"></i>
                                </button>
                            </div>

                            <input
                                type="text"
                                className={"form-control" + (draftError ? " is-invalid" : "")}
                                placeholder="Reason (e.g. New Year)"
                                maxLength={100}
                                autoComplete="off"
                                value={draft}
                                onChange={(e) => {
                                    setDraft(sanitizeReason(e.target.value));
                                    setDraftError("");
                                }}
                                onKeyDown={(e) => {
                                    if (e.key === "Enter") {
                                        e.preventDefault();
                                        commitDate();
                                    }
                                }}
                            />

                            {draftError && <small className="hol-error">{draftError}</small>}

                            <div className="hol-pop-actions">

                                {pop.key in picked && (
                                    <button type="button" className="hol-pop-remove" onClick={removeDate}>
                                        Remove
                                    </button>
                                )}

                                <button type="button" className="hol-pop-ok" onClick={commitDate}>
                                    OK
                                </button>

                            </div>

                        </div>
                    )}

                </div>


                {/* ---------- FOOTER ---------- */}
                <div className="hol-foot">

                    <span className="hol-message">{message}</span>

                    <button
                        type="button"
                        className="hol-btn is-ghost"
                        disabled={saving}
                        onClick={closeNow}
                    >
                        Cancel
                    </button>

                    <button
                        type="button"
                        className="hol-btn is-primary"
                        disabled={saving}
                        onClick={handleSave}
                    >
                        {saving
                            ? "Saving..."
                            : `Save Holiday${pickedKeys.length > 1 ? "s" : ""}${pickedKeys.length ? ` (${pickedKeys.length})` : ""}`}
                    </button>

                </div>

            </div>


            {/* ---------- POPUP MESSAGES ---------- */}
            {popup && (

                <div className="hol-popup-overlay">

                    <div className="hol-popup" role="alertdialog" aria-modal="true">

                        {popup.kind === "alert" && (
                            <>
                                <span className="hol-popup-icon is-warn"><i className="bx bx-error"></i></span>
                                <h6>Alert</h6>
                                <p>{popup.text}</p>
                                <div className="hol-popup-actions">
                                    <button type="button" className="hol-btn is-primary" onClick={closePopup}>
                                        OK
                                    </button>
                                </div>
                            </>
                        )}

                        {popup.kind === "discard" && (
                            <>
                                <span className="hol-popup-icon is-warn"><i className="bx bx-error"></i></span>
                                <h6>Not saved</h6>
                                <p>
                                    Your holidays are not saved yet. If you close now,
                                    the selected dates will be lost.
                                </p>
                                <div className="hol-popup-actions">
                                    <button type="button" className="hol-btn is-ghost" onClick={closePopup}>
                                        Keep Editing
                                    </button>
                                    <button type="button" className="hol-btn is-danger" onClick={props.toggle}>
                                        Close Without Saving
                                    </button>
                                </div>
                            </>
                        )}

                        {popup.kind === "confirm" && (
                            <>
                                <span className="hol-popup-icon is-ok"><i className="bx bxs-star"></i></span>
                                <h6>Save these holidays?</h6>

                                <div className="hol-popup-info">
                                    <div><b>Dates ({pickedKeys.length}):</b></div>
                                    <div className="hol-popup-list">
                                        {pickedKeys.map((k) => (
                                            <div key={k}>
                                                <span>{prettyDate(k)}</span>
                                                <em>{picked[k].reason}</em>
                                                <b className={`hol-popup-cat cat-${picked[k].category.toLowerCase()}`}>
                                                    {picked[k].category}
                                                </b>
                                            </div>
                                        ))}
                                    </div>
                                </div>

                                <div className="hol-popup-actions">
                                    <button type="button" className="hol-btn is-ghost" onClick={closePopup}>
                                        Back
                                    </button>
                                    <button type="button" className="hol-btn is-primary" onClick={doSave}>
                                        Save
                                    </button>
                                </div>
                            </>
                        )}

                    </div>

                </div>
            )}

        </div>
    );
};

export default Addholiday;
