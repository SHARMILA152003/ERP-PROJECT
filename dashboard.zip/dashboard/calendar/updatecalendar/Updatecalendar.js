import React, { useContext, useState } from "react";
import AuthContext from "../../../services/AuthContext";
import {
    buildEventPayload,
    validateField,
    toDateKey,
    toTimeShort
} from "../addcalendar/Addcalendar";
import "../addcalendar/addcalendar.css";

// Edit page for a holiday: Date, Reason, Category only.

const CATEGORIES = [
    { value: "Government",  icon: "bxs-flag-alt", color: "#2563EB" },
    { value: "Emergency",   icon: "bxs-error",    color: "#DC2626" },
    { value: "Celebration", icon: "bxs-gift",     color: "#D946EF" }
];

// Government + Emergency are saved as Holiday, Celebration as a Working day
const eventTypeFor = (category) => (category === "Celebration" ? "Working" : "Holiday");

// saved value -> category name ("Celebrity" is the old name)
const categoryName = (v) => {
    const t = String(v || "").trim().toLowerCase();
    if (t === "government") return "Government";
    if (t === "emergency") return "Emergency";
    if (t === "celebration" || t === "celebrity") return "Celebration";
    return "";
};

const Updatecalendar = (props) => {

    const { update } = useContext(AuthContext);

    const record = props.data || {};

    const [values, setValues] = useState({
        Event_title: record.Event_title || "",
        Event_date: toDateKey(record.Event_date),
        Holiday_category: categoryName(record.Holiday_category)
    });

    const [errors, setErrors] = useState({});
    const [loading, setLoading] = useState(false);
    const [popup, setPopup] = useState("");

    const ctx = {
        existingEvents: props.existingEvents,
        currentId: record.Event_id
    };

    const validateCategory = (v) => (v ? "" : "Please select a category.");

    const validate = (name, value, all) =>
        name === "Holiday_category"
            ? validateCategory(value)
            : validateField(name, value, all, ctx);

    const setField = (name, value) => {

        const next = { ...values, [name]: value };

        setValues(next);

        setErrors((prev) => ({
            ...prev,
            [name]: validate(name, value, next),
            // title / date together decide the duplicate rule
            ...(name === "Event_title"
                ? { Event_date: validateField("Event_date", next.Event_date, next, ctx) }
                : {}),
            ...(name === "Event_date"
                ? { Event_title: validateField("Event_title", next.Event_title, next, ctx) }
                : {})
        }));
    };

    const handleSubmit = async (e) => {

        e.preventDefault();

        const found = {};

        ["Event_title", "Event_date", "Holiday_category"].forEach((name) => {
            const msg = validate(name, values[name], values);
            if (msg) found[name] = msg;
        });

        if (Object.keys(found).length > 0) {
            setErrors(found);
            setPopup(Object.values(found)[0]);
            return;
        }

        try {

            setLoading(true);

            // end date / time / description are kept as they were
            const payload = buildEventPayload(
                {
                    Event_title: values.Event_title,
                    Event_type: eventTypeFor(values.Holiday_category),
                    Event_date: values.Event_date,
                    Event_end_date: toDateKey(record.Event_end_date),
                    Event_time: toTimeShort(record.Event_time),
                    Event_description: record.Event_description || ""
                },
                {
                    Event_id: record.Event_id,
                    Holiday_category: values.Holiday_category
                }
            );

            await update(payload, "update_calendar_datail", "/calendar");

            if (props.onSuccess) {
                await props.onSuccess();
            } else {
                props.toggle();
            }

        } catch (err) {

            console.error("Holiday update failed:", err);

            const data = err && err.responseData;

            let message = "Holiday could not be updated. Please try again.";

            if (data) {
                const firstKey = Object.keys(data).find((k) => k !== "detail");
                if (data.detail) {
                    message = data.detail;
                } else if (firstKey) {
                    message = Array.isArray(data[firstKey]) ? data[firstKey][0] : String(data[firstKey]);
                }
            }

            setPopup(message);

        } finally {

            setLoading(false);
        }
    };

    const err = (name) => errors[name];
    const cls = (name) => "form-control" + (err(name) ? " is-invalid" : "");

    return (

        <div className="calendar-page centered-form-page container-xxl flex-grow-1 container-p-y">

            <div className="centered-form-wrap">

                <div className="page-header">

                    <h3 className="page-title">Edit Holiday</h3>

                    <button
                        type="button"
                        className="cal-back-btn"
                        onClick={props.toggle}
                        disabled={loading}
                    >
                        <i className="bx bx-arrow-back me-2"></i>
                        Back to list
                    </button>

                </div>

                <div className="card calendar-card">

                    <div className="card-body">

                        <form onSubmit={handleSubmit} noValidate>

                            <div className="row cal-form-grid">

                                {/* ---------- Date ---------- */}
                                <div className="col-md-6 mb-3">
                                    <label htmlFor="Event_date" className="cal-field-label">
                                        Date<span className="req">*</span>
                                    </label>
                                    <div className="cal-input-icon">
                                        <i className="bx bx-calendar"></i>
                                        <input
                                            id="Event_date"
                                            type="date"
                                            min="2000-01-01"
                                            max="2100-12-31"
                                            className={cls("Event_date")}
                                            value={values.Event_date}
                                            onChange={(e) => setField("Event_date", e.target.value)}
                                        />
                                    </div>
                                    {err("Event_date") && (
                                        <div className="invalid-feedback d-block">{err("Event_date")}</div>
                                    )}
                                </div>

                                {/* ---------- Reason ---------- */}
                                <div className="col-md-6 mb-3">
                                    <label htmlFor="Event_title" className="cal-field-label">
                                        Reason<span className="req">*</span>
                                    </label>
                                    <div className="cal-input-icon">
                                        <i className="bx bx-text"></i>
                                        <input
                                            id="Event_title"
                                            type="text"
                                            maxLength={100}
                                            autoComplete="off"
                                            placeholder="Enter reason"
                                            className={cls("Event_title")}
                                            value={values.Event_title}
                                            onChange={(e) =>
                                                setField(
                                                    "Event_title",
                                                    e.target.value.replace(/^\s+/, "").replace(/\s{2,}/g, " ")
                                                )
                                            }
                                        />
                                    </div>
                                    {err("Event_title") && (
                                        <div className="invalid-feedback d-block">{err("Event_title")}</div>
                                    )}
                                </div>

                                {/* ---------- Category ---------- */}
                                <div className="col-12 mb-3">
                                    <label className="cal-field-label">
                                        Category<span className="req">*</span>
                                    </label>
                                    <div
                                        className={"cal-radio-group" + (err("Holiday_category") ? " is-invalid" : "")}
                                        role="radiogroup"
                                        aria-label="Category"
                                    >
                                        {CATEGORIES.map((c) => (
                                            <label key={c.value} className="cal-radio">
                                                <input
                                                    type="radio"
                                                    name="Holiday_category"
                                                    value={c.value}
                                                    checked={values.Holiday_category === c.value}
                                                    onChange={() => setField("Holiday_category", c.value)}
                                                />
                                                <i className={`bx ${c.icon}`} style={{ color: c.color }}></i>
                                                {c.value}
                                            </label>
                                        ))}
                                    </div>
                                    {err("Holiday_category") && (
                                        <div className="invalid-feedback d-block">{err("Holiday_category")}</div>
                                    )}
                                </div>

                            </div>

                            {/* ---------- FOOTER ---------- */}
                            <div className="cal-form-footer">

                                <div className="d-flex gap-2">

                                    <button
                                        type="button"
                                        className="btn btn-outline-secondary"
                                        onClick={props.toggle}
                                        disabled={loading}
                                    >
                                        Cancel
                                    </button>

                                    {props.onDelete && (
                                        <button
                                            type="button"
                                            className="btn btn-outline-danger"
                                            onClick={props.onDelete}
                                            disabled={loading}
                                        >
                                            <i className="bx bx-trash me-1"></i>
                                            Delete
                                        </button>
                                    )}

                                </div>

                                <button type="submit" className="btn btn-primary" disabled={loading}>
                                    {loading ? (
                                        <>
                                            <span
                                                className="spinner-border spinner-border-sm me-2"
                                                role="status"
                                                aria-hidden="true"
                                            ></span>
                                            Saving...
                                        </>
                                    ) : (
                                        "Update Holiday"
                                    )}
                                </button>

                            </div>

                        </form>

                    </div>

                </div>

            </div>

            {/* ================= ERROR POPUP ================= */}
            {popup && (

                <div className="cal-popup-backdrop" onClick={() => setPopup("")}>

                    <div
                        className="cal-popup"
                        role="alertdialog"
                        aria-modal="true"
                        onClick={(e) => e.stopPropagation()}
                    >

                        <div className="cal-popup-icon">⚠</div>

                        <h5>{popup}</h5>

                        <button
                            type="button"
                            className="btn btn-primary mt-3"
                            onClick={() => setPopup("")}
                            autoFocus
                        >
                            OK
                        </button>

                    </div>

                </div>

            )}

        </div>
    );
};

export default Updatecalendar;
