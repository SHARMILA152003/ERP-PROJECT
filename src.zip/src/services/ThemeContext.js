import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react";

/* =====================================================================
   Theme (light / dark / system)

   - "mode"     what the user picked:   "light" | "dark" | "system"
   - "resolved" what is actually shown: "light" | "dark"
                ("system" follows the operating-system setting live)

   The choice is saved in localStorage and applied to <html> as
       data-theme="dark" | "light"      (all dark CSS is scoped to this)
       class="dark-style"               (Sneat's own dark hook)
   public/index.html applies the saved theme before React starts, so the page
   never flashes white when you reload in dark mode.
   ===================================================================== */

export const THEME_STORAGE_KEY = "igt-theme";
export const THEME_MODES = ["light", "dark", "system"];

/* What new visitors get. Change to "system" to follow the OS by default. */
const DEFAULT_MODE = "light";

const ThemeContext = createContext({
  mode: DEFAULT_MODE,
  resolved: "light",
  setMode: () => {},
});

const darkQuery = () =>
  typeof window !== "undefined" && window.matchMedia
    ? window.matchMedia("(prefers-color-scheme: dark)")
    : null;

const readStoredMode = () => {
  try {
    const saved = localStorage.getItem(THEME_STORAGE_KEY);
    return THEME_MODES.includes(saved) ? saved : DEFAULT_MODE;
  } catch (e) {
    return DEFAULT_MODE; // storage blocked (private mode etc.)
  }
};

export function applyTheme(resolved) {
  const root = document.documentElement;
  root.setAttribute("data-theme", resolved);
  root.classList.toggle("dark-style", resolved === "dark");
}

export const ThemeProvider = ({ children }) => {
  const [mode, setModeState] = useState(readStoredMode);
  const [systemDark, setSystemDark] = useState(() => !!darkQuery()?.matches);

  // follow the operating system while mode === "system"
  useEffect(() => {
    const mq = darkQuery();
    if (!mq) return undefined;
    const onChange = (e) => setSystemDark(e.matches);
    if (mq.addEventListener) mq.addEventListener("change", onChange);
    else mq.addListener(onChange); // older Safari
    return () => {
      if (mq.removeEventListener) mq.removeEventListener("change", onChange);
      else mq.removeListener(onChange);
    };
  }, []);

  // keep several open tabs in sync
  useEffect(() => {
    const onStorage = (e) => {
      if (e.key === THEME_STORAGE_KEY) setModeState(readStoredMode());
    };
    window.addEventListener("storage", onStorage);
    return () => window.removeEventListener("storage", onStorage);
  }, []);

  const resolved = mode === "system" ? (systemDark ? "dark" : "light") : mode;

  useEffect(() => {
    applyTheme(resolved);
  }, [resolved]);

  const setMode = useCallback((next) => {
    if (!THEME_MODES.includes(next)) return;
    setModeState(next);
    try {
      localStorage.setItem(THEME_STORAGE_KEY, next);
    } catch (e) {
      /* storage blocked: the choice still applies for this session */
    }
  }, []);

  const value = useMemo(() => ({ mode, resolved, setMode }), [mode, resolved, setMode]);

  return <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>;
};

export const useTheme = () => useContext(ThemeContext);

export default ThemeContext;
